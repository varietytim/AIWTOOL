welcome to /tool.
we provide some script and CCCI UT framework here.

----------------------------------------------SCRIPT-----------------------------------------------------------------------
1. setup.sh 
Please use this script for initial setup of MTK driver. Please make sure the .ko files are in current directory firstly.
You can also load the kernel modules manully according to the same order of script.

2. log_level_adjust.sh 
Please use this script to adjust log level. We provide some examples here:
#for debug(all) log level.
./log_level_adjust.sh 7 1 
#for NOTICE/NORMAL log level. 
./log_level_adjust.sh 3 3
ERROR log will always be printfed.

3. grab_log.sh
Please use this script to grab mtk driver log after testing. 
We recommend that the operating system to be UNBUNTU18.04.1 LTS + Linux Kernel version 4.15.0-29-generic to fit for this script.

4. clear_log.sh
Please use this script to clear log if we want to test without disturbing of the previous logs. 
We recommend that the operating system to be UNBUNTU18.04.1 LTS + Linux Kernel version 4.15.0-29-generic to fit for this script.

5. unload.sh
Please use this script to unload mtk driver modules.
