#!/bin/sh

#this is MTK driver log level adjustment script. MAKE SURE to use it after MTK kernel module installed.

#error check
#param number check
if 
	[ $# -ne 2 ]
then
	echo "Error : input extra parameters number should be 2. Please refer to readme for further infomation."
	exit 1
fi
#pcie input check
if 
	[ $1 -gt 7 ] || [ $1 -lt 0 ]
then
	echo "Error : pcie input $1 (1st input) should between 0 to 7, recommend 3(greater than error log) or 7(all debug log)"
	exit 1
fi
#ccci input check
if 
	[ $2 -ne 1 ] && [ $2 -ne 3 ]
then
	echo "Error : ccci input $2 (2nd input) should be 1(for full log) or 3(for critical log)"
	exit 1
fi

#start to configure
echo "start to configure pcie and ccci log level"
echo "pcie.loglevel $1" > /sys/pcie/mtkpcie
echo $2 > /sys/kernel/ccci/debug
echo "configure pcie and ccci log level done"
exit 0