#!/bin/sh

echo "start to clear log"
cat /dev/null > /var/log/kern.log
cat /dev/null > /var/log/syslog

rm -rf /var/log/kern.log.*
rm -rf /var/log/syslog.*
echo "clear log done"