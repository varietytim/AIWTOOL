#!/bin/sh

string=$(lsmod|grep "mtk_pcie_wwan_*")
rmmod ${string%% *}
