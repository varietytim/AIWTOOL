#!/bin/sh

if [ ! -d "./driver_log" ];then
	echo "newly create ./driver_log dir."
    mkdir ./driver_log
else
	echo "delete previous dir's files."
	rm -rf ./driver_log/*
fi

if [ -f "./driver_log.tar.bz2" ];then
	echo "delete previous driver_log.tar.bz2."
	rm ./driver_log.tar.bz2
fi

sync

echo "start to get log."
cat /proc/ccci_dump > ./driver_log/ccci_dump
cp -f /var/log/kern.log* ./driver_log/
cp -f /var/log/syslog* ./driver_log/

tar jcf driver_log.tar.bz2 ./driver_log/* 

rm -rf ./driver_log/*

echo "get log done."