#!/bin/sh

# install pcie driver and enable all pcie logs
insmod mtk_pcie_wwan_*.ko dynamic_log_level=6 nic_interface_num=21
# set max log level
echo 7 > /proc/sys/kernel/printk

# set system max network buffer
sysctl -w net.core.rmem_max=16777216
sysctl -w net.core.wmem_max=16777216

cat /sys/kernel/mtk_wwan_*_pcie/build_time
cat /sys/kernel/mtk_wwan_*_pcie/label
