

cat pcie_drv/label.h | awk -F '"' '{print $2}'
