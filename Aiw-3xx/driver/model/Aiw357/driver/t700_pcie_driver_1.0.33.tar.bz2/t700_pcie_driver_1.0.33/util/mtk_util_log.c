// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/kernel.h>       /* printk() */
#include "mtk_util_log.h"

unsigned int mtk_log_level = MTK_LOG_EMERG;  /*default*/

void init_log_level(void)
{
	if ((dynamic_log_level < 0) || (dynamic_log_level > 7)) {
		MTK_ERR_LOG("logging",
			"log level %d not expected(should from 0 to 7), keep default log level 6.\n",
			dynamic_log_level);
		dynamic_log_level = MTK_LOG_INFO;
	}

	mtk_log_level = dynamic_log_level;
}

