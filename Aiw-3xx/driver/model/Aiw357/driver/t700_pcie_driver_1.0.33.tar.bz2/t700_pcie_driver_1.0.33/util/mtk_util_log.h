/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_UTIL_LOG_H__
#define __MTK_UTIL_LOG_H__


/***********host driver dump log level (control log print)***************/
enum {
	MTK_LOG_EMERG = 0,
	MTK_LOG_ALERT,
	MTK_LOG_CRIT,
	MTK_LOG_ERR,
	MTK_LOG_WARN,
	MTK_LOG_NOTICE,
	MTK_LOG_INFO,
	MTK_LOG_DEBUG,
};
extern unsigned int mtk_log_level;
extern unsigned int dynamic_log_level;

#define MTK_LOG_TAG		"[MTK_PCIE_WWAN]"
/***********host driver dump log API******************************/
#define MTK_EMERG_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_EMERG) { \
		pr_emerg(MTK_LOG_TAG "[%s][%s][%d]:"fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_ALERT_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_ALERT) { \
		pr_alert(MTK_LOG_TAG "[%s][%s][%d]:"fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_CRIT_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_CRIT) { \
		pr_crit(MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_ERR_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_ERR) { \
		pr_err(MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_WARN_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_WARN) { \
		pr_warn(MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_NOTICE_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_NOTICE) { \
		pr_notice(MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_INFO_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_INFO) { \
		pr_info(MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_INFO_LIMITED_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_INFO) { \
		printk_ratelimited(KERN_INFO MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_DEBUG_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_DEBUG) { \
		printk(KERN_DEBUG MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)

#define MTK_DEBUG_LIMITED_LOG(tag, fmt, args...) \
do { \
	if (mtk_log_level >= MTK_LOG_DEBUG) { \
		printk_ratelimited(KERN_DEBUG MTK_LOG_TAG "[%s][%s][%d]:" fmt,\
			tag, __func__, __LINE__, ##args);\
	} \
} while (0)


/********init mtk host driver log level**********/

void init_log_level(void);

#endif //__MTK_UTIL_LOG_H__
