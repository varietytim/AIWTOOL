/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef MTK_PCIE_DRV_TEST_H
#define MTK_PCIE_DRV_TEST_H

int mtk_pcie_test_attr_init(struct mtk_pci_dev *mtk_dev);


#endif
