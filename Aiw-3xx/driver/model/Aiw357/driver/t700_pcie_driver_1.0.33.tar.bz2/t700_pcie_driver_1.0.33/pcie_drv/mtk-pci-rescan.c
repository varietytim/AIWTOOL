// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/init.h>
#include <linux/irq.h>
#include <linux/log2.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/fs.h>           /* everything... */
#include <linux/types.h>        /* size_t */
#include <linux/delay.h>
#include "mtk-pcie-dbg.h"
#include "mtk-pci.h"
#include "mtk-pci-rescan.h"
struct remove_rescan_context g_mtk_rescan_context;


/*reference to bus rescan function*/
void mtk_pci_dev_rescan(void)
{
	struct pci_bus *b = NULL;

	pci_lock_rescan_remove();
	while ((b = pci_find_next_bus(b)) != NULL)
		pci_rescan_bus(b);

	pci_unlock_rescan_remove();
}

void mtk_rescan_done(void)
{
	unsigned long flags;
	spin_lock_irqsave(&g_mtk_rescan_context.dev_lock, flags);
	if (g_mtk_rescan_context.rescan_done == 0) {
		MTK_INFO_LOG(TAG, "this is a rescan probe.\n");
		g_mtk_rescan_context.rescan_done = 1;
	} else {
		MTK_INFO_LOG(TAG, "this is a init probe.\n");
	}
	spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
}
void mtk_remove_rescan(struct work_struct *work)
{
	struct pci_dev *pdev;
	unsigned long flags;
	int retry;

	spin_lock_irqsave(&g_mtk_rescan_context.dev_lock, flags);
	g_mtk_rescan_context.rescan_done = 0;
	pdev = g_mtk_rescan_context.dev;
	spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
	if (pdev) {
		/*bus provided remove function*/
		pci_stop_and_remove_bus_device_locked(pdev);
		MTK_INFO_LOG(TAG, "start mtk remove and rescan flow.\n");
	}
	for (retry = 35; retry > 0; retry--) {
		msleep(DELAY_RESCAN_MTIME);
		mtk_pci_dev_rescan();
		spin_lock_irqsave(&g_mtk_rescan_context.dev_lock, flags);
		if (1 == g_mtk_rescan_context.rescan_done) {
			spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
			break;
		}
		spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
	}
	MTK_INFO_LOG(TAG, "rescan try times left %d.\n",retry);
}

int mtk_queue_rescan_work(struct pci_dev *dev)
{
	unsigned long flags = 0;

	MTK_INFO_LOG(TAG, "start queue_mtk_rescan_work.\n");
	spin_lock_irqsave(&g_mtk_rescan_context.dev_lock, flags);
	if (g_mtk_rescan_context.rescan_done == 0) {
		MTK_ERR_LOG(TAG,
			"mtk rescan failed because last rescan undone.\n");
		goto fail_unlock;
	}
	g_mtk_rescan_context.dev = dev;
	MTK_DEBUG_LOG(TAG, "get lock and start to queue.\n");
	spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
	queue_work(g_mtk_rescan_context.pcie_rescan_wq,
		&g_mtk_rescan_context.service_task);
	return 0;
fail_unlock:
	spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
	return -1;
}
EXPORT_SYMBOL(mtk_queue_rescan_work);

int mtk_rescan_init(void)
{
	int retval = 0;

	MTK_DEBUG_LOG(TAG, "start %s.\n", __func__);
	spin_lock_init(&g_mtk_rescan_context.dev_lock);
	g_mtk_rescan_context.rescan_done = 1;
	g_mtk_rescan_context.dev = NULL;
	g_mtk_rescan_context.pcie_rescan_wq =
		create_singlethread_workqueue(MTK_RESCAN_WQ);
	if (!g_mtk_rescan_context.pcie_rescan_wq) {
		MTK_ERR_LOG(TAG,
			"Failed to create workqueue: %s\n",  MTK_RESCAN_WQ);
		retval = 1;
		goto fail;
	}
	INIT_WORK(&g_mtk_rescan_context.service_task, mtk_remove_rescan);

	return retval;
fail:
	destroy_workqueue(g_mtk_rescan_context.pcie_rescan_wq);
	return retval;
}

void mtk_rescan_deinit(void)
{
	unsigned long flags;
	MTK_DEBUG_LOG(TAG, "start %s.\n", __func__);
	spin_lock_irqsave(&g_mtk_rescan_context.dev_lock, flags);
	g_mtk_rescan_context.rescan_done = 1;
	g_mtk_rescan_context.dev = NULL;
	spin_unlock_irqrestore(&g_mtk_rescan_context.dev_lock, flags);
	cancel_work_sync(&g_mtk_rescan_context.service_task);
	destroy_workqueue(g_mtk_rescan_context.pcie_rescan_wq);
}

