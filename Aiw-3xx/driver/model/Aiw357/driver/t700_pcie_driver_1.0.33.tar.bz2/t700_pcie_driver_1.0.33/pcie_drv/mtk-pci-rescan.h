/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef MTK_PCI_RESCAN_H
#define MTK_PCI_RESCAN_H

#define MTK_RESCAN_WQ "mtk_rescan_wq"

#define DELAY_RESCAN_MTIME 1000

struct remove_rescan_context {
	struct work_struct service_task;
	struct workqueue_struct *pcie_rescan_wq;
	spinlock_t dev_lock;
	struct pci_dev *dev;
	int rescan_done;
};

extern struct remove_rescan_context g_mtk_rescan_context;

void mtk_pci_dev_rescan(void);
int mtk_queue_rescan_work(struct pci_dev *dev);
int mtk_rescan_init(void);
void mtk_rescan_deinit(void);
void mtk_rescan_done(void);

#endif
