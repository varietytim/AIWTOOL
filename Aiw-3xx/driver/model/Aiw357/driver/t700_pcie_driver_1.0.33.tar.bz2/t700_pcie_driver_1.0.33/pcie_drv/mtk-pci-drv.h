/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef MTK_PCI_DRV_H
#define MTK_PCI_DRV_H

extern unsigned int mtk_log_level;

struct mtk_pcie_attribute {
	struct attribute attr;
	struct mtk_pci_dev *mtk_dev;
	 ssize_t (*show)(struct mtk_pci_dev *mtk_dev, char *buf);
	 ssize_t (*store)(struct mtk_pci_dev *mtk_dev,
		const char *buf, size_t n);
};

#define MTK_PCIE_ATTR(_mtk_dev, _name, _mode, _show, _store)	\
static struct mtk_pcie_attribute mtk_pcie_attr_##_name = { \
	.attr = {.name = __stringify(_name), .mode = _mode }, \
	.mtk_dev = _mtk_dev,					\
	.show = _show,						\
	.store = _store,					\
}

int call_function(struct mtk_pci_dev *mtk_dev, char *buf);
//extern int cmd_show(char *buf);
int mtk_pcie_attr_init(struct pci_dev *pdev);
void mtk_pcie_attr_remove(struct pci_dev *pdev);


#define MTK_PCIE_FUNCTION_NUMBER   "mtk_pcie"

#endif
