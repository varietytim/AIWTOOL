// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/init.h>
#include <linux/irq.h>
#include <linux/log2.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>

#include <linux/kernel.h>       /* printk() */
#include <linux/fs.h>           /* everything... */
#include <linux/errno.h>        /* error codes */
#include <linux/types.h>        /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>        /* O_ACCMODE */
#include <linux/seq_file.h>
#include <linux/cdev.h>
#include <linux/string.h>
#include <linux/random.h>
#include <linux/scatterlist.h>
#include <asm/unaligned.h>
#include <asm/uaccess.h>
#include <linux/uaccess.h>

#include <linux/interrupt.h>
#include <linux/suspend.h>
#include <linux/reboot.h>
#include <trace/events/power.h>

#include <mtk-pcie-dbg.h>
#include <mtk-pci.h>
#include <mtk-isr.h>
#include "mtk-pci-drv.h"
#include "mtk-pci-rescan.h"
#include "label.h"
#include <linux/kobject.h>
#include "mtk_util_log.h"
#include "ccci_core.h"
#include "mtk-pcie-drv-test.h"



#define BUILD_TIME   __DATE__ " " __TIME__



static int mtk_drv_register;
static struct kobject *pcie_drv_info_kobj;

bool l_res_lock_enable = true;
bool runtime_detect_enable = true;
unsigned short runtime_idle_delay = 20;
u32 suspend_wait_timeout = 1500;
u32 resume_wait_timeout = 1500;
u32 suspend_wait_timeout_sap = 1500;
u32 resume_wait_timeout_sap = 1500;
u32 l_res_polling_period = 100;
u32 l_res_polling_max = 10000;
unsigned int dynamic_log_level = MTK_LOG_INFO;
bool l_res_delayed_unlock = true;
u32 l_res_delayed_unlock_timeout = 100;
bool pm_suspend_enable = true;
bool l1ss_state_logging = false;
bool suspend_direct_complete = true;
bool d3l2_force_dsw = false;
bool rpm_resume_set_powerstate = false;


static ssize_t mtk_pcie_attr_show(struct kobject *kobj,
	struct attribute *attr, char *buf)
{
	ssize_t len = 0;
	struct mtk_pcie_attribute *a = container_of(attr,
		struct mtk_pcie_attribute, attr);

	if (a->show)
		len = a->show(a->mtk_dev, buf);

	return len;
}

static ssize_t mtk_pcie_attr_store(struct kobject *kobj,
	struct attribute *attr, const char *buf, size_t n)
{
	ssize_t len = 0;
	struct mtk_pcie_attribute *a = container_of(attr,
		struct mtk_pcie_attribute, attr);

	if (a->store)
		len = a->store(a->mtk_dev, buf, n);

	return len;
}

static const struct sysfs_ops mtk_pcie_sysfs_ops = {
	.show = mtk_pcie_attr_show,
	.store = mtk_pcie_attr_store
};

static struct kobj_type mtk_pcie_ktype = {
	.sysfs_ops = &mtk_pcie_sysfs_ops,
};

int __weak mtk_ccci_attr_init(struct mtk_pci_dev *mtk_dev)
{
	return 0;
}
void __weak mtk_ccci_attr_deinit(struct mtk_pci_dev *mtk_dev)
{

}

static ssize_t build_time_show(struct kobject *kobj,
	struct kobj_attribute *attr, char *buf)
{
	int cnt;

	MTK_DEBUG_LOG(TAG, "MTK platform %d , build_time %s !\n",
		PCI_DEVICE_ID_TEST, BUILD_TIME);

	sprintf(buf, "%s\n", BUILD_TIME);
	cnt = strlen(BUILD_TIME)+1;
	return cnt;
}


static ssize_t build_time_store(struct kobject *kobj,
	struct kobj_attribute *attr, const char *buf, size_t n)
{
	MTK_DEBUG_LOG(TAG, "dummy function !\n");
	return 0;
}

static ssize_t label_show(struct kobject *kobj,
	struct kobj_attribute *attr, char *buf)
{
	int cnt;

	MTK_DEBUG_LOG(TAG, "MTK platform %d , label %s !\n",
		PCI_DEVICE_ID_TEST, LABEL);
	sprintf(buf, "%s\n", LABEL);
	cnt = strlen(LABEL)+1;
	return cnt;

}

static ssize_t label_store(struct kobject *kobj, struct kobj_attribute *attr,
	        const char *buf, size_t n)
{
	MTK_DEBUG_LOG(TAG, "dummy function !\n");
	return 0;
}

static ssize_t mtk_log_level_show(struct kobject *kobj,
	struct kobj_attribute *attr, char *buf)
{
	int curr = 0;

	curr = snprintf(buf, 16, "log_level = %d\n", mtk_log_level);
	return curr;
}

static ssize_t mtk_log_level_store(struct kobject *kobj,
	struct kobj_attribute *attr, const char *buf, size_t n)
{
	int err;
	unsigned int tmp_val = 0;

	err = kstrtoint(buf, 10, &tmp_val);
	if (err) {
		pr_err("mtk_log_level set : invalid input\n");
		return n;
	}

	if ((tmp_val < MTK_LOG_EMERG) || (tmp_val > MTK_LOG_DEBUG))
		pr_err("mtk_log_level set : invalid input : %d\n", tmp_val);
	else
		mtk_log_level = tmp_val;


	return n;
}

static ssize_t  post_dump_port_show(struct kobject *kobj,
	struct kobj_attribute *attr, char *buf)
{
	int ret = 0;

	ret = snprintf(buf, PAGE_SIZE, "/dev/%s", DEVICE_POST_DUMP_PORT_NAME);

	return ret;
}



static struct kobj_attribute build_time_attr = {
	.attr = {
		.name = __stringify(build_time),
		.mode = 0664,
	},
	.show = build_time_show,
	.store = build_time_store,
};

static struct kobj_attribute label_attr = {
	.attr = {
		.name = __stringify(label),
		.mode = 0664,
	},
	.show = label_show,
	.store = label_store,
};

static struct kobj_attribute mtk_log_level_attr = {
	.attr = {
		.name = __stringify(log_level),
		.mode = 0664,
	},
	.show = mtk_log_level_show,
	.store = mtk_log_level_store,
};

static struct kobj_attribute post_dump_port_attr = {
	.attr = {
		.name = __stringify(post_dump_port),
		.mode = 0444,
	},
	.show = post_dump_port_show,
	.store = NULL,
};


static struct attribute *pcie_driver_cfg[] = {
	&build_time_attr.attr,
	&label_attr.attr,
	&mtk_log_level_attr.attr,
	&post_dump_port_attr.attr,
	NULL,
};

static struct attribute_group pcie_driver_info_group = {
	.attrs = pcie_driver_cfg,
};

int mtk_pcie_driver_info_attr_init(VOID)
{
	char strdocname[64];
	int retval = 0;

	sprintf(strdocname, "mtk_wwan_%x_pcie", PCI_DEVICE_ID_TEST);
	pcie_drv_info_kobj = kobject_create_and_add(strdocname, kernel_kobj);

		/* Create the files associated with this kobject */
	retval = sysfs_create_group(pcie_drv_info_kobj,
		&pcie_driver_info_group);
	if (retval) {
		MTK_ERR_LOG(TAG, " sysfs_create_group fail (%d)\n", retval);
		kobject_put(pcie_drv_info_kobj);
		return -1;
	}

	return 0;
}

int mtk_pcie_attr_init(struct pci_dev *pdev)
{
	int retval = 0;
	struct mtk_pci_dev *mtk_dev;

	MTK_DEBUG_LOG(TAG, "start!\n");
	if(NULL == pdev || NULL==&(pdev->dev.kobj) ||NULL==pdev->dev.driver_data){
		MTK_ERR_LOG(TAG, " mtk_pcie_attr_init input error  (pdev=%p,&(pdev->dev.kobj)=%p,pdev->dev.driver_data=%p)\n",
			pdev,&(pdev->dev.kobj),pdev->dev.driver_data);
		retval = -1;
		goto fail;
	}

	mtk_dev = pci_get_drvdata(pdev);

	MTK_DEBUG_LOG(TAG,
		"kobject_init_and_add start!&(pdev->dev.kobj)=%p\n",
		&(pdev->dev.kobj));
	retval = kobject_init_and_add(&mtk_dev->pcie_kobj,
		&mtk_pcie_ktype,  &(pdev->dev.kobj), MTK_PCIE_FUNCTION_NUMBER);
	if (retval < 0) {
		MTK_ERR_LOG(TAG, " kobject_create_and_add fail (%d)\n", retval);
		goto fail_test_sysfs_create;
	}
	MTK_DEBUG_LOG(TAG, "mtk_pcie_test_attr_init start!\n");
	retval = mtk_pcie_test_attr_init(mtk_dev);
	if(retval){
		MTK_ERR_LOG(TAG, "mtk_pcie_test_attr_init fail (%d)\n", retval);
		goto fail_test_sysfs_create;
	}
	MTK_DEBUG_LOG(TAG, "mtk_ccci_attr_init start!\n");
	retval = mtk_ccci_attr_init(mtk_dev);
	if(retval){
		MTK_ERR_LOG(TAG, " ccci_attr_init fail (%d)\n", retval);
		goto fail_test_sysfs_create;
	}
	MTK_DEBUG_LOG(TAG, "leave!\n");
	return 0;

fail_test_sysfs_create:
	kobject_put(&mtk_dev->pcie_kobj);
fail:
	return retval;
}

void mtk_pcie_attr_remove(struct pci_dev *pdev)
{
	struct mtk_pci_dev *mtk_dev;

	mtk_dev =  pci_get_drvdata(pdev);

	mtk_ccci_attr_deinit(mtk_dev);

	kobject_put(&mtk_dev->pcie_kobj);

}

static int mtk_notify_reboot(struct notifier_block *this,
			unsigned long code, void *x)
{
	printk("driver cleanup  (%s)\n", MTK_PCIE_FUNCTION_NUMBER);

	if (mtk_drv_register) {
		mtk_unregister_pci();
		mtk_drv_register = 0;
	}

	ccci_uninit();

	mtk_rescan_deinit();

	kobject_put(pcie_drv_info_kobj);

	printk("driver cleanup done (%s)\n", MTK_PCIE_FUNCTION_NUMBER);

	return NOTIFY_DONE;
}

static struct notifier_block mtk_notifier = {
	.notifier_call	= mtk_notify_reboot,
	.next		= NULL,
	.priority	= 0,
};

static int __init mtk_drv_init(void)
{
	int retval = 0;

	MTK_DEBUG_LOG(TAG, "Init (%s)\n", MTK_PCIE_FUNCTION_NUMBER);
	mtk_drv_register = 0;

	mtk_pci_dev_rescan();
	init_log_level();

	retval = mtk_rescan_init();
	if (retval) {
		MTK_ERR_LOG(TAG, "Failed to init mtk rescan work\n");
		goto fail_rescan_init;
	}
	retval = ccci_init();
	if (retval) {
		MTK_ERR_LOG(TAG, "Failed to register ccci driver\n");
		goto fail_register_ccci;
	}

	retval = mtk_pcie_driver_info_attr_init();
	if (retval < 0) {
		MTK_ERR_LOG(TAG,
			" mtk_pcie_driver_info_attr_init fail (%d)\n", retval);
		goto fail_register_ccci;
	}

	retval = mtk_register_pci();
	if (retval) {
		MTK_ERR_LOG(TAG, "Failed to register pci driver\n");
		goto fail_register_pci;
	}
	mtk_drv_register = 1;

	register_reboot_notifier(&mtk_notifier);

	return 0;
fail_register_pci:
	mtk_unregister_pci();
fail_register_ccci:
	ccci_uninit();
fail_rescan_init: /*no need to do deinit, because init function handled it*/
//fail_wq_create:
//	destroy_workqueue(pcie_isr_wq);
	return retval;
}
module_init(mtk_drv_init);

static void __exit mtk_drv_cleanup(void)
{
	MTK_DEBUG_LOG(TAG, "driver cleanup  (%s)\n", MTK_PCIE_FUNCTION_NUMBER);

	if (mtk_drv_register) {
		mtk_unregister_pci();
		mtk_drv_register = 0;
	}

	unregister_reboot_notifier(&mtk_notifier);

	ccci_uninit();

	mtk_rescan_deinit();

	kobject_put(pcie_drv_info_kobj);

	MTK_INFO_LOG(TAG, "driver cleanup done (%s)\n", MTK_PCIE_FUNCTION_NUMBER);
}
module_exit(mtk_drv_cleanup);


module_param(runtime_detect_enable, bool, 0644);
MODULE_PARM_DESC(runtime_detect_enable,
	"Whether to enable Runtime PM for this device");

module_param(runtime_idle_delay, ushort, 0644);
MODULE_PARM_DESC(runtime_idle_delay,
	"The waiting time for Runtime Suspend to be executed after Idle detection, the unit is second");

module_param(suspend_wait_timeout, uint, 0644);
MODULE_PARM_DESC(suspend_wait_timeout,
	"The timeout in microsecond to wait for Device execute Suspend flow");

module_param(resume_wait_timeout, uint, 0644);
MODULE_PARM_DESC(resume_wait_timeout,
	"The timeout in microsecond to wait for Device execute Resume flow");

module_param(suspend_wait_timeout_sap, uint, 0644);
MODULE_PARM_DESC(suspend_wait_timeout_sap,
	"The timeout in microsecond to wait for Device sAP execute Suspend flow");

module_param(resume_wait_timeout_sap, uint, 0644);
MODULE_PARM_DESC(resume_wait_timeout_sap,
	"The timeout in millisecond to wait for  Device sAP execute Resume flow");

module_param(l_res_lock_enable, bool, 0644);
MODULE_PARM_DESC(l_res_lock_enable,
	"Whether to enable Runtime PM for this device");

module_param(dynamic_log_level, uint, 0644);
MODULE_PARM_DESC(dynamic_log_level,
	"The value is used to control mtk log level\n");

module_param(l_res_delayed_unlock, bool, 0644);
MODULE_PARM_DESC(l_res_delayed_unlock,
	"Whether to enable delayed unlock");

module_param(l_res_delayed_unlock_timeout, uint, 0644);
MODULE_PARM_DESC(l_res_delayed_unlock_timeout,
	"The timeout in millisecond to wait for Device execute Suspend flow");

module_param(pm_suspend_enable, bool, 0644);
MODULE_PARM_DESC(pm_suspend_enable,
	"Whether to enable PM Suspend, debug purpose only(sometimes we want to disable it)");

module_param(l1ss_state_logging, bool, 0644);
MODULE_PARM_DESC(l1ss_state_logging,
	"Debug purpose only, when we want to check L1.2 sub state change log from MD, \
	we should enable it, then after suspend the L1SS is only disabled for D0");

module_param(suspend_direct_complete, bool, 0644);
MODULE_PARM_DESC(suspend_direct_complete,
	"When the value is true , when Runtime PM is enabled, the S1/S2/S3 suspend will skip and reuse the result of Runtime suspend");

module_param(d3l2_force_dsw, bool, 0644);
MODULE_PARM_DESC(d3l2_force_dsw,
	"For some BIOS, the _DSW is not enabled for device, so we use the RP to directly send _DSW");

module_param(rpm_resume_set_powerstate, bool, 0644);
MODULE_PARM_DESC(rpm_resume_set_powerstate,
	"For some BIOS, the device state got is D0 in rpm resume flow and lead to power resource reference count is not corrected. \
	 This is used to fix the power resource reference count in rpm resume flow");

MODULE_AUTHOR("mediatek corporation");
MODULE_DESCRIPTION("MTK PCIe driver");
MODULE_LICENSE("GPL");
MODULE_INFO(build_time, BUILD_TIME);
MODULE_INFO(label, LABEL);
