// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/string.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/delay.h>
#include <linux/workqueue.h>
#include <linux/semaphore.h>
#include <linux/list.h>
#include <linux/acpi.h>

#include "mhccif_reg.h"
#include "mtk-pcie-dbg.h"
#include "PCIE_MAC_IREG_c_header.h"
#include "mtk-pci.h"
#include "mtk-pci-drv.h"
#include "mtk-pcie.h"
#include "mhccif.h"
#include "mtk-pci-rescan.h"
#include "mtk-pcie-drv-test.h"


#define MAX_ARG_SIZE 10

/* 0: L1.2 resource lock work, 1:entity reg work*/
static unsigned int pm_work;
static struct work_struct pm_ut_task_0;
static struct work_struct pm_ut_task_1;
static struct delayed_work pm_ut_task_l_res;
static struct mtk_pci_dev *pm_ut_mtk_dev;
static struct semaphore pm_ut_task_0_sem;
static struct semaphore pm_ut_task_1_sem;

int t_pcie_reginfo(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{

	return 0;
}



/*read by bdf to test if we still can read vendor id
 *by enum bdf after reset device. now expected not?
 */
#define PCI_CONF1_ADDRESS(bus, devfn, reg) \
	(0x80000000 | ((reg & 0xF00) << 16) | (bus << 16) \
	| (devfn << 8) | (reg & 0xFC))
#define PCI_ADDRESS_PORT 0xCF8
#define PCI_DATA_PORT 0xCFC

int t_pcie_vend_read(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	u32 bus, device, function, l = 0;
	u32 findflag = 0;
	u32 retry = 60;
	unsigned short vend_id=0;
	/*method 1: use inbox API.*/
	pci_read_config_word(mtk_dev->pdev, PCI_VENDOR_ID, &vend_id);
	MTK_DEBUG_LOG(TAG,
		"MTK PCIE vendor id read by API is %d.\n",vend_id);
	/*method 2:io port PCI_ADDRESS_PORT/PCI_DATA_PORT
	 *already applied by pci_direct_probe()
	 */
	for (bus = 0; bus <= 255; bus++) {
		for (device = 0; device <= 31; device++) {
			for (function = 0; function <= 7; function++) {
				outl(PCI_CONF1_ADDRESS(bus,
					PCI_DEVFN(device, function),
					PCI_VENDOR_ID), PCI_ADDRESS_PORT);
read_vendor_id:
				l = inl(PCI_DATA_PORT);
				if ((l & 0xffff) == PCI_VENDOR_ID_TEST) {
					findflag = 1;
					MTK_DEBUG_LOG(TAG,
						"MTK PCIE vendor id find ( %x ),with bdf %u,%u,%u.\n",
						l, bus, device, function);
					} else if ((l & 0xffff) != 0xffff)
						MTK_DEBUG_LOG(TAG,
							"OTHER vendor id find ( %x ).\n",
							l);
				else if (l == 0xffff0001) {
					MTK_DEBUG_LOG(TAG,
						"retry status find by B(%u)D(%u)F(%u).\n",
						bus, device, function);
					if (retry--) {
						msleep(1000);
						goto read_vendor_id;
						}
					MTK_DEBUG_LOG(TAG,
						"retry status timeout by B(%u)D(%u)F(%u).\n",
						bus, device, function);
					}
				}
			}
		}
	if (findflag == 0)
		MTK_DEBUG_LOG(TAG, "not exist MTK pci device vendor id.\n");


	return 0;
}

int t_pcie_mhccif_unit_test(struct mtk_pci_dev *mtk_dev,
	int argc, char **argv)
{
	mhccif_rc2ep_swint_trigger(mtk_dev,3);
	return 0;
}

int t_pcie_reg_test(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	PPCIE_MAC_IREG_REGS pbase;

	pbase = mtk_dev->base_addr.pcie_mac_ireg_base;
	MTK_DEBUG_LOG(TAG, "\nPCIE_SW_TRIG_INT read %x.\n",
		MTK_PCIE_SW_TRIG_INT(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_SW_TRIG_INT reg %p.\n",
		&MTK_PCIE_SW_TRIG_INT(pbase));

	MTK_DEBUG_LOG(TAG, "\nISTATUS_LOCAL read %x.\n",
		MTK_ISTATUS_LOCAL(pbase));
	MTK_DEBUG_LOG(TAG, "ISTATUS_LOCAL reg %p.\n",
		&MTK_ISTATUS_LOCAL(pbase));

	MTK_DEBUG_LOG(TAG, "\nMTK_INT_ENABLE_HOST read %x.\n",
		MTK_INT_ENABLE_HOST(pbase));
	MTK_DEBUG_LOG(TAG, "MTK_INT_ENABLE_HOST reg %p.\n",
		&MTK_INT_ENABLE_HOST(pbase));

	MTK_DEBUG_LOG(TAG, "\nISTATUS_HOST read %x.\n",
		MTK_ISTATUS_HOST(pbase));
	MTK_DEBUG_LOG(TAG, "ISTATUS_HOST reg %p.\n",
		&MTK_ISTATUS_HOST(pbase));

	MTK_DEBUG_LOG(TAG, "\nISTATUS_HOST_CTRL read %x.\n",
		MTK_ISTATUS_HOST_CTRL(pbase));
	MTK_DEBUG_LOG(TAG, "ISTATUS_HOST_CTRL reg %p.\n",
		&MTK_ISTATUS_HOST_CTRL(pbase));

	MTK_DEBUG_LOG(TAG, "\nINT_ENABLE_HOST_SET read %x.\n",
		MTK_INT_ENABLE_HOST_SET(pbase));
	MTK_DEBUG_LOG(TAG, "INT_ENABLE_HOST_SET reg %p.\n",
		&MTK_INT_ENABLE_HOST_SET(pbase));

	MTK_DEBUG_LOG(TAG, "\nINT_ENABLE_HOST_CLR read %x.\n",
		MTK_INT_ENABLE_HOST_CLR(pbase));
	MTK_DEBUG_LOG(TAG, "INT_ENABLE_HOST_CLR reg %p.\n",
		&MTK_INT_ENABLE_HOST_CLR(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_DMA_DUMMY_0 read %x.\n",
		MTK_PCIE_DMA_DUMMY_0(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_DMA_DUMMY_0 reg %p.\n",
		&MTK_PCIE_DMA_DUMMY_0(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_DUMMY_0 read %x.\n",
		MTK_PCIE_DUMMY_0(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_DUMMY_0 reg %p.\n",
		&MTK_PCIE_DUMMY_0(pbase));

	MTK_DEBUG_LOG(TAG,
		"\nPCIE_ATR_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB read %x.\n",
		MTK_PCIE_ATR_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_ATR_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB reg %p.\n",
		&MTK_PCIE_ATR_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_ATR_WIN0_T0_SRC_ADDR_MSB read %x.\n",
		MTK_PCIE_ATR_WIN0_T0_SRC_ADDR_MSB(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_ATR_WIN0_T0_SRC_ADDR_MSB reg %p.\n",
		&MTK_PCIE_ATR_WIN0_T0_SRC_ADDR_MSB(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_ATR_WIN0_T0_TRSL_ADDR_LSB read %x.\n",
		MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_LSB(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_ATR_WIN0_T0_TRSL_ADDR_LSB reg %p.\n",
		&MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_LSB(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_ATR_WIN0_T0_TRSL_ADDR_MSB read %x.\n",
		MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_MSB(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_ATR_WIN0_T0_TRSL_ADDR_MSB reg %p.\n",
		&MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_MSB(pbase));

	MTK_DEBUG_LOG(TAG, "\nPCIE_ATR_WIN0_T0_TRSL_PARAM read %x.\n",
		MTK_PCIE_ATR_WIN0_T0_TRSL_PARAM(pbase));
	MTK_DEBUG_LOG(TAG, "PCIE_ATR_WIN0_T0_TRSL_ADDR_MSB reg %p.\n",
		&MTK_PCIE_ATR_WIN0_T0_TRSL_PARAM(pbase));

	MTK_DEBUG_LOG(TAG,
		"REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB reg 0x%p\n",
		MTK_REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(pbase));

	MTK_DEBUG_LOG(TAG, "REG_BASE_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB reg 0x%p\n",
		MTK_REG_BASE_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB(pbase));

	MTK_DEBUG_LOG(TAG, "REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB reg 0x%p\n",
		MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB(pbase));

	MTK_DEBUG_LOG(TAG, "REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB reg 0x%p\n",
		MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB(pbase));

	MTK_DEBUG_LOG(TAG, "REG_BASE_ATR_PCIE_WIN0_T0_TRSL_PARAM reg 0x%p\n",
		MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_PARAM(pbase));

	return 0;
}

int t_pcie_l1ss(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	int ret, ds_mode, us_mode, aspm_mode;

	aspm_mode = 1;
	ds_mode = 0;
	us_mode = 0;

	if (argc > 1) {
		if (!strcmp(argv[1], "PCIPM")) {
			MTK_DEBUG_LOG(TAG, "Test L1 PM Substates PCI-PM\n");
			aspm_mode = 0;
		}
		if (!strcmp(argv[1], "ASPM")) {
			MTK_DEBUG_LOG(TAG, "Test L1 PM Substates ASPM\n");
			aspm_mode = 1;
		}
	}
	if (argc > 2) {
		if (!strcmp(argv[2], "L11")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.1 (DS)\n");
			ds_mode |= (aspm_mode) ? L1SS_ASPM_L11 : L1SS_PCIPM_L11;
		}
		if (!strcmp(argv[2], "L12")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.2 (DS)\n");
			ds_mode |= (aspm_mode) ? L1SS_ASPM_L12 : L1SS_PCIPM_L12;
		}
		if (!strcmp(argv[2], "both")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.1 & L1.2 (DS)\n");
			ds_mode |= (aspm_mode) ?
				(L1SS_ASPM_L11 | L1SS_ASPM_L12) :
				(L1SS_PCIPM_L11 | L1SS_PCIPM_L12);
		}
		if (!strcmp(argv[2], "disable")) {
			MTK_DEBUG_LOG(TAG, "Disable L1 PM Substates (DS)\n");
			ds_mode = 0;
		}
	}
	if (argc > 3) {
		if (!strcmp(argv[3], "L11")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.1 (US)\n");
			us_mode |= (aspm_mode) ? L1SS_ASPM_L11 : L1SS_PCIPM_L11;
		}
		if (!strcmp(argv[3], "L12")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.2 (US)\n");
			us_mode |= (aspm_mode) ? L1SS_ASPM_L12 : L1SS_PCIPM_L12;
		}
		if (!strcmp(argv[3], "both")) {
			MTK_DEBUG_LOG(TAG, "Enable L1.1 & L1.2 (US)\n");
			us_mode |= (aspm_mode) ?
				(L1SS_ASPM_L11 | L1SS_ASPM_L12) :
				(L1SS_PCIPM_L11 | L1SS_PCIPM_L12);
		}
		if (!strcmp(argv[3], "disable")) {
			MTK_DEBUG_LOG(TAG, "Disable L1 PM Substates (US)\n");
			us_mode = 0;
		}
	}
	ret = mtk_setup_l1ss(mtk_dev->pdev,ds_mode, us_mode);
	if (ret)
		return ret;

	return 0;
}


int t_pcie_aspm(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{

	int ret;
	struct mkt_aspm_state aspm = {0};

	if (argc > 1) {
		if (!strcmp(argv[1], "L0s")) {
			MTK_DEBUG_LOG(TAG, "Test DS L0s aspm\n");
			aspm.aspm_ds = LINK_STATE_L0S;
		}
		if (!strcmp(argv[1], "L1")) {
			MTK_DEBUG_LOG(TAG, "Test DS L1 aspm\n");
			aspm.aspm_ds = LINK_STATE_L1;
		}
		if (!strcmp(argv[1], "both")) {
			MTK_DEBUG_LOG(TAG, "Test DS L0s/L1 aspm\n");
			aspm.aspm_ds = (LINK_STATE_L0S | LINK_STATE_L1);
		}
		if (!strcmp(argv[1], "disable")) {
			MTK_DEBUG_LOG(TAG, "Disable DS aspm\n");
			aspm.aspm_ds = 0;
		}
	}
	if (argc > 2) {
		if (!strcmp(argv[2], "L0s")) {
			MTK_DEBUG_LOG(TAG, "Test US L0s aspm\n");
			aspm.aspm_us = LINK_STATE_L0S;
		}
		if (!strcmp(argv[2], "L1")) {
			MTK_DEBUG_LOG(TAG, "Test US L1 aspm\n");
			aspm.aspm_us = LINK_STATE_L1;
		}
		if (!strcmp(argv[2], "both")) {
			MTK_DEBUG_LOG(TAG, "Test US L0s/L1 aspm\n");
			aspm.aspm_us = (LINK_STATE_L0S | LINK_STATE_L1);
		}
		if (!strcmp(argv[2], "disable")) {
			MTK_DEBUG_LOG(TAG, "Disable US aspm\n");
			aspm.aspm_us = 0;
		}
	}
	ret = mtk_pcie_aspm(mtk_dev,aspm);

	return ret;
}

int t_pcie_rescan(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	int ret;

	ret = mtk_queue_rescan_work(mtk_dev->pdev);
	return ret;
}

int t_pcie_reg_wr_test(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	u32 val = 0;
	PPCIE_MAC_IREG_REGS pbase;

	if (argc > 1) {
		if (!strcmp(argv[1], "1")) {
			pbase = mtk_dev->base_addr.pcie_mac_ireg_base;
			MTK_DEBUG_LOG(TAG,
				"MTK_REG_BASE_PCIE_DEBUG_DUMMY_7 reg wr test\n");
			if (!strcmp(argv[2], "1")) {
				REG_IO_WRITE32(
					MTK_REG_BASE_PCIE_DEBUG_DUMMY_7(pbase),
					0xFF);
			} else if (!strcmp(argv[2], "2")) {
				val = REG_IO_READ32(
					MTK_REG_BASE_PCIE_DEBUG_DUMMY_7(pbase));
				MTK_DEBUG_LOG(TAG, "Data:0x%08x\n", val);
			}
		} else if (!strcmp(argv[1], "2")) {
			MTK_DEBUG_LOG(TAG,
				"REG_PCIE_SPARE_RC_0_REG reg wr test\n");
			if (!strcmp(argv[2], "1")) {
				REG_IO_WRITE32(REG_PCIE_SPARE_RC_0_REG(
					mtk_dev->base_addr.mhccif_rc_base),
					0xAA);
			} else if (!strcmp(argv[2], "2")) {
				val = REG_IO_READ32(
					REG_PCIE_SPARE_RC_0_REG(
					mtk_dev->base_addr.mhccif_rc_base));
				MTK_DEBUG_LOG(TAG, "Data:0x%08x\n", val);
			}
		}
	}

	return 0;
}

static int pm_ut_suspend_0(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	MTK_PCI_PM_FUNC_ENTER();
	return 0;
}

static int pm_ut_resume_0(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	MTK_PCI_PM_FUNC_ENTER();

	return 0;
}

static struct md_pm_entity pm_ut_entity_0 = {
	.suspend = pm_ut_suspend_0,
	.resume = pm_ut_resume_0,

	.key = PM_ENTITY_KEY_RESERVE0,
	.entity_param = NULL,
};

static struct md_pm_entity pm_ut_entity_1 = {
	.suspend = pm_ut_suspend_0,
	.resume = pm_ut_resume_0,

	.key = PM_ENTITY_KEY_RESERVE1,
	.entity_param = NULL,
};


static void pm_ut_work_0(struct work_struct *work)
{
	int i;

	for (i = 0; i < 1000; i++) {
		if (pm_work == 0) {
			if (unlikely(i == 50))
				mtk_pci_pm_init_late(pm_ut_mtk_dev);

			if (mtk_pci_l_resource_lock(pm_ut_mtk_dev,
				L_RES_USER_CTRL) == 1) {
				MTK_INFO_LOG(TAG, "Control Wait\n");
				cancel_delayed_work_sync(&pm_ut_task_l_res);
				schedule_delayed_work(
					&pm_ut_task_l_res,
					msecs_to_jiffies(20));

			}
			usleep_range(3000, 4000);

			mtk_pci_l_resource_wait_complete(
				pm_ut_mtk_dev, L_RES_USER_CTRL);
			mtk_pci_l_resource_unlock(
				pm_ut_mtk_dev, L_RES_USER_CTRL);

		} else {
			mtk_pci_pm_entity_register(
				pm_ut_mtk_dev, &pm_ut_entity_0);
			usleep_range(4000, 5000);
			mtk_pci_pm_entity_unregister(
				pm_ut_mtk_dev, &pm_ut_entity_0);
		}
	}
	up(&pm_ut_task_0_sem);


}

static void pm_ut_work_1(struct work_struct *work)
{

	int i;

	for (i = 0; i < 1000; i++) {
		if (pm_work == 0) {
			if (mtk_pci_l_resource_lock(
				pm_ut_mtk_dev, L_RES_USER_DATA) == 1) {
				MTK_INFO_LOG(TAG, "Data Wait\n");
				cancel_delayed_work_sync(&pm_ut_task_l_res);
				schedule_delayed_work(&pm_ut_task_l_res,
					msecs_to_jiffies(20));
			}

			usleep_range(2000, 3000);
			mtk_pci_l_resource_wait_complete(
				pm_ut_mtk_dev, L_RES_USER_DATA);
			mtk_pci_l_resource_unlock(pm_ut_mtk_dev,
				L_RES_USER_DATA);

		} else {
			mtk_pci_pm_entity_register(pm_ut_mtk_dev,
				&pm_ut_entity_1);
			usleep_range(5000, 6000);
			mtk_pci_pm_entity_unregister(pm_ut_mtk_dev,
				&pm_ut_entity_1);
		}
	}

	up(&pm_ut_task_1_sem);
}

static void pm_ut_work_l_res(struct work_struct *work)
{
	complete_all(&pm_ut_mtk_dev->l_res_acquire);
}

int t_pcie_lp_register_unregister(struct mtk_pci_dev *mtk_dev,
	int argc, char **argv)
{
	pm_work = 1;

	cancel_work_sync(&pm_ut_task_0);
	cancel_work_sync(&pm_ut_task_1);

	schedule_work(&pm_ut_task_0);
	schedule_work(&pm_ut_task_1);

	down(&pm_ut_task_0_sem);
	down(&pm_ut_task_1_sem);

	if (unlikely(!list_empty(&mtk_dev->md_pm_entities))) {
		MTK_ERR_LOG(TAG, "Entity List not empty\n");
		return -1;
	}

	mtk_pci_pm_entity_register(pm_ut_mtk_dev, &pm_ut_entity_1);

	if (unlikely(list_empty(&mtk_dev->md_pm_entities))) {
		MTK_ERR_LOG(TAG, "Entity List  empty after register\n");
		return -2;
	}

	mtk_pci_pm_entity_unregister(pm_ut_mtk_dev, &pm_ut_entity_1);

	if (unlikely(!list_empty(&mtk_dev->md_pm_entities))) {
		MTK_ERR_LOG(TAG, "Entity List  not empty after unregister\n");
		return -3;
	}

	return 0;
}

int t_pcie_lp_lock_unlock(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	pm_work = 0;
	cancel_work_sync(&pm_ut_task_0);
	cancel_work_sync(&pm_ut_task_1);

	schedule_work(&pm_ut_task_0);
	schedule_work(&pm_ut_task_1);

	down(&pm_ut_task_0_sem);
	down(&pm_ut_task_1_sem);
	return 0;
}

int t_pcie_lp_rpm(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	int i;

	for (i = 0; i < 100; i++) {
		mtk_pm_runtime_get(mtk_dev);

		mtk_pm_runtime_put_sync(mtk_dev);

		mtk_pm_runtime_get_sync(mtk_dev);

		mtk_pm_runtime_put(mtk_dev);
	}
	return 0;
}

int t_pcie_lp_work_init(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	INIT_WORK(&pm_ut_task_0, pm_ut_work_0);
	INIT_WORK(&pm_ut_task_1, pm_ut_work_1);
	INIT_DELAYED_WORK(&pm_ut_task_l_res, pm_ut_work_l_res);
	sema_init(&pm_ut_task_0_sem, 0);
	sema_init(&pm_ut_task_1_sem, 0);
	pm_ut_mtk_dev = mtk_dev;

	return 0;
}

int t_pcie_lp_show_lp_info(struct mtk_pci_dev *mtk_dev, int argc, char **argv)
{
	MTK_INFO_LOG(TAG, "md_pm_init_done=%d\n",
		atomic_read(&mtk_dev->md_pm_init_done));
	MTK_INFO_LOG(TAG, "l_res_lock_count=%d\n",
		atomic_read(&mtk_dev->l_res_lock_count));
	MTK_INFO_LOG(TAG, "md_pm_resumed=%d\n",
		atomic_read(&mtk_dev->md_pm_resumed));
#ifdef CONFIG_PM
	MTK_INFO_LOG(TAG, "runtime usage_count=%d\n",
		atomic_read(&(mtk_dev->pdev->dev.power.usage_count)));
#endif
	MTK_INFO_LOG(TAG, "dev disconnected=%d\n",
		test_bit(0, &mtk_dev->pdev->priv_flags));

        {
            struct pci_dev *bridge;
            bridge = mtk_dev->pdev->bus->self;
    	    if (bridge && bridge->current_state != PCI_D0)
            {
            
                MTK_INFO_LOG(TAG, "[PM]Continue\n");
                if(bridge) {
                     MTK_INFO_LOG(TAG, "[PM]bridge->current_state=%d\n", bridge->current_state);
                 }
                
           } else {
                MTK_INFO_LOG(TAG, "[PM]Read\n");
            }
        }
        MTK_INFO_LOG(TAG, "[PM] pme_poll = %d, pm_cap=%x\n", mtk_dev->pdev->pme_poll, mtk_dev->pdev->pm_cap);
	return 0;
}

int mtk_acpi_fldr_func(struct mtk_pci_dev *mtk_dev) 
{
	int ret = 0;
#ifdef CONFIG_ACPI
	struct device *dev = &(mtk_dev->pdev->dev);
	struct acpi_buffer buffer = { ACPI_ALLOCATE_BUFFER, NULL };
	acpi_handle handle = NULL;
	acpi_status acpi_ret;
	if(acpi_disabled){
		MTK_ERR_LOG(TAG, "acpi function isn't enable\n");
		ret = -1;
	}else {
		handle = ACPI_HANDLE(dev);
		if (NULL == handle) {
			MTK_INFO_LOG(TAG,"acpi handle isn't found\n");
			ret = -1;
		} else {
			/*check method exist*/
			if (acpi_has_method(handle, "\\_SB.PCI0.RP02.PXSX._RST")) {
				/*execute method*/
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXSX._RST", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG,"_RST method fail: %s\n",\
								acpi_format_exception(acpi_ret));
					ret = -1;
				} else {
					MTK_INFO_LOG(TAG, "_RST Method execute successfully\n");
				}
			} else {
				MTK_ERR_LOG(TAG, "_RST method isn't found\n");
				ret = -1;
			}
		}
	}
#else
	MTK_INFO_LOG(TAG, "CONFIG ACPI isn't set to 'y' \n");
#endif
	return ret;
}

int mtk_acpi_pldr_func(struct mtk_pci_dev *mtk_dev)
{
	int ret = 0;
#ifdef CONFIG_ACPI
	struct device *dev = &(mtk_dev->pdev->dev);
	struct acpi_buffer buffer = { ACPI_ALLOCATE_BUFFER, NULL };
	acpi_handle handle = NULL;
	acpi_status acpi_ret;
	if(acpi_disabled){
		MTK_ERR_LOG(TAG, "acpi function isn't enable\n");
		ret = -1;
	} else {
		handle = ACPI_HANDLE(dev);
		if (handle == NULL) {
			MTK_INFO_LOG(TAG,"acpi handle isn't found\n");
			ret = -1;
		} else {
			/*check method exist*/
			if (acpi_has_method(handle, "\\_SB.PCI0.RP02.PXP._OFF") &&
				acpi_has_method(handle, "\\_SB.PCI0.RP02.PXP._ON")) {

				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXP._OFF", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG, "The method fail: %s\n",\
								acpi_format_exception(acpi_ret));
					ret = -1;
					goto OUT;
				} else {
					MTK_INFO_LOG(TAG, "_OFF method work successfully\n");
				}
				msleep(500);
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXP._ON", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG, "The method fail: %s\n",\
								acpi_format_exception(acpi_ret));
					ret = -1;
					goto OUT;
				} else {
					MTK_INFO_LOG(TAG, "_ON method work successfully\n");
				}
			} else {
				MTK_ERR_LOG(TAG, "pldr method isn't supported\n");
				ret = -1;
			}
		}
	}
#else
	MTK_INFO_LOG(TAG, "CONFIG ACPI isn't set to 'y' \n");
#endif
#ifdef __x86_64__
OUT:
#endif
	return ret;

}

int t_pcie_acpi_fldr_test(struct mtk_pci_dev *mtk_dev, int argc, char** argv)
{
	int ret = 0;
	ret = mtk_acpi_fldr_func(mtk_dev);
	if (ret == -1) 
		MTK_ERR_LOG(TAG, "fldr method fail\n");
	else 
		MTK_INFO_LOG(TAG, "fldr method work succefully\n");
	return ret;
}

int t_pcie_acpi_pldr_test(struct mtk_pci_dev *mtk_dev, int argc, char** argv)
{
	int ret = 0;
#ifdef CONFIG_ACPI
	struct device *dev = &(mtk_dev->pdev->dev);
	struct acpi_buffer buffer = { ACPI_ALLOCATE_BUFFER, NULL };
	acpi_handle handle = NULL;
	acpi_status acpi_ret;
	if(acpi_disabled){
		MTK_INFO_LOG(TAG, "acpi is't enable\n");
	}else {
		handle = ACPI_HANDLE(dev);
		if (NULL == handle) {
			MTK_INFO_LOG(TAG,"acpi handle isn't found\n");
		} else {
			/*check method exist*/
			if (acpi_has_method(handle, "_ADR")) 
				MTK_INFO_LOG(TAG, "there are _ADR Method\n");

			if (!strcmp(argv[1], "pldr")) {  
				ret = mtk_acpi_pldr_func(mtk_dev);
				if (ret == -1) 
					MTK_ERR_LOG(TAG, "pldr method fail\n");
				else 
					MTK_INFO_LOG(TAG, "pldr method work succefully\n");
			}
	
			if (!strcmp(argv[1], "OFF") && acpi_has_method(handle, "\\_SB.PCI0.RP02.PXP._OFF")) {
				MTK_INFO_LOG(TAG, "there are _OFF Method\n");
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXP._OFF", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG, "The method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}
			}

			if (!strcmp(argv[1], "ON") && acpi_has_method(handle, "\\_SB.PCI0.RP02.PXP._ON")) {
				MTK_INFO_LOG(TAG, "there are _ON Method\n");				
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXP._ON", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG, "The method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}
			}
				
			if (!strcmp(argv[1], "PON") && acpi_has_method(handle, "\\_SB.PCI0.RP02.WDL2")) {
				MTK_INFO_LOG(TAG, "there are WDL2 Method\n");
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.WDL2", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG,"The method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}				
			} 
				
			if (!strcmp(argv[1], "POFF") && acpi_has_method(handle, "\\_SB.PCI0.RP02.WL2D")) {
				/*execute method*/
				MTK_INFO_LOG(TAG, "there are WL2D Method\n");
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.WL2D", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG,"POFF method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}
	   		}

			if (!strcmp(argv[1], "DRST") && acpi_has_method(handle, "\\_SB.PCI0.RP02.PXSX.DRST._RST")) {
				/*execute method*/
				MTK_INFO_LOG(TAG, "there are DRST Method\n");
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXSX.DRST._RST", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG,"DRST method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}
	   		}

			if (!strcmp(argv[1], "WRST") && acpi_has_method(handle, "\\_SB.PCI0.RP02.PXSX.WRST._RST")) {
				/*execute method*/
				MTK_INFO_LOG(TAG, "there are WRST Method\n");
				acpi_ret = acpi_evaluate_object(handle, "\\_SB.PCI0.RP02.PXSX.WRST._RST", NULL, &buffer);
				if (ACPI_FAILURE(acpi_ret)) {
					MTK_INFO_LOG(TAG,"WRST method fail: %s\n",\
								acpi_format_exception(acpi_ret));
				}
	   		}
		}
	}
#else
	MTK_INFO_LOG(TAG, "CONFIG ACPI isn't set to 'y' \n");
#endif
	return ret;
}

struct CMD_TBL_T {
	char name[256];
	int (*cb_func)(struct mtk_pci_dev *mtk_dev, int argc, char **argv);
};

struct CMD_TBL_T _arPCmdTbl[] = {
	{"pcie.reginfo", &t_pcie_reginfo},
	{"pcie.vend_read", &t_pcie_vend_read},
	{"pcie.mhccifut", &t_pcie_mhccif_unit_test},
	{"pcie.regtest", &t_pcie_reg_test},
	{"pcie.l1ss", &t_pcie_l1ss},
	{"pcie.aspm", &t_pcie_aspm},
	{"pcie.rescan", &t_pcie_rescan},
	{"pcie.regwrtest", &t_pcie_reg_wr_test},
	{"pcie.lp.register.unregister.test", t_pcie_lp_register_unregister},
	{"pcie.lp.lres.lock.unlock", t_pcie_lp_lock_unlock},
	{"pcie.lp.rpm.test", t_pcie_lp_rpm},
	{"pcie.lp.work.init", t_pcie_lp_work_init},
	{"pcie.lp.show.lp.info", t_pcie_lp_show_lp_info},
	{"pcie.fldr", t_pcie_acpi_fldr_test},
	{"pcie.pldr", t_pcie_acpi_pldr_test},
};


int call_function(struct mtk_pci_dev *mtk_dev, char *buf)
{
	int i, ret, match;
	int argc;
	char *argv[MAX_ARG_SIZE];

	argc = 0;
	do {
		argv[argc] = strsep(&buf, " ");
		MTK_INFO_LOG(TAG, "[%d] %s\n", argc, argv[argc]);
		argc++;
	} while (buf);

	match = 0;
	for (i = 0; i < sizeof(_arPCmdTbl)/sizeof(struct CMD_TBL_T); i++) {
		if ((!strcmp(_arPCmdTbl[i].name, argv[0])) &&
			(_arPCmdTbl[i].cb_func != NULL)) {
			ret = _arPCmdTbl[i].cb_func(mtk_dev, argc, argv);
			for (i = 0; i < argc; i++)
				MTK_INFO_LOG(TAG, "[%d] %s\n", i, argv[i]);
			MTK_INFO_LOG(TAG, "RESULT: %s (%s)\n",
				(!ret ? "PASS" : "FAIL"),
				MTK_PCIE_FUNCTION_NUMBER);

			return ret;
		}
	}

	return -1;
}

static ssize_t pcie_test_show(struct mtk_pci_dev *mtk_dev, char *buf)
{
	int i;
	unsigned int ptr;

	MTK_INFO_LOG(TAG, "MTK pcie test show for B(%d)D(%d)F(%d).\n",
		mtk_dev->pdev->bus->number, (mtk_dev->pdev->devfn)>>12,
		(mtk_dev->pdev->devfn)&0xfff);

	ptr = 0;
	for (i = 0; i < sizeof(_arPCmdTbl)/sizeof(struct CMD_TBL_T); i++) {
		sprintf(buf + ptr, "%s\n", _arPCmdTbl[i].name);
		ptr = ptr + strlen(_arPCmdTbl[i].name) + 1;
	}

	return ptr;

}
static ssize_t pcie_test_store(struct mtk_pci_dev *mtk_dev,
	const char *buf, size_t n)
{
	int retval;
	char *ch;

	MTK_DEBUG_LOG(TAG, "MTK pcie test store for B(%d)D(%d)F(%d),\n",
		mtk_dev->pdev->bus->number, (mtk_dev->pdev->devfn)>>12,
		(mtk_dev->pdev->devfn)&0xfff);

	ch = kmalloc(n, GFP_KERNEL);
	memcpy(ch, buf, n);
	if (ch[n-1] == '\n')
		ch[n-1] = '\0';

	retval = call_function(mtk_dev, ch);

	if (retval < 0) {
		MTK_INFO_LOG(TAG, "pcie cli fail\n");
		kfree(ch);
		return -1;
	}

	kfree(ch);
	MTK_INFO_LOG(TAG, "%s", buf);
	return n;

}

MTK_PCIE_ATTR(NULL, pcie_test, 0664, pcie_test_show, pcie_test_store);

static inline bool mtk_dev_is_disconnected(
	const struct mtk_pci_dev *mtk_dev, u16 *vend_id)
{
	pci_read_config_word(mtk_dev->pdev, PCI_VENDOR_ID, vend_id);

	return *vend_id != PCI_VENDOR_ID_TEST_CHIP;
}

static ssize_t mtk_pcie_lock_state_show(struct mtk_pci_dev *mtk_dev, char *buf)
{
	const char* state;
	unsigned int locked;
	u16 vend_id;
	u32 reg32;
	int lock_count;

	lock_count = atomic_read(&mtk_dev->l_res_lock_count);

	if (mtk_dev_is_disconnected(mtk_dev, &vend_id)) {
		MTK_INFO_LOG(TAG , "mtk_dev is disconnected !! vend_id=0x%04X lock_count=%d\n", vend_id, lock_count);
		return sprintf(buf, "Disconnected count=%d\n", lock_count) + 1;
	}

	reg32 = MTK_PCIE_MISC_CTRL(mtk_dev->base_addr.pcie_mac_ireg_base);
	locked = REG_FLD_GET(REG_FLD(1, 7), reg32);

	if (locked)
		state = "Locked";
	else
		state = "Unlocked";

	MTK_INFO_LOG(TAG ,
		"read lock_state: %s lock_count=%d locked_reg=%x locked_val=%x\n",
		state, lock_count, reg32, locked);

	return sprintf(buf, "%s count=%d\n", state, lock_count) + 1;
}

static ssize_t mtk_pcie_lock_state_store(
	struct mtk_pci_dev *mtk_dev, const char *buf, size_t n)
{
	bool send_lock;

	if (!strncmp(buf, "unlock", 6))
	{
		PCIE_CFG_SET_PEXTP_MAC_SLEEP(MTK_PCIE_MISC_CTRL(mtk_dev->base_addr.pcie_mac_ireg_base), 0);
		MTK_DEBUG_LOG(TAG , "send_lock = unlock [force]\n");
		return n;
	}

	send_lock = buf[0] == '1';

	if (send_lock)
		mtk_pci_l_resource_lock(mtk_dev, 4);
	else
		mtk_pci_l_resource_unlock(mtk_dev, 4);

	MTK_DEBUG_LOG(TAG , "send_lock = %s\n", send_lock ? "True" : "False");

	return n;
}

MTK_PCIE_ATTR(NULL, lock_state, 0664, mtk_pcie_lock_state_show, mtk_pcie_lock_state_store);


static ssize_t mtk_pcie_hp_status_show(struct mtk_pci_dev *mtk_dev, char *buf)
{
	const char* state;
	u16 vend_id;

	if (mtk_dev_is_disconnected(mtk_dev, &vend_id)) {
		MTK_INFO_LOG(TAG , "mtk_dev is Disconnected !! vend_id=0x%04X\n", vend_id);
		return sprintf(buf, "Disconnected\n") + 1;
	}

	if (mtk_dev->hp_enable)
		state = "1";
	else
		state = "0";

	MTK_INFO_LOG(TAG , "Hotplug status %d\n", mtk_dev->hp_enable);

	return sprintf(buf, "%s\n", state) + 1;
}


MTK_PCIE_ATTR(NULL, hp_status, 0444, mtk_pcie_hp_status_show, NULL);


static int __mtk_pcie_test_attr_register(
	struct mtk_pci_dev *mtk_dev, struct mtk_pcie_attribute *test_attr)
{
	int ret;

	if (test_attr == NULL || mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "fail to add sysfs node: test_attr = %p mtk_dev = %p\n",
			test_attr, mtk_dev);
		return -1;
	}

	test_attr->mtk_dev = mtk_dev;
	ret = sysfs_create_file(&mtk_dev->pcie_kobj, &test_attr->attr);
	if (ret) {
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s ret = %d\n",
			test_attr->attr.name, ret);
	}

	return ret;
}

int mtk_pcie_test_attr_init(struct mtk_pci_dev *mtk_dev)
{
	int ret;

	ret = __mtk_pcie_test_attr_register(mtk_dev, &mtk_pcie_attr_pcie_test);
	if (ret)
		return ret;

	ret = __mtk_pcie_test_attr_register(mtk_dev, &mtk_pcie_attr_lock_state);
	if (ret)
		return ret;

	ret = __mtk_pcie_test_attr_register(mtk_dev, &mtk_pcie_attr_hp_status);
	if (ret)
		return ret;
		
	return 0;
}


