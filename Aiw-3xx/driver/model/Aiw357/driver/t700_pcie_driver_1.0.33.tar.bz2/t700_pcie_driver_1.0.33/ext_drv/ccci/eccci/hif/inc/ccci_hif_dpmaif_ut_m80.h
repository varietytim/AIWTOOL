/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_HIF_DPMAIF_UT_H__
#define __CCCI_HIF_DPMAIF_UT_H__


#include <linux/skbuff.h>
#include <linux/types.h>
#include <uapi/linux/ip.h>
#include <linux/sched.h>

#include "dpmaif_hif_platform_m80.h"


/*
 *  UT Compile Flags
 *
 *  DATA_PATH_UT_LOOPBACK: for CCMNI layer + HIF layer loopback UT
 *  DATA_PATH_UT_HW_LOOPBACK:
 * for CCMNI layer + HIF layer + HW layer loopback UT-IT
 */
#if defined(DATA_PATH_UT_LOOPBACK) || defined(DATA_PATH_UT_HW_LOOPBACK)

enum dpmaif_ut_packet_type {
	DPMF_UT_PKT_UNKNOWN = 0,
	DPMF_UT_PKT_ICMP,
	DPMF_UT_PKT_UDP,
	DPMF_UT_PKT_TCP
};

/*
 *  dpmaif_ut_get_packet_type - checks this IP packet's type
 *  @ skb: pakcet buffer
 *
 *  return this packet's type in dpmaif_ut_packet_type_t
 */
enum dpmaif_ut_packet_type dpmaif_ut_get_packet_type(const struct sk_buff *skb);

/*
 *  dpmaif_ut_reply_icmp_echo_pkt - generates ICMP echo
 * reply packet by modifying original packet
 *  @ skb: packet buffer to modify
 *
 *  return 0 for generating reply packet success;
 *  return -1 for this is NOT a ICMP echo packet;
 *  return others for generating reply packet failed.
 */
int dpmaif_ut_reply_icmp_echo_pkt(struct sk_buff *skb);


/*
 *  dpmaif_ut_loopback_pkt - loopback TX packets for RX packets
 *  @ skb: packet to loopback
 *
 *  return 0 for loopback this packet success;
 *  return -1 for this is NOT a ICMP/UDP/TCP packet;
 *  return others for loopback this packet failed.
 */
int dpmaif_ut_loopback_pkt(struct sk_buff *skb);


void dpmaif_ut_show_packet_checksum(struct sk_buff *skb);


#endif  /* ifdef DATA_PATH_UT_LOOPBACK */


/* ====================================================== */
/* ====================================================== */

unsigned short dpmaif_ut_get_packet_id(struct iphdr *iph);

/* ====================================================== */
/* ====================================================== */
#ifdef DATA_PATH_TP_CALC
/* dl/ul monitor setting */
#define T_DPMAIF_UL_MONITOR_OFFSET (0)
#define T_DPMAIF_DL_MONITOR_OFFSET (1)

#define T_DPMAIF_UL_MONITOR_MASK (0x01)
#define T_DPMAIF_DL_MONITOR_MASK (0x01)

/* MD Tput setting Mask */
#define T_DPMAIF_MD_TPUT_MODE_SET_MASK (0x01 << 31)
#define T_DPMAIF_MD_TPUT_CTL_SET_MASK (0x01 << 30)
#define T_DPMAIF_MD_TPUT_PKT_SET_MASK (0x01 << 29)
#define T_DPMAIF_MD_TPUT_TIME_SET_MASK (0x01 << 28)


/*  MD TPUT mode [bit0-3]*/
#define T_DPMAIF_MD_TPUT_MODE_OFFSET (0)
#define T_DPMAIF_MD_TPUT_MODE_MASK (0x0F)

/* start/stop MD DL [bit4]*/
#define T_DPMAIF_MD_DL_CTL_OFFSET (4)
#define T_DPMAIF_MD_DL_CTL_MASK (0x01)

/* pkt_count/ms mask [bit5-15]*/
#define T_DPMAIF_MD_PKT_OFFSET (5)
#define T_DPMAIF_MD_PKT_MASK (0x7FF)

/* MD DL test time */
#define T_DPMAIF_MD_DL_TIME_OFFSET (16)
#define T_DPMAIF_MD_DL_TIME_MASK (0x7)

struct ccci_dp_tput_configure {
	unsigned char ul_tput_monitor_enable;
	unsigned char dl_tput_monitor_enable;
	unsigned char md_tput_mode;
	unsigned char md_start_dl_tput;
	unsigned int md_pkt_number_per_ms;
	unsigned char md_dl_tput_test_time; /*1 -> 10s*/
};

struct dpmaif_tp_statistics {
	u64 rx_num;
	u64 tx_num[2]; //0: software, 1: HW
	u64 rx_rec_start_tm;
	u64 tx_rec_start_tm;
	bool rx_rec_enable;
	bool tx_rec_enable;
	bool first_rx_pkt;
	bool first_tx_pkt;
};
#endif


#define DPMA_UT_TIME_NOW()      sched_clock()

/* ============================================================ */
/* ============================================================ */

#endif /* __CCCI_HIF_DPMAIF_UT_H__ */
