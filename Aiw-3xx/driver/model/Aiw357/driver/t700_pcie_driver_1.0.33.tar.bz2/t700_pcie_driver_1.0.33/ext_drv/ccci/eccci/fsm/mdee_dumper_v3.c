// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/kernel.h>
#include <linux/rtc.h>
#include <linux/timer.h>
#include <linux/vmalloc.h>
#include "mdee_dumper_v3.h"

//XSQUARE
#include <linux/version.h>


static void mdee_dumper_v3_set_ee_pkg(struct ccci_fsm_ee *mdee, char *data, int len)
{
	struct mdee_dumper_v3 *dumper = mdee->dumper_obj;
	int cpy_len = len > MD_HS1_FAIL_DUMP_SIZE ? MD_HS1_FAIL_DUMP_SIZE : len;

	memcpy(dumper->ex_pl_info, data, cpy_len);
}
static void mdee_dumper_v3_dump_ee_info(struct ccci_fsm_ee *mdee,
	MDEE_DUMP_LEVEL level, int more_info)
{
	struct mdee_dumper_v3 *dumper = mdee->dumper_obj;
	int md_state = ccci_fsm_get_md_state(mdee->md_id);

	dumper->more_info = more_info;
	if (level == MDEE_DUMP_LEVEL_BOOT_FAIL) {
		if (md_state == BOOT_WAITING_FOR_HS1) {
            /*will be implemented in the future(M80)*/
		} else if (md_state == BOOT_WAITING_FOR_HS2) {
            /*will be implemented in the future(M80)*/
        }
	} else if (level == MDEE_DUMP_LEVEL_STAGE1) {
		/*will be implemented in the future(M80)*/
	} else if (level == MDEE_DUMP_LEVEL_STAGE2) {
		/*will be implemented in the future(M80)*/
	}
}

static struct md_ee_ops mdee_ops_v3 = {
	.dump_ee_info = &mdee_dumper_v3_dump_ee_info,
	.set_ee_pkg = &mdee_dumper_v3_set_ee_pkg,
};
int mdee_dumper_v3_alloc(struct ccci_fsm_ee *mdee)
{
	struct mdee_dumper_v3 *dumper;

	/* Allocate port_proxy obj and set all member zero */
	dumper = kzalloc(sizeof(struct mdee_dumper_v3), GFP_KERNEL);
	if (dumper == NULL) {
		MTK_ERR_LOG(FSM, "faliled to alloc mdee_parser_v3\n");
		return -1;
	}
	mdee->dumper_obj = dumper;
	mdee->ops = &mdee_ops_v3;
	return 0;
}

int mdee_dumper_v3_free(struct ccci_fsm_ee *mdee)
{
	if (mdee->dumper_obj) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(mdee->dumper_obj);
#else
		kzfree(mdee->dumper_obj);
#endif		
		mdee->dumper_obj = NULL;
		mdee->ops = NULL;
	}
	return 0;
}

