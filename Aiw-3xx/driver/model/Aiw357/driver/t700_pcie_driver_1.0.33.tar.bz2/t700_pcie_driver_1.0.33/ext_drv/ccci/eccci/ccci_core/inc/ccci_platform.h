/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_PLATFORM_H__
#define __CCCI_PLATFORM_H__

#include <mt-plat/sync_write.h>
#include "ccci_config.h"
//#include "ccci_hif_cldma.h"
#include "modem_sys.h"

/* the last EMI bank, properly not used */
#define INVALID_ADDR (0xF0000000)
#define KERN_EMI_BASE (0x40000000)	/* Bank4 */

/* - AP side, using mcu config base */
/* -- AP Bank4 */
/* ((volatile unsigned int*)(MCUSYS_CFGREG_BASE+0x200)) */
#define AP_BANK4_MAP0 (0)
/* ((volatile unsigned int*)(MCUSYS_CFGREG_BASE+0x204)) */
#define AP_BANK4_MAP1 (0)

/* - MD side, using infra config base */
#define DBG_FLAG_DEBUG		(1<<0)
#define DBG_FLAG_JTAG		(1<<1)
#define MD_DBG_JTAG_BIT		(1<<0)

#define ccci_write32(b, a, v)           mt_reg_sync_writel(v, (b)+(a))
#define ccci_write16(b, a, v)           mt_reg_sync_writew(v, (b)+(a))
#define ccci_write8(b, a, v)            mt_reg_sync_writeb(v, (b)+(a))
#define ccci_read32(b, a)               ioread32((void __iomem *)((b)+(a)))
#define ccci_read16(b, a)               ioread16((void __iomem *)((b)+(a)))
#define ccci_read8(b, a)                ioread8((void __iomem *)((b)+(a)))

/* INFRA */
#define INFRA_RST0_REG_PD (0x0150)/* rgu reset reg */
#define INFRA_RST1_REG_PD (0x0154)/* rgu clear reset reg */
#define CLDMA_PD_RST_MASK (1 << 2)
#define INFRA_RST0_REG_AO (0x0140)
#define INFRA_RST1_REG_AO (0x0144)
#define CLDMA_AO_RST_MASK (1 << 6)

#define INFRA_AP2MD_DUMMY_REG	(0x370)
#define INFRA_AP2MD_DUMMY_BIT	0
#define	INFRA_MD2PERI_PROT_EN	(0x250)
#define	INFRA_MD2PERI_PROT_RDY	(0x258)
#define	INFRA_MD2PERI_PROT_BIT	6

#define	INFRA_PERI2MD_PROT_EN	(0x220)
#define	INFRA_PERI2MD_PROT_RDY	(0x228)
#define	INFRA_PERI2MD_PROT_BIT	7

#define INFRA_AO_MD_SRCCLKENA    (0xF0C) /* SRC CLK ENA */

extern void *vmap_reserved_mem(phys_addr_t start,
	phys_addr_t size, pgprot_t prot);
int ccci_plat_common_init(void);
void ccci_set_clk_cg(struct ccci_modem *md, unsigned int is_on);
#endif	/* __CCCI_PLATFORM_H__ */
