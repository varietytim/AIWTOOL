/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_DPMA_H__
#define __MODEM_DPMA_H__

#include <linux/device.h>
#include <linux/pm_wakeup.h>
#include <linux/dmapool.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/hrtimer.h>
#include <linux/skbuff.h>

#include <mt-plat/mtk_ccci_common.h>
#include "ccci_config.h"
#include "ccci_hif_internal.h"
#include "dpmaif_hif_platform_m80.h" 
#include "mtk-pci.h"


enum bat_type {
	NORMAL_BUF = 0,
	FRAG_BUF = 1,
};

#define DPMAIF_RXQ_NUM			MAIFQ_MAX_DLQ_NUM
#define DPMAIF_TXQ_NUM			MAIFQ_MAX_ULQ_NUM

#define DPMAIF_BUF_PKT_SIZE		NET_RX_BUF
#define DPMAIF_BUF_FRAG_SIZE	DPMAIF_HW_FRG_PKTBUF

#define DPMF_BAT_CNT_UPDATE_THRESHOLD		(30)
#define DPMF_PIT_CNT_UPDATE_THRESHOLD		(60)

#define DPMF_RX_PUSH_THRESHOLD_MASK			(0x7)
#define DPMF_NOTIFY_RELEASE_COUNT			(128)

#define DPMF_POLL_SAME_PIT_CNT_MAX		(100)	//try to poll up to 2ms
#define DPMAIF_PIT_SEQ_CHECK_FAIL_CNT	(2500)

#define DPMF_TX_REL_TIMEOUT				(0) //ms
#define DPMF_SKB_TX_BURST_CNT			(5)

#define DPMF_PCIE_LOCK_RES_TRY_WAIT_CNT     (20)
#define DPMF_WORKQUEUE_TIME_LIMIT		(2) //ms

/*
 *	DPMAIF HW checksum check result
 */
enum dpmaif_cs_check_result {
	DPMF_CS_RESULT_INVALID = -1,
	DPMF_CS_RESULT_PASS = 0x00,
	DPMF_CS_RESULT_FAIL = 0x01,
	DPMF_CS_RESULT_NOTSUPPORT = 0x02,
	DPMF_CS_RESULT_RESERVE = 0x03
};

struct ringbuf_str {
unsigned int rd_idx;
unsigned int wrt_idx;
unsigned int buf_len;
};

/****************************************************************************
 * Structure of DL PIT
 ****************************************************************************/
struct dpmaifq_normal_pit {
	unsigned int	packet_type:1;
	unsigned int	c_bit:1;
	unsigned int	buffer_type:1;
	unsigned int	buffer_id:13;
	unsigned int	data_len:16;
	unsigned int	p_data_addr;
	unsigned int	data_addr_ext;
	unsigned int	pit_seq:8;
	unsigned int	h_bid:3;
	unsigned int	reserved1:5;
	unsigned int	ig:1;
	unsigned int	bi_f:2;
	unsigned int	header_offset:5;
	unsigned int	ulq_done:6;
	unsigned int	dlq_done:2;

};

/* packet_type */
#define DES_PT_PD			 0x00
#define DES_PT_MSG			 0x01
/* c_bit */
#define PKT_LAST_ONE	(0x00)
/* buffer_type*/
#define PKT_BUF_FRAG	(0X01)

struct dpmaifq_msg_pit {
	unsigned int	packet_type:1;
	unsigned int	c_bit:1;
	unsigned int	check_sum:2;
	unsigned int	error_bit:1;
	unsigned int	src_qid:3;
	unsigned int	hpc_idx:4;
	unsigned int	reserved:4;
	unsigned int	channel_id:8;
	unsigned int	network_type:3;
	unsigned int	reserved2:4;
	unsigned int	dp:1;

	unsigned int	count_l:16;
	unsigned int	flow:5;
	unsigned int	reserved3:3;
	unsigned int	cmd:3;
	unsigned int	hp_idx:5;

	unsigned int	reserved4:3;
	unsigned int	vbid:13;
	unsigned int	pro:2;
	unsigned int	reserved5:6;
	unsigned int	hash:8;

	unsigned int	pit_seq:8;
	unsigned int	h_bid:3;
	unsigned int	reserved6:5;
	unsigned int	ig:1;
	unsigned int	reserved7:3;
	unsigned int	mr:2;
	unsigned int	reserved8:1;
	unsigned int	ip:1;

	unsigned int	ulq_done:6;
	unsigned int	dlq_done:2;

};

/****************************************************************************
 * Structure of DL BAT
 ****************************************************************************/
struct dpmaif_cur_rx_skb_info {
	bool msg_pit_received;
	struct sk_buff *cur_skb;
	unsigned int cur_chn_idx;
	unsigned int check_sum;
	unsigned int pit_dp;
	int err_payload;
};

struct dpmaif_bat_t {
	unsigned int	p_buffer_addr;
	unsigned int	buffer_addr_ext;
};


struct dpmaif_bat_skb_t {
	struct sk_buff *skb;
	dma_addr_t data_bus_addr;
	unsigned int data_len;
};

struct dpmaif_bat_page_t {
	struct page *page;
	dma_addr_t data_bus_addr;
	unsigned int offset;
	unsigned int data_len;
};

#define MAX_BD_NUM (MAX_SKB_FRAGS + 1)

#ifdef DATA_PATH_TP_CALC
#define DPMAIF_TRAFFIC_MONITOR_INTERVAL 10   
#else
#define DPMAIF_TRAFFIC_MONITOR_INTERVAL 0   /*s: 0 for disable traffic monitor */
#endif

#define SKB_RX_LIST_MAX_LEN 0xFFFFFFFF

struct dpmaif_bat_request {
	void *bat_base;
	dma_addr_t bat_bus_addr;
	unsigned int	bat_size_cnt;
	unsigned short	  bat_wr_idx;
	unsigned short	  bat_rd_idx;
	unsigned short	  bat_rel_rd_idx;
	void *bat_skb_ptr;/* collect skb linked to bat */
	unsigned int	 skb_pkt_cnt;
	unsigned int pkt_buf_sz;

	/* newly added */
	unsigned char *bat_mask;

	atomic_t refcnt;
};

struct dpmaif_rx_queue {
	unsigned char index;
	bool que_started;
	unsigned short budget;

	void *pit_base;
	dma_addr_t pit_bus_addr;
	unsigned int	pit_size_cnt;

	unsigned short	  pit_rd_idx;
	unsigned short	  pit_wr_idx;
	unsigned short	  pit_rel_rd_idx;
	unsigned int reg_int_mask_bak;

	struct dpmaif_bat_request *bat_req; /*for NORMAL_BAT*/
	struct dpmaif_bat_request *bat_frag;  /* for FRG_BAT feature */

	wait_queue_head_t rx_wq;
	struct task_struct *rx_thread;
	struct ccci_skb_queue skb_list;

	/*none napi mode*/
	struct tasklet_struct dpmaif_rxq_task;
	struct workqueue_struct *worker;
	struct work_struct dpmaif_rxq_work;

	atomic_t rx_processing;

	struct napi_struct napi;
	int check_bid_fail_cnt;

	struct md_dpmaif_ctrl *dpmaif_ctrl;
	unsigned int expect_pit_seq;
	unsigned int pit_remain_rel_cnt;
	int cur_irq_cpu;	/* current CPU that isr is running on */
	/* current CPU that rx push thread is running on */
	int cur_rx_thrd_cpu;

	unsigned int pit_seq_fail_cnt;

	struct dpmaif_cur_rx_skb_info rx_data_info;
};

/****************************************************************************
 * Structure of UL DRB
 ****************************************************************************
 */
/*
 * UL unit: WORD == 4bytes, && 1drb == 8bytes,
 * so 1 drb = size_cnt * 2, rd_idx_sw = rd_idx_hw/2.
 */
// #define DPMAIF_UL_DRB_ENTRY_WORD	 2 /* (sizeof(dpmaif_drb_pd)/4)*/

struct dpmaif_drb_pd {
	unsigned int	dtyp:2;
	unsigned int	c_bit:1;
	unsigned int	reserved:13;
	unsigned int	data_len:16;
	unsigned int	p_data_addr;
	unsigned int	data_addr_ext;
	unsigned int	reserved2;
};


/* drb->dtype */
#define DES_DTYP_PD			0x00
#define DES_DTYP_MSG		0x01
#define DES_DRB_CBIT		0x01

struct dpmaif_drb_msg {
	unsigned int	dtyp:2;
	unsigned int	c_bit:1;
	unsigned int	reserved:13;
	unsigned int	packet_len:16;
	unsigned int	count_l:16;
	unsigned int	channel_id:8;
	unsigned int	network_type:3;
	unsigned int	reserved2:1;
	unsigned int	ip_chk:1;
	unsigned int	l4_chk:1;
	unsigned int	reserved3:2;
	unsigned int	reserved4;
	unsigned int	reserved5;
};

struct dpmaif_drb_skb {
	struct sk_buff *skb;

	dma_addr_t bus_addr;
	unsigned short data_len;

	/* just for debug */
	unsigned short drb_idx:13;
	unsigned short is_msg:1;
	unsigned short is_frag:1;
	unsigned short is_last_one:1;
};

struct dpmaif_tx_queue {
	unsigned char index;
	bool que_started;
	atomic_t tx_budget;

	void	*drb_base;
	dma_addr_t drb_bus_addr;
	unsigned int	drb_size_cnt;

	unsigned short		drb_wr_idx;
	unsigned short		drb_rd_idx;
	unsigned short		drb_rel_rd_idx;
	unsigned short		last_ch_id;

	void	*drb_skb_base;
	wait_queue_head_t req_wq;
	struct workqueue_struct *worker;
	struct delayed_work dpmaif_tx_work;
	spinlock_t tx_lock;
	atomic_t tx_processing;
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	unsigned int busy_count;
#endif

	/* newly added */
	struct md_dpmaif_ctrl *dpmaif_ctrl;

	/* tx thread skb_list */
	spinlock_t tx_event_lock;
	struct list_head tx_event_queue;
	unsigned int tx_submit_skb_cnt;
	unsigned int tx_list_max_len;
	unsigned int tx_skb_stat;
	bool drb_lack;
};

enum hifdpmaif_state {
	HIFDPMAIF_STATE_MIN	 = 0,
	HIFDPMAIF_STATE_PWROFF,
	HIFDPMAIF_STATE_PWRON,
	HIFDPMAIF_STATE_EXCEPTION,
	HIFDPMAIF_STATE_MAX,
};

#define DPMA_SKB_SIZE_OVER_HEAD  SKB_DATA_ALIGN(sizeof(struct skb_shared_info))
#define DPMA_SKB_SIZE_EXTRA\
	(SKB_DATA_ALIGN((NET_SKB_PAD) + (DPMA_SKB_SIZE_OVER_HEAD)))
#define DPMA_SKB_SIZE_TRUE(s)		((s) + (DPMA_SKB_SIZE_EXTRA))
#define DPMA_SKB_SIZE_MAX\
	(DPMAIF_HW_BAT_PKTBUF)	/* SHOULD less than PAGE_SIZE */
#define DPMA_SKB_QUEUE_CNT			(1)
#define DPMA_SKB_QUEUE_SIZE\
	((DPMAIF_DL_BAT_ENTRY_SIZE) * DPMA_SKB_SIZE_TRUE(DPMA_SKB_SIZE_MAX))
#define DPMA_SKB_TRUE_SIZE_MIN		(32)
#define DPMA_RELOAD_TH_1			(4)
#define DPMA_RELOAD_TH_2			(5)
/* data path skb pool */
struct dpmaif_map_skb {
	struct list_head head;
	u32 qlen;
	spinlock_t lock;
};

struct dpmaif_skb_info {
	struct list_head entry;
	struct sk_buff *skb;
	unsigned int data_len;
	unsigned long long data_bus_addr;
};

struct dpmaif_skb_queue {
	//struct sk_buff_head skb_list;
	struct dpmaif_map_skb skb_list;
	unsigned int size;
	unsigned int max_len;
	unsigned long busy_cnt;
};

struct dpmaif_skb_pool {
	struct dpmaif_skb_queue queue[DPMA_SKB_QUEUE_CNT];
	struct workqueue_struct *pool_reload_work_queue;
	struct work_struct reload_work;
	unsigned int queue_cnt;
};

/*
 *	DPMAIF over PCIE interrupt structure
 */
struct dpmaif_isr_para {
	struct md_dpmaif_ctrl *dpmaif_ctrl;
	unsigned char pcie_ext_int;
	unsigned char dlq_id;
};

struct dpmaif_tx_event {
	struct list_head entry;
	unsigned char md_id;
	int qno;
	struct sk_buff *skb;
	int blocking;
	int drb_cnt;
};

struct md_dpmaif_ctrl {
	struct mtk_pci_dev *mtk_dev;
	struct ccmni_ctl_block *ctlb;
	bool napi_enable;
	enum hifdpmaif_state dpmaif_state;
	struct dpmaif_tx_queue txq[DPMAIF_TXQ_NUM];
	struct dpmaif_rx_queue rxq[DPMAIF_RXQ_NUM];
	struct dma_pool *tx_drb_dmapool;
	struct dma_pool *rx_pit_dmapool;
	struct dma_pool *rx_bat_dmapool;

	unsigned char rxq_ext_int_mapping[DPMAIF_RXQ_NUM];
	struct dpmaif_isr_para isr_para[DPMAIF_RXQ_NUM];

	spinlock_t bat_release_lock;
	struct dpmaif_bat_request bat_req;	/* for NORMAL_BAT feature */
	spinlock_t frag_bat_release_lock;
	struct dpmaif_bat_request bat_frag;	 /* for FRG_BAT feature */

	struct workqueue_struct *bat_rel_work_queue;
	struct work_struct bat_rel_work;

	unsigned char md_id;
	unsigned char hif_id;
	struct ccci_hif_traffic traffic_info;
	atomic_t dpmaif_irq_enabled;

	/* dpmaif HW information */
	struct pcie_hw_info pcie_hw_info;
	struct dpmaif_hw_info hif_hw_info;

	struct dpmaif_skb_pool skb_pool;

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	unsigned long long tx_traffic_monitor[DPMAIF_TXQ_NUM];
	unsigned long long rx_traffic_monitor[DPMAIF_RXQ_NUM];
	unsigned long long tx_pre_traffic_monitor[DPMAIF_TXQ_NUM];
	unsigned long long tx_payload_monitor[DPMAIF_TXQ_NUM];
	unsigned long long tx_done_last_start_time[DPMAIF_TXQ_NUM];
	unsigned int tx_done_last_count[DPMAIF_TXQ_NUM];

	struct timer_list traffic_monitor;
	char traffic_started;
#endif

	bool dpmaif_sw_init_done;
	mtk_l_res_t lock_user;
	struct md_pm_entity dpmaif_pm_entity;

	/* TX thread */
	wait_queue_head_t tx_wq;
	struct task_struct *tx_thread;
	unsigned char txq_select_times;
};


int dpmaif_hif_init(unsigned char md_id, struct ccmni_ctl_block *ctlb);
void dpmaif_hif_exit(unsigned char md_id, struct ccmni_ctl_block *ctlb);

int dpmaif_tx_send_skb(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl, 
	int qno, struct sk_buff *skb, int blocking);

int dpmaif_md_state_callback(unsigned char md_id,
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char state);

int dpmaif_napi_rx_poll(struct napi_struct *napi, int budget);
struct napi_struct *dpmaif_get_napi(struct md_dpmaif_ctrl *dpmaif_ctrl, int qno);

#endif				/* __MODEM_DPMA_H__ */
