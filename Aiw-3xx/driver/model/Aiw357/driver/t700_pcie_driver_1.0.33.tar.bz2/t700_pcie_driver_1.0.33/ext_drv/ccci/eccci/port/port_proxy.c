// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/kthread.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/poll.h>
#include <linux/string.h>
#include <linux/netlink.h>
#ifdef CONFIG_COMPAT
#include <linux/compat.h>
#endif
#include <linux/string.h>
#include <mt-plat/mtk_boot_common.h>
#include <mt-plat/mtk_ccci_common.h>

#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_bm.h"
#include "ccci_fsm.h"
#include "ccci_modem.h"
#include "ccci_hif.h"
#include "ccci_port.h"
#include "port_proxy.h"
#include "modem_sys.h"
#include "ccci_fsm_internal.h"
#include "port_cfg.h"

#define CREATE_TRACE_POINTS
#include "port_event.h"

#define TAG PORT
#define CCCI_DEV_NAME "CCCI_PORT"

//XSQUARE
#include <linux/version.h>


/*****************************************************************************/
/* Port_proxy: instance definition, which is alloced for every Modem */
/*****************************************************************************/
struct port_proxy *proxy_table[MAX_MD_NUM];
#define GET_PORT_PROXY(md_id) (proxy_table[md_id])
#define SET_PORT_PROXY(md_id, proxy_p) (proxy_table[md_id] = proxy_p)

#define CCCI_SYSFS_PORTS

#define PORT_NETLINK_MSG_MAX_PAYLOAD		(64)
#define PORT_NOTIFY_PROTOCOL				(NETLINK_USERSOCK)
#define PORT_NETLINK_PORT_ID				(100)
#define PORT_STATE_BROADCAST_GROUP			(21)
#define PORT_MINIDUMP_BROADCAST_GROUP		(22)

#ifdef CCCI_SYSFS_PORTS
struct kobject ccci_ports_kobj;

struct ccci_ports_attribute {
	struct attribute attr;
	ssize_t (*show)(char *buf);
	ssize_t (*store)(const char *buf, size_t count);
};

#define CCCI_PORTS_ATTR(_name, _mode, _show, _store)  \
static struct ccci_ports_attribute ccci_attr_##_name = { \
	.attr = {.name = __stringify(_name), .mode = _mode}, \
	.show = _show, \
	.store = _store, \
}

static void ccci_ports_obj_release(struct kobject *kobj)
{
	MTK_INFO_LOG(CHAR, "ccci ports obj release.");
}

static ssize_t ccci_ports_attr_show(struct kobject *kobj,
	struct attribute *attr, char *buf)
{
	ssize_t len = 0;
	struct ccci_ports_attribute *a =
		container_of(attr, struct ccci_ports_attribute, attr);

	if (a->show)
		len = a->show(buf);

	return len;
}

static ssize_t ccci_ports_attr_store(struct kobject *kobj,
	struct attribute *attr, const char *buf, size_t count)
{
	ssize_t len = 0;
	struct ccci_ports_attribute *a =
		container_of(attr, struct ccci_ports_attribute, attr);

	if (a->store)
		len = a->store(buf, count);

	return len;
}

static const struct sysfs_ops ccci_ports_sysfs_ops = {
	.show = ccci_ports_attr_show,
	.store = ccci_ports_attr_store
};

static ssize_t ccci_port_add_show(char *buf)
{
	return snprintf(buf, 32, "ccci port add.\n");
}

static ssize_t ccci_port_add_store(const char *buf, size_t count)
{
	int i = 0;
	char *port_buf = NULL;
	char arr_buf[20] = {0};
	int ret = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	strcpy(arr_buf, buf);
	port_buf = arr_buf;
	port_buf = strsep(&port_buf, "\r\n");
	proxy_p = GET_PORT_PROXY(MD_SYS1);
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		ret = strcmp(port->name, port_buf);
		if ((ret == 0) && (port->ops->enable_chl != NULL))
			port->ops->enable_chl(port);
	}
	return count;
}
CCCI_PORTS_ATTR(port_add, 0660, &ccci_port_add_show, &ccci_port_add_store);

static ssize_t ccci_port_remove_show(char *buf)
{
	return snprintf(buf, 32, "ccci port remove.\n");
}

static ssize_t ccci_port_remove_store(const char *buf, size_t count)
{
	int i = 0;
	char *port_buf = NULL;
	char _buf[20] = {0};
	int ret = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	strcpy(_buf, buf);
	port_buf = _buf;
	port_buf = strsep(&port_buf, "\r\n");
	proxy_p = GET_PORT_PROXY(MD_SYS1);
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		ret = strcmp(port->name, port_buf);
		if ((ret == 0) && (port->ops->disable_chl != NULL))
			port->ops->disable_chl(port);
	}

	return count;
}
CCCI_PORTS_ATTR(port_remove, 0660, &ccci_port_remove_show,
	&ccci_port_remove_store);

static ssize_t ccci_port_status_show(char *buf)
{
	int i = 0;
	int count = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	proxy_p = GET_PORT_PROXY(MD_SYS1);

	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (port->chn_crt_stat)
			count += snprintf((buf + count), (count + 32),
				"%s, Enable\n", port->name);
		else
			count += snprintf((buf + count), (count + 32),
				"%s, Disable\n", port->name);
	}

	return count;
}



static ssize_t ccci_port_status_store(const char *buf, size_t count)
{
	return count;
}
CCCI_PORTS_ATTR(port_status, 0660,
	&ccci_port_status_show, &ccci_port_status_store);

static ssize_t ccci_minidump_status_store(const char *buf, size_t count)
{
	int i = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	proxy_p = GET_PORT_PROXY(MD_SYS1);

	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (!strcmp(port->name, DEVICE_MINIDUMP_NOTIFY_PORT_NAME)) {
			port_broadcast_minidump_status(port, buf, count);
			break;
		}
	}

	return count;
}

CCCI_PORTS_ATTR(minidump_status, 0222,
	NULL, &ccci_minidump_status_store);


static struct attribute *ccci_ports_default_attrs[] = {
	&ccci_attr_port_add.attr,
	&ccci_attr_port_remove.attr,
	&ccci_attr_port_status.attr,
	&ccci_attr_minidump_status.attr,
	NULL
};

static struct kobj_type ccci_ports_ktype = {
	.release = ccci_ports_obj_release,
	.sysfs_ops = &ccci_ports_sysfs_ops,
	.default_attrs = ccci_ports_default_attrs
};

int ccci_sysfs_add_ports(struct kobject *proxy_kobj,
	struct kobject *parent_kobj)
{
	int ret = 0;

	ret = kobject_init_and_add(proxy_kobj, &ccci_ports_ktype,
		parent_kobj, "ports");
	if (ret < 0) {
		kobject_put(proxy_kobj);
		return -1;
	}
	return 0;
}

void ccci_sysfs_release_ports(struct kobject *proxy_kobj)
{
	kobject_put(proxy_kobj);
}
#endif /* CCCI_SYSFS_PORTS */

static inline void proxy_set_critical_user(struct port_proxy *proxy_p,
	int user_id, int enabled)
{
	if (enabled)
		proxy_p->critical_user_active |= (1 << user_id);
	else
		proxy_p->critical_user_active &= ~(1 << user_id);
}

static inline int proxy_get_critical_user(struct port_proxy *proxy_p,
	int user_id)
{
	return ((proxy_p->critical_user_active & (1 << user_id)) >> user_id);
}
/*
 * Sequence number help to check lose packets
 */
void port_inc_tx_seq_num(struct port_t *port, struct ccci_header *ccci_h)
{
	if (ccci_h != NULL && port != NULL) {
		ccci_h->seq_num = port->seq_nums[MTK_OUT];
		ccci_h->assert_bit = 1;
	}
}

static inline void port_update_rx_seq_num(struct port_t *port, u16 seq_num)
{
	port->seq_nums[MTK_IN] = seq_num;
}

static inline u16 port_check_rx_seq_num(unsigned char md_id,
		struct port_t *port, struct ccci_header *ccci_h)
{
	u16 channel, seq_num, assert_bit;
	unsigned int param[3] = {0};

	channel = ccci_h->channel;
	seq_num = ccci_h->seq_num;
	assert_bit = ccci_h->assert_bit;
	if (assert_bit && port->seq_nums[MTK_IN] != 0 &&
			((seq_num - port->seq_nums[MTK_IN]) & 0x7FFF) != 1) {
		MTK_ERR_LOG(CORE,
			"channel %d seq number out-of-order %d->%d (data: %X, %X)\n",
			channel, seq_num, port->seq_nums[MTK_IN],
			ccci_h->data[0], ccci_h->data[1]);
		ccci_md_dump_info(md_id, DUMP_FLAG_DATA_HIF,
			NULL, (int)port->rxq_index);
		param[0] = channel;
		param[1] = port->seq_nums[MTK_IN];
		param[2] = seq_num;
		ccci_md_force_assert(md_id, MD_FORCE_ASSERT_BY_MD_SEQ_ERROR,
			(char *)param, sizeof(param));
	}
	return seq_num;
}

void port_reset(unsigned char md_id)
{
	struct port_t *port;
	struct port_proxy *proxy_p;
	int port_index;

	proxy_p = GET_PORT_PROXY(md_id);
	if (!proxy_p) {
		MTK_CRIT_LOG(CHAR, "invalid port proxy\n");
		return;
	}
	for (port_index = 0;  port_index < proxy_p->port_number; port_index++) {
		port = proxy_p->ports + port_index;
		port->tx_busy_count = 0;
		port->rx_busy_count = 0;
		port->seq_nums[MTK_IN] = -1;
		port->seq_nums[MTK_OUT] = 0;
	}
}
/****************************************************************************/
/*REGION: default char device operation definition for node,
 * which export node for userspace
 ****************************************************************************/
int port_dev_open(struct inode *inode, struct file *file)
{
	int md_id;
	int major = imajor(inode);
	int minor = iminor(inode);
	struct port_t *port;

	port = port_get_by_node(major, minor);

	if (strcmp(port->name, "brom_download") != 0) {
		if (atomic_read(&port->usage_cnt))
			return -EBUSY;
	}
	md_id = port->md_id;
	MTK_INFO_LOG(CHAR, "port %s open with flag %X by %s\n", port->name,
		file->f_flags, current->comm);
	atomic_inc(&port->usage_cnt);
	file->private_data = port;
	nonseekable_open(inode, file);
	port_user_register(port);
	return 0;
}

int port_dev_close(struct inode *inode, struct file *file)
{
	struct port_t *port = file->private_data;
	struct sk_buff *skb = NULL;
	unsigned long flags;
	int clear_cnt = 0;

	/* 0. decrease usage count, so when we ask more,
	 * the packet can be dropped in recv_request
	 */
	atomic_dec(&port->usage_cnt);
	/* 1. purge Rx request list */
	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
	while ((skb = __skb_dequeue(&port->rx_skb_list)) != NULL) {
		ccci_free_skb(skb);
		clear_cnt++;
	}
	port->rx_drop_cnt += clear_cnt;
	/*	flush Rx */
	port_ask_more_req_to_md(port);
	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
	MTK_INFO_LOG(CHAR,
		"port %s close rx_len=%u empty=%d, clear_cnt=%d, drop=%u\n",
		port->name, port->rx_skb_list.qlen,
		skb_queue_empty(&port->rx_skb_list),
		clear_cnt, port->rx_drop_cnt);
	port_user_unregister(port);

	return 0;
}

ssize_t port_dev_read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
	struct port_t *port = file->private_data;
	struct sk_buff *skb = NULL;
	int ret = 0, read_len = 0, full_req_done = 0;
	unsigned long flags = 0;

READ_START:
	/* 1. get incoming request */
#ifdef PORT_EVENT
	trace_port_dev_read(port->name, count, port->rx_skb_list.qlen);
#endif //PORT_EVENT
	MTK_DEBUG_LIMITED_LOG(CHAR, "port:%s, data size: %zu , rx_skb_list:%d\n",
		port->name, count, port->rx_skb_list.qlen);
	if (skb_queue_empty(&port->rx_skb_list)) {
		if (!(file->f_flags & O_NONBLOCK)) {
			spin_lock_irq(&port->rx_wq.lock);
			ret = wait_event_interruptible_locked_irq(port->rx_wq,
				!skb_queue_empty(&port->rx_skb_list));
			spin_unlock_irq(&port->rx_wq.lock);
			if (ret == -ERESTARTSYS) {
				ret = -EINTR;
				goto exit;
			}
		} else {
			ret = -EAGAIN;
			goto exit;
		}
	}
	//CCCI_DEBUG_LOG(md_id, CHAR,
	//"read on %s for %zu\n", port->name, count);
	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
	if (skb_queue_empty(&port->rx_skb_list)) {
		spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
		if (!(file->f_flags & O_NONBLOCK)) {
			goto READ_START;
		} else {
			ret = -EAGAIN;
			goto exit;
		}
	}

	skb = skb_peek(&port->rx_skb_list);
	read_len = skb->len;

	if (count >= read_len) {
		full_req_done = 1;
		__skb_unlink(skb, &port->rx_skb_list);
		/*
		 * here we only ask for more request when rx list is empty.
		 * no need to be too gready, because for most of the case,
		 * queue will not stop sending request to port.actually we
		 * just need to ask by ourselves when we rejected requests
		 * before. these rejected requests will staty in queue's
		 * buffer and may never get a chance to be
		 * handled again.
		 */
		if (port->rx_skb_list.qlen == 0)
			port_ask_more_req_to_md(port);
	} else {
		read_len = count;
	}
	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
	if (port->flags & PORT_F_CH_TRAFFIC)
		port_ch_dump(port, 0, skb->data, read_len);
	/* 3. copy to user */
	if (copy_to_user(buf, skb->data, read_len)) {
		MTK_ERR_LOG(CHAR, "read on %s, copy to user failed, %d/%zu\n",
			port->name, read_len, count);
		ret = -EFAULT;
	}
	skb_pull(skb, read_len);
	/* 4. free request */
	if (full_req_done)
		ccci_free_skb(skb);

 exit:
	return ret ? ret : read_len;
}

ssize_t port_dev_write(struct file *file,
	const char __user *buf, size_t count, loff_t *ppos)
{
	struct port_t *port = file->private_data;
	unsigned char blocking = !(file->f_flags & O_NONBLOCK);
	struct sk_buff *skb = NULL;
	struct ccci_header *ccci_h = NULL;
	size_t actual_count = 0, alloc_size = 0, txq_mtu = 0;
	int ret = 0;
	int md_id = port->md_id;
	int md_state;
	int i, multi_packet = 1;

	if (count == 0)
		return -EINVAL;

	md_state = ccci_fsm_get_md_state(md_id);
	MTK_DEBUG_LIMITED_LOG(CHAR,
		"port:%s, md_state; %d, data size: %zu\n",
		port->name, md_state, count);
	if (md_state == BOOT_WAITING_FOR_HS1 ||
		md_state == BOOT_WAITING_FOR_HS2) {
		MTK_ERR_LOG(CHAR,
			"port %s ch%d write fail when md_state=%d !!!\n",
			port->name, port->tx_ch, md_state);
		return -ENODEV;
	}

	if (unlikely(port_write_room_to_md(port) <= 0 && !blocking)) {
		return -EAGAIN;
	}
	txq_mtu = ccci_hif_get_queue_mtu(port->md_id,
				port->path_id, port->txq_index);
	if (port->flags & PORT_F_RAW_DATA ||
		port->flags & PORT_F_USER_HEADER) {
		if (port->flags & PORT_F_USER_HEADER && count > txq_mtu) {
			MTK_ERR_LOG(CHAR,
				"reject packet(size=%zu ), larger than MTU on %s\n",
				count, port->name);
			ret = -ENOMEM;
			goto err_out;
		} else {
			actual_count = count > txq_mtu ? txq_mtu : count;
			alloc_size = actual_count;
		}
	} else {
		actual_count = (count + CCCI_H_ELEN) > txq_mtu ?
			(txq_mtu - CCCI_H_ELEN) : count;
		alloc_size = actual_count + CCCI_H_ELEN;
		if ((count + CCCI_H_ELEN) > txq_mtu && (port->tx_ch == CCCI_MBIM_TX || (port->tx_ch >= CCCI_DSS0_TX && port->tx_ch <= CCCI_DSS7_TX))) {
			multi_packet = (count + txq_mtu - CCCI_H_ELEN - 1) / (txq_mtu - CCCI_H_ELEN);
			MTK_DEBUG_LOG(CHAR, "multi_packet = %d", multi_packet);
		}
	}
	mutex_lock(&port->tx_mutex_lock);
	/* loop start */
	for (i = 0; i < multi_packet; i++) {
	if (multi_packet > 1 && multi_packet == i + 1) {
		actual_count = count % (txq_mtu - CCCI_H_ELEN);
		alloc_size = actual_count + CCCI_H_ELEN;
	}
	MTK_DEBUG_LOG(CHAR, "[%d-%d]port mtu:%ld, count:%ld, actual_count:%ld, alloc_size:%ld\n",
		multi_packet, i, txq_mtu, count, actual_count, alloc_size);
	skb = ccci_alloc_skb(alloc_size, 1, blocking);
	if (skb) {
		if (port->flags & PORT_F_RAW_DATA) {
		/* get user data */
			ret = copy_from_user(skb_put(skb, actual_count),
				buf, actual_count);
			if (port->flags & PORT_F_USER_HEADER) {
			/* ccci_header provided by user,
			 * For only send ccci_header without additional data
			 * case, data[0]=CCCI_MAGIC_NUM, data[1]=user_data,
			 * ch=tx_channel, reserved=no_use For send ccci_header
			 * with additional data case, data[0]=0,
			 * data[1]=data_size, ch=tx_channel, reserved=user_data
			 */
				ccci_h = (struct ccci_header *)skb->data;
				if (actual_count == CCCI_H_LEN)
					ccci_h->data[0] = CCCI_MAGIC_NUM;
				else
					ccci_h->data[1] = actual_count;

				ccci_h->channel = port->tx_ch;
			}
		} else {
		/* ccci_header is provided by driver */
			ccci_h = (struct ccci_header *)skb_put(skb, CCCI_H_LEN);
			ccci_h->data[0] = 0;
			ccci_h->data[1] = actual_count + CCCI_H_LEN;
			ccci_h->channel = port->tx_ch;
			ccci_h->reserved = 0;
		/* get user data */
			ret = copy_from_user(skb_put(skb, actual_count),
					buf + i * (txq_mtu - CCCI_H_ELEN), actual_count);
		}
		if (ret) {
			MTK_ERR_LOG(CHAR, "copy_from_user error\n");
			goto err_out;
		}
#ifdef ENABLE_CCCI_DRI_UT
		if (ccci_h != NULL)
			ccci_h->channel = port->rx_ch;
#endif
		if (port->flags & PORT_F_CH_TRAFFIC) {
			if (port->flags & PORT_F_USER_HEADER)
				port_ch_dump(port, 1, skb->data, actual_count);
			else
				port_ch_dump(port, 1, skb->data + CCCI_H_LEN,
					actual_count);
		}
#ifdef PORT_EVENT
		trace_port_dev_write(port->name,
			md_state, skb, count, blocking);
#endif /* PORT_EVENT */
		/* send out */
		port_inc_tx_seq_num(port, ccci_h);
		ret = port_send_skb_to_md(port, skb, blocking);
		if (ret) {
			if (ret == -EBUSY && !blocking)
				ret = -EAGAIN;
			goto err_out;
		} else {
			/*record the port seq_num after the data is sent to HIF*/
			port->seq_nums[MTK_OUT]++;
		}
		if (multi_packet == 1) {
			mutex_unlock(&port->tx_mutex_lock);
			return actual_count;
		}
		else if (multi_packet == i + 1) {
			mutex_unlock(&port->tx_mutex_lock);
			return count;
		}
	} else {
		/* consider this case as non-blocking */
		mutex_unlock(&port->tx_mutex_lock);
		return -EBUSY;
	}
	} /* loop end */

err_out:
	mutex_unlock(&port->tx_mutex_lock);
	if (ret != ENOMEM) {
		MTK_ERR_LOG(CHAR, "write error done on %s, size=%zu, ret=%d\n",
			 port->name, actual_count, ret);
		ccci_free_skb(skb);
	}
	return ret;
}

long port_dev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	long ret = 0;
	struct port_t *port = file->private_data;

	switch (cmd) {
	case CCCI_IOC_SET_HEADER:
		port->flags |= PORT_F_USER_HEADER;
		break;
	case CCCI_IOC_CLR_HEADER:
		port->flags &= ~PORT_F_USER_HEADER;
		break;
	default:
		ret = -1;
		break;
	}
	if (ret == -1)
		ret = ccci_fsm_ioctl(port->md_id, cmd, arg);

	return ret;
}

#ifdef CONFIG_COMPAT
long port_dev_compat_ioctl(struct file *filp,
	unsigned int cmd, unsigned long arg)
{
	if (!filp->f_op || !filp->f_op->unlocked_ioctl)
		return -ENOTTY;

	switch (cmd) {
	case CCCI_IOC_PCM_BASE_ADDR:
	case CCCI_IOC_PCM_LEN:
	case CCCI_IOC_ALLOC_MD_LOG_MEM:
	case CCCI_IOC_FORCE_FD:
	case CCCI_IOC_AP_ENG_BUILD:
	case CCCI_IOC_GET_MD_MEM_SIZE:
		MTK_ERR_LOG(CHAR, "deprecated cmd:%d\n", cmd);
		return 0;
	default:
		return filp->f_op->unlocked_ioctl(filp, cmd,
			(unsigned long)compat_ptr(arg));
	}
}
#endif

/*****************************************************************************/
/*REGION: port common API implementation,*/
/*these APIs are valiable for every port*/
/*****************************************************************************/
static inline void port_struct_init(struct port_t *port,
	struct port_proxy *port_p)
{
	INIT_LIST_HEAD(&port->entry);
	INIT_LIST_HEAD(&port->exp_entry);
	INIT_LIST_HEAD(&port->queue_entry);
	skb_queue_head_init(&port->rx_skb_list);
	init_waitqueue_head(&port->rx_wq);
	port->tx_busy_count = 0;
	port->rx_busy_count = 0;
	port->seq_nums[MTK_IN] = -1;
	port->seq_nums[MTK_OUT] = 0;
	atomic_set(&port->usage_cnt, 0);
	port->port_proxy = port_p;
	port->md_id = port_p->md_id;
}

static void port_dump_string(struct port_t *port,
	int dir, void *msg_buf, int len)
{
#define DUMP_BUF_SIZE 32
	unsigned char *char_ptr = (unsigned char *)msg_buf;
	char buf[DUMP_BUF_SIZE];
	int i, j;
	u64 ts_nsec;
	unsigned long rem_nsec;
	char *replace_str;

	for (i = 0, j = 0; i < len && i < DUMP_BUF_SIZE
		&& j + 4 < DUMP_BUF_SIZE; i++) {
		if (((char_ptr[i] >= 32) && (char_ptr[i] <= 126))) {
			buf[j] = char_ptr[i];
			j += 1;
		} else if (char_ptr[i] == '\r' ||
			char_ptr[i] == '\n' ||
			char_ptr[i] == '\t') {
			switch (char_ptr[i]) {
			case '\r':
				replace_str = "\\r";
				break;
			case '\n':
				replace_str = "\\n";
				break;
			case '\t':
				replace_str = "\\t";
				break;
			default:
				replace_str = "";
				break;
			}
			snprintf(buf+j, DUMP_BUF_SIZE - j, "%s", replace_str);
			j += 2;
		} else {
			snprintf(buf+j, DUMP_BUF_SIZE - j,
				"[%02X]", char_ptr[i]);
			j += 4;
		}
	}
	buf[j] = '\0';
	ts_nsec = local_clock();
	rem_nsec = do_div(ts_nsec, 1000000000);
	if (dir == 0)
		MTK_DEBUG_LOG(TAG, "[%5lu.%06lu]C:%d,%d(%d,%d,%d) %s: %d<%s\n",
			(unsigned long)ts_nsec, rem_nsec / 1000, port->flags,
			port->rx_ch, port->rx_skb_list.qlen, port->rx_pkg_cnt,
			port->rx_drop_cnt, "R", len, buf);
	else
		MTK_DEBUG_LOG(TAG, "[%5lu.%06lu]C:%d,%d(%d) %s: %d>%s\n",
			(unsigned long)ts_nsec, rem_nsec / 1000, port->flags,
			port->tx_ch, port->tx_pkg_cnt, "W", len, buf);
}
static void port_dump_raw_data(struct port_t *port,
	int dir, void *msg_buf, int len)
{
#define DUMP_RAW_DATA_SIZE 16
	unsigned int *curr_p = (unsigned int *)msg_buf;
	unsigned char *curr_ch_p;
	int _16_fix_num = len / 16;
	int tail_num = len % 16;
	char buf[16];
	int i, j;
	int dump_size;
	u64 ts_nsec;
	unsigned long rem_nsec;

	if (curr_p == NULL) {
		MTK_DEBUG_LOG(TAG, "start_addr <NULL>\n");
		return;
	}
	if (len == 0) {
		MTK_DEBUG_LOG(TAG, "len [0]\n");
		return;
	}
	if (port->rx_ch == CCCI_FS_RX)
		curr_p++;

	dump_size = len > DUMP_RAW_DATA_SIZE ? DUMP_RAW_DATA_SIZE : len;
	_16_fix_num = dump_size / 16;
	tail_num = dump_size % 16;

	ts_nsec = local_clock();
	rem_nsec = do_div(ts_nsec, 1000000000);

	if (dir == 0)
		MTK_DEBUG_LOG(TAG, "[%5lu.%06lu]C:%d,%d(%d,%d,%d) %s: %d<",
			(unsigned long)ts_nsec, rem_nsec / 1000, port->flags,
			port->rx_ch, port->rx_skb_list.qlen, port->rx_pkg_cnt,
			port->rx_drop_cnt, "R", len);
	else
		MTK_DEBUG_LOG(TAG, "[%5lu.%06lu]C:%d,%d(%d) %s: %d>",
			(unsigned long)ts_nsec, rem_nsec / 1000, port->flags,
			port->tx_ch, port->tx_pkg_cnt, "W", len);
	/* Fix section */
	for (i = 0; i < _16_fix_num; i++) {
		MTK_DEBUG_LOG(TAG, "%03X: %08X %08X %08X %08X\n",
			i * 16, *curr_p, *(curr_p + 1),
			*(curr_p + 2), *(curr_p + 3));
		curr_p += 4;
	}

	/* Tail section */
	if (tail_num > 0) {
		curr_ch_p = (unsigned char *)curr_p;
		for (j = 0; j < tail_num; j++) {
			buf[j] = *curr_ch_p;
			curr_ch_p++;
		}
		for (; j < 16; j++)
			buf[j] = 0;
		curr_p = (unsigned int *)buf;
		MTK_DEBUG_LOG(TAG, "%03X: %08X %08X %08X %08X\n",
			i * 16, *curr_p, *(curr_p + 1),
			*(curr_p + 2), *(curr_p + 3));
	}
}
static inline int port_get_queue_no(struct port_t *port, enum direction dir,
			int is_ack)
{
	int md_state;
	int md_id = port->md_id;

	md_state = ccci_fsm_get_md_state(md_id);

	if (dir == MTK_OUT) {
		if (is_ack == 1)
			return (md_state == EXCEPTION ? port->txq_exp_index
			: (port->txq_exp_index&0x0F));
		return (md_state == EXCEPTION ?
			port->txq_exp_index : port->txq_index);
	} else if (dir == MTK_IN)
		return (md_state == EXCEPTION ?
			port->rxq_exp_index : port->rxq_index);
	else
		return -1;
}

static inline int port_adjust_skb(struct port_t *port, struct sk_buff *skb)
{
	struct ccci_header *ccci_h = NULL;

	ccci_h = (struct ccci_header *)skb->data;
	if (port->flags & PORT_F_USER_HEADER) { /* header provide by user */
		/*CCCI_MON_CH should fall in here, as header must be
		 * send to md_init
		 */
		if (ccci_h->data[0] == CCCI_MAGIC_NUM) {
			if (unlikely(skb->len > sizeof(struct ccci_header))) {
				MTK_ERR_LOG(TAG,
					"recv unexpected data for %s, skb->len=%d\n",
					port->name, skb->len);
				skb_trim(skb, sizeof(struct ccci_header));
			}
		}
	} else {
		/* remove CCCI header */
		skb_pull(skb, sizeof(struct ccci_header));
	}

	return 0;
}
/* This API is used to receive raw data from dedicated queue*/

int port_recv_skb_from_dedicatedQ(unsigned char md_id, unsigned char hif_id,
	unsigned char qno, struct sk_buff *skb)
{
	int ret = 0;
	struct port_proxy *proxy_p;
	struct port_t *port;

	proxy_p = GET_PORT_PROXY(md_id);
	port = proxy_p->dedicated_ports[hif_id][qno];

	if (likely(skb && port->ops->recv_skb))
		ret = port->ops->recv_skb(port, skb);

	if (ret < 0) {
		if (ret != -CCCI_ERR_PORT_RX_FULL) {
			MTK_ERR_LOG(TAG, "drop on rx ch %d, ret %d\n", port->rx_ch, ret);
			ccci_free_skb(skb);
			ret = -CCCI_ERR_DROP_PACKET;
		}
	}
	return ret;
}
/*
 *This API is common API for port to resceive skb form modem or HIF,
 *
 */
int port_recv_skb(struct port_t *port, struct sk_buff *skb)
{
	unsigned long flags;
	struct ccci_header *ccci_h = (struct ccci_header *)skb->data;

	if (!(port->flags & PORT_F_WITH_CHAR_NODE)) {
		if (!strcmp(port->name, DEVICE_MINIDUMP_NOTIFY_PORT_NAME)) {
			skb_pull(skb, CCCI_H_LEN);
			port_broadcast_minidump_status(port, skb->data, skb->len);
			ccci_free_skb(skb);
			return 0;
		}
	}

	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
#ifdef PORT_EVENT
	trace_port_recv_skb(port->name, skb, port->rx_skb_list.qlen, flags);
#endif /* PORT_EVENT */
	MTK_DEBUG_LOG(TAG, "recv on %s, rx_skb_list len=%d\n",
		port->name, port->rx_skb_list.qlen);
	if (port->rx_skb_list.qlen < port->rx_length_th) {
		port->flags &= ~PORT_F_RX_FULLED;
		if (port->flags & PORT_F_ADJUST_HEADER)
			port_adjust_skb(port, skb);
		if (!(port->flags & PORT_F_RAW_DATA)
			&& ccci_h->channel == CCCI_STATUS_RX)
			port->skb_handler(port, skb);
		else
			__skb_queue_tail(&port->rx_skb_list, skb);
		port->rx_pkg_cnt++;
		spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
		spin_lock_irqsave(&port->rx_wq.lock, flags);
		wake_up_all_locked(&port->rx_wq);
		spin_unlock_irqrestore(&port->rx_wq.lock, flags);

		return 0;
	}
	port->flags |= PORT_F_RX_FULLED;
	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
	if (port->flags & PORT_F_ALLOW_DROP) {
		MTK_ERR_LOG(TAG, "port %s Rx full, drop packet\n", port->name);
		goto drop;
	} else
		return -CCCI_ERR_PORT_RX_FULL;

 drop:
	port->rx_drop_cnt++;
	return -CCCI_ERR_DROP_PACKET;
}

int port_kthread_handler(void *arg)
{
	struct port_t *port = arg;
	/* struct sched_param param = { .sched_priority = 1 }; */
	struct sk_buff *skb;
	unsigned long flags;
	int ret = 0;

	while (1) {
		if (skb_queue_empty(&port->rx_skb_list)) {
			ret = wait_event_interruptible(port->rx_wq,
				(!skb_queue_empty(&port->rx_skb_list)
				|| kthread_should_stop()));
			if (ret == -ERESTARTSYS)
				continue;	/* FIXME */
		}
		if (kthread_should_stop())
			break;

		/* 1. dequeue */
		spin_lock_irqsave(&port->rx_skb_list.lock, flags);
		skb = __skb_dequeue(&port->rx_skb_list);
		if (port->rx_skb_list.qlen == 0)
			port_ask_more_req_to_md(port);
		spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
#ifdef PORT_EVENT
		trace_port_kthread_handler(port->name, skb);
#endif /* PORT_EVENT */
		/* 2. process port skb */
		if (port->skb_handler)
			port->skb_handler(port, skb);
	}
	return 0;
}

/*
 *This API is called by port,
 *which wants to dump message as ascii string or raw binary format,
 */
void port_ch_dump(struct port_t *port, int dir, void *msg_buf, int len)
{
	if (port->flags & PORT_F_DUMP_RAW_DATA)
		port_dump_raw_data(port, dir, msg_buf, len);
	else
		port_dump_string(port, dir, msg_buf, len);
}


int port_ask_more_req_to_md(struct port_t *port)
{
	int ret = -1;
	int rx_qno = port_get_queue_no(port, MTK_IN, -1);

	if (port->flags & PORT_F_RX_FULLED)
		ret = ccci_hif_ask_more_request(port->md_id,
			GET_PATH_FLAG(port->path_id), rx_qno);
	return ret;
}

int port_write_room_to_md(struct port_t *port)
{
	int ret = -1;
	int tx_qno;

	tx_qno = port_get_queue_no(port, MTK_OUT, -1);
	ret = ccci_hif_write_room(port->md_id,
			port->path_id, tx_qno);
	return ret;
}

int port_user_register(struct port_t *port)
{
	int md_id = port->md_id;
	int rx_ch = port->rx_ch;
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	if (rx_ch == CCCI_FS_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_FS, 1);
	if (rx_ch == CCCI_UART2_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_MUXD, 1);
	if (rx_ch == CCCI_MD_LOG_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_MDLOG, 1);
	if (rx_ch == CCCI_UART1_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_META, 1);
	return 0;
}

int port_user_unregister(struct port_t *port)
{
	int rx_ch = port->rx_ch;
	int md_id = port->md_id;
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);

	if(proxy_p == NULL){
		MTK_INFO_LOG(TAG, "proxy has been free\n");
		return 0;
	}

        if(!proxy_p)
        {
            MTK_INFO_LOG(TAG, "Port proxy already removed\n");
            return 0;
        }

	if (rx_ch == CCCI_FS_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_FS, 0);
	if (rx_ch == CCCI_UART2_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_MUXD, 0);
	if (rx_ch == CCCI_MD_LOG_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_MDLOG, 0);
	if (rx_ch == CCCI_UART1_RX)
		proxy_set_critical_user(proxy_p, CRIT_USR_META, 0);

	MTK_INFO_LOG(TAG, "critical user check: 0x%x\n",
		proxy_p->critical_user_active);
	return 0;
}

int ccci_port_send_hif(struct port_t *port, struct sk_buff *skb,
	unsigned char from_pool, unsigned char blocking)
{
	struct ccci_header *ccci_h;
	int ret = 0;
	unsigned char tx_qno;

	ccci_h = (struct ccci_header *)(skb->data);
	tx_qno = port_get_queue_no(port, MTK_OUT, -1);
	port_inc_tx_seq_num(port, ccci_h);
	ret = ccci_hif_send_skb(port->md_id, GET_PATH_FLAG(port->path_id),
		tx_qno, skb, from_pool, blocking);
	if (ret) {
		MTK_ERR_LOG(CHAR, "failed to send skb,ret = %d\n", ret);
	} else {
		/*record the port seq_num after the data is sent to HIF*/
		port->seq_nums[MTK_OUT]++;
	}
	return ret;
}


/*
 *This API is called by port_net,
 *which is used to send skb message to md
 */
int port_net_send_skb_to_md(struct port_t *port,
	int is_ack, struct sk_buff *skb)
{
	int md_id = port->md_id;

	if (ccci_fsm_get_md_state(md_id) != READY)
		return -ENODEV;
	return ccci_port_send_hif(port, skb, port->skb_from_pool, 0);
}

int port_send_skb_to_md(struct port_t *port, struct sk_buff *skb, int blocking)
{
	int tx_qno = 0;
	int err = 0;
	int md_id = port->md_id;
	unsigned int md_state, fsm_state;

	md_state = ccci_fsm_get_md_state(md_id);
	fsm_state = ccci_fsm_get_current_state(md_id);
	if (fsm_state != CCCI_FSM_PRE_STARTING) {
		if ((md_state == BOOT_WAITING_FOR_HS1 ||
			md_state == BOOT_WAITING_FOR_HS2)) {
			err = -ENODEV;
			goto exit;
		}
		if (md_state == EXCEPTION
			&& port->tx_ch != CCCI_MD_LOG_TX
			&& port->tx_ch != CCCI_UART1_TX
			) {
			err = -ETXTBSY;
			goto exit;
		}
		if (md_state == STOPPED
			|| md_state == WAITING_TO_STOP
			|| md_state == INVALID){

			err = -ENODEV;
			goto exit;
		}
	}
	tx_qno = port_get_queue_no(port, MTK_OUT, -1);

#ifdef PORT_EVENT
	trace_port_send_skb_to_md(port->name, tx_qno,
		skb, GET_PATH_FLAG(port->path_id));
#endif /* PORT_EVENT */
	err = ccci_hif_send_skb(md_id, GET_PATH_FLAG(port->path_id),
		tx_qno, skb, port->skb_from_pool, blocking);
	if (err)
		goto exit;

	port->tx_pkg_cnt++;
	return 0;

exit:
	MTK_ERR_LOG(TAG,
		"failed to send packet via port:%s, ch:%d, md state:%d\n",
		port->name, port->tx_ch, md_state);
	return err;
}
/*****************************************************************************/
/*REGION: port_proxy class method implementation*/
/*****************************************************************************/
static inline int proxy_check_critical_user(struct port_proxy *proxy_p)
{
	int ret = 1;

	if (proxy_get_critical_user(proxy_p, CRIT_USR_MUXD) == 0) {
		if (is_meta_mode() || is_advanced_meta_mode()) {
			if (proxy_get_critical_user(proxy_p, CRIT_USR_META)
				== 0) {
				MTK_INFO_LOG(TAG,
					"ready to reset MD in META mode\n");
				ret = 0;
				goto __EXIT_FUN__;
			}
			/* this should never happen */
			MTK_ERR_LOG(TAG,
				"DHL ctrl is still open in META mode\n");
		} else {
			if (proxy_get_critical_user(proxy_p, CRIT_USR_MDLOG)
				== 0 &&
				proxy_get_critical_user(proxy_p,
				CRIT_USR_MDLOG_CTRL) == 0) {
				MTK_INFO_LOG(TAG,
					"ready to reset MD in normal mode\n");
				ret = 0;
				goto __EXIT_FUN__;
			}
		}
	}
__EXIT_FUN__:
	return ret;
}


static inline void proxy_setup_channel_mapping(struct port_proxy *proxy_p)
{
	int i, hif;
	int hif_id;
	struct port_t *port = NULL;

	/* Init RX_CH=>port list mapping */
	for (i = 0; i < ARRAY_SIZE(proxy_p->rx_ch_ports); i++)
		INIT_LIST_HEAD(&proxy_p->rx_ch_ports[i]);
	/* Init queue_id=>port list mapping per HIF*/
	for (hif = 0; hif < ARRAY_SIZE(proxy_p->queue_ports); hif++) {
		for (i = 0; i < ARRAY_SIZE(proxy_p->queue_ports[hif]); i++)
			INIT_LIST_HEAD(&proxy_p->queue_ports[hif][i]);
	}
	/*Init EE_ports list*/
	INIT_LIST_HEAD(&proxy_p->exp_ports);
	/*setup port mapping*/
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		/*setup RX_CH=>port list mapping*/
		list_add_tail(&port->entry,
			&proxy_p->rx_ch_ports[port->rx_ch&0xFFF]);

		/*skip no data transmission port,such as
		 * CCCI_DUMMY_CH type port
		 */
		if (port->txq_index == 0xFF || port->rxq_index == 0xFF)
			continue;
		/*setup QUEUE_ID=>port list mapping*/
		hif_id = GET_HIF_ID(port->md_id, port->path_id);
		list_add_tail(&port->queue_entry,
			&proxy_p->queue_ports[hif_id][port->rxq_index]);
		/*if port configure exception queue index, setup ee_ports*/
		if ((port->txq_exp_index & 0xF0) == 0 ||
			(port->rxq_exp_index & 0xF0) == 0)
			list_add_tail(&port->exp_entry, &proxy_p->exp_ports);
	}

}

static struct port_t *proxy_get_port(struct port_proxy *proxy_p,
	int minor, enum ccci_ch ch)
{
	int i;
	struct port_t *port;

	if (proxy_p == NULL)
		return NULL;
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (minor >= 0 && port->minor == minor)
			return port;
		if (ch != CCCI_INVALID_CH_ID &&
			(port->rx_ch == ch || port->tx_ch == ch))
			return port;
	}
	return NULL;
}

/*
 * kernel inject CCCI message to modem.
 */
static inline int proxy_send_msg_to_md(struct port_proxy *proxy_p,
	int ch, unsigned int msg, unsigned int resv, int blocking)
{
	struct port_t *port = NULL;
	struct sk_buff *skb = NULL;
	struct ccci_header *ccci_h;
	struct ctrl_msg_header *ctrl_msg_h;
	int ret = 0;
	int md_id;

	if (!proxy_p) {
		MTK_ERR_LOG(TAG, "proxy_p is NULL\n");
		return -CCCI_ERR_MD_NOT_READY;
	}
	md_id = proxy_p->md_id;
	port = port_get_by_channel(md_id, ch);
	if (port == NULL)
		return -CCCI_ERR_INVALID_LOGIC_CHANNEL_ID;
	skb = ccci_alloc_skb(sizeof(struct ccci_header),
			port->skb_from_pool, blocking);
	if (skb == NULL)
		return -CCCI_ERR_ALLOCATE_MEMORY_FAIL;

	if (ch == CCCI_CONTROL_TX || ch == CCCI_SAP_CONTROL_TX) {
		ccci_h = (struct ccci_header *)(skb->data);
		ccci_h->data[0] = CCCI_MAGIC_NUM;
		ccci_h->data[1] = sizeof(struct ctrl_msg_header) + CCCI_H_LEN;
		ccci_h->channel = ch;
		ccci_h->reserved = 0;
		ctrl_msg_h = (struct ctrl_msg_header *)(skb->data + CCCI_H_LEN);
		ctrl_msg_h->data_length = 0;
		ctrl_msg_h->reserved = resv;
		ctrl_msg_h->ctrl_msg_id = msg;
		skb_put(skb, CCCI_H_LEN + sizeof(struct ctrl_msg_header));
	} else {
		ccci_h = (struct ccci_header *)skb_put(skb,
			sizeof(struct ccci_header));
		ccci_h->data[0] = CCCI_MAGIC_NUM;
		ccci_h->data[1] = msg;
		ccci_h->channel = ch;
		ccci_h->reserved = resv;
	}
	ret = ccci_port_send_hif(port, skb, port->skb_from_pool, blocking);
	if (ret) {
		MTK_ERR_LOG(TAG, "port%s send to md fail\n", port->name);
		ccci_free_skb(skb);
		return -CCCI_ERR_INVALID_LOGIC_CHANNEL_ID;
	}
	return 0;
}

/*
 * if recv_request returns 0 or -CCCI_ERR_DROP_PACKET, then it's port's duty
 * to free the request, and caller should NOT reference the request any more
 * but if it returns other error, caller should be responsible to
 * free the request.
 */
static inline int proxy_dispatch_recv_skb(struct port_proxy *proxy_p,
	int hif_id, struct sk_buff *skb, unsigned int flag)
{
	struct ccci_header *ccci_h = NULL;
	struct port_t *port = NULL;
	struct list_head *port_list = NULL;
	int ret = -CCCI_ERR_CHANNEL_NUM_MIS_MATCH;
	char matched = 0;
	int md_id = proxy_p->md_id;
	int md_state = ccci_fsm_get_md_state(md_id);
	int channel = CCCI_INVALID_CH_ID;
	int hif_id_temp = 0;
	u16 seq_num = 0;

	if (unlikely(!skb)) {
		ret = -CCCI_ERR_INVALID_PARAM;
		goto err_exit;
	}

	ccci_h = (struct ccci_header *)skb->data;
	channel = ccci_h->channel;

	if (unlikely
		(channel >= CCCI_MAX_CH_NUM || channel == CCCI_INVALID_CH_ID)) {
		ret = -CCCI_ERR_CHANNEL_NUM_MIS_MATCH;
		goto err_exit;
	}
	if (unlikely(md_state == INVALID)) {
		ret = -CCCI_ERR_HIF_NOT_POWER_ON;
		goto err_exit;
	}
	/*bit 15~12 is used as peer_id*/
	port_list = &proxy_p->rx_ch_ports[channel&0xfff];
	list_for_each_entry(port, port_list, entry) {
		/*
		 * multi-cast is not supported, because one port may freed
		 or modified this request before another port can process it.
		 * but we still can use req->state to achive some kind of
		 * multi-cast if needed.
		 */
		hif_id_temp = GET_HIF_ID(port->md_id, port->path_id);
		matched = (hif_id == hif_id_temp) &&
			((port->ops->recv_match == NULL) ?
			(channel == port->rx_ch) :
			port->ops->recv_match(port, skb));
		if (matched) {
			if (likely(skb && port->ops->recv_skb)) {
				seq_num = port_check_rx_seq_num(md_id,
					port, ccci_h);
				ret = port->ops->recv_skb(port, skb);
				/*
				 * If the packet is stored to rx buffer
				 * successfully or drop, the sequence
				 * num will be updated
				 */
				if (-CCCI_ERR_PORT_RX_FULL != ret)
					port_update_rx_seq_num(port, seq_num);
			} else {
				MTK_ERR_LOG(TAG,
					"port->ops->recv_skb is null\n");
				ret = -CCCI_ERR_CHANNEL_NUM_MIS_MATCH;
				goto err_exit;
			}
			break;
		}
	}
#ifdef PORT_EVENT
	trace_proxy_dispatch_recv_skb(md_state, ret, matched, skb, ccci_h);
#endif /* PORT_EVENT */
 err_exit:
	if (ret < 0) {
		if (ret != -CCCI_ERR_PORT_RX_FULL) {
			MTK_NOTICE_LOG(CORE,
				"drop on channel %d, ret %d\n", channel, ret);
			ccci_free_skb(skb);
			ret = -CCCI_ERR_DROP_PACKET;
		} else {
			MTK_DEBUG_LOG(CORE,
				"the rx buffer is full %d\n",
				port->rx_busy_count);
			port->rx_busy_count++;
		}
	}
	return ret;
}
static inline void proxy_dispatch_queue_status(struct port_proxy *proxy_p,
	int hif, int qno, int dir, unsigned int state)
{
	struct port_t *port;
	int match = 0;
	unsigned int hif_id;
	struct list_head *head;

	/*EE then notify EE port*/
	if (unlikely(ccci_fsm_get_md_state(proxy_p->md_id) == EXCEPTION)) {
		head = &proxy_p->exp_ports;
		if (!head->next)
			return;

		list_for_each_entry(port, &proxy_p->exp_ports, exp_entry) {
			hif_id = GET_HIF_ID(port->md_id, port->path_id);
			match = (hif_id == hif);
			if (dir == MTK_OUT)
				match =	(qno == port->txq_exp_index);
			else
				match = (qno == port->rxq_exp_index);
			if (match && port->ops->queue_state_notify)
				port->ops->queue_state_notify(port,
				dir, qno, state);
		}
		return;
	}

	head = &proxy_p->queue_ports[hif][qno];
	if (!head->next)
		return;

	list_for_each_entry(port, &proxy_p->queue_ports[hif][qno],
		queue_entry) {
		hif_id = GET_HIF_ID(port->md_id, port->path_id);
		match = (hif_id == hif);
		/* consider network data/ack queue design */
		if (dir == MTK_OUT)
			match = qno == port->txq_index
				|| qno == (port->txq_exp_index & 0x0F);
		else
			match = qno == port->rxq_index;
		if (match && port->ops->queue_state_notify)
			port->ops->queue_state_notify(port, dir, qno, state);
	}
}
static inline void proxy_dispatch_md_status(struct port_proxy *proxy_p,
	unsigned int state)
{
	int i;
	struct port_t *port;

	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if ((state == INVALID || state == STOPPED) && (port->flags & PORT_F_CH_TRAFFIC)) {
			port->rx_pkg_cnt = 0;
			port->rx_drop_cnt = 0;
			port->tx_pkg_cnt = 0;
		}
		if (port->ops->md_state_notify)
			port->ops->md_state_notify(port, state);
	}
}

static inline void proxy_dump_status(struct port_proxy *proxy_p)
{
	struct port_t *port;
	/* hardcode, port number should not be larger than 64 */
	unsigned long long port_full = 0;
	unsigned int i;

	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (port->flags & PORT_F_RX_FULLED)
			port_full |= (1LL << i);
		if (port->tx_busy_count != 0 || port->rx_busy_count != 0) {
			MTK_DEBUG_LOG(TAG, "port %s busy count %d/%d\n",
				port->name, port->tx_busy_count,
				port->rx_busy_count);
			port->tx_busy_count = 0;
			port->rx_busy_count = 0;
		}
		if (port->ops->dump_info)
			port->ops->dump_info(port, 0);
	}
	if (port_full)
		MTK_ERR_LOG(TAG, "port_full status=%llx\n", port_full);
}

static inline int proxy_register_char_dev(struct port_proxy *proxy_p)
{
	int ret = 0;
	dev_t dev = 0;
	char tmp_buf[30];

	snprintf(tmp_buf, 30, CCCI_DEV_NAME"%d", proxy_p->md_id);
	if (proxy_p->major) {
		dev = MKDEV(proxy_p->major, proxy_p->minor_base);
		ret = register_chrdev_region(dev, CCCI_IPC_MINOR_BASE, tmp_buf);
	} else {
		ret = alloc_chrdev_region(&dev, proxy_p->minor_base,
				CCCI_IPC_MINOR_BASE, tmp_buf);
		if (ret)
			MTK_ERR_LOG(CHAR,
				"failed to alloc chrdev region,ret=%d\n", ret);
		proxy_p->major = MAJOR(dev);
	}
	return ret;
}

static inline void proxy_init_all_ports(struct port_proxy *proxy_p)
{
	int i;
	int md_id, hif_id;
	struct port_t *port;
	struct ccci_modem *md = modem_sys[proxy_p->md_id];

	md_id = proxy_p->md_id;
	/* init port */
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		port_struct_init(port, proxy_p);
		if (port->tx_ch == CCCI_SYSTEM_TX)
			proxy_p->sys_port = port;
		if (port->tx_ch == CCCI_CONTROL_TX) {
			proxy_p->ctl_port = port;
			md->core_md.ctl_port = port;
		}
		if (port->tx_ch == CCCI_SAP_CONTROL_TX)
			md->core_sap.ctl_port = port;

		port->major = proxy_p->major;
		port->minor_base = proxy_p->minor_base;
		mutex_init(&port->tx_mutex_lock);
		spin_lock_init(&port->port_update_lock);
		spin_lock(&port->port_update_lock);
		if (port->flags & PORT_F_CHAR_NODE_SHOW) {
			port->chan_enable = CCCI_CHAN_ENABLE;
		} else {
			port->chan_enable = CCCI_CHAN_DISABLE;
		}
		port->chn_crt_stat = CCCI_CHAN_DISABLE;
		spin_unlock(&port->port_update_lock);
		if (port->ops->init)
			port->ops->init(port);
		if (port->flags & PORT_F_RAW_DATA) {
			hif_id = GET_HIF_ID(md_id, port->path_id);
			proxy_p->dedicated_ports[hif_id][port->rxq_index] =
				port;
			MTK_DEBUG_LOG(TAG,
				"Dedicated Port Hid:%d, Qno:%d, Port_name:%s\n",
				hif_id, port->rxq_index, port->name);
		}
	}
	if (proxy_p->current_cfg_id == PORT_CFG0)
		proxy_setup_channel_mapping(proxy_p);

}

static inline void proxy_set_traffic_flag(struct port_proxy *proxy_p,
	unsigned int dump_flag)
{
	int idx;
	struct port_t *port;

	proxy_p->traffic_dump_flag = dump_flag;

	for (idx = 0; idx < proxy_p->port_number; idx++) {
		port = proxy_p->ports + idx;
		/*clear traffic & dump flag*/
		port->flags &= ~(PORT_F_CH_TRAFFIC | PORT_F_DUMP_RAW_DATA);

		/*set RILD related port*/
		if (proxy_p->traffic_dump_flag & (1 << PORT_DBG_DUMP_RILD)) {
			if (port->rx_ch == CCCI_UART2_RX)
				port->flags |= PORT_F_CH_TRAFFIC;
		}
		/*set AUDIO related port*/
		if (proxy_p->traffic_dump_flag & (1 << PORT_DBG_DUMP_AUDIO)) {
			if (port->rx_ch == CCCI_PCM_RX)
				port->flags |= (PORT_F_CH_TRAFFIC |
					PORT_F_DUMP_RAW_DATA);
		}
		/*set IMS related port*/
		if (proxy_p->traffic_dump_flag & (1 << PORT_DBG_DUMP_IMS)) {
			if (port->rx_ch == CCCI_IMSV_DL ||
				port->rx_ch == CCCI_IMSC_DL ||
				port->rx_ch == CCCI_IMSA_DL ||
				port->rx_ch == CCCI_IMSA_DL ||
				port->rx_ch == CCCI_IMSEM_DL)
				port->flags |= (PORT_F_CH_TRAFFIC |
					PORT_F_DUMP_RAW_DATA);
		}
	}
}

static inline struct port_proxy *proxy_alloc(int md_id,
	PORT_CFG_ENUM port_cfg_id)
{
	int ret = 0;
	struct port_proxy *proxy_p;

	/* Allocate port_proxy obj and set all member zero */
	proxy_p = kzalloc(sizeof(struct port_proxy), GFP_KERNEL);
	if (proxy_p == NULL) {
		MTK_ERR_LOG(TAG, "failed to alloc port_proxy\n");
		return NULL;
	}
	proxy_p->md_id = md_id;
	proxy_p->current_cfg_id = port_cfg_id;

	ret = proxy_register_char_dev(proxy_p);
	if (ret)
		goto EXIT_FUN;
	proxy_p->port_number = port_get_cfg(proxy_p->md_id,
		&proxy_p->ports, port_cfg_id);
	if (proxy_p->port_number > 0 && proxy_p->ports)
		proxy_init_all_ports(proxy_p);
	else
		ret = -1;

EXIT_FUN:
	if (ret) {
		kfree(proxy_p);
		proxy_p = NULL;
		MTK_ERR_LOG(TAG, "fail to get md port config,ret=%d\n", ret);
	}
	return proxy_p;
};

struct port_t *port_get_by_minor(int md_id, int minor)
{
	return proxy_get_port(GET_PORT_PROXY(md_id), minor, CCCI_INVALID_CH_ID);
}
struct port_t *port_get_by_channel(int md_id, enum ccci_ch ch)
{
	return proxy_get_port(GET_PORT_PROXY(md_id), -1, ch);
}

struct port_t *port_get_by_node(int major, int minor)
{
	int i;
	struct port_proxy *proxy_p = NULL;

	for (i = 0; i < MAX_MD_NUM; i++) {
		proxy_p = GET_PORT_PROXY(i);
		if (proxy_p && proxy_p->major == major)
			return proxy_get_port(proxy_p, minor,
					CCCI_INVALID_CH_ID);
	}
	return NULL;
}
struct port_t *port_get_by_name(int md_id, char *port_name)
{
	struct port_proxy *proxy_p = NULL;
	int i = 0;
	struct port_t *port = NULL;

	proxy_p = GET_PORT_PROXY(md_id);
	if (proxy_p == NULL)
		return NULL;

	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (strncmp(port->name, port_name, strlen(port->name)) == 0)
			return port;
	}
	return NULL;
}

int port_send_msg_to_md(struct port_t *port, unsigned int msg,
	unsigned int resv, int blocking)
{
	int md_id = port->md_id;
	int ch = port->tx_ch;
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	return proxy_send_msg_to_md(port->port_proxy, ch, msg, resv, blocking);
}

static int port_netlink_send_msg(struct port_t *port, int grp,
	const char *buf, int len)
{
	struct sk_buff *nl_skb;
	struct nlmsghdr *nlh;
	struct port_proxy *proxy_p;
	int err;

	nl_skb = nlmsg_new(len, GFP_KERNEL);
	if (!nl_skb) {
		MTK_ERR_LOG(TAG, "Could not alloc netlink msg\n");
		return -1;
	}

	nlh = nlmsg_put(nl_skb, 0, 1, NLMSG_DONE, len, 0);
	if (!nlh) {
		MTK_ERR_LOG(TAG, "Could not release netlink\n");
		nlmsg_free(nl_skb);
		return -1;
	}

	memcpy(nlmsg_data(nlh), buf, len);

	proxy_p = (struct port_proxy *)port->port_proxy;
	err = netlink_broadcast(proxy_p->netlink_sock, nl_skb,
		0, grp, GFP_KERNEL);
	return err;
}


int port_broadcast_state(struct port_t *port, int state)
{

	int err = 0;
	char msg[PORT_NETLINK_MSG_MAX_PAYLOAD];

	if (state >= PORT_STATE_INVALID)
		return -EINVAL;

	switch (state) {
	case PORT_STATE_ENABLE:
		snprintf(msg, PORT_NETLINK_MSG_MAX_PAYLOAD,
			"enable %s", port->name);
		break;

	case PORT_STATE_DISABLE:
		snprintf(msg, PORT_NETLINK_MSG_MAX_PAYLOAD,
			"disable %s", port->name);
		break;

	default:
		snprintf(msg, PORT_NETLINK_MSG_MAX_PAYLOAD,
			"invalid operation");
		break;
	}

	err = port_netlink_send_msg(port, PORT_STATE_BROADCAST_GROUP,
				msg, strlen(msg) + 1);
	return err;
}


int port_broadcast_minidump_status(struct port_t *port,
							const char *buff, int len)
{
	int err = 0;

	err = port_netlink_send_msg(port, PORT_MINIDUMP_BROADCAST_GROUP,
				buff, len);
	return err;
}


static int port_netlink_init(struct port_proxy *proxy_p)
{
	proxy_p->netlink_sock = (struct sock *)netlink_kernel_create(
					&init_net, PORT_NOTIFY_PROTOCOL, NULL);

	if (!proxy_p->netlink_sock) {
		MTK_ERR_LOG(TAG, "failed to create netlink socket\n");
		return -EAGAIN;
	}

	return 0;
}

static int port_netlink_uninit(struct port_proxy *proxy_p)
{
	if (proxy_p->netlink_sock) {
		netlink_kernel_release(proxy_p->netlink_sock);
		proxy_p->netlink_sock = NULL;
	}
	return 0;
}

/*****************************************************************************/
/* Extern API implement for none port related module */
/*****************************************************************************/
/*
 * This API is called by ccci_modem,
 * and used to create all ccci port instance for per modem
 */
int ccci_port_init(int md_id, PORT_CFG_ENUM port_cfg_id)
{
	int err;
	struct port_proxy *proxy_p;
	struct ccci_modem *md;

	md = modem_sys[md_id];
	if (md == NULL) {
		MTK_ERR_LOG(TAG, "modem sys is null.\n");
		return -1;
	}

	proxy_p = proxy_alloc(md_id, port_cfg_id);
	if (proxy_p == NULL) {
		MTK_ERR_LOG(TAG, "failed to alloc port_proxy\n");
		return -1;
	}
	SET_PORT_PROXY(md_id, proxy_p);
	err = port_netlink_init(proxy_p);
	if (err)
		MTK_ERR_LOG(TAG, "failed to init netlink\n");
	ccci_sysfs_add_ports(&(proxy_p->kobj), &(md->kobj));
	return 0;
}

int ccci_port_uninit(int md_id)
{
	int i = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	proxy_p = GET_PORT_PROXY(md_id);
	if (proxy_p == NULL) {
		MTK_NOTICE_LOG(TAG,"port_status notify: proxy not inited\n");
		return -1;
	}

	/*port uninit*/
	for (i = 0; i < proxy_p->port_number; i++) {
		port = proxy_p->ports + i;
		if (port->ops->uninit)
			port->ops->uninit(port);
	}
	ccci_sysfs_release_ports(&(proxy_p->kobj));
	/*free the char device number*/
	unregister_chrdev_region(MKDEV(proxy_p->major, proxy_p->minor_base),
		CCCI_IPC_MINOR_BASE);
	port_netlink_uninit(proxy_p);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
	kfree_sensitive(proxy_p);
#else	
	kzfree(proxy_p);
#endif	
	SET_PORT_PROXY(md_id, NULL);
	return 0;
}

/*
 * This API is called by ccci_fsm,
 * and used to dump all ccci port status for debugging
 */
void ccci_port_dump_status(int md_id)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	proxy_dump_status(proxy_p);
}

/*
 * This API is called by ccci_fsm,
 * and used to switch port configuration
 */

void switch_port_cfg(int md_id, PORT_CFG_ENUM port_cfg_id)
{
	int i = 0;
	struct port_proxy *proxy_p = NULL;
	struct port_t *port = NULL;

	proxy_p = GET_PORT_PROXY(md_id);
	if (proxy_p->current_cfg_id != port_cfg_id) {
		proxy_p->current_cfg_id = port_cfg_id;
		for (i = 0; i < proxy_p->port_number; i++) {
			port = proxy_p->ports + i;
			if (port->ops->uninit)
				port->ops->uninit(port);
		}
		proxy_p->port_number = port_get_cfg(proxy_p->md_id,
			&proxy_p->ports, port_cfg_id);
		proxy_init_all_ports(proxy_p);
	}
}
/*
 * This API is called by ccci_fsm,
 * and used to dispatch modem status for all ports,
 * which want to know md state transition.
 */
void ccci_port_md_status_notify(int md_id, unsigned int state)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	if (proxy_p == NULL) {
		MTK_NOTICE_LOG(TAG,"port_status notify: proxy  not inited\n");
	} else
		proxy_dispatch_md_status(proxy_p, (unsigned int)state);
}


/*
 * This API is called by HIF,
 * and used to dispatch Queue status for all ports,
 * which is mounted on the hif_id & qno
 */
void ccci_port_queue_status_notify(int md_id, int hif_id, int qno,
	int dir, unsigned int state)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);

	if (proxy_p == NULL) {
		MTK_NOTICE_LOG(TAG,"port_status notify: proxy  not inited\n");
		return;
	}
	proxy_dispatch_queue_status(proxy_p, hif_id, qno, dir,
		(unsigned int)state);
}

/*
 * This API is called by HIF,
 * and used to dispatch RX data for related port
 */
int ccci_port_recv_skb(int md_id, int hif_id, struct sk_buff *skb,
	unsigned int flag)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	return proxy_dispatch_recv_skb(proxy_p, hif_id, skb, flag);
}

/*
 * This API is called by ccci fsm,
 * and used to check whether all critical user exited.
 */
int ccci_port_check_critical_user(int md_id)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	return proxy_check_critical_user(proxy_p);
}

/*
 * This API is called by ccci fsm,
 * and used to get critical user status.
 */
int ccci_port_get_critical_user(int md_id, unsigned int user_id)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	return proxy_get_critical_user(proxy_p, user_id);
}

/*
 * This API is called by ccci fsm,
 * and used to send a ccci msg for modem.
 */
int ccci_port_send_msg_to_md(int md_id, int ch, unsigned int msg,
	unsigned int resv, int blocking)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	return proxy_send_msg_to_md(proxy_p, ch, msg, resv, blocking);
}

/*
 * This API is called by ccci fsm,
 * and used to set port traffic flag to catch traffic history on some important
 *channel.port traffic use md_boot_data[MD_CFG_DUMP_FLAG] = 0x6000_000x
 * as port dump flag
 */
void ccci_port_set_traffic_flag(int md_id, unsigned int dump_flag)
{
	struct port_proxy *proxy_p;

	proxy_p = GET_PORT_PROXY(md_id);
	proxy_set_traffic_flag(proxy_p, dump_flag);
}
/*
* This API is used to update port status, now it used to control create/remove device node
*/
int ccci_port_status_update(int md_id, void *data)
{
	struct port_enum_msg_t *port_enum_msg = ( struct port_enum_msg_t *)data;
	struct port_info_t* port_info;
	struct port_t* port=NULL;
	int md_state;
	u16 port_cnt, port_index;

	md_state = ccci_fsm_get_md_state(md_id);
	MTK_DEBUG_LOG(TAG, "dump port enum msg info: 0x%x, 0x%x, 0x%x", \
		port_enum_msg->head_pattern, port_enum_msg->port_count, port_enum_msg->tail_pattern);
	if (port_enum_msg->head_pattern != PORT_ENUM_HEAD_PATTERN ||
				port_enum_msg->tail_pattern != PORT_ENUM_TAIL_PATTERN) {
		MTK_ERR_LOG(TAG, "port enumeration info pattern is error(0x%x, 0x%x)\n",\
			port_enum_msg->head_pattern, port_enum_msg->tail_pattern);
		return -1;
	}
	if (port_enum_msg->version != PORT_ENUM_VER){
		MTK_ERR_LOG(TAG, "port enumeration info version doesn't match(0x%x)\n",\
			port_enum_msg->version);
		return -2;
	}
	port_cnt = port_enum_msg->port_count;
	for(port_index = 0; port_index < port_cnt; port_index++) {
		port_info = (struct port_info_t *)(port_enum_msg->data + (sizeof(struct port_info_t)*port_index));
		if (port_info == NULL) {
			MTK_ERR_LOG(TAG, "the port info is NULL, the index %d\n", port_index);
			return -3;
		}
		MTK_DEBUG_LOG(TAG, "dump port info: 0x%x", *(u32*)port_info);
		port = port_get_by_channel(md_id, port_info->ch_id);
		if (port == NULL) {
			MTK_ERR_LOG(TAG, "the port 0x%X isn't found\n", port_info->ch_id);
			continue;
		}
		if (md_state == READY) {
			if (port_info->en_flag == CCCI_CHAN_ENABLE){
				if(port->ops->enable_chl != NULL)
					port->ops->enable_chl(port);
			}else {
				if (port->ops->disable_chl != NULL)
					port->ops->disable_chl(port);
			}
		} else {
			port->chan_enable =	port_info->en_flag;
		}
	}
	return 0;
}

