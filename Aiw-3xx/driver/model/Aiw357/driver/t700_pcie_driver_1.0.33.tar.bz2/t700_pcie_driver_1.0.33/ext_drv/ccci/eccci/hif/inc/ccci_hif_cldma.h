/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_CD_H__
#define __MODEM_CD_H__

#include <linux/dmapool.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/hrtimer.h>
#include <linux/skbuff.h>
#include <mt-plat/mtk_ccci_common.h>

#include "ccci_config.h"
#include "ccci_bm.h"
#include "ccci_hif_internal.h"
#include "ccci_driver_cldma.h"
#include "mtk-pci.h"
/*
 * hardcode, max queue number should be synced with port array in port_cfg.c
 *and macros in ccci_core.h following number should sync with
 * MAX_TXQ/RXQ_NUM in ccci_core.h and bitmask in modem_cldma.c
 */

#define GF_PORT_LIST_MAX 128

#define CLDMA_TXQ_NUM CLDMA_TQ_NUM
#define CLDMA_RXQ_NUM CLDMA_RQ_NUM
#define NORMAL_TXQ_NUM CLDMA_TQ_NUM
#define NORMAL_RXQ_NUM CLDMA_TQ_NUM

#define MAX_BD_NUM (MAX_SKB_FRAGS + 1)
#define SKB_RX_QUEUE_MAX_LEN 200000
#define CLDMA_ACTIVE_T 20
#define CLDMA_AP_MTU_SIZE	(NET_RX_BUF)	/*sync with runtime data*/

/* CPU information */
#define CTRL_GET_CUR_CPU(cpu) {\
	*(cpu) = get_cpu(); \
	put_cpu(); \
}

extern int normal_tx_queue_buffer_size[CLDMA_TXQ_NUM];
extern struct mutex ctl_cfg_mutex;

typedef enum {
	SHARED_Q = 0,
	DEDICATED_Q,
} Q_TYPE_ENUM;


/*
 * CLDMA feature options:
 * CLDMA_NO_TX_IRQ: mask all TX interrupts, collect TX_DONE skb
 * when get Rx interrupt or Tx busy.
 */
/* #define CLDMA_NO_TX_IRQ */

struct cldma_request {
	void *gpd;		/* virtual address for CPU */
	dma_addr_t gpd_addr;	/* physical address for DMA */
	struct sk_buff *skb;
	dma_addr_t data_buffer_ptr_saved;
	struct list_head entry;
	struct list_head bd;
	/* inherit from skb */
	/* bit7: override or not; bit0: IOC setting */
	unsigned char ioc_override;
} __packed;

typedef enum {
	RING_GPD = 0,
	RING_GPD_BD = 1,
	RING_SPD = 2,
} CLDMA_RING_TYPE;

struct md_cd_queue;

/*
 * In a ideal design, all read/write pointers should be member of cldma_ring,
 * and they will complete a ring buffer object with buffer itself and Tx/Rx
 * funcitions. but this will change too much of the original code and we have
 * to drop it. so here the cldma_ring is quite light and most of ring buffer
 * opertions are still in queue struct.
 */
struct cldma_ring {
	struct list_head gpd_ring;	/* ring of struct cldma_request */
	int length;		/* number of struct cldma_request */
	int pkt_size;		/* size of each packet in ring */
	CLDMA_RING_TYPE type;

	int (*handle_tx_request)(struct md_cd_queue *queue,
		struct cldma_request *req, struct sk_buff *skb,
		unsigned int ioc_override);
	int (*handle_rx_done)(struct md_cd_queue *queue,
		int budget, int blocking);
	int (*handle_tx_done)(struct md_cd_queue *queue,
		int budget, int blocking);
};

#define QUEUE_LEN(a) (sizeof(a)/sizeof(struct md_cd_queue))

struct md_cd_queue {
	unsigned char index;
	struct ccci_modem *modem;
	struct cldma_ring *tr_ring;
	struct cldma_request *tr_done;
	int budget;		/* same as ring buffer size by default */
	struct cldma_request *rx_refill;	/* only for Rx */
	struct cldma_request *tx_xmit;	/* only for Tx */
	Q_TYPE_ENUM q_type;
	struct port_t *dedicated_port;
	wait_queue_head_t req_wq;	/* only for Tx */
	spinlock_t ring_lock;

	struct workqueue_struct *worker;
	struct work_struct cldma_rx_work;
	struct delayed_work cldma_tx_work;

	wait_queue_head_t rx_wq;
	struct task_struct *rx_thread;

#ifdef ENABLE_CLDMA_TIMER
	struct timer_list timeout_timer;
	unsigned long long timeout_start;
	unsigned long long timeout_end;
#endif
	unsigned char hif_id;
	enum direction dir;
	unsigned int busy_count;
#ifdef ENABLE_CCCI_DRI_UT
	struct work_struct lp_qwork;
	struct workqueue_struct *lp_worker;
	unsigned long ut_tx_on_going;
#endif
};


struct cldma_sram_layout {
	struct ccci_header dl_header;
	struct md_query_ap_feature md_rt_data;
	struct ccci_header up_header;
	struct ap_query_md_feature ap_rt_data;
};


struct md_cd_ctrl {
	struct md_cd_queue txq[CLDMA_TXQ_NUM];
	struct md_cd_queue rxq[CLDMA_RXQ_NUM];
	unsigned short txq_active;
	unsigned short rxq_active;
	unsigned short txq_started;
	atomic_t cldma_irq_enabled;

	/* this lock is using to protect CLDMA, not only for timeout checking */
	spinlock_t cldma_timeout_lock;
	unsigned char md_id;
	unsigned char hif_id;
	unsigned char cfg_id;
	struct ccci_hif_traffic traffic_info;
	atomic_t wakeup_src;
	unsigned int tx_busy_warn_cnt;
	/* here we assume T/R GPD/BD/SPD have the same size	 */
	struct dma_pool *gpd_dmapool;
	struct cldma_ring normal_tx_ring[NORMAL_TXQ_NUM];
	struct cldma_ring normal_rx_ring[NORMAL_RXQ_NUM];
	struct cldma_sram_layout *cldma_sram_layout;
	struct md_pm_entity *pm_entity;
	struct ccci_hif_ops *ops;
	void *hif_hw_info;
	unsigned char is_late_init;
};

struct cldma_tgpd {
	u8 gpd_flags;
	/* original checksum bits, now for debug:1 for Tx in; 2 for Tx done */
	u16 non_used;
	u8 debug_id;
	u32 next_gpd_ptr_h;
	u32 next_gpd_ptr_l;
	u32 data_buff_bd_ptr_h;
	u32 data_buff_bd_ptr_l;
	u16 data_buff_len;
	u16 non_used1;
} __packed;

struct cldma_rgpd {
	u8 gpd_flags;
	u8 non_used; /* original checksum bits */
	u16 data_allow_len;
	u32 next_gpd_ptr_h;
	u32 next_gpd_ptr_l;
	u32 data_buff_bd_ptr_h;
	u32 data_buff_bd_ptr_l;
	u16 data_buff_len;
	u8 non_used1;
	u8 debug_id;
} __packed;

struct cldma_tbd {
	u8 bd_flags;
	u8 non_used; /* original checksum bits */
	u16 non_used2;
	u32 next_bd_ptr_h;
	u32 next_bd_ptr_l;
	u32 data_buff_ptr_h;
	u32 data_buff_ptr_l;
	u16 data_buff_len;
	u16 non_used1;
} __packed;

struct cldma_rbd {
	u8 bd_flags;
	u8 non_used; /* original checksum bits */
	u16 data_allow_len;
	u32 next_bd_ptr_h;
	u32 next_bd_ptr_l;
	u32 data_buff_ptr_h;
	u32 data_buff_ptr_l;
	u16 data_buff_len;
	u16 non_used1;
} __packed;

/*typedef enum {
 *	ONCE_MORE,
 *	ALL_CLEAR,
 *} RX_COLLECT_RESULT;
 */

enum {
	CCCI_TRACE_TX_IRQ = 0,
	CCCI_TRACE_RX_IRQ = 1,
};

#ifdef CONFIG_MTK_ECCCI_CLDMA

static inline void md_cd_queue_struct_reset(struct md_cd_queue *queue,
	unsigned char hif_id, enum direction dir, unsigned char index)
{
	queue->dir = dir;
	queue->index = index;
	queue->hif_id = hif_id;
	queue->tr_ring = NULL;
	queue->tr_done = NULL;
	queue->tx_xmit = NULL;
	queue->busy_count = 0;
}


static inline void md_cd_queue_struct_init(struct md_cd_queue *queue,
	unsigned char hif_id, enum direction dir, unsigned char index)
{
	md_cd_queue_struct_reset(queue, hif_id, dir, index);
	init_waitqueue_head(&queue->req_wq);
	spin_lock_init(&queue->ring_lock);
}

/*****************************************************************************
 * interface function
 * For other module usage
 *****************************************************************************/
extern int ccci_cldma_hif_hw_init(unsigned char hif_id, unsigned char md_id);
extern int ccci_cldma_hif_init(unsigned char hif_id, unsigned char md_id);
void poll_cldma_status(void);
int ccci_cldma_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage);


static inline int ccci_cldma_hif_send_skb(unsigned char md_id,
	unsigned char hif_id, int tx_qno, struct sk_buff *skb,
	int from_pool, int blocking)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	if (md_ctrl)
		return md_ctrl->ops->send_skb(md_id,
			hif_id, tx_qno, skb, from_pool, blocking);
	else
		return -1;
}

static inline int ccci_cldma_hif_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->write_room(md_id, hif_id, qno);
	else
		return -1;

}
static inline int ccci_cldma_hif_give_more(unsigned char md_id,
	unsigned char hif_id, int rx_qno)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->give_more(md_id, hif_id, rx_qno);
	else
		return -1;

}

static inline int ccci_cldma_hif_dump_status(unsigned int md_id,
	unsigned int hif_id, enum modem_dump_flag dump_flag, void *data, int length)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->dump_status(md_id,
			hif_id, dump_flag, data, length);
	else
		return -1;

}

static inline int ccci_cldma_hif_set_wakeup_src(unsigned int md_id,
	unsigned char hif_id, int value)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl) {
		atomic_set(&md_ctrl->wakeup_src, value);
		return 0;
	} else
		return -1;
}

static inline int ccci_cldma_hif_start(unsigned char md_id,
	unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	if (md_ctrl)
		return md_ctrl->ops->hif_start(md_id, hif_id);
	else
		return -1;
}

static inline void ccci_cldma_hif_stop(unsigned char md_id,
	unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		md_ctrl->ops->hif_stop(md_id, hif_id);
}
static inline void ccci_cldma_stop_for_ee(unsigned char md_id,
	unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		md_ctrl->ops->hif_stop_for_ee(md_id, hif_id);
}
static inline void ccci_cldma_hif_clear(unsigned char md_id,
	unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		md_ctrl->ops->hif_clear(md_id, hif_id);
}
static inline void ccci_cldma_hif_reset(unsigned char md_id,
	unsigned char hif_id, unsigned char is_hw)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		md_ctrl->ops->hif_reset(md_id, hif_id, is_hw);
}
static inline int ccci_cldma_clear_all_queue(unsigned char md_id,
	unsigned char hif_id, enum direction dir)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->hif_clear_all_queue(md_id, hif_id, dir);
	else
		return -1;
}
static inline void ccci_cldma_allQreset_work(unsigned char md_id,
	unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		md_ctrl->ops->hif_allQreset_work(md_id, hif_id);
}

extern void *cldma_hif_fill_rt_header(unsigned char md_id,
	unsigned char hif_id, int packet_size,
	unsigned int tx_ch, unsigned int txqno);

extern void *ccci_cldma_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *mtk_dev);

extern int ccci_cldma_late_init(unsigned char md_id, unsigned char hif_id);

void cldma_hif_exit(unsigned char md_id, unsigned char hif_id);

void switch_cldma_cfg(unsigned char md_id,
	unsigned char hif_id, unsigned char cfg_id);

int ccci_cldma_write_room(unsigned char md_id, \
			unsigned char hif_id, unsigned char qno);

#else //CONFIG_MTK_ECCCI_CLDMA
static inline int ccci_cldma_hif_hw_init(unsigned char md_id,
	unsigned char hif_id)
{
	return -1;
}

static inline int ccci_cldma_hif_init(unsigned char md_id,
	unsigned char hif_id)
{
	return -1;
}

static inline int ccci_cldma_hif_send_skb(unsigned char md_id,
	unsigned char hif_id, int tx_qno, struct sk_buff *skb,
	int from_pool, int blocking)
{
	return -1;
}

static inline int ccci_cldma_hif_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	return -1;
}
static inline int ccci_cldma_hif_give_more(unsigned char md_id,
	unsigned char hif_id, int rx_qno)
{
	return -1;
}

static inline int ccci_cldma_hif_dump_status(unsigned int md_id,
	unsigned int hif_id, enum modem_dump_flag dump_flag, void *data, int length)
{
	return -1;
}

static inline int ccci_cldma_hif_set_wakeup_src(unsigned int md_id,
	unsigned char hif_id, int value)
{
	return -1;
}

static inline int ccci_cldma_hif_start(unsigned char md_id,
	unsigned char hif_id)
{
	return -1;
}

static inline void ccci_cldma_hif_stop(unsigned char md_id,
	unsigned char hif_id)
{
}
static inline void ccci_cldma_stop_for_ee(unsigned char md_id,
	unsigned char hif_id)
{
}
static inline void ccci_cldma_hif_clear(unsigned char md_id,
	unsigned char hif_id)
{
}
static inline void ccci_cldma_hif_reset(unsigned char md_id,
	unsigned char hif_id, unsigned char is_hw)
{
}
static inline int ccci_cldma_late_init(unsigned char md_id,
	unsigned char hif_id)
{
	return -1;
}
static inline int ccci_cldma_clear_all_queue(unsigned char md_id,
	unsigned char hif_id, enum direction dir)
{
}
static inline void ccci_cldma_allQreset_work(unsigned char md_id,
	unsigned char hif_id)
{
}

static inline void *cldma_hif_fill_rt_header(unsigned char md_id,
	unsigned char hif_id, int packet_size, unsigned int tx_ch,
	unsigned int txqno)
{
	return NULL;
}

static inline void *ccci_cldma_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *dev_ptr)
{
	MTK_DEBUG_LOG("CLD_HIF",
		"%s: please define CONFIG_MTK_ECCCI_CLDMA\n", __func__);
	return NULL;
}

static inline int ccci_cldma_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	MTK_DEBUG_LOG("CLD_HIF",
		"%s: please define CONFIG_MTK_ECCCI_CLDMA\n", __func__);
	return NULL;
}
#endif //CONFIG_MTK_ECCCI_CLDMA
#endif				/* __MODEM_CD_H__ */

