/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __DPMAIF_HIF_PLATFORM_H__
#define __DPMAIF_HIF_PLATFORM_H__

#include <linux/io.h>
#include <linux/sched.h>
#include "ccci_debug.h"

#include <linux/delay.h>

#include <linux/types.h>
#include <linux/string.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/kernel.h>


/* ftrace log */
#ifdef DPMA_FTRACE_DEBUG
#define DPMA_FT_TAG                 "DPMA-FTRACE"
#define DPMA_FT_LOG(fmt, args...)\
	trace_printk("[%s], "fmt"\n", DPMA_FT_TAG, ##args)
#else
#define DPMA_FT_LOG(fmt, args...)
#endif


enum error_num {
	LOW_MEMORY_ERR = -15,
	LOW_MEMORY_PIT,
	LOW_MEMORY_BAT,
	LOW_MEMORY_SKB,
	LOW_MEMORY_DRB,
	LOW_MEMORY_TYPE_MAX, /* -10 */

	DMA_MAPPING_ERR,
	FLOW_CHECK_ERR,
	DATA_CHECK_FAIL,
	HW_REG_CHK_FAIL,
	ERROR_STOP_MAX, /* -5 */
};


/*
 *   I/O read and write functions
 */
#define PLAT_WRITE32(a, v)           writel((v), (void __iomem *)(a))
#define PLAT_WRITE16(a, v)           writew((v), (void __iomem *)(a))
#define PLAT_WRITE8(a, v)            writeb((v), (void __iomem *)(a))
#define PLAT_READ32(a)               readl((void __iomem *)(a))
#define PLAT_READ16(a)               readw((void __iomem *)(a))
#define PLAT_READ8(a)                readb((void __iomem *)(a))

#define DPMAIF_WriteReg32(a, v)         PLAT_WRITE32(a, v)
#define DPMAIF_WriteReg16(a, v)         PLAT_WRITE16(a, v)
#define DPMAIF_WriteReg8(a, v)          PLAT_WRITE8(a, v)
#define DPMAIF_ReadReg32(a)             PLAT_READ32(a)
#define DPMAIF_ReadReg16(a)             PLAT_READ16(a)
#define DPMAIF_ReadReg8(a)              PLAT_READ8(a)

#ifndef DPMAIF_DEBUG_DUMP
#define DPMAIF_REG_IO_WRITE32(a, v)            PLAT_WRITE32(a,v)
#define DPMAIF_REG_IO_READ32(a)                PLAT_READ32(a)

#else
#define DPMAIF_REG_IO_READ32(a) ({\
	unsigned int tmp;\
	MTK_DEBUG_LOG("HW-DPMAIF", "start READ: %s", #a);\
	tmp = PLAT_READ32(a);\
	MTK_DEBUG_LOG("HW-DPMAIF", "end READ: %s, 0x%x", #a, tmp);\
	tmp;\
})

#define DPMAIF_REG_IO_WRITE32(a, v) do {\
	MTK_DEBUG_LOG("HW-DPMAIF", "start WRITE: %s, 0x%x", #a, (v));\
	PLAT_WRITE32(a, v);\
	MTK_DEBUG_LOG("HW-DPMAIF", "end WRITE: %s, 0x%x", #a, (v));\
} while (0)
#endif


/***********************************************************************
 *  DPMAIF HW feature
 *
 ***********************************************************************/
#define DPMA_CHECK_REG_TIMEOUT (1000000)
#define DPMA_MASK_FAIL_CNT_MAX  (100)

#define DPMAIF_UL_DRB_ENTRY_SIZE  6144  // from 512
#define DPMAIF_DL_BAT_ENTRY_SIZE  8192  // from 512
#define DPMAIF_DL_FRG_ENTRY_SIZE  4814  // from 512
#define DPMAIF_DL_PIT_ENTRY_SIZE  (DPMAIF_DL_BAT_ENTRY_SIZE * 2) // from 512

#define DPMAIF_DL_PIT_BYTE_SIZE   16

#define DPMAIF_DL_BAT_BYTE_SIZE   8
#define DPMAIF_DL_FRG_BYTE_SIZE   8
#define DPMAIF_UL_DRB_BYTE_SIZE   16

#define DPMAIF_UL_DRB_ENTRY_WORD  (DPMAIF_UL_DRB_BYTE_SIZE >> 2)
#define DPMAIF_DL_PIT_ENTRY_WORD  (DPMAIF_DL_PIT_BYTE_SIZE >> 2)
#define DPMAIF_DL_BAT_ENTRY_WORD  (DPMAIF_DL_BAT_BYTE_SIZE >> 2)

#define DPMAIF_UL_DRB_SIZE (DPMAIF_UL_DRB_ENTRY_SIZE * DPMAIF_UL_DRB_BYTE_SIZE)
#define DPMAIF_DL_PIT_SIZE (DPMAIF_DL_PIT_ENTRY_SIZE * DPMAIF_DL_PIT_BYTE_SIZE)
#define DPMAIF_DL_BAT_SIZE (DPMAIF_DL_BAT_ENTRY_SIZE * DPMAIF_DL_BAT_BYTE_SIZE)
#define DPMAIF_DL_FRG_SIZE (DPMAIF_DL_FRG_ENTRY_SIZE * DPMAIF_DL_FRG_BYTE_SIZE)

#define DPMAIF_DL_PIT_SEQ_VALUE        (251)
#define DPMF_PIT_SEQ_MAX                DPMAIF_DL_PIT_SEQ_VALUE

extern unsigned long g_DPMAIF_CACHE_LINE_SIZE;
#define DP_CACHE_LINE_SIZE      (unsigned long)(g_DPMAIF_CACHE_LINE_SIZE)
#define DP_CACHE_LINE_SIZE_MASK      (unsigned long)(DP_CACHE_LINE_SIZE - 1)
#define DPMAIF_PIT_REL_BATCH_NUM  (DP_CACHE_LINE_SIZE/DPMAIF_DL_PIT_BYTE_SIZE)


/*Default DPMAIF DL common setting*/
#define DPMAIF_HW_BAT_REMAIN       64

#ifdef DPMAIF_HW_FRAG_IT
#define DPMAIF_HW_BAT_PKTBUF       (128 * 8)   //1024
#else
#define DPMAIF_HW_BAT_PKTBUF       (128 * 28)   //128*28
#endif


#define DPMAIF_HW_FRG_PKTBUF       128 //128
#define DPMAIF_HW_BAT_RSVLEN       64
#define DPMAIF_HW_PKT_BIDCNT       1
#define DPMAIF_HW_PKT_ALIGN        64

#define DPMAIF_HW_MTU_SIZE          (3*1024 + 8)

#define DPMAIF_HW_CHK_BAT_NUM      62
#define DPMAIF_HW_CHK_FRG_NUM      3
#define DPMAIF_HW_CHK_PIT_NUM      (2 * DPMAIF_HW_CHK_BAT_NUM)

#define DPMAIF_DLQ0_NUM 0
#define DPMAIF_DLQ1_NUM 1
#define DPMAIF_DLQPIT_SEPARATE_NUM 2

#define MAIFQ_MAX_DLQ_NUM          DPMAIF_DLQPIT_SEPARATE_NUM
#define MAIFQ_MAX_ULQ_NUM          5

#define MAIFQ_ULQ_BUDGET           1000
#define MAIFQ_DLQ_BUDGET           1000

#define DPMAIF_PKT_BIDCNT          1




/***********************************************************************
 *  System variable
 *
 ***********************************************************************/
#define DRV_BOOL   bool
#define DRV_FALSE  false
#define DRV_TRUE   true

/***********************************************************************
 *  DPMAIF driver common structure and variable
 *
 ***********************************************************************/
struct dpmaif_isr_en_mask {
	unsigned int    AP_UL_L2INTR_En_Msk;
	unsigned int    AP_DL_L2INTR_En_Msk;
	unsigned int    AP_UDL_IP_BUSY_En_Msk;
	unsigned int    AP_DL_L2INTR_ERR_En_Msk;
};

struct dpmaif_drv_priv {
	struct dpmaif_isr_en_mask dpmaif_isr_en_mask;
    unsigned short dlq_mask_fail_cnt[MAIFQ_MAX_DLQ_NUM];
};

struct hifmaif_ul_st {
	unsigned int     que_config;
	DRV_BOOL          que_started;
	unsigned char     reserve[3];
	unsigned int     *drb_base;
	unsigned int     drb_size_cnt;

};

struct hifdpmaif_dl_st {
	unsigned int     que_config;
	DRV_BOOL          que_started;
	unsigned char     reserve[3];
	unsigned int     *pit_base;
	unsigned int     pit_size_cnt;
	unsigned int     *bat_base;
	unsigned int     bat_size_cnt;
	unsigned int     *frg_base;
	unsigned int     frg_size_cnt;
	unsigned int    pit_seq;
};

struct hifdpmaif_dl_hwq {
	unsigned int    bat_remain_size;
	unsigned int    bat_pkt_bufsz;
	unsigned int    frg_pkt_bufsz;
	unsigned int    bat_rsv_length;
	unsigned int    pkt_bid_max_cnt;
	unsigned int    pkt_alignment;
	unsigned int    mtu_size;
	unsigned int    chk_pit_num;
	unsigned int    chk_bat_num;
	unsigned int    chk_frg_num;
};

struct hifdpmaif_property {
	struct hifdpmaif_dl_st	dl_que[MAIFQ_MAX_DLQ_NUM];
	struct hifmaif_ul_st	ul_que[MAIFQ_MAX_ULQ_NUM];
	struct hifdpmaif_dl_hwq	dl_que_hw[MAIFQ_MAX_DLQ_NUM];
};

struct hw_dpmaif_ctrl {
	struct hifdpmaif_property    dpmaif_property;
	struct dpmaif_drv_priv	dpmaif_drv_ctrl;
};


struct pcie_hw_info {
	struct device *pcie_dev;	// pcie device for DMA address mapping
	u64 hw_base_addr;	// MTK device base address without mapping
	u64 hw_map_base_addr;	// MTK device base address on eAP after mapping
};

struct dpmaif_hw_info {
	u64 pcie_base_offset;
	struct hifdpmaif_property dpmaif_property;
	struct dpmaif_drv_priv dpmaif_drv_ctrl;
};


/***********************************************************************
 *  DPMAIF Register read/write
 *
 ***********************************************************************/

#define dpmaif_write32(addr, data)   DPMAIF_REG_IO_WRITE32(addr, data)
#define dpmaif_read32(a)                DPMAIF_REG_IO_READ32(a)

#define DPMAIF_READ_PD_MISC(a, b)      dpmaif_read32(((a)->pcie_base_offset) + (b))
#define DPMAIF_READ_PD_UL(a, b)        dpmaif_read32(((a)->pcie_base_offset) + (b))
#define DPMAIF_READ_PD_DL(a, b)        dpmaif_read32(((a)->pcie_base_offset) + (b))
#define DPMAIF_READ_AO_DL(a, b)        dpmaif_read32(((a)->pcie_base_offset) + (b))
#define DPMAIF_READ_AO_UL(a, b)        dpmaif_read32(((a)->pcie_base_offset) + (b))
#define DPMAIF_READ_PD_WDMA(a, b)      dpmaif_read32(((a)->pcie_base_offset) + (b))


#define DPMAIF_WRITE_PD_MISC(a, b, v)  dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_PD_UL(a, b, v)    dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_PD_DL(a, b, v)    dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_AO_DL(a, b, v)    dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_AO_UL(a, b, v)    dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_PD_WDMA(a, b, v)    dpmaif_write32((((a)->pcie_base_offset) + (b)), v)
#define DPMAIF_WRITE_RGU(a, b, v)    dpmaif_write32(((a->pcie_base_offset) + (b)), v)


/***********************************************************************
 *  Brief:
 *  Debug operate in defferent platform
 *
 ***********************************************************************/

#ifdef DPMAIFQ_ASSERT_EN
	#define DPMAIF_ASSERT(hif_ctrl) \
	do {\
		dpmaif_dump_status(hif_ctrl, DUMP_FLAG_REG, -1); \
		ASSERT(0); \
	} while (0)

	#define DPMAIF_ASSERT_NODUMP() \
	do {\
		MTK_ERR_LOG("HIF-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
		ASSERT(0); \
	} while (0)

    #define DPMAIF_HW_ASSERT(hw_info) \
	do {\
		MTK_ERR_LOG("HW-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
		drv_dpmaif_dump_debug_regs(hw_info);\
		ASSERT(0); \
	} while (0)

#else
	#define DPMAIF_ASSERT(hif_ctrl) \
	do {\
		dpmaif_dump_status(hif_ctrl, DUMP_FLAG_REG, -1); \
		MTK_ERR_LOG("HIF-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
	} while (0)
	#define DPMAIF_ASSERT_NODUMP() \
	do {\
		MTK_ERR_LOG("HIF-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
	} while (0)

    #define DPMAIF_HW_ASSERT(hw_info) \
	do {\
		MTK_ERR_LOG("HW-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
		drv_dpmaif_dump_debug_regs(hw_info);\
	} while (0)
#endif


#define DPMAIF_MD_ASSERT(hif_ctrl) \
do {\
	MTK_ERR_LOG("HIF-DPMAIF", \
		"DPMAIF_MD_ASSERT file: %s, function: %s, line %d", \
		__FILE__, __func__, __LINE__); \
	dpmaif_md_assert_hdr(hif_ctrl); \
} while (0)


#ifndef ASSERT
#define ASSERT(expr) \
{ \
	if (!expr) { \
		MTK_ERR_LOG("HIF-DPMAIF", "DPMAIF_ASSERT file: %s, function: %s, line %d", __FILE__, __func__, __LINE__); \
		BUG_ON(1); \
	} \
}
#endif


#endif
