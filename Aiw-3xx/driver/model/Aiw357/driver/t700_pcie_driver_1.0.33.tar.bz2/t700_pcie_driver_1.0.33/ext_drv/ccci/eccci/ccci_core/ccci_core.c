// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/kobject.h>
#include <linux/notifier.h>

#include "ccci_util_lib_main.h"
#include "ccci_util_lib_sys.h"
#include "ccci_core.h"
#include "ccci_fsm.h"
#include "modem_sys.h"
#include "ccci_port.h"
#include "ccci_hif.h"
#include "md_sys1_platform.h"
#include "ccci_fsm_internal.h"
#include "label.h"
static void *dev_class;
unsigned int mod_param_val;
extern unsigned short brom_dl_flag;

#if defined(CONFIG_XS_MOD) && defined(__arm64__)
unsigned int t700_index = 0;
#endif


/*
 * for debug log: 0 to disable; 1 for print to ram; 2 for print to uart
 * other value to desiable all log
 */
static void ccci_md_obj_release(struct kobject *kobj)
{
	MTK_NOTICE_LOG(CORE, "md kobject release\n");
}

int boot_md_show(int md_id, char *buf, int size)
{
	int curr = 0;

	if (get_modem_is_enabled(md_id))
		curr += snprintf(&buf[curr], size, "md%d:%d",
			md_id + 1, ccci_fsm_get_md_state(md_id));
	return curr;
}

int boot_md_store(int md_id)
{
	return -EACCES;
}

static ssize_t ccci_md_attr_show(struct kobject *kobj,
	struct attribute *attr, char *buf)
{
	ssize_t len = 0;
	struct ccci_md_attribute *a =
		container_of(attr, struct ccci_md_attribute, attr);

	if (a->show)
		len = a->show(a->modem, buf);

	return len;
}

static ssize_t ccci_md_attr_store(struct kobject *kobj,
	struct attribute *attr, const char *buf, size_t count)
{
	ssize_t len = 0;
	struct ccci_md_attribute *a =
		container_of(attr, struct ccci_md_attribute, attr);

	if (a->store)
		len = a->store(a->modem, buf, count);

	return len;
}

static const struct sysfs_ops ccci_md_sysfs_ops = {
	.show = ccci_md_attr_show,
	.store = ccci_md_attr_store
};

static struct attribute *ccci_md_default_attrs[] = {
	NULL
};

static struct kobj_type ccci_md_ktype = {
	.release = ccci_md_obj_release,
	.sysfs_ops = &ccci_md_sysfs_ops,
	.default_attrs = ccci_md_default_attrs
};
void ccci_sysfs_add_md(int md_id, void *kobj)
{
	ccci_sysfs_add_modem(md_id, (void *)kobj, (void *)&ccci_md_ktype,
		boot_md_show, boot_md_store);
}

void ccci_sysfs_remove_md(int md_id, void *kobj)
{
	ccci_sysfs_remove_modem(md_id, (void *)kobj);
}

int exec_ccci_kern_func_by_md_id(int md_id,
	unsigned int id, char *buf, unsigned int len)
{
	int ret = 0;

	if (!get_modem_is_enabled(md_id)) {
		MTK_ERR_LOG(CORE, "wrong MD ID from %ps for %d\n",
			__builtin_return_address(0), id);
		return -CCCI_ERR_MD_INDEX_NOT_FOUND;
	}

	MTK_DEBUG_LOG(CORE, "%ps execute function %d\n",
		__builtin_return_address(0), id);
	switch (id) {
	case ID_GET_MD_STATE:
		ret = ccci_fsm_get_md_state_for_user(md_id);
		break;
	default:
		ret = -CCCI_ERR_FUNC_ID_ERROR;
		break;
	};
	return ret;
}

int ccci_register_dev_node(const char *name, int major_id, int minor)
{
	int ret = 0;
	dev_t dev_n;
	struct device *dev;

	dev_n = MKDEV(major_id, minor);
	dev = device_create(dev_class, NULL, dev_n, NULL, "%s", name);

	if (IS_ERR(dev))
		ret = PTR_ERR(dev);

	return ret;
}

int ccci_unregister_dev_node(int major_id, int minor)
{
	int ret = 0;

	device_destroy(dev_class, MKDEV(major_id, minor));
	return ret;
}
int ccci_init(void)
{
	int ret = 0;

	MTK_INFO_LOG(CORE, ""LABEL"\n");
	ret = ccci_util_init();
#if defined(CONFIG_XS_MOD) && defined(__arm64__)
	char new_ccci_node[16];
	memset(new_ccci_node,0,16);
	sprintf(new_ccci_node,"ccci_node%d",t700_index);	
#else
	dev_class = class_create(THIS_MODULE, "ccci_node");
#endif
	ccci_subsys_bm_init();
	//ret = modem_sys_init();
	return ret;
}

void ccci_uninit(void)
{
	MTK_INFO_LOG(CORE, "%s.\n", __func__);
	ccci_subsys_bm_uninit();

	if (dev_class) {
		class_destroy(dev_class);
		dev_class = NULL;
	}
	ccci_util_exit();
}
#if defined(CONFIG_XS_MOD) && defined(__arm64__)
module_param(t700_index, uint, 0644);
MODULE_PARM_DESC(t700_index, "the value is used to define t700 module index\n");
#endif
module_param(mod_param_val, uint, 0644);
MODULE_PARM_DESC(mod_param_val, "the value is used to control port enumeration\n");
module_param(brom_dl_flag, ushort, 0644);
MODULE_PARM_DESC(brom_dl_flag, "the value is used to control dl behaivor\n");

