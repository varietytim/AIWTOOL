/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __DRV_AT_DPMAIF_H__
#define __DRV_AT_DPMAIF_H__



void drv_dpmaif_hw_init(void);

unsigned int drv_dpmaif_ip_code_version(void);

void drv_dpmaif_dl_set_ao_remain_minsz(unsigned char q_num, unsigned int sz);
void drv_dpmaif_dl_set_ao_bat_bufsz(unsigned char q_num, unsigned int buf_sz);
void drv_dpmaif_dl_set_ao_bat_rsv_length(unsigned char q_num,
	unsigned int length);
void drv_dpmaif_dl_set_ao_bid_maxcnt(unsigned char q_num, unsigned int cnt);
void drv_dpmaif_dl_set_pkt_alignment(unsigned char q_num,
	DRV_BOOL enable, unsigned int mode);
void drv_dpmaif_dl_set_pkt_alignment(unsigned char q_num,
	DRV_BOOL enable, unsigned int mode);
void drv_dpmaif_dl_set_ao_mtu(unsigned int mtu_sz);
void drv_dpmaif_dl_set_ao_pit_chknum(unsigned char q_num, unsigned int number);
void drv_dpmaif_dl_set_ao_bat_check_thres(unsigned char q_num,
	unsigned int size);
void drv_dpmaif_dl_set_ao_frg_check_thres(unsigned char q_num,
	unsigned int size);
void drv_dpmaif_dl_set_bat_base_addr(unsigned char q_num, unsigned long addr);
void drv_dpmaif_dl_set_pit_base_addr(unsigned char q_num, unsigned long addr);
void drv_dpmaif_dl_set_bat_size(unsigned char q_num, unsigned int size);
void drv_dpmaif_dl_set_pit_size(unsigned char q_num, unsigned int size);
void drv_dpmaif_dl_pit_en(unsigned char q_num, DRV_BOOL enable);
void drv_dpmaif_dl_bat_en(unsigned char q_num, DRV_BOOL enable);
void drv_dpmaif_dl_bat_init_done(unsigned char q_num, DRV_BOOL frg_en);
void drv_dpmaif_dl_pit_init_done(unsigned char q_num);

DRV_BOOL drv_dpmaif_config_que_hw(hifdpmaif_property_t *p_property);
DRV_BOOL drv_dpmaif_config_tx_que_hw(hifdpmaif_property_t *p_property);

unsigned int drv_dpmaif_ul_get_ridx(unsigned char q_num);
int drv_dpmaif_ul_add_wcnt(unsigned char q_num, unsigned int drb_entry_cnt);
void drv_dpmaif_ul_restore(unsigned char q_num, unsigned int restore_ridx);
void drv_dpmaif_ul_arb_en(unsigned char q_num, DRV_BOOL enable);
void drv_dpmaif_ul_rdy_en(unsigned char q_num, DRV_BOOL ready);
unsigned int drv_dpmaif_ul_get_drb_size(unsigned int q_num);
void drv_dpmaif_ul_update_drb_size(unsigned char q_num, unsigned int size);
void drv_dpmaif_ul_update_drb_base_addr(unsigned char q_num,
	unsigned long addr);

void drv_dpmaif_ul_queue_en(unsigned char q_num, DRV_BOOL enable);

void drv_dpmaif_ul_all_queue_en(DRV_BOOL enable);
void drv_dpmaif_dl_queue_en(unsigned char q_num, DRV_BOOL enable);
void drv_dpmaif_dl_all_queue_en(DRV_BOOL enable);
unsigned int drv_dpmaif_dl_idle_check(void);
unsigned int drv_dpmaif_ul_idle_check(unsigned char q_num);
unsigned int drv_dpmaif_ul_all_idle_check(void);

unsigned int drv_dpmaif_dl_get_pit_ridx(unsigned char q_num);
unsigned int drv_dpmaif_dl_get_bat_wridx(unsigned char q_num);

void drv_dpmaif_dl_set_pkt_checksum(void);

/*DPMAIF HISR API*/
unsigned int drv_dpmaif_get_ul_lv2_sts(void);
void drv_dpmaif_clr_ul_all_interrupt(void);
unsigned int drv_dpmaif_get_dl_lv2_sts(void);
void drv_dpmaif_clr_dl_all_interrupt(void);
unsigned int drv_dpmaif_get_ulq_done_sts(unsigned char q_num);
void drv_dpmaif_clr_ulq_done_sts(unsigned char q_num);
void drv_dpmaif_clr_ip_busy_sts(void);

void drv_dpmaif_clr_dlq_done_sts(unsigned char q_num);
void drv_dpmaif_dl_set_ao_dl_interrupt_mask(unsigned int mask);

void drv_dpmaif_mask_dl_que_interrupt(unsigned int q_num);
void drv_dpmaif_unmask_dl_que_interrupt(void);
void drv_dpmaif_unmask_ul_que_empty_interrupt(unsigned int q_num);


void drv_dpmaif_unmask_ul_que_interrupt(unsigned int q_num);
void drv_dpmaif_mask_ul_que_interrupt(unsigned int q_num);
void drv_dpmaif_mask_ul_que_empty_interrupt(unsigned int q_num);
void drv_dpmaif_unmask_dl_pkt_empty_interrupt(void);
void drv_dpmaif_mask_dl_pkt_empty_interrupt(void);

void drv_dpmaif_mask_dl_batcnt_len_err_interrupt(unsigned int q_num);
void drv_dpmaif_unmask_dl_batcnt_len_err_interrupt(void);
void drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(unsigned int q_num);
void drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt(void);

void drv_dpmaif_init_intr(void);
void drv_dpmaif_init_ul_intr(void);

int drv_dpmaif_dl_add_pit_remain_cnt(unsigned char q_num,
	unsigned int pit_remain_cnt);
unsigned int drv_dpmaif_dl_get_wridx(unsigned char q_num);
unsigned int drv_dpmaif_dl_get_pit_ridx(unsigned char q_num);
int drv_dpmaif_dl_add_bat_cnt(unsigned char q_num, unsigned int bat_entry_cnt);
unsigned int drv_dpmaif_dl_get_bat_ridx(unsigned char q_num);

void drv_dpmaif_dl_add_frg_cnt(unsigned char q_num, unsigned int frg_entry_cnt);
unsigned int drv_dpmaif_dl_get_frg_ridx(unsigned char q_num);

DRV_BOOL drv_dpmaif_check_power_down(void);
void dpmaif_drv_ap_reorder_en(void);

void dpmaif_drv_pcie_dpmaif_sign(void);
void drv_dpmaif_hw_reset(void);


#endif

