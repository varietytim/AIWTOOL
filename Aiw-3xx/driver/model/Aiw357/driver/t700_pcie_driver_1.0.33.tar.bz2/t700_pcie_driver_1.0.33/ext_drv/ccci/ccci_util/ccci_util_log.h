/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_UTIL_LOG_H__
#define __CCCI_UTIL_LOG_H__

/* -------------------------------------------------------------------- */
/*runtime debug level control*/
/* -------------------------------------------------------------------- */
/* No MD id message part */

enum {
	CCCI_LOG_ALL_UART = 1,
	CCCI_LOG_ALL_MOBILE,
	CCCI_LOG_CRITICAL_UART,
	CCCI_LOG_CRITICAL_MOBILE,
	CCCI_LOG_ALL_OFF,
};

extern int ccci_dump_write(int md_id, int buf_type,
	unsigned int flag, const char *fmt, ...);

/* -----------------------------------------------------------------------*/
/* For normal stage log ---------------------------------------------------*/
/* -----------------------------------------------------------------------*/
/* No MD id message part */
#define CCCI_UTIL_DBG_MSG(fmt, args...)\
do {\
	ccci_dump_write(0, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[0/util]" fmt, ##args);\
	ccci_dump_write(0, CCCI_DUMP_NORMAL, CCCI_DUMP_TIME_FLAG,\
		"[0/util]" fmt, ##args);\
} while (0)

#define CCCI_UTIL_INF_MSG(fmt, args...)\
do {\
	ccci_dump_write(0, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[0/util]" fmt, ##args);\
	ccci_dump_write(0, CCCI_DUMP_NORMAL, CCCI_DUMP_TIME_FLAG,\
		"[0/util]" fmt, ##args);\
} while (0)

#define CCCI_UTIL_ERR_MSG(fmt, args...)\
	ccci_dump_write(0, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[0/util]" fmt, ##args)\

/* With MD id message part */
#define CCCI_UTIL_DBG_MSG_WITH_ID(id, fmt, args...)\
do {\
	ccci_dump_write(id, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args);\
	ccci_dump_write(id, CCCI_DUMP_NORMAL, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args);\
} while (0)

#define CCCI_UTIL_INF_MSG_WITH_ID(id, fmt, args...)\
do {\
	ccci_dump_write(id, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args);\
	ccci_dump_write(id, CCCI_DUMP_NORMAL, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args);\
} while (0)

#define CCCI_UTIL_NOTICE_MSG_WITH_ID(id, fmt, args...)\
	ccci_dump_write(id, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args)\

#define CCCI_UTIL_ERR_MSG_WITH_ID(id, fmt, args...)\
	ccci_dump_write(id, CCCI_DUMP_INIT, CCCI_DUMP_TIME_FLAG,\
		"[%d/util]" fmt, (id+1), ##args)\

#endif /*__CCCI_UTIL_LOG_H__ */
