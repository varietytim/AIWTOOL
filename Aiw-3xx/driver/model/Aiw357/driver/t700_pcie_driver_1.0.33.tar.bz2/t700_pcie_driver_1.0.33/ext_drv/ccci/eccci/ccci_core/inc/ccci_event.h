/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


/*
 * If TRACE_SYSTEM is defined, that will be the directory created
 * in the ftrace directory under /sys/kernel/debug/tracing/events/<system>
 *
 * The define_trace.h below will also look for a file name of
 * TRACE_SYSTEM.h where TRACE_SYSTEM is what is defined here.
 * In this case, it would look for sample.h
 *
 * If the header name will be different than the system name
 * (as in this case), then you can override the header name that
 * define_trace.h will look up by defining TRACE_INCLUDE_FILE
 *
 * This file is called trace-events-sample.h but we want the system
 * to be called "sample". Therefore we must define the name of this
 * file:
 *
 * #define TRACE_INCLUDE_FILE trace-events-sample
 *
 * As we do an the bottom of this file.
 *
 * Notice that TRACE_SYSTEM should be defined outside of #if
 * protection, just like TRACE_INCLUDE_FILE.
 */
#undef TRACE_SYSTEM
#define TRACE_SYSTEM ccci_event

/*
 * Notice that this file is not protected like a normal header.
 * We also must allow for rereading of this file. The
 *
 *  || defined(TRACE_HEADER_MULTI_READ)
 *
 * serves this purpose.
 */
#if !defined(_CCCI_EVENTS_H) || defined(TRACE_HEADER_MULTI_READ)
#define _CCCI_EVENTS_H

/*
 * All trace headers should include tracepoint.h, until we finally
 * make it into a standard header.
 */
#include <linux/tracepoint.h>
#include "ccci_core.h"
//#define CCCI_CTL_TRACE
#define TRACE_LOG_LEN 64
/*
 * The TRACE_EVENT macro is broken up into 5 parts.
 *
 * name: name of the trace point. This is also how to enable the tracepoint.
 *   A function called trace_foo_bar() will be created.
 *
 * proto: the prototype of the function trace_foo_bar()
 *   Here it is trace_foo_bar(char *foo, int bar).
 *
 * args:  must match the arguments in the prototype.
 *    Here it is simply "foo, bar".
 *
 * struct:  This defines the way the data will be stored in the ring buffer.
 *    There are currently two types of elements. __field and __array.
 *    a __field is broken up into (type, name). Where type can be any
 *    type but an array.
 *    For an array. there are three fields. (type, name, size). The
 *    type of elements in the array, the name of the field and the size
 *    of the array.
 *
 *    __array( char, foo, 10) is the same as saying   char foo[10].
 *
 * fast_assign: This is a C like function that is used to store the items
 *    into the ring buffer.
 *
 * printk: This is a way to print out the data in pretty print. This is
 *    useful if the system crashes and you are logging via a serial line,
 *    the data can be printed to the console using this "printk" method.
 *
 * Note, that for both the assign and the printk, __entry is the handler
 * to the data structure in the ring buffer, and is defined by the
 * TP_STRUCT__entry.
 */

/* for UL flow */
TRACE_EVENT(md_cldma_send_skb,
		TP_PROTO(const void *gpd, int budget),

		TP_ARGS(gpd, budget),

		TP_STRUCT__entry(
			__field(int, budget)
			__field(const void *, gpd)
		),

		TP_fast_assign(
			__entry->budget = budget;
			__entry->gpd = gpd;
		),

		TP_printk("gpd:%p budget:%d ", __entry->gpd, __entry->budget)
	);

TRACE_EVENT(cldma_gpd_tx_collect,
		TP_PROTO( void *skb, int txq_id, int budget, int count),

		TP_ARGS(skb, txq_id, budget, count),

		TP_STRUCT__entry(
			__field(void *, skb)
			__field(int, budget)
			__field(int, txq_id)
			__field(int, count)
		),

		TP_fast_assign(
			__entry->budget = budget;
			__entry->skb = skb;
			__entry->txq_id = txq_id;
			__entry->count = count;
		),

		TP_printk(
			"tx_qno:%d skb_addr:%p budget:%d count:%d",
			 __entry->txq_id, __entry->skb, __entry->budget, __entry->count)
	);
/* for DL flow */
TRACE_EVENT(cldma_irq_work_cb,
		TP_PROTO(void *tr_x, int irq_status),

		TP_ARGS(tr_x, irq_status),

		TP_STRUCT__entry(
			__string(str, tr_x)
			__field(int, irq_status)
		),

		TP_fast_assign(
			__assign_str(str, tr_x);
			__entry->irq_status = irq_status;
		),

		TP_printk("%s irq:%d", __get_str(str), __entry->irq_status)
	);

TRACE_EVENT(cldma_gpd_rx_collect,
		TP_PROTO(unsigned int rxq_id, unsigned int rgpd_buff_len,
			void *skb, void *rgpd_addr),

		TP_ARGS(rxq_id, rgpd_buff_len, skb, rgpd_addr),

		TP_STRUCT__entry(
				__field(unsigned int, rxq_id)
				__field(unsigned int, rgpd_buff_len)
				__field(void *, skb)
				__field(void *, rgpd_addr)
		),

		TP_fast_assign(
			__entry->rxq_id = rxq_id;
			__entry->rgpd_buff_len = rgpd_buff_len;
			__entry->skb = skb;
			__entry->rgpd_addr = rgpd_addr;
		),

		TP_printk(
			"rxq%d rgpd_len:%d skb_addr:0x%p rgpd_addr:0x%p",
			__entry->rxq_id, __entry->rgpd_buff_len, __entry->skb, __entry->rgpd_addr)
	);

/* exception flow */
TRACE_EVENT(md_ex_isr,
		TP_PROTO(unsigned int exp_id),

		TP_ARGS(exp_id),

		TP_STRUCT__entry(__field(unsigned int, exp_id)),

		TP_fast_assign(__entry->exp_id = exp_id;),

		TP_printk("exp_id:%d", __entry->exp_id)
	);

TRACE_EVENT(fsm_append_command,
		TP_PROTO(unsigned int cmd_id, unsigned int flag, void *p),

		TP_ARGS(cmd_id, flag, p),

		TP_STRUCT__entry(
			__field(unsigned int, cmd_id)
			__field(unsigned int, flag)
			__field(void *, p)
		),

		TP_fast_assign(
			__entry->cmd_id = cmd_id;
			__entry->flag = flag;
			__entry->p = p;
		),

		TP_printk("cmd_id:%d, flag:%d, from:%p",
			__entry->cmd_id, __entry->flag, __entry->p)
	);

TRACE_EVENT(fsm_main_thread,
		TP_PROTO(unsigned int cmd_id),

		TP_ARGS(cmd_id),

		TP_STRUCT__entry(__field(unsigned int, cmd_id)),

		TP_fast_assign(__entry->cmd_id = cmd_id;),

		TP_printk("command %d process", __entry->cmd_id)
	);

TRACE_EVENT(fsm_routine_exception,
		TP_PROTO(void *str),

		TP_ARGS(str),

		TP_STRUCT__entry(__string(str,	str)),

		TP_fast_assign(__assign_str(str, str);),

		TP_printk("%s", __get_str(str))
	);

TRACE_EVENT(ccci_fsm_recv_control_packet,
		TP_PROTO(const struct ccci_header *ccci_h),

		TP_ARGS(ccci_h),

		TP_STRUCT__entry(
				__field(unsigned int, data1)
				__field(unsigned int, reserved)
		),

		TP_fast_assign(
				__entry->data1 = ccci_h->data[1];
				__entry->reserved = ccci_h->reserved;
		),

		TP_printk("contorl message 0x%x,0x%x",
			__entry->data1, __entry->reserved)
	);

TRACE_EVENT(fsm_append_event,
		TP_PROTO(unsigned int event_id, void *p),

		TP_ARGS(event_id, p),

		TP_STRUCT__entry(
			__field(unsigned int, event_id)
			__field(void *, p)
		),

		TP_fast_assign(
			__entry->event_id = event_id;
			__entry->p = p;
		),

		TP_printk("event%d is appended from %p",
			__entry->event_id, __entry->p)
	);

TRACE_EVENT(wait_hif_ex_hk_event,
		TP_PROTO(unsigned int exp_id),

		TP_ARGS(exp_id),

		TP_STRUCT__entry(__field(unsigned int, exp_id)),

		TP_fast_assign(__entry->exp_id = exp_id;),

		TP_printk("EX CCIF HS poll RCHNUM 0x%4x", __entry->exp_id)
	);

/* Initialization  Flow */
TRACE_EVENT(ccci_modem_probe,
		TP_PROTO(void *str),

		TP_ARGS(str),

		TP_STRUCT__entry(__string(str,	str)
		),

		TP_fast_assign(__assign_str(str, str);),

		TP_printk("%s", __get_str(str))
	);

TRACE_EVENT(ccci_hif_init,
		TP_PROTO(void *str),

		TP_ARGS(str),

		TP_STRUCT__entry(__string(str,	str)),

		TP_fast_assign(__assign_str(str, str);),

		TP_printk("%s", __get_str(str))
	);

TRACE_EVENT(fsm_routine_start,
		TP_PROTO(void *str),

		TP_ARGS(str),

		TP_STRUCT__entry(__string(str, str)),

		TP_fast_assign(__assign_str(str, str);),

		TP_printk("%s", __get_str(str))
	);

TRACE_EVENT(md_start,
		TP_PROTO(void *str),

		TP_ARGS(str),

		TP_STRUCT__entry(__string(str, str)),

		TP_fast_assign(__assign_str(str, str);),

		TP_printk("%s", __get_str(str))
	);
#endif
/***** NOTICE! The #if protection ends here. *****/

/*
 * There are several ways I could have done this. If I left out the
 * TRACE_INCLUDE_PATH, then it would default to the kernel source
 * include/trace/events directory.
 *
 * I could specify a path from the define_trace.h file back to this
 * file.
 *
 * #define TRACE_INCLUDE_PATH ../../samples/trace_events
 *
 * But the safest and easiest way to simply make it use the directory
 * that the file is in is to add in the Makefile:
 *
 * CFLAGS_trace-events-sample.o := -I$(src)
 *
 * This will make sure the current path is part of the include
 * structure for our file so that define_trace.h can find it.
 *
 * I could have made only the top level directory the include:
 *
 * CFLAGS_trace-events-sample.o := -I$(PWD)
 *
 * And then let the path to this directory be the TRACE_INCLUDE_PATH:
 *
 * #define TRACE_INCLUDE_PATH samples/trace_events
 *
 * But then if something defines "samples" or "trace_events" as a macro
 * then we could risk that being converted too, and give us an unexpected
 * result.
 */
#undef TRACE_INCLUDE_PATH
#undef TRACE_INCLUDE_FILE
#define TRACE_INCLUDE_PATH .
/*
 * TRACE_INCLUDE_FILE is not needed if the filename and TRACE_SYSTEM are equal
 */
#define TRACE_INCLUDE_FILE ccci_event
#include <trace/define_trace.h>
