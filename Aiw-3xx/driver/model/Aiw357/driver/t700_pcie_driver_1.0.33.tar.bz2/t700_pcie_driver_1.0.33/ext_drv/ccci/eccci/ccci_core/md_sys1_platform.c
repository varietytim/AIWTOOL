// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include "ccci_config.h"
#include <linux/clk.h>
#include "ccci_core.h"
#include "ccci_platform.h"
#include "md_sys1_platform.h"
#include "ccci_hif.h"
#include "modem_reg_base.h"
#include "ccci_driver.h"
#include "mtk-pci.h"
#include "mhccif_reg.h"
#include "mhccif.h"

#define TAG "PLT"
#define ROr2W(a, b, c)	ccci_write32(a, b, (ccci_read32(a, b)|c))
#define RAnd2W(a, b, c)	 ccci_write32(a, b, (ccci_read32(a, b)&c))
#define RabIsc(a, b, c) ((ccci_read32(a, b)&c) != c)
/*
 * control mhccif to enable/disable mhccif interrupt  
 * para ismask 0: unmask , 1: mask
 */
void md_mhccif_mask_set(struct ccci_modem *md, u32 bitmask, bool ismask) 
{
	if (ismask) {
		mhccif_mask_set(md->mtk_dev, bitmask);
	} else {
		mhccif_mask_clr(md->mtk_dev, bitmask);
	}
}
int md_get_mdsys1_hw_info(struct mtk_pci_dev *mtk_dev,
	struct ccci_dev_cfg *dev_cfg, struct ccci_modem *md)
{
	int err;
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;

	if (!md_info) {
		MTK_ERR_LOG(TAG, "invalid input:md_info is NULL\n");
		return -1;
	}
	memset(dev_cfg, 0, sizeof(struct ccci_dev_cfg));
	dev_cfg->index = 0;
	dev_cfg->capability = 0x6;

	/*configurate Modem sys control, data, exception path id*/
	ccci_hif_path[dev_cfg->index][HIF_PATH_CTRL] = HIF_ID_CLDMA_PCIE;
	ccci_hif_path[dev_cfg->index][HIF_PATH_CTRL_1] = HIF_ID_CLDMA0_PCIE;
	#if defined(ENABLE_CCCI_DRI_UT)
	ccci_hif_path[dev_cfg->index][HIF_PATH_DATA] = -1;
	ccci_hif_path[dev_cfg->index][HIF_PATH_EX] = -1;
	#else //ENABLE_CCCI_DRI_UT
	ccci_hif_path[dev_cfg->index][HIF_PATH_DATA] = HIF_ID_DPMAIF_PCIE;
	ccci_hif_path[dev_cfg->index][HIF_PATH_EX] = HIF_ID_PCIE;
	#endif ///ENABLE_CCCI_DRI_UT

	MTK_DEBUG_LOG(TAG, "CTRL_PATH hif_id = %d, CTRL1_PATH hif_id = %d\n",
		ccci_hif_path[dev_cfg->index][HIF_PATH_CTRL],
		ccci_hif_path[dev_cfg->index][HIF_PATH_CTRL_1]);
	MTK_DEBUG_LOG(TAG, "DATA_PATH hif_id = %d ,EX_PATH hif_id = %d\n",
		ccci_hif_path[dev_cfg->index][HIF_PATH_DATA],
		ccci_hif_path[dev_cfg->index][HIF_PATH_EX]);

	err = ccci_hif_get_hw_info(dev_cfg->index,
		HIF_FLAG_CTRL_DATA|HIF_FLAG_EX, mtk_dev);

	return err;

}

void md_dump_debug_register(struct ccci_modem *md)
{
}

int md_soft_power_off(struct ccci_modem *md, unsigned int mode)
{
	return 0;
}

int md_soft_power_on(struct ccci_modem *md, unsigned int mode)
{
	return 0;
}

int md_power_on(struct ccci_modem *md)
{
	MTK_DEBUG_LOG(TAG, "Hardware operation to poweron MD\n");
	return 0;
}

int md_let_md_go(struct ccci_modem *md)
{
	return 0;
}

int md_power_off(struct ccci_modem *md, unsigned int timeout)
{
	int ret = 0;

	MTK_DEBUG_LOG(TAG, "Hardware operation to poweroff MD\n");
	return ret;
}

void ccci_modem_restore_reg(struct ccci_modem *md)
{
}

int ccci_modem_syssuspend(void)
{
	MTK_DEBUG_LOG(TAG, "%s\n", __func__);
	return 0;
}

void ccci_modem_sysresume(void)
{
	struct ccci_modem *md;

	MTK_DEBUG_LOG(TAG, "%s\n", __func__);
	md = ccci_md_get_modem_by_id(0);
	if (md != NULL)
		ccci_modem_restore_reg(md);
}
#ifdef FT_PORT_ENUM
void ccci_dummy_register_val_write(struct ccci_modem *md, int n)
{
	if(unlikely(md == NULL || md->mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid arguments\n");
		return;
	}
	REG_IO_WRITE32(MTK_REG_BASE_PCIE_DEBUG_DUMMY_7(
		md->mtk_dev->base_addr.pcie_mac_ireg_base), n);
}
u32 ccci_dummy_register_val_get(struct ccci_modem *md, int n)
{
	//temporarily use the mhccif register instead
	u32 ret = 0;
	
	if(unlikely(md == NULL || md->mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid arguments\n");
		return -EINVAL;
	}
	
	ret = REG_IO_READ32(MTK_REG_BASE_PCIE_DEBUG_DUMMY_7(
		md->mtk_dev->base_addr.pcie_mac_ireg_base));

	return ret;
}
#else
void ccci_dummy_register_val_write(struct ccci_modem *md, int n){
}
u32 ccci_dummy_register_val_get(struct ccci_modem *md, int n)
{
	unsigned int port_event_val = 0;
	unsigned int retval = 0x4;

	port_event_val = mod_param_val & MOD_PARAM_BITMASK_PORT_EVENT;
	switch (port_event_val) {
	case 0:
		retval = 0x4;
		break;
	case 1:
		retval = 0x41;
		break;
	case 2:
		retval = 0x103;
		break;
	default:
		MTK_ERR_LOG(TAG, "port_event %d is undefined\n",
			port_event_val);
		break;
	}
	return retval;
}
#endif

