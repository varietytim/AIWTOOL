/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MHCCIF_H__
#define __MHCCIF_H__

#include "mhccif_reg.h"

#define MHCCIF_INT_CH_NUMBER (32)

/* MHCCIF Channel Number, Host to Device */
#define MHCCIF_H2D_INT_except_ack                             (1)
#define MHCCIF_H2D_INT_except_clearQ_ack                 (2)
#define MHCCIF_H2D_INT_PCIE_DS_LOCK                       (3) /* PCIE PM */
#define MHCCIF_H2D_RESERVED_FOR_CLDMA0               (4)
#define MHCCIF_H2D_RESERVED_FOR_CLDMA1               (5)
#define MHCCIF_H2D_RESERVED_FOR_CLDMA3               (6)
#define MHCCIF_H2D_RESERVED_FOR_CLDMA2               (7)
#define MHCCIF_H2D_RESERVED_FOR_DPMAIF               (8)
#define MHCCIF_H2D_INT_PCIE_PM_SUSPEND_REQ        (9)
#define MHCCIF_H2D_INT_PCIE_PM_RESUME_REQ         (10)
#define MHCCIF_H2D_INT_PCIE_PM_SUSPEND_REQ_AP  (11)
#define MHCCIF_H2D_INT_PCIE_PM_RESUME_REQ_AP    (12)
#define MHCCIF_H2D_INT_DEVICE_RESET    			(13)
#define MHCCIF_H2D_INT_DRM_DISABLE_AP    		(14)

/* MHCCIF Channel Number, Device to Host */
#define MHCCIF_D2H_INT_PCIE_DS_LOCK_ACK                (0)
#define MHCCIF_D2H_INT_except_init                               (1)
#define MHCCIF_D2H_INT_except_init_done                      (2)
#define MHCCIF_D2H_INT_except_clearQ_done                 (3)
#define MHCCIF_D2H_INT_except_allQ_reset                    (4)
#define MHCCIF_BOOT_FLOW_SYNC                                  (5)
//PCIE/PM
#define MHCCIF_D2H_RESERVED_FOR_CLDMA0               (6)
#define MHCCIF_D2H_RESERVED_FOR_CLDMA1               (7)
#define MHCCIF_D2H_RESERVED_FOR_CLDMA3               (8)
#define MHCCIF_D2H_RESERVED_FOR_CLDMA0_2           (9)
#define MHCCIF_D2H_RESERVED_FOR_DPMAIF                (10)
#define MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK        (11)
#define MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK          (12)
#define MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK_AP  (13)
#define MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK_AP    (14)
#define MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_SAP        (15)
#define MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_MD         (16)

/* MHCCIF Spare Register Number, Host to Device */
#define MHCCIF_H2D_REG_PCIE_PM_MSG                       (1)
#define MHCCIF_H2D_REG_PCIE_PM_MSG_AP                 (2)

/* MHCCIF Spare Register Number, Device to Host */
#define MHCCIF_D2H_REG_PCIE_PM_MSG                       (1)
#define MHCCIF_D2H_REG_PCIE_PM_MSG_AP                 (2)



#define H2D_INT_CCCI_EXP_ACK(n)    RC2EP_SW_SET_BSY_N(n)

#define    MHCCIF_RC2EP_CHANNEL_L_RES_LOCK      0
#define    MHCCIF_RC2EP_CHANNEL_D3_ENTER         1
#define    MHCCIF_RC2EP_CHANNEL_D3_EXIT            1


#define MHCCIF_EP2RC_CHANNEL_L


bool mhccif_spare_reg_ep_get(struct mtk_pci_dev *mtk_dev,u32 set, u32 *data);
bool mhccif_spare_reg_rc_get(struct mtk_pci_dev *mtk_dev,u32 set, u32 *data);
bool mhccif_spare_reg_rc_set(struct mtk_pci_dev *mtk_dev,u32 set, u32 data);
void mhccif_mask_set(struct mtk_pci_dev *mtk_dev, u32 val);
void mhccif_mask_clr(struct mtk_pci_dev *mtk_dev, u32 val);
u32 mhccif_mask_get(struct mtk_pci_dev *mtk_dev);
void mhccif_update_reg_trsl_addr(struct mtk_pci_dev *mtk_dev);
int mhccif_int_callback(void *param);
int mhccif_init(void *param);
int mhccif_deinit(void *param);
void mtk_pcie_clear_mhccif_int(struct mtk_pci_dev *mtk_dev, u32 reg);
bool mhccif_ep2rc_reg_read(struct mtk_pci_dev *mtk_dev,u32 *reg);
void mhccif_rc2ep_swint_trigger(struct mtk_pci_dev *mtk_dev,u32 channel);
void __mhccif_rc2ep_swint_trigger(struct mtk_pci_dev *mtk_dev, u32 channel);
void __mhccif_print_ep_reg_status(struct mtk_pci_dev *mtk_dev);


#endif /*__MHCCIF_H__*/
