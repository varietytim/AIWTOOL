/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_PROXY_H__
#define __PORT_PROXY_H__
#include <linux/skbuff.h>
#include <net/sock.h>
#include <linux/netlink.h>
#include <mt-plat/mtk_ccci_common.h>
#include "port_t.h"
#ifdef M7X
#include "ccmni.h"
#endif
#include "ccci_hif.h"

#ifndef MAX_HIF_NUM
#define MAX_HIF_NUM HIF_ID_MAX
#endif

#ifndef MAX_QUEUE_NUM
#define MAX_QUEUE_NUM 16
#endif

#define PORT_STATE_ENABLE			(0)
#define PORT_STATE_DISABLE			(1)
#define PORT_STATE_INVALID			(2)

struct port_proxy {
	int md_id;
	int port_number;
	struct kobject kobj;
	unsigned int major;
	unsigned int minor_base;
	unsigned int critical_user_active;
	unsigned int traffic_dump_flag;
	unsigned char current_cfg_id;
	/*do NOT use this manner, otherwise spinlock inside private_data
	 *will trigger alignment exception
	 */
	struct port_t *ports;
	struct port_t *sys_port;
	struct port_t *ctl_port;
	// raw data single port <-> single Q
	struct port_t *dedicated_ports[MAX_HIF_NUM][MAX_QUEUE_NUM];
	/* port list of each Rx channel, for Rx dispatching
	 *  hash table
	 */
	struct list_head rx_ch_ports[CCCI_MAX_CH_ID];
	/* port list of each queue for receiving queue status dispatching */
	struct list_head queue_ports[MAX_HIF_NUM][MAX_QUEUE_NUM];
	/*all ee port linked in a list*/
	struct list_head exp_ports;
	unsigned long long latest_rx_thread_time;
	struct sock *netlink_sock;
};

struct ctrl_msg_header {
	u32 ctrl_msg_id;
	u32 reserved;
	u32 data_length;
	u8 data[0];
}__packed;

struct port_info_t {
	u32 ch_id:15;
	u32 en_flag:1; /*1:enable, 0:disable*/
	u32 reserved:16; /*no use now*/
}__packed;

struct port_enum_msg_t{
	u32 head_pattern;
	u32 port_count:16;
	u32 version:16;
	u32 tail_pattern;
	u8 data[0]; /*port set info*/
}__packed;

#define PORT_ENUM_VER 0
#define PORT_ENUM_HEAD_PATTERN 0x5a5a5a5a
#define PORT_ENUM_TAIL_PATTERN 0xa5a5a5a5
#define PORT_ENUM_VER_DISMATCH 0x00657272
/*****************************************************************************/
/* External API Region called by port proxy object */
/*****************************************************************************/
extern struct port_proxy *proxy_table[MAX_MD_NUM];
#define GET_PORT_PROXY(md_id) (proxy_table[md_id])
#define SET_PORT_PROXY(md_id, proxy_p) (proxy_table[md_id] = proxy_p)

int port_recv_skb_from_dedicatedQ(unsigned char md_id, unsigned char hif_id,
	unsigned char qno, struct sk_buff *skb);
int ccci_port_send_hif(struct port_t *port, struct sk_buff *skb,
	unsigned char from_pool, unsigned char blocking);
void port_inc_tx_seq_num(struct port_t *port, struct ccci_header *ccci_h);
int ccci_port_status_update(int md_id, void *data);
void port_reset(unsigned char md_id);
int port_broadcast_state(struct port_t *port, int state);
int port_broadcast_minidump_status(struct port_t *port, const char *buff, int len);

extern int __attribute__((weak))
	port_ipc_write_check_id(struct port_t *port, struct sk_buff *skb);

#if defined(M7X) && defined(CONFIG_MTK_NET_CCMNI)
extern int ccci_get_ccmni_channel(int md_id,
	int ccmni_idx, struct ccmni_ch *channel);
#else
#define ccci_get_ccmni_channel(x, y, z) ({0; })
#endif

#endif /* __PORT_PROXY_H__ */
