/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_DPMA_H__
#define __MODEM_DPMA_H__

#include <linux/device.h>
#include <linux/pm_wakeup.h>
#include <linux/dmapool.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/hrtimer.h>
#include <linux/skbuff.h>
#include <mt-plat/mtk_ccci_common.h>

#include "ccci_config.h"
#include "ccci_bm.h"
#include "ccci_hif_internal.h"

#include "ccci_driver.h"
#include "ccci_hif_internal.h"
#include "dpmaif_hif_platform.h"
#include "ccci_driver_dpmaif.h"

#include "mtk-pci.h"


typedef struct dpmaif_ul_pkt_info {
	unsigned int total_len;
	unsigned int pkt_cnt;
	unsigned int *data_len;
	void **data_addr;
	unsigned int remain_len;
	void *remain_data_addr;
} dpmaif_ul_pkt_info_t;

#define DPMAIF_RXQ_NUM			MAIFQ_MAX_DLQ_NUM
#define DPMAIF_TXQ_NUM			MAIFQ_MAX_ULQ_NUM

#define DPMAIF_BUF_PKT_SIZE		NET_RX_BUF

#define DPMF_BAT_CNT_UPDATE_THRESHOLD		10
#define DPMF_PIT_CNT_UPDATE_THRESHOLD		20
#define DPMF_RX_PUSH_THRESHOLD_MASK			(0x7)
#define DPMF_NOTIFY_RELEASE_COUNT			 (128)


#define DPMAIF_PIT_SEQ_MAGIC				(0xFFFF)
#define DPMAIF_PIT_REL_BATCH_NUM  (DP_CACHE_LINE_SIZE/DPMAIF_DL_PIT_BYTE_SIZE)

#define DPMAIF_TX_RETRY_TIMES (5)
#define DPMAIF_TX_BURST_SEND_COUNT			(1024)

/*
 **	DPMAIF HW checksum check result
 */
typedef enum dpmaif_cs_check_result {
	DPMF_CS_RESULT_INVALID = -1,
	DPMF_CS_RESULT_PASS = 0x00,
	DPMF_CS_RESULT_FAIL = 0x01,
	DPMF_CS_RESULT_NOTSUPPORT = 0x02,
	DPMF_CS_RESULT_RESERVE = 0x03
} dpmaif_cs_check_result_t, *dpmaif_cs_check_result_ptr_t;

struct ringbuf_str {
unsigned int rd_idx;
unsigned int wrt_idx;
unsigned int buf_len;
};

/****************************************************************************
 * Structure of DL PIT
 ****************************************************************************/
struct dpmaifq_normal_pit {
	unsigned int	packet_type:1;
	unsigned int	c_bit:1;
	unsigned int	buffer_type:1;
	unsigned int	buffer_id:13;
	unsigned int	data_len:16;
	unsigned int	p_data_addr;
	unsigned int	data_addr_ext;
	unsigned int	pit_seq:16;
	unsigned int	ig:1;
	unsigned int	reserved2:7;
	unsigned int	ulq_done:6;
	unsigned int	dlq_done:2;
};

/* packet_type */
#define DES_PT_PD			0x00
#define DES_PT_MSG			0x01

struct dpmaifq_msg_pit {
	unsigned int	packet_type:1;
	unsigned int	c_bit:1;
	unsigned int	check_sum:2;
	unsigned int	error_bit:1;
	unsigned int	src_qid:3;
	unsigned int	reserved:8;
	unsigned int	channel_id:8;
	unsigned int	network_type:3;
	unsigned int	reserved2:4;
	unsigned int	dp:1;

	unsigned int	count_l:16;
	unsigned int	flow:5;
	unsigned int	reserved3:3;
	unsigned int	cmd:3;
	unsigned int	reserved4:5;

	unsigned int	reserved5:3;
	unsigned int	vbid:13;
	unsigned int	reserved6:16;

	unsigned int	pit_seq:16;
	unsigned int	ig:1;
	unsigned int	reserved7:7;
	unsigned int	ulq_done:6;
	unsigned int	dlq_done:2;
};

/****************************************************************************
 * Structure of DL BAT
 ****************************************************************************/
struct dpmaif_bat_t {
	unsigned int	p_buffer_addr;
	unsigned int	buffer_addr_ext;
};


struct dpmaif_bat_skb_t {
	struct sk_buff *skb;
	dma_addr_t data_phy_addr;
	unsigned int data_len;
};

#define MAX_BD_NUM (MAX_SKB_FRAGS + 1)
/* 0 for disable traffic monitor */
#define DPMAIF_TRAFFIC_MONITOR_INTERVAL 0
#define SKB_RX_LIST_MAX_LEN 0xFFFFFFFF

struct dpmaif_bat_request {
	void *bat_base;
	dma_addr_t bat_phy_addr; /* physical address for DMA */
	unsigned int	bat_size_cnt;
	unsigned short	  bat_wr_idx;
	unsigned short	  bat_rd_idx;
	unsigned short	  bat_rel_rd_idx;
	void *bat_skb_ptr;/* collect skb linked to bat */
	unsigned int	 skb_pkt_cnt;
	unsigned int pkt_buf_sz;

	/* newly added */
	unsigned char *bat_mask;
};

enum error_num {
	LOW_MEMORY_ERR = -15,
	LOW_MEMORY_PIT,
	LOW_MEMORY_BAT,
	LOW_MEMORY_SKB,
	LOW_MEMORY_DRB,
	LOW_MEMORY_TYPE_MAX, /* -10 */

	DMA_MAPPING_ERR,
	FLOW_CHECK_ERR,
	DATA_CHECK_FAIL,
	HW_REG_CHK_FAIL,
	ERROR_STOP_MAX, /* -5 */
};

struct dpmaif_rx_queue {
	unsigned char index;
	bool que_started;
	unsigned short budget;

	void *pit_base;
	dma_addr_t pit_phy_addr; /* physical address for DMA */
	unsigned int	pit_size_cnt;

	unsigned short	  pit_rd_idx;
	unsigned short	  pit_wr_idx;
	unsigned short	  pit_rel_rd_idx;
	unsigned int	  pit_not_rel_entrynum;

	unsigned int reg_int_mask_bak;

	struct dpmaif_bat_request bat_req;
	struct dpmaif_bat_request frg_bat_req;	/* for FRG_BAT feature */

#if !defined(DATA_PATH_NET_NAPI_MODE) || defined(DATA_PATH_UT_LOOPBACK)
	wait_queue_head_t rx_wq;
	struct task_struct *rx_thread;
	struct ccci_skb_queue skb_list;
#endif
#ifndef DATA_PATH_NET_NAPI_MODE
	struct tasklet_struct dpmaif_rxq0_task;
	struct workqueue_struct *worker;
	struct work_struct dpmaif_rxq0_work;
#endif
	spinlock_t rx_lock;
	atomic_t rx_processing;

	int	cur_chn_idx;
	unsigned char cs_result;
	bool begin_drop;

	int check_bid_fail_cnt;

	struct md_dpmaif_ctrl *dpmaif_ctrl;
	unsigned int expect_pit_seq;
	unsigned int pit_remain_rel_cnt;
	int cur_irq_cpu;	/* current CPU that isr is running on */
	/* current CPU that rx push thread is running on */
	int cur_rx_thrd_cpu;
};

/****************************************************************************
 * Structure of UL DRB
 ****************************************************************************
 */
/*
 * UL unit: WORD == 4bytes, && 1drb == 8bytes,
 * so 1 drb = size_cnt * 2, rd_idx_sw = rd_idx_hw/2.
 */
// #define DPMAIF_UL_DRB_ENTRY_WORD	 2 /* (sizeof(dpmaif_drb_pd)/4)*/
struct dpmaif_drb_pd {
	unsigned int	dtyp:2;
	unsigned int	c_bit:1;
	unsigned int	reserved:13;
	unsigned int	data_len:16;
	unsigned int	p_data_addr;
	unsigned int	data_addr_ext;
	unsigned int	reserved2;
};

/* drb->dtype */
#define DES_DTYP_PD			0x00
#define DES_DTYP_MSG		0x01
#define DES_DRB_CBIT		0x01

struct dpmaif_drb_msg {
	unsigned int	dtyp:2;
	unsigned int	c_bit:1;
	unsigned int	reserved:13;
	unsigned int	packet_len:16;
	unsigned int	count_l:16;
	unsigned int	channel_id:8;
	unsigned int	network_type:3;
	unsigned int	reserved2:5;
	unsigned int	reserved3;
	unsigned int	reserved4;
};

struct dpmaif_drb_skb {
	struct sk_buff *skb;
	void *clone_buffer;		/* this buffer for 8 bytes align */

	dma_addr_t phy_addr; /* physical address for DMA */
	unsigned short data_len;

	/* just for debug */
	unsigned short drb_idx:13;
	unsigned short is_msg:1;
	unsigned short is_frag:1;
	unsigned short is_last_one:1;
};

struct dpmaif_tx_queue {
	unsigned char index;
	bool que_started;
	atomic_t tx_budget;

	void	*drb_base;
	dma_addr_t drb_phy_addr;	/* physical address for DMA */
	unsigned int	drb_size_cnt;

	unsigned short		drb_wr_idx;
	unsigned short		drb_rd_idx;
	unsigned short		drb_rel_rd_idx;
	unsigned short	last_ch_id;

	void	*drb_skb_base;
	wait_queue_head_t req_wq;
	struct workqueue_struct *worker;
	struct delayed_work dpmaif_tx_work;
	spinlock_t tx_lock;
	atomic_t tx_processing;
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	unsigned int busy_count;
#endif

	/* newly added */
	struct md_dpmaif_ctrl *dpmaif_ctrl;

	/* tx thread skb_list */
	unsigned int tx_submit_cnt;
	unsigned int tx_list_max_len;
};

enum hifdpmaif_state {
	HIFDPMAIF_STATE_MIN	 = 0,
	HIFDPMAIF_STATE_PWROFF,
	HIFDPMAIF_STATE_PWRON,
	HIFDPMAIF_STATE_EXCEPTION,
	HIFDPMAIF_STATE_MAX,
};

#define UL_ALIGNMENT		(8)
#define ADDR_ALIGN(addr, alignment)\
	(0 == ((unsigned long)(addr) & ((alignment) - 1)))
#define SIZE_ALIGN_MASK(size, mask)\
	(((size) + (mask)) & (~(mask)))
#define SIZE_ALIGN(size, alignment)\
	(SIZE_ALIGN_MASK((size), (((typeof(size))alignment) - 1)))
#define SIZE_ALIGN_DOWN_MASK(size, mask)\
	((size) & (~(mask)))
#define SIZE_ALIGN_DOWN(size, alignment)\
	(SIZE_ALIGN_DOWN_MASK((size), (((typeof(size))alignment) - 1)))


#define DPMA_ALIGN_BUF_SIZE_TRUE(s)	SIZE_ALIGN(s, UL_ALIGNMENT)
#define DPMA_ALIGN_BUF_SIZE_MAX	DPMA_ALIGN_BUF_SIZE_TRUE(CCCI_NET_MTU)
/* each buffer size = DPMA_ALIGN_BUF_SIZE_MAX / (1 <<
 * DPMA_ALIGN_BUF_SIZE_DIV_POW * index)
 */
#define DPMA_ALIGN_BUF_SIZE_DIV_POW			(2)
#define DPMA_ALIGN_QUEUE_CNT				(4)
#define DPMA_ALIGN_BUF_CNT					(256)
#define DPMA_ALIGN_BUF_RELOAD_TH			(2)

/* data path align buffer pool */
struct dpmaif_align_buffer {
	struct list_head entry;
	unsigned char *buffer;
	unsigned int size;
	void *queue;
	/* for recycle */
	bool from_pool;
};
struct dpmaif_align_buf_queue {
	struct list_head buf_list;
	unsigned int size;
	unsigned int max_len;
	unsigned int busy_cnt;
	spinlock_t lock;
	unsigned int avail_cnt;
	unsigned int q_index;
};

struct dpmaif_align_buf_pool {
	struct dpmaif_align_buf_queue queue[DPMA_ALIGN_QUEUE_CNT];
	struct work_struct reload_work;
	unsigned int queue_cnt;
};

#define DPMA_GET_ALIGN_BUF(e)\
	(container_of(e, struct dpmaif_align_buffer, entry))

#define DPMA_SKB_SIZE_OVER_HEAD  SKB_DATA_ALIGN(sizeof(struct skb_shared_info))
#define DPMA_SKB_SIZE_EXTRA\
	(SKB_DATA_ALIGN((NET_SKB_PAD) + (DPMA_SKB_SIZE_OVER_HEAD)))
#define DPMA_SKB_SIZE_TRUE(s)	((s) + (DPMA_SKB_SIZE_EXTRA))
/* SHOULD less than PAGE_SIZE */
#define DPMA_SKB_SIZE_MAX			(DPMAIF_HW_BAT_PKTBUF)
#define DPMA_SKB_QUEUE_CNT			(1)
#define DPMA_SKB_QUEUE_SIZE\
	((DPMAIF_DL_BAT_ENTRY_SIZE) * DPMA_SKB_SIZE_TRUE(DPMA_SKB_SIZE_MAX))
#define DPMA_SKB_TRUE_SIZE_MIN		(32)
#define DPMA_RELOAD_TH_1			(4)
#define DPMA_RELOAD_TH_2			(5)
/* data path skb pool */
struct dpmaif_map_skb {
	struct list_head head;
	u32 qlen;
	spinlock_t lock;
};

struct dpmaif_skb_info {
	struct list_head entry;
	struct sk_buff *skb;
	unsigned int data_len;
	unsigned long long data_phy_addr;
};

struct dpmaif_skb_queue {
	//struct sk_buff_head skb_list;
	struct dpmaif_map_skb skb_list;
	unsigned int size;
	unsigned int max_len;
	unsigned long busy_cnt;
};

struct dpmaif_skb_pool {
	struct dpmaif_skb_queue queue[DPMA_SKB_QUEUE_CNT];
	struct workqueue_struct *pool_reload_work_queue;
	struct work_struct reload_work;
	unsigned int queue_cnt;
};

struct dpmaif_tx_event {
	struct list_head entry;
	unsigned char md_id;
	unsigned char hif_id;
	int qno;
	struct sk_buff *skb;
	int skb_from_pool;
	int blocking;
};

struct md_dpmaif_ctrl {
	enum hifdpmaif_state dpmaif_state;
	struct dpmaif_tx_queue txq[DPMAIF_TXQ_NUM];
	struct dpmaif_rx_queue rxq[DPMAIF_RXQ_NUM];
	struct dma_pool *tx_drb_dmapool;
	struct dma_pool *rx_pit_dmapool;
	struct dma_pool *rx_bat_dmapool;

	unsigned char md_id;
	unsigned char hif_id;
	struct ccci_hif_traffic traffic_info;

	/*void __iomem *dpmaif_ao_ul_base;
	 *void __iomem *dpmaif_ao_dl_base;
	 *void __iomem *dpmaif_pd_ul_base;
	 *void __iomem *dpmaif_pd_dl_base;
	 *void __iomem *dpmaif_pd_misc_base;
	 *void __iomem *dpmaif_pd_md_misc_base;
	 *void __iomem *dpmaif_pd_sram_base;

	 *unsigned int dpmaif_irq_id;
	 *unsigned long dpmaif_irq_flags;
	 */
	atomic_t dpmaif_irq_enabled;

	void *hif_hw_info;		// HW layer information
	struct ccci_hif_ops *ops;
	struct dpmaif_skb_pool skb_pool;
	struct dpmaif_align_buf_pool align_buf_pool;

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	unsigned long long tx_traffic_monitor[DPMAIF_TXQ_NUM];
	unsigned long long rx_traffic_monitor[DPMAIF_RXQ_NUM];
	unsigned long long tx_pre_traffic_monitor[DPMAIF_TXQ_NUM];
	unsigned long long tx_payload_monitor[DPMAIF_TXQ_NUM];
	unsigned long long tx_done_last_start_time[DPMAIF_TXQ_NUM];
	unsigned int tx_done_last_count[DPMAIF_TXQ_NUM];

	struct timer_list traffic_monitor;
	char traffic_started;
#endif

	bool dpmaif_sw_init_done;

	/* Lowpower*/
	struct mtk_pci_dev *mtk_dev;
	mtk_l_res_t lock_user;
	struct md_pm_entity dpmaif_pm_entity;

	/* TX thread */
	spinlock_t tx_event_lock;
	struct list_head tx_event_queue;
	wait_queue_head_t tx_wq;
	struct task_struct *tx_thread;
};

#define DPMF_GET_HIF_CTRL(md_id, hif_id)\
	((struct md_dpmaif_ctrl *)ccci_hif_get_by_id(md_id, hif_id))
#define DPMF_GET_HW_CTRL(md_id, hif_id)\
	((struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id))


static inline int ccci_dpma_hif_send_skb(unsigned char md_id,
	unsigned char hif_id, int tx_qno, struct sk_buff *skb,
	int from_pool, int blocking)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	if (hif_ctrl)
		return hif_ctrl->ops->send_skb(md_id, hif_id, tx_qno, skb,
			from_pool, blocking);
	else
		return -1;
}

static inline int ccci_dpma_hif_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	if (hif_ctrl)
		return hif_ctrl->ops->write_room(md_id, hif_id, qno);
	else
		return -1;

}
static inline int ccci_dpma_hif_give_more(unsigned char md_id,
	unsigned char hif_id, int rx_qno)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	if (hif_ctrl)
		return hif_ctrl->ops->give_more(md_id, hif_id, rx_qno);
	else
		return -1;

}

static inline int ccci_dpmaif_hif_dump_status(unsigned char md_id,
	unsigned char hif_id, enum modem_dump_flag dump_flag, void *data, int length)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	if (hif_ctrl)
		return hif_ctrl->ops->dump_status(md_id, hif_id,
			dump_flag, data, length);
	else
		return -1;
}

int ccci_dpmaif_hif_init(unsigned char md_id, unsigned char hif_id);
int dpmaif_sw_init(unsigned char md_id, unsigned char hif_id);
int dpmaif_start(unsigned char md_id, unsigned char hif_id);
int dpmaif_stop(unsigned char md_id, unsigned char hif_id);

void dpmaif_stop_hw(unsigned char md_id, unsigned char hif_id);
void dpmaif_pos_stop_hw(unsigned char md_id, unsigned char hif_id);

void dpmaif_pre_start_hw(unsigned char md_id, unsigned char hif_id);
void dpmaif_start_hw(unsigned char md_id, unsigned char hif_id);

#ifdef DATA_PATH_NET_NAPI_MODE
void dpmaif_init_napi_mode(void *para);
int dpmaif_napi_rx_poll(struct napi_struct *napi, int budget);
#endif
/* newly added */
void *ccci_dpmaif_get_hw_info(unsigned char md_id,
	unsigned char hif_id, struct mtk_pci_dev *dev_ptr);
void ccci_dpmaif_rel_hw_info(unsigned char md_id,
	unsigned char hif_id, struct mtk_pci_dev *dev_ptr);
void ccci_dpmaif_hif_exit(unsigned char md_id, unsigned char hif_id);
#endif				/* __MODEM_DPMA_H__ */
