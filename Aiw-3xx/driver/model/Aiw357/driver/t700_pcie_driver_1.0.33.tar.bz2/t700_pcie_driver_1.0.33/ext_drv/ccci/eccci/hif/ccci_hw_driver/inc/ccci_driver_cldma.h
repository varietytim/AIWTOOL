/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_CLDMAHWDRV_H__
#define __MODEM_CLDMAHWDRV_H__

//?? temp ccci_structure.h for test
#include "ccci_driver.h"
#include "sync_write.h"
#include <mt_reg_base.h>
#include <mt_irqid.h>

#define cldma_write32(b, a, v)			mt_reg_sync_writel(v, (b) + (a))
#define cldma_write16(b, a, v)			mt_reg_sync_writew(v, (b) + (a))
#define cldma_write8(b, a, v)			mt_reg_sync_writeb(v, (b) + (a))

#define cldma_read32(b, a)	ioread32((void __iomem *)((b) + (a)))
#define cldma_read16(b, a)	ioread16((void __iomem *)((b) + (a)))
#define cldma_read8(b, a)	ioread8((void __iomem *)((b) + (a)))

extern u64 g_CLDMA_AO_BASE;
extern u64 g_CLDMA_PD_BASE;

#define CLDMA_TQ_NUM 8
#define CLDMA_RQ_NUM 8

/*interrupt status bit meaning , bitmask*/
#define IRQ_TYPE_TXRX 1
#define IRQ_TYPE_EQ 2
#define STATUS_BITMASK 0xFFFF
#define EQ_STA_BIT_OFFSET 8
#define EMPTY_STATUS_BITMASK 0xFF00
#define TXRX_STA_BIT_OFFSET 0
#define TXRX_STATUS_BITMASK 0x00FF

/*/*L2RISAR0*/
#define TQ_ERR_INT_OFFSET					(16)
#define TQ_ERR_INT_BITMASK					(0X00FF0000)
#define TQ_ACTIVE_START_ERR_INT_OFFSET		(24)
#define TQ_ACTIVE_START_ERR_INT_BITMASK		(0XFF000000)

/*L2RISAR0*/
#define RQ_ERR_INT_OFFSET					(16)
#define RQ_ERR_INT_BITMASK					(0X00FF0000)
#define RQ_ACTIVE_START_ERR_INT_OFFSET		(24)
#define RQ_ACTIVE_START_ERR_INT_BITMASK		(0XFF000000)


/* HW address @sAP view for reference, eAP is the left user of CLDMA0/CLDMA1*/
#define RIGHT_CLDMA_OFFSET 0x1000

#ifdef M8X75
#define CLDMA0_AO_BASE			(0x10049000)
#define CLDMA0_PD_BASE			(0x1021D000)
#define CLDMA1_AO_BASE			(0x1004B000)
#define CLDMA1_PD_BASE			(0x1021F000)
#else
#define CLDMA0_AO_BASE			CLDMA0_AO_AP_BASE// CLDMA0 LEFT_AO_BASE 0x10022000
#define CLDMA0_PD_BASE			CLDMA0_AP_BASE// CLDMA0 LEFT_PD_BASE 0x1023C000
#define CLDMA1_AO_BASE			CLDMA1_AO_AP_BASE//CLDMA1 LEFT_AO_BASE 0x10024000
#define CLDMA1_PD_BASE			CLDMA1_AP_BASE//CLDMA1 LEFT_PD_BASE 0x1023E000
#endif

#define CLDMA_R_AO_BASE			CLDMA0_AO_MD_BASE//CLDMA0 RIGHT_AO_BASE 0x10023000
#define CLDMA_R_PD_BASE			CLDMA0_MD_BASE//CLDMA0 RIGHT_AO_BASE 0x10023D00
#define CLDMA0_R_INT			CLDMA0_MD_AP_IRQ_BIT

#define BASE_ADDR_CLDMA_AO		(g_CLDMA_AO_BASE)
#define BASE_ADDR_CLDMA_PD		(g_CLDMA_PD_BASE)

#define BASE_ADDR_CLDMA_IN	(BASE_ADDR_CLDMA_PD + 0x00000000)
#define BASE_ADDR_CLDMA_OUT		(BASE_ADDR_CLDMA_PD + 0x00000400)
#define BASE_ADDR_CLDMA_MISC		(BASE_ADDR_CLDMA_PD + 0x00000800)
#define BASE_ADDR_CLDMA_IN_AO		(BASE_ADDR_CLDMA_AO + 0x00000000)
#define BASE_ADDR_CLDMA_OUT_AO	(BASE_ADDR_CLDMA_AO + 0x00000400)
#define BASE_ADDR_CLDMA_MISC_AO	(BASE_ADDR_CLDMA_AO + 0x00000800)


/*CLDMA IN(Tx) AO*/
#define REG_CLDMA_UL_CURRENT_ADDRL_0_AO	(0x0044)
#define REG_CLDMA_UL_CURRENT_ADDRH_0_AO	(0x0048)

/*CLDMA IN(Tx) PD*/
#define REG_CLDMA_UL_START_ADDRL_0		(0x0004)
#define REG_CLDMA_UL_START_ADDRH_0		(0x0008)
#define REG_CLDMA_UL_CURRENT_ADDRL_0	(0x0044)
#define REG_CLDMA_UL_CURRENT_ADDRH_0	(0x0048)
#define REG_CLDMA_UL_STATUS				(0x0084)
#define REG_CLDMA_UL_START_CMD			(0x0088)
#define REG_CLDMA_UL_RESUME_CMD		(0x008C)
#define REG_CLDMA_UL_STOP_CMD			(0x0090)
#define REG_CLDMA_UL_ERROR				(0x0094)
#define REG_CLDMA_UL_CFG				(0x0098)
#define REG_CLDMA_UL_DUMMY_0			(0x009C)

/*CLDMA OUT(Rx) PD*/
#define REG_CLDMA_SO_ERROR			(0x0400 + 0x0100)
#define REG_CLDMA_SO_START_CMD		(0x0400 + 0x01BC)
#define REG_CLDMA_SO_RESUME_CMD	(0x0400 + 0x01C0)
#define REG_CLDMA_SO_STOP_CMD		(0x0400 + 0x01C4)
#define REG_CLDMA_SO_DUMMY_0		(0x0400 + 0x0108)

/*CLDMA OUT(Rx) AO*/
#define REG_CLDMA_SO_CFG		(0x0400 + 0x0004)
#define REG_CLDMA_SO_START_ADDRL_0			(0x0400 + 0x0078)
#define REG_CLDMA_SO_START_ADDRH_0		(0x0400 + 0x007C)
#define REG_CLDMA_SO_CURRENT_ADDRL_0		(0x0400 + 0x00B8)
#define REG_CLDMA_SO_CURRENT_ADDRH_0		(0x0400 + 0x00BC)
#define REG_CLDMA_SO_STATUS				(0x0400 + 0x00F8)
#define REG_CLDMA_DEBUG_ID_EN				(0x0400 + 0x00FC)
#define REG_CLDMA_SO_LAST_UPDATE_ADDRL_0	(0x0400 + 0x0100)
#define REG_CLDMA_SO_LAST_UPDATE_ADDRH_0	(0x0400 + 0x0104)

/*CLDMA MISC PD*/
#define REG_CLDMA_L2TISAR0			(0x0800 + 0x0010)
#define REG_CLDMA_L2TISAR1			(0x0800 + 0x0014)
#define REG_CLDMA_L2TIMR0			(0x0800 + 0x0018)
#define REG_CLDMA_L2TIMR1			(0x0800 + 0x001C)
#define REG_CLDMA_L2TIMCR0			(0x0800 + 0x0020)
#define REG_CLDMA_L2TIMCR1			(0x0800 + 0x0024)
#define REG_CLDMA_L2TIMSR0			(0x0800 + 0x0028)
#define REG_CLDMA_L2TIMSR1			(0x0800 + 0x002C)
#define REG_CLDMA_L3TISAR0			(0x0800 + 0x0030)
#define REG_CLDMA_L3TISAR1			(0x0800 + 0x0034)
#define REG_CLDMA_L3TIMR0			(0x0800 + 0x0038)
#define REG_CLDMA_L3TIMR1			(0x0800 + 0x003C)
#define REG_CLDMA_L3TIMCR0			(0x0800 + 0x0040)
#define REG_CLDMA_L3TIMCR1			(0x0800 + 0x0044)
#define REG_CLDMA_L3TIMSR0			(0x0800 + 0x0048)
#define REG_CLDMA_L3TIMSR1			(0x0800 + 0x004C)
#define REG_CLDMA_L2RISAR0			(0x0800 + 0x0050)
#define REG_CLDMA_L2RISAR1			(0x0800 + 0x0054)
#define REG_CLDMA_L3RISAR0			(0x0800 + 0x0070)
#define REG_CLDMA_L3RISAR1			(0x0800 + 0x0074)
#define REG_CLDMA_L3RIMR0			(0x0800 + 0x0078)
#define REG_CLDMA_L3RIMR1			(0x0800 + 0x007C)
#define REG_CLDMA_L3RIMCR0			(0x0800 + 0x0080)
#define REG_CLDMA_L3RIMCR1			(0x0800 + 0x0084)
#define REG_CLDMA_L3RIMSR0			(0x0800 + 0x0088)
#define REG_CLDMA_L3RIMSR1			(0x0800 + 0x008C)
#define REG_CLDMA_IP_BUSY			(0x0800 + 0x00B4)
#define REG_CLDMA_L3TISAR2			(0x0800 + 0x00C0)
#define REG_CLDMA_L3TIMR2			(0x0800 + 0x00C4)
#define REG_CLDMA_L3TIMCR2			(0x0800 + 0x00C8)
#define REG_CLDMA_L3TIMSR2			(0x0800 + 0x00CC)

/*CLDMA MISC AO*/
#define REG_CLDMA_L2RIMR0			(0x0800 + 0x0058)
#define REG_CLDMA_L2RIMR1			(0x0800 + 0x005C)
#define REG_CLDMA_L2RIMCR0			(0x0800 + 0x0060)
#define REG_CLDMA_L2RIMCR1			(0x0800 + 0x0064)
#define REG_CLDMA_L2RIMSR0			(0x0800 + 0x0068)
#define REG_CLDMA_L2RIMSR1			(0x0800 + 0x006C)

/*CLDMA RESET*/
#define REG_INFRA_RST4_SET			0x730
#define REG_INFRA_RST4_CLR			0x734
#define REG_INFRA_RST2_SET          0x140
#define REG_INFRA_RST2_CLR          0x144
//#define REG_CLDMA_BUS_CFG		(0x0800 + 0x0058)
#define REG_CLDMA_DUMMY				(0x0800 + 0x0150)

#ifdef M8X75
#define REG_CLDMA_INT_MASK			(0x0800 + 0x0160)
#define REG_CLDMA_BUSY_MASK			(0x0800 + 0x0154)
#else
#define REG_CLDMA_INT_MASK			(0x0800 + 0x0154)
#define REG_CLDMA_BUSY_MASK			(0x0800 + 0x0158)
#endif

#define R_CLDMA_TQ_IS_ACTIVE(base_addr, _qid)\
	(REG_IO_READ32(base_addr + REG_CLDMA_UL_STATUS) & (1 << (_qid)))
#define R_CLDMA_RQ_IS_ACTIVE(base_addr, _qid)\
	(REG_IO_READ32(base_addr + REG_CLDMA_SO_STATUS) & (1 << (_qid)))


/*L: low 32 bit register; H: high 32 bit register*/
#define REG_CLDMA_QSAR32L(base_addr, i)\
	((volatile unsigned int *)((char *)(base_addr) + (i) * 8))
#define REG_CLDMA_QSAR32H(base_addr, i)\
	((volatile unsigned int *)((char *)(base_addr) + ((i) * 8 + 4)))

/*L: low 32 bit register; H: high 32 bit register*/
#define REG_CLDMA_GET_QN_ADDRL(base_addr, _qid)\
	(base_addr + _qid * 2 * 4)
#define REG_CLDMA_GET_QN_ADDRH(base_addr, _qid)\
	(base_addr + (_qid * 2 + 1) * 4)

#define W_CLDMA_QSAR32L(base_addr, i, value)\
	REG_IO_WRITE32(REG_CLDMA_QSAR32L((base_addr), (i)), (u32)(value))
#define W_CLDMA_QSAR32H(base_addr, i, value)\
	REG_IO_WRITE32(REG_CLDMA_QSAR32H((base_addr),\
	(i)), (u32)(((u64)(value)) >> 32))

/*
 * the struct is used in PM flow
 */
struct cldma_reg_bk_t {
	u32 ul_start_addr_l_bk[CLDMA_TQ_NUM];
	u32 ul_start_addr_h_bk[CLDMA_RQ_NUM];
	u32 ul_current_addr_l_bk[CLDMA_TQ_NUM];
	u32 ul_current_addr_h_bk[CLDMA_RQ_NUM];
};

#if defined(ENABLE_CCCI_DRI_UT)
struct cldma_hw_info {
	struct device *pcie_dev; // pcie device for DMA address mapping
	unsigned int hw_id; //single handle function multi HW IP
	dir_enum direction; // AP->MD ,MD->AP
	void __iomem *cldma_ap_ao_base;
	void __iomem *cldma_ap_pdn_base;
	u32 cldma_irq_id;
	u64 cldma_irq_flags;
	struct cldma_reg_bk_t cldma_reg_bk;
	struct tasklet_struct cldma_irq_task;
	char other_attr[0];
};
#else //ENABLE_CCCI_DRI_UT
struct cldma_hw_info {
	struct device *pcie_dev; // pcie device for DMA address mapping
	unsigned int hw_id; //single handle function multi HW IP
	dir_enum direction;
	hw_mode_enum hw_mode;
	void __iomem *cldma_ap_ao_base;
	void __iomem *cldma_ap_pdn_base;
	u32 cldma_irq_id;
	u64 cldma_irq_flags;
	unsigned long cldma_phy_ao_base;
	unsigned long cldma_phy_pd_base;
	u32 cldma_phy_interrupt_id;
	struct cldma_reg_bk_t cldma_reg_bk;
	char other_attr[0];
};
#endif // ENABLE_CCCI_DRI_UT

int cldma_hw_send(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
int cldma_hw_mask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
int cldma_hw_mask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
int cldma_hw_dismask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
int cldma_hw_dismask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
unsigned int cldma_hw_txrxirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx);
unsigned int cldma_hw_eqirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx);
int cldma_hw_error_check(struct ccci_hw_ctrl *hw_ctrl);
unsigned int cldma_hw_queue_isactive(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
void cldma_hw_init(struct ccci_hw_ctrl *hw_ctrl);
int cldma_hw_resume_queue(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
void cldma_hw_start(struct ccci_hw_ctrl *hw_ctrl);
void cldma_hw_start_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char tx_rx);
unsigned int cldma_hw_tx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask);
unsigned int cldma_hw_rx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask);
void cldma_hw_stop_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char rx_tx);
void cldma_hw_set_start_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx);
void cldma_hw_set_current_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx);
void cldma_hw_reset(struct ccci_hw_ctrl *hw_ctrl);
void cldma_hw_stop(struct ccci_hw_ctrl *hw_ctrl, unsigned char rx_tx);
void cldma_hw_dump(struct ccci_hw_ctrl *hw_ctrl);
unsigned int cldma_hw_queue_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);
unsigned int cldma_hw_int_status(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask, unsigned char tx_rx);
void cldma_hw_reg_restore(struct ccci_hw_ctrl *hw_ctrl);
void cldma_hw_reg_backup(struct ccci_hw_ctrl *hw_ctrl);
void clear_ip_busy(struct ccci_hw_ctrl *hw_ctrl);
int cldma_hw_pd_check(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno);
void cldma_check_queue_statue(struct ccci_hw_ctrl *hw_ctrl, unsigned char rx_tx);
#endif


