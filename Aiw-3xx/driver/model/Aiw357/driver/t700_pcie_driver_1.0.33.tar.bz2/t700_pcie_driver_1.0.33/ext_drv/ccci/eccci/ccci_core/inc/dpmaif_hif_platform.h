/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __DPMAIF_HIF_PLATFORM_H__
#define __DPMAIF_HIF_PLATFORM_H__

#include <linux/io.h>
#include <linux/sched.h>
#include "ccci_debug.h"


/* ftrace log */
#ifdef DPMA_FTRACE_DEBUG
#define DPMA_FT_TAG		"DPMA-FTRACE"
#define DPMA_FT_LOG(fmt, args...)\
	trace_printk("[%s], "fmt"\n", DPMA_FT_TAG, ##args)
#else
#define DPMA_FT_LOG(fmt, args...)
#endif

#define DPMA_CHECK_RGE_TIMEOUT (1600000)


/*
 *   DPMAIF base register address
 */
extern unsigned long g_DPMAIF_PD_BASE;
extern unsigned long g_DPMAIF_AO_BASE;

/*
 *   I/O read and write functions
 */
#define PLAT_WRITE32(a, v)           writel((v), (void __iomem *)(a))
#define PLAT_WRITE16(a, v)           writew((v), (void __iomem *)(a))
#define PLAT_WRITE8(a, v)            writeb((v), (void __iomem *)(a))
#define PLAT_READ32(a)               readl((void __iomem *)(a))
#define PLAT_READ16(a)               readw((void __iomem *)(a))
#define PLAT_READ8(a)                readb((void __iomem *)(a))

#define DPMAIF_WriteReg32(a, v)         PLAT_WRITE32(a, v)
#define DPMAIF_WriteReg16(a, v)         PLAT_WRITE16(a, v)
#define DPMAIF_WriteReg8(a, v)          PLAT_WRITE8(a, v)
#define DPMAIF_ReadReg32(a)             PLAT_READ32(a)
#define DPMAIF_ReadReg16(a)             PLAT_READ16(a)
#define DPMAIF_ReadReg8(a)              PLAT_READ8(a)

#define DPMAIF_REG_IO_WRITE32(a, v)            PLAT_WRITE32(a, v)
#define DPMAIF_REG_IO_READ32(a)                PLAT_READ32(a)

/***********************************************************************
 *  DPMAIF HW feature
 *
 ***********************************************************************/
#define DPMAIF_UL_DRB_ENTRY_SIZE  4096  // from 512
#define DPMAIF_DL_BAT_ENTRY_SIZE  4814  // from 512
#define DPMAIF_DL_PIT_ENTRY_SIZE  14400 // from 512
#define DPMAIF_DL_PIT_BYTE_SIZE   16
#define DPMAIF_DL_BAT_BYTE_SIZE   8
#define DPMAIF_DL_FRG_BYTE_SIZE   8
#define DPMAIF_UL_DRB_BYTE_SIZE   16
#define DPMAIF_UL_DRB_ENTRY_WORD  (DPMAIF_UL_DRB_BYTE_SIZE >> 2)
#define DPMAIF_DL_PIT_ENTRY_WORD  (DPMAIF_DL_PIT_BYTE_SIZE >> 2)
#define DPMAIF_DL_BAT_ENTRY_WORD  (DPMAIF_DL_BAT_BYTE_SIZE >> 2)

#define DPMAIF_UL_DRB_SIZE (DPMAIF_UL_DRB_ENTRY_SIZE * DPMAIF_UL_DRB_BYTE_SIZE)
#define DPMAIF_DL_PIT_SIZE (DPMAIF_DL_PIT_ENTRY_SIZE * DPMAIF_DL_PIT_BYTE_SIZE)
#define DPMAIF_DL_BAT_SIZE (DPMAIF_DL_BAT_ENTRY_SIZE * DPMAIF_DL_BAT_BYTE_SIZE)
#define DPMAIF_DL_FRG_SIZE (DPMAIF_DL_BAT_ENTRY_SIZE * DPMAIF_DL_FRG_BYTE_SIZE)


/*================ FROM DPMAIF OVER PCIE CODE ==================*/

#include <linux/types.h>
#include <linux/string.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/kernel.h>


/*Default DPMAIF DL common setting*/
#define DPMAIF_HW_BAT_REMAIN       64
#define DPMAIF_HW_BAT_PKTBUF       (128 * 28)   //128*28
#define DPMAIF_HW_FRG_PKTBUF       (128 * 28) //128*28
#define DPMAIF_HW_BAT_RSVLEN       64
#define DPMAIF_HW_PKT_BIDCNT       1
#define DPMAIF_HW_PKT_ALIGN        64
#define DPMAIF_HW_MTU_SIZE          (3*1024 + 8)

#define DPMAIF_HW_CHK_BAT_NUM      62
#define DPMAIF_HW_CHK_FRG_NUM      3
#define DPMAIF_HW_CHK_PIT_NUM      (2 * DPMAIF_HW_CHK_BAT_NUM)

#define MAIFQ_MAX_DLQ_NUM          1
#define MAIFQ_MAX_ULQ_NUM          5

#define MAIFQ_ULQ_BUDGET           1000
#define MAIFQ_DLQ_BUDGET           1000

#define DPMAIF_PKT_BIDCNT          1

/***********************************************************************
 *  System variable
 *
 ***********************************************************************/
#define DRV_BOOL   bool
#define DRV_FALSE  false
#define DRV_TRUE   true

/***********************************************************************
 *  DPMAIF driver common structure and variable
 *
 ***********************************************************************/
typedef struct _dpmaif_isr_en_mask {
	unsigned int    AP_UL_L2INTR_En_Msk;
	unsigned int    AP_DL_L2INTR_En_Msk;
	unsigned int    AP_UDL_IP_BUSY_En_Msk;
	unsigned int    AP_DL_L2INTR_ERR_En_Msk;
} dpmaif_isr_en_mask_t;

typedef struct _dpmaif_drv_priv {
	dpmaif_isr_en_mask_t dpmaif_isr_en_mask;
} dpmaif_drv_priv_t;

typedef struct _hifmaif_ul_st {
	unsigned int     que_config;
	DRV_BOOL          que_started;
	unsigned char     reserve[3];
	unsigned int     *drb_base;
	unsigned int     drb_size_cnt;
} hifmaif_ul_st_t;

typedef struct _hifdpmaif_dl_st {
	unsigned int     que_config;
	DRV_BOOL          que_started;
	unsigned char     reserve[3];
	unsigned int     *pit_base;
	unsigned int     pit_size_cnt;
	unsigned int     *bat_base;
	unsigned int     bat_size_cnt;
	unsigned int     *frg_base;
	unsigned int     frg_size_cnt;
	unsigned int    pit_seq;
} hifmaif_dl_st_t;

typedef struct _hifdpmaif_dl_hwq {
	unsigned int    bat_remain_size;
	unsigned int    bat_pkt_bufsz;
	unsigned int    frg_pkt_bufsz;
	unsigned int    bat_rsv_length;
	unsigned int    pkt_bid_max_cnt;
	unsigned int    pkt_alignment;
	unsigned int    mtu_size;
	unsigned int    chk_pit_num;
	unsigned int    chk_bat_num;
	unsigned int    chk_frg_num;
} hifmaif_dl_hwq_t;

typedef struct _hifdpmaif_property {
	hifmaif_dl_st_t      dl_que[MAIFQ_MAX_DLQ_NUM];
	hifmaif_ul_st_t      ul_que[MAIFQ_MAX_ULQ_NUM];
	hifmaif_dl_hwq_t     dl_que_hw[MAIFQ_MAX_DLQ_NUM];
} hifdpmaif_property_t;

typedef struct _hw_dpmaif_ctrl {
	hifdpmaif_property_t    dpmaif_property;
	dpmaif_drv_priv_t       dpmaif_drv_ctrl;
} hw_dpmaif_ctrl_t;

/***********************************************************************
 *  DPMAIF Register read/write
 *
 ***********************************************************************/
#define dpmaif_write32(addr, data)   DPMAIF_REG_IO_WRITE32(addr, data)
#define dpmaif_read32(a)                DPMAIF_REG_IO_READ32(a)

#define DPMAIF_READ_PD_MISC(a)      dpmaif_read32(a)
#define DPMAIF_READ_PD_UL(a)        dpmaif_read32(a)
#define DPMAIF_READ_PD_DL(a)        dpmaif_read32(a)
#define DPMAIF_READ_AO_DL(a)        dpmaif_read32(a)

#define DPMAIF_WRITE_PD_MISC(a, v)  dpmaif_write32(a, v)
#define DPMAIF_WRITE_PD_UL(a, v)    dpmaif_write32(a, v)
#define DPMAIF_WRITE_PD_DL(a, v)    dpmaif_write32(a, v)
#define DPMAIF_WRITE_AO_DL(a, v)    dpmaif_write32(a, v)

extern unsigned long g_DPMAIF_CACHE_LINE_SIZE;
#define DP_CACHE_LINE_SIZE      (unsigned long)(g_DPMAIF_CACHE_LINE_SIZE)
#define DP_CACHE_LINE_SIZE_MASK      (unsigned long)(DP_CACHE_LINE_SIZE - 1)


/***********************************************************************
 *  Brief:
 *  Debug operate in defferent platform
 *
 ***********************************************************************/
#ifdef DPMAIFQ_ASSERT_EN
	#define DPMAIF_ASSERT(...)  ASSERT(0)
#else
	#define DPMAIF_ASSERT(hif_ctrl) \
	do {\
		MTK_ERR_LOG("HIF-DPMAIF", \
			"DPMAIF_ASSERT file: %s, function: %s, line %d", \
			__FILE__, __func__, __LINE__); \
	} while (0)
#endif

#ifndef ASSERT
#define ASSERT(expr) \
{ \
	if (!expr) { \
		MTK_ERR_LOG("HIF-DPMAIF",\
			"DPMAIF_ASSERT file: %s, function: %s, line %d",\
			__FILE__, __func__, __LINE__); \
		BUG_ON(1); \
	} \
}
#endif

#endif
