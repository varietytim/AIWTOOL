/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __CLDMA_REG_H__
#define __CLDMA_REG_H__


#endif				/* __CLDMA_REG_H__ */
