/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __CCCI_HIF_H__
#define __CCCI_HIF_H__

#include <linux/skbuff.h>
#include "ccci_modem.h"
#include "ccci_core.h"
#include "mtk-pci.h"

//#include "ccif_hif_platform.h"

#define GET_PATH_FLAG(path_id) (1<<path_id)
#define GET_HIF_ID(md_id, path_id) (ccci_hif_path[md_id][path_id])

typedef enum {
	HIF_ID_CLDMA0_PCIE = 0,
	HIF_ID_CLDMA_PCIE = 1,
	HIF_ID_DPMAIF_PCIE = 2,
	HIF_ID_PCIE = 3,
	HIF_ID_CLDMA = 4,
	HIF_ID_MAX,
} hif_id_type;
#define CCCI_NET_HIF HIF_ID_DPMAIF_PCIE //support network

typedef enum {
	HIF_FLAG_CTRL = 0x01, // 1 << HIF_PATH_CTRL
	HIF_FLAG_CTRL_1 = 0x02,// 1 << HIF_PATH_CTRL_1
	HIF_FLAG_DATA = 0x04,
	HIF_FLAG_CTRL_DATA = 0x07,
	HIF_FLAG_EX = 0x08,
	HIF_FLAG_ALL = 0x0F,
	HIF_FLAG_MAX,
} hif_path_flag;

typedef enum {
	HIF_PATH_CTRL = 0,
	HIF_PATH_CTRL_1,
	HIF_PATH_DATA,
	HIF_PATH_EX,
	HIF_PATH_MAX,
} hif_path_type;

extern hif_id_type ccci_hif_path[MAX_MD_NUM][HIF_PATH_MAX];

extern void *ccci_hif[MAX_MD_NUM][HIF_ID_MAX];

typedef enum{
	NORMAL_DATA = (1<<0),
	CLDMA_NET_DATA = (1<<1),
} CCCI_HIF_FLAG;

typedef enum {
	HIF_CFG_DEF = 0,
	HIF_CFG1,
	HIF_CFG2,
	HIF_CFG_MAX,
} HIF_CFG_ENUM;
extern void spm_ap_mdsrc_req(u8 lock);//ccci_hif_cldma.h

#define MD1_NET_HIF         HIF_ID_DPMAIF_PCIE
#define MD1_NORMAL_HIF          HIF_ID_CLDMA_PCIE

#define MD1_NET_HIF_FLAG        (1 << MD1_NET_HIF)
#define MD1_NORMAL_HIF_FLAG     (1 << MD1_NORMAL_HIF)
#define MD1_NET_NORMAL_HIF_FLAG (MD1_NET_HIF_FLAG | MD1_NORMAL_HIF_FLAG)

int ccci_hif_get_queue_mtu(unsigned char md_id,
	unsigned int path_id, unsigned char qno);
int ccci_hif_init(unsigned char md_id, unsigned int path_flag);
int ccci_hif_hw_init(unsigned char md_id, unsigned int path_flag);
int ccci_hif_late_init(unsigned char md_id, unsigned int path_flag);
int ccci_hif_send_skb(unsigned char md_id, unsigned int path_flag,
	unsigned char tx_qno, struct sk_buff *skb, unsigned char from_pool,
	unsigned char blocking);
int ccci_hif_write_room(unsigned char md_id,
	unsigned char path_id, unsigned char qno);
int ccci_hif_ask_more_request(unsigned char md_id,
	unsigned int path_flag, unsigned char rx_qno);

int ccci_hif_set_wakeup_src(unsigned char md_id,
	unsigned int path_flag, int value);
int ccci_hif_start(unsigned char md_id, unsigned int path_flag);
int ccci_hif_stop(unsigned char md_id, unsigned int path_flag);
int ccci_hif_start_queue(unsigned char md_id, unsigned int path_flag,
	unsigned char qno, enum direction dir);
int ccci_hif_stop_queue(unsigned char md_id, unsigned int path_flag,
	unsigned char qno, enum direction dir);
int ccci_hif_stop_for_ee(unsigned char md_id, unsigned int path_flag);
int ccci_hif_clear(unsigned int  md_id, unsigned int path_flag);
int ccci_hif_clear_all_queue(u8 md_id, unsigned int path_flag, enum direction dir);
int ccci_hif_allQreset_work(unsigned int md_id, unsigned int path_flag);
int ccci_hif_exception(unsigned char md_id,
	unsigned int path_flag, HIF_EX_STAGE stage);
int ccci_hif_ex_handshake(unsigned char md_id,
	unsigned int hif_id, HIF_EX_STAGE stage);
int ccci_hif_get_hw_info(unsigned char md_id, unsigned int path_flag,
	struct mtk_pci_dev *dev_ptr);
int ccci_hif_get_rt_header(unsigned char md_id, unsigned int path_flag,
	int tx_ch, int packet_size, unsigned int txqno, int skb_from_pool);
unsigned long ccci_hif_get_event_id(unsigned char md_id, unsigned int hif_id);

//========= newly added ================
#ifdef M7X
int ccci_hif_state_notification(unsigned char md_id, unsigned char state);
#endif
//========= newly added ================
int ccci_hif_dump_status(unsigned char md_id,
	unsigned int path_flag, enum modem_dump_flag dump_flag,
	void *data, int length);
void ccci_hif_reset(u8 md_id, unsigned int path_flag, char is_hw);
void *get_rt_header(unsigned char md_id, unsigned int path_flag,
	int tx_ch, int packet_size, unsigned int txqno, int skb_from_pool);
void ccci_hif_uninit(unsigned char md_id, unsigned int path_flag);
void ccci_switch_hif_cfg(unsigned char md_id,
	hif_path_type path_id, unsigned int cfg_id);

#endif
