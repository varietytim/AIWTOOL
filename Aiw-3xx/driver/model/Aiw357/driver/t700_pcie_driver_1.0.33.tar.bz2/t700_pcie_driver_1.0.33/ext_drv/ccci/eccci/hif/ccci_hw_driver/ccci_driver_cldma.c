// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_driver.h"
#include "ccci_driver_cldma.h"
#include "mtk-pci-ext.h"
#include <linux/delay.h>
#define TAG			"DRV_CLDMA"

u64 g_CLDMA_AO_BASE;
u64 g_CLDMA_PD_BASE;
u64 g_MHCCIFRC_BASE;

/*****************************************************************************
 * FUNCTION
 *	cldma_hw_init
 * DESCRIPTION
 * This function will init CLDMA HW: such as config GPD/BD mode,
 * interrupt mask, busy signal mask, etc.
 * PARAMETERS
 *	base_info: mapped AO+PD base address structure pointer
 *****************************************************************************/
#if defined(ENABLE_CCCI_DRI_UT)
void cldma_hw_start_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char tx_rx)
{
}
void cldma_hw_set_start_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx)
{
}
void cldma_hw_start(struct ccci_hw_ctrl *hw_ctrl)
{
}
void cldma_hw_reset(struct ccci_hw_ctrl *hw_ctrl)
{
}
int cldma_hw_resume_queue(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	return 0;
}
int cldma_hw_send(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	unsigned long flags;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	spin_lock_irqsave(&hw_ctrl->spinlock, flags);
	cldma_write32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2RISAR0, 1 << qno);
	spin_unlock_irqrestore(&hw_ctrl->spinlock, flags);
	return 0;
}
unsigned int cldma_hw_queue_isactive(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	return qno;
}
void clear_ip_busy(struct ccci_hw_ctrl *hw_ctrl)
{

}
unsigned int cldma_hw_queue_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	return 0;
}
unsigned int cldma_hw_txrxirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		return cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&TXRX_STATUS_BITMASK;
	} else {
		return cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2RIMR0)&TXRX_STATUS_BITMASK;
	}
	return 0;
}
unsigned int cldma_hw_eqirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx)
{
	return 0;
}
unsigned int cldma_hw_tx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	unsigned int ch_id;
	unsigned long flags;

	ch_id = cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2TISAR0) & bitmask;
	/*ack interrupt*/
	spin_lock_irqsave(&hw_ctrl->spinlock, flags);
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR0, 0x00);
	spin_unlock_irqrestore(&hw_ctrl->spinlock, flags);
	return ch_id;
}
unsigned int cldma_hw_rx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	unsigned int ch_id;
	unsigned long flags;

	ch_id = cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2RISAR0) & bitmask;
	/*ack interrupt*/
	spin_lock_irqsave(&hw_ctrl->spinlock, flags);
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR0, 0x00);
	spin_unlock_irqrestore(&hw_ctrl->spinlock, flags);
	return ch_id;
}
int cldma_hw_error_check(struct ccci_hw_ctrl *hw_ctrl)
{
	return 0;
}
int cldma_hw_mask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	//	  CCCI_DEBUG_LOG(-1, "CLD_DRV", "%s\n",__FUNCTION__);
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMR0,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&(1 << qno)));
	} else {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RIMR0,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&(1 << qno)));
	}
	return 0;
}
int cldma_hw_mask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	//  CCCI_DEBUG_LOG(-1, "CLD_DRV", "%s\n",__FUNCTION__);
	return 0;
}
int cldma_hw_dismask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	//	CCCI_DEBUG_LOG(-1, "CLD_DRV", "%s\n",__FUNCTION__);
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMR0,
		(cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2TIMR0) & ~(1 << qno)));
	} else {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RIMR0,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2RIMR0) & ~(1 << qno)));
	}
	return 0;
}

unsigned int cldma_hw_int_status(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask, unsigned char tx_rx)
{
	unsigned long flags;
	unsigned int int_status = 0x0;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	spin_lock_irqsave(&hw_ctrl->spinlock, flags);
	int_status = cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2RISAR0) & bitmask;
	spin_unlock_irqrestore(&hw_ctrl->spinlock, flags);
	return int_status;
}

int cldma_hw_dismask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
//  CCCI_DEBUG_LOG(-1, "CLD_DRV", "%s\n",__FUNCTION__);

	return 0;
}
void cldma_hw_init(struct ccci_hw_ctrl *hw_ctrl)
{
}

void cldma_hw_stop_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char rx_tx)
{
}

void cldma_hw_stop(struct ccci_hw_ctrl *hw_ctrl, int isforex)
{
}

void cldma_hw_dump(struct ccci_hw_ctrl *hw_ctrl)
{
}
void cldma_hw_reg_restore(struct ccci_hw_ctrl *hw_ctrl)
{
}
void cldma_hw_reg_back(struct ccci_hw_ctrl *hw_ctrl)
{
}
int cldma_hw_pd_check(struct ccci_hw_ctrl *hw_ctrl)
{
}
void cldma_hw_set_current_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx)//0 tx,1 rx
{
}
#else //ENABLE_CCCI_DRI_UT
void clear_ip_busy(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	/* clear IP busy register wake up cpu case */
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_IP_BUSY,
		(cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_IP_BUSY) | 0x1));
}
void cldma_hw_reg_restore(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;


	if (hw_info->hw_mode == MODE_BIT_64) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG) & (~(0x7 << 5)))|(0x4 << 5));
	} else if (hw_info->hw_mode == MODE_BIT_40) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG)&(~(0x7<<5)))|(0x2<<5));
	} else if (hw_info->hw_mode == MODE_BIT_36) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG) & (~(0x7 << 5)))|(0x1 << 5));
	}
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_DUMMY_0, 1);
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_SO_DUMMY_0, 1);
}

void cldma_hw_reg_backup(struct ccci_hw_ctrl *hw_ctrl)
{
	u8 qno = 0;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	for (qno = 0; qno < CLDMA_TQ_NUM; qno++) {
		hw_info->cldma_reg_bk.ul_start_addr_l_bk[qno] =
			cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_START_ADDRL_0 + qno * 8);
		hw_info->cldma_reg_bk.ul_start_addr_h_bk[qno] =
			cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_START_ADDRL_0 + qno * 8 + 4);
	}
}
void cldma_hw_start_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno == 0xff)
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_START_CMD, TXRX_STATUS_BITMASK);
		else
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_START_CMD, (1 << qno));
	} else {
		if (qno == 0xff)
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_SO_START_CMD, TXRX_STATUS_BITMASK);
		else
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_SO_START_CMD, (1 << qno));
	}
}

void cldma_hw_start(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	/*diamask txrx interrupt*/
	cldma_write32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2TIMCR0, TXRX_STATUS_BITMASK);
	cldma_write32(hw_info->cldma_ap_ao_base,
		REG_CLDMA_L2RIMCR0, TXRX_STATUS_BITMASK);
	/*dismask empty queue interrupt*/
	cldma_write32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2TIMCR0, EMPTY_STATUS_BITMASK);
	cldma_write32(hw_info->cldma_ap_ao_base,
		REG_CLDMA_L2RIMCR0, EMPTY_STATUS_BITMASK);

}
void cldma_hw_reset(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	struct mtk_pci_dev *mtk_dev = hw_ctrl->mtk_dev;

	if (!mtk_dev || !hw_info)
		return;
	if (hw_info->hw_id == HIF_ID_CLDMA_PCIE) {
		cldma_write32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST4_SET,
					cldma_read32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST4_SET)|1<<20);
		cldma_write32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST2_SET,
					cldma_read32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST2_SET)|1<<18);
		udelay(1);
		cldma_write32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST4_CLR,
					cldma_read32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST4_CLR)|1<<20);
		cldma_write32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST2_CLR,
					cldma_read32(mtk_dev->base_addr.infracfg_ao_base, REG_INFRA_RST2_CLR)|1<<18);
	}
}
int cldma_hw_pd_check(struct ccci_hw_ctrl *hw_ctrl,
		unsigned char qno)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	u32 start_addr_l = cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_START_ADDRL_0 + qno * 8);
	u32 start_addr_h = cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_START_ADDRL_0 + qno * 8 + 4);

	return (start_addr_l!=0||start_addr_h!=0)? 0 : -1;
}
void cldma_hw_set_current_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!rx_tx) {
		W_CLDMA_QSAR32L(((hw_info->cldma_ap_pdn_base) +
			REG_CLDMA_UL_CURRENT_ADDRL_0), (qno), (address));
		W_CLDMA_QSAR32H(((hw_info->cldma_ap_pdn_base) +
			REG_CLDMA_UL_CURRENT_ADDRL_0), (qno), (address));
	} else {
		W_CLDMA_QSAR32L(((hw_info->cldma_ap_ao_base) +
			REG_CLDMA_SO_CURRENT_ADDRL_0), (qno), (address));
		W_CLDMA_QSAR32H(((hw_info->cldma_ap_ao_base) +
			REG_CLDMA_SO_CURRENT_ADDRL_0), (qno), (address));
	}
}

//0 tx,1 rx
void cldma_hw_set_start_address(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, u64 address, unsigned char rx_tx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!rx_tx) {
		W_CLDMA_QSAR32L(((hw_info->cldma_ap_pdn_base) +
			REG_CLDMA_UL_START_ADDRL_0), (qno), (address));
		W_CLDMA_QSAR32H(((hw_info->cldma_ap_pdn_base) +
			REG_CLDMA_UL_START_ADDRL_0), (qno), (address));
	} else {
		W_CLDMA_QSAR32L(((hw_info->cldma_ap_ao_base) +
			REG_CLDMA_SO_START_ADDRL_0), (qno), (address));
		W_CLDMA_QSAR32H(((hw_info->cldma_ap_ao_base) +
			REG_CLDMA_SO_START_ADDRL_0), (qno), (address));
	}
}

int cldma_hw_resume_queue(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		cldma_write32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_RESUME_CMD, (1 << qno));
	} else {
		cldma_write32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_SO_RESUME_CMD, (1 << qno));
	}
	return 0;
}

unsigned int cldma_hw_queue_isactive(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno == 0xFF) {
			return cldma_read32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_STATUS);
		} else {
			return (cldma_read32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_STATUS) & (1 << qno)) ? 1:0;
		}
	} else {
		if (qno == 0xFF) {
			return cldma_read32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_SO_STATUS);
		} else {
			return (cldma_read32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_SO_STATUS) & (1 << qno)) ? 1:0;
		}
	}
}
unsigned int cldma_hw_queue_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		return cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&(1 << qno);
	} else {
		return cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMR0)&(1 << qno);
	}
}

unsigned int cldma_hw_txrxirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		return cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&TXRX_STATUS_BITMASK;
	} else {
		return cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMR0)&TXRX_STATUS_BITMASK;
	}
}
unsigned int cldma_hw_eqirq_ismask(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		return cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMR0)&EMPTY_STATUS_BITMASK;
	} else {
		return cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMR0)&EMPTY_STATUS_BITMASK;
	}
}

unsigned int cldma_hw_tx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	unsigned int ch_id;

	ch_id = cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2TISAR0) & bitmask;
	/*ack interrupt*/
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR0, ch_id);

	cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR0);

	return ch_id;
}

unsigned int cldma_hw_rx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	unsigned int ch_id;

	ch_id = cldma_read32(hw_info->cldma_ap_pdn_base,
		REG_CLDMA_L2RISAR0) & bitmask;
	/*ack interrupt*/
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR0, ch_id);

	cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR0);
	return ch_id;
}

unsigned int cldma_hw_int_status(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	unsigned int int_status = 0x0;

	if (!tx_rx) {
		int_status = cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TISAR0) & bitmask;
	} else {
		int_status = cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2RISAR0) & bitmask;
	}
	return int_status;
}
int cldma_hw_error_check(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	MTK_ERR_LOG(TAG, "HW ERROR\n");
	MTK_ERR_LOG(TAG, "L2TISAR1: 0x%x, L2RISAR1: 0x%x\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR1),
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR1));
	MTK_ERR_LOG(TAG, "L3TISAR0: 0x%x, L3TISAR1: 0x%x\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR0),
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR1));
	MTK_ERR_LOG(TAG, "L3RISAR0: 0x%x, L3RISAR1: 0x%x\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR0),
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR1));
	MTK_ERR_LOG(TAG, "L2TIMR0: 0x%x, L2RIMR0: 0x%x\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMR0),
			cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMR0));
	cldma_hw_dump(hw_ctrl);
	return 0;
}

int cldma_hw_mask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMSR0, (1 << qno));
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMSR0, 0xFF);
		}
	} else {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMSR0, (1 << qno));
		} else {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMSR0, 0xFF);
		}
	}
	return 0;
}
int cldma_hw_mask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMSR0,
				((1 << qno) << EQ_STA_BIT_OFFSET));
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMSR0,
				(0xFF << EQ_STA_BIT_OFFSET));
		}
	} else {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMSR0,
				((1 << qno) << EQ_STA_BIT_OFFSET));
		} else {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMSR0,
				(0xFF << EQ_STA_BIT_OFFSET));
		}
	}
	return 0;
}
int cldma_hw_dismask_txrxirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMCR0, (1 << qno));
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMCR0, 0xFF);
		}
	} else {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMCR0, (1 << qno));
		} else {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMCR0, 0xFF);
		}
	}
	return 0;
}
int cldma_hw_dismask_eqirq(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!tx_rx) {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMCR0,
				((1 << qno) << EQ_STA_BIT_OFFSET));
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_L2TIMCR0,
				(0xFF << EQ_STA_BIT_OFFSET));
		}
	} else {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMCR0,
				((1 << qno) << EQ_STA_BIT_OFFSET));
		} else {
			cldma_write32(hw_info->cldma_ap_ao_base,
				REG_CLDMA_L2RIMCR0,
				(0xFF << EQ_STA_BIT_OFFSET));
		}
	}
	return 0;
}

void cldma_hw_init(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	/* set CLDMA to 64 bit mode GPD/BD */
	if (hw_info->hw_mode == MODE_BIT_64) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG)&(~(0x7<<5)))|(0x4<<5));
		cldma_write32(hw_info->cldma_ap_ao_base, REG_CLDMA_SO_CFG,
			(cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_SO_CFG)&(~(0x7<<10)))|(0x4<<10));
	} else if (hw_info->hw_mode == MODE_BIT_40) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG)&(~(0x7<<5)))|(0x2<<5));
		cldma_write32(hw_info->cldma_ap_ao_base, REG_CLDMA_SO_CFG,
			(cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_SO_CFG)&(~(0x7<<10)))|(0x2<<10));
	} else if (hw_info->hw_mode == MODE_BIT_36) {
		cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_CFG,
			(cldma_read32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_UL_CFG)&(~(0x7<<5)))|(0x1<<5));
		cldma_write32(hw_info->cldma_ap_ao_base, REG_CLDMA_SO_CFG,
			(cldma_read32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_SO_CFG)&(~(0x7<<10)))|(0x1<<10));
	}
	cldma_write32(hw_info->cldma_ap_ao_base, REG_CLDMA_SO_CFG,
		(cldma_read32(hw_info->cldma_ap_ao_base,
		REG_CLDMA_SO_CFG) | (0x1<<2)));

#ifdef M8X75
		/* enable interrupt */
		//CLDMA_MISC_AO, INT_EAP_USIP_MASK
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_INT_MASK, 0x00);
		/* mask wakeup signal */
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_BUSY_MASK, 0x4);//mask cldma wakeup signal

#else//M70 case
		/* mask interrupt signal */
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_INT_MASK, 0x5);
		/* mask wakeup signal */
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_BUSY_MASK, 0x4);
#endif

	/* diable TX and RX invalid address check */
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_DUMMY_0, 1);
	cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_SO_DUMMY_0, 1);

}

void cldma_check_queue_statue(struct ccci_hw_ctrl *hw_ctrl, unsigned char rx_tx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!rx_tx)
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_UL_STATUS);
	else
		cldma_read32(hw_info->cldma_ap_ao_base, REG_CLDMA_SO_STATUS);
}

void cldma_hw_stop_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char rx_tx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!rx_tx) {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_STOP_CMD, 1 << qno);
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_UL_STOP_CMD, qno);
		}
	} else {
		if (qno != 0xFF) {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_SO_STOP_CMD, 1 << qno);
		} else {
			cldma_write32(hw_info->cldma_ap_pdn_base,
				REG_CLDMA_SO_STOP_CMD, qno);
		}
	}
}


void cldma_hw_stop(struct ccci_hw_ctrl *hw_ctrl, unsigned char rx_tx)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (!rx_tx) {
		cldma_write32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMSR0, TXRX_STATUS_BITMASK);
		cldma_write32(hw_info->cldma_ap_pdn_base,
			REG_CLDMA_L2TIMSR0, EMPTY_STATUS_BITMASK);
	} else {
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMSR0, TXRX_STATUS_BITMASK);
		cldma_write32(hw_info->cldma_ap_ao_base,
			REG_CLDMA_L2RIMSR0, EMPTY_STATUS_BITMASK);
	}
}
void cldma_hw_dump(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	MTK_DEBUG_LOG(TAG, "CLDMA %d DEBUG DUMP -- LEFT\n", hw_info->hw_id);
	MTK_ERR_LOG(TAG, "dump AP CLDMA INDMA PD Register Address:%lx\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_UL_START_ADDRL_0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base +
		REG_CLDMA_UL_START_ADDRL_0, 0x210+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA OUTDMA PD Register Address: %lx\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_SO_ERROR);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base + REG_CLDMA_SO_ERROR, 0xC4+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA OUTDMA AO Register Address: %lx\n",
		hw_info->cldma_phy_ao_base + REG_CLDMA_SO_CFG);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_ao_base + REG_CLDMA_SO_CFG, 0x19C+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA AO MISC Register Address: %lx\n",
		hw_info->cldma_phy_ao_base + REG_CLDMA_L2RIMR0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_ao_base + REG_CLDMA_L2RIMR0, 0x1D8+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA PD MISC Register Address: %lx\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2TISAR0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base + REG_CLDMA_L2TISAR0, 0xD4+4);
	MTK_DEBUG_LOG(TAG, "CLDMA %d DEBUG DUMP -- RIGHT\n", hw_info->hw_id);
	MTK_ERR_LOG(TAG, "dump AP CLDMA INDMA PD Register Address:%lx\n",
		hw_info->cldma_phy_pd_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_UL_START_ADDRL_0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET +
		REG_CLDMA_UL_START_ADDRL_0, 0x210 + 4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA OUTDMA PD Register Address: %lx\n",
		hw_info->cldma_phy_pd_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_SO_ERROR);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_SO_ERROR, 0xC4+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA OUTDMA AO Register Address: %lx\n",
		hw_info->cldma_phy_ao_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_SO_CFG);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_SO_CFG, 0x19C+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA AO MISC Register Address: %lx\n",
		hw_info->cldma_phy_ao_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_L2RIMR0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_L2RIMR0, 0x1D8+4);
	MTK_ERR_LOG(TAG, "dump AP CLDMA PD MISC Register Address: %lx\n",
		hw_info->cldma_phy_pd_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_L2TISAR0);
	ccci_util_mem_dump(0, CCCI_DUMP_MEM_DUMP,
		hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET + REG_CLDMA_L2TISAR0, 0xD4+4);
}

#endif




