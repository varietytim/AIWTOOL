/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_TTY__
#define __PORT_TTY__
#include "ccci_core.h"
#include "port_t.h"
#include "ccci_tty.h"


/*the ccci tty port base name*/
#define CCCI_TTY_PORT_NAME_BASE "ttyC"

/*should ccci driver owner modify [tty port number]*/
#define TTY_PORT_NR (32)

/*provide by ccci tty driver*/
extern struct tty_dev_ops tty_ops;


#endif	/*__PORT_RELAY__*/
