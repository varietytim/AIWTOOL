// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_fsm_internal.h"

static int fsm_md_data_ioctl(int md_id,
unsigned int cmd, unsigned long arg)
{
	int ret = 0;
	unsigned int data = 0;
	struct ccci_per_md *per_md_data = ccci_get_per_md_data(md_id);

	switch (cmd) {
	case CCCI_IOC_GET_MD_PROTOCOL_TYPE:
		if (copy_to_user((void __user *)arg, "DHL", sizeof("DHL"))) {
			MTK_ERR_LOG(FSM,
				"CCCI_IOC_GET_MD_PROTOCOL_TYPE: copy_to_user fail\n");
			return -EFAULT;
		}
		break;
	case CCCI_IOC_GET_EXT_MD_POST_FIX:
		if (copy_to_user((void __user *)arg,
			per_md_data->img_post_fix, IMG_POSTFIX_LEN)) {
			MTK_ERR_LOG(FSM,
				"CCCI_IOC_GET_EXT_MD_POST_FIX: copy_to_user fail\n");
			ret = -EFAULT;
		}
		break;

	case CCCI_IOC_DL_TRAFFIC_CONTROL:
		if (copy_from_user(&data,
			(void __user *)arg, sizeof(unsigned int)))
			MTK_ERR_LOG(FSM,
			"CCCI_IOC_DL_TRAFFIC_CONTROL: copy_from_user fail\n");
		if (data == 1)
			;/* turn off downlink queue */
		else if (data == 0)
			;/* turn on donwlink queue */	
		ret = 0;
		break;
	case CCCI_IOC_SET_MD_BOOT_MODE:
		if (copy_from_user(&data, (void __user *)arg,
			sizeof(unsigned int))) {
			MTK_ERR_LOG(FSM,
				"CCCI_IOC_SET_MD_BOOT_MODE: copy_from_user fail\n");
			ret = -EFAULT;
		} else {
			MTK_INFO_LOG(FSM, "set MD boot mode to %u\n", data);
			per_md_data->md_boot_mode = data;
		}
		break;
	case CCCI_IOC_GET_MD_INFO:
		ret = put_user(
			(unsigned int)per_md_data->img_info[IMG_MD].img_info.version,
			(unsigned int __user *)arg);
		break;
	case CCCI_IOC_GET_MD_IMG_EXIST:
		break;
	case CCCI_IOC_GET_MD_TYPE_SAVING:
		ret = put_user(per_md_data->config.load_type_saving,
			(unsigned int __user *)arg);
		break;
	case CCCI_IOC_GET_AT_CH_NUM:
		{
			unsigned int at_ch_num = 4; /*default value*/
			struct ccci_runtime_feature *rt_feature = NULL;

			rt_feature = ccci_md_get_rt_feature_by_id(md_id,
				AT_CHANNEL_NUM, 1);
			if (rt_feature)
				ret = ccci_md_parse_rt_feature(md_id,
					rt_feature, &at_ch_num,
					sizeof(at_ch_num));
			else
				MTK_ERR_LOG(FSM, "get AT_CHANNEL_NUM fail\n");

			MTK_INFO_LOG(FSM, "get at_ch_num = %u\n", at_ch_num);
			ret = put_user(at_ch_num, (unsigned int __user *)arg);
			break;
		}
	default:
		ret = -ENOTTY;
		break;
	}
	return ret;
}

long ccci_fsm_ioctl(int md_id, unsigned int cmd, unsigned long arg)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);
	int ret = 0;
	enum MD_STATE_FOR_USER state_for_user;
	unsigned int data;

	if (!ctl)
		return -EINVAL;

	switch (cmd) {
	case CCCI_IOC_GET_MD_STATE:
		state_for_user = ccci_fsm_get_md_state_for_user(md_id);
		if (state_for_user >= 0) {
			ret = put_user((unsigned int)state_for_user,
				(unsigned int __user *)arg);
		} else {
			MTK_ERR_LOG(FSM,
				"Get MD state fail: %d\n", state_for_user);
			ret = state_for_user;
		}
		break;
	case CCCI_IOC_MD_RESET:
		MTK_INFO_LOG(FSM,
			"MD reset ioctl called by %s\n", current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_RESET_REQUEST, 0);
		break;
	case CCCI_IOC_FORCE_MD_ASSERT:
		MTK_INFO_LOG(FSM,
			"MD force assert ioctl called by %s\n", current->comm);
		ret = ccci_md_force_assert(md_id,
			MD_FORCE_ASSERT_BY_USER_TRIGGER, NULL, 0);
		break;
	case CCCI_IOC_SEND_STOP_MD_REQUEST:
		MTK_INFO_LOG(FSM,
			"MD stop request ioctl called by %s\n", current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FORCE_STOP_REQUEST, 0);
		break;
	case CCCI_IOC_SEND_START_MD_REQUEST:
		MTK_INFO_LOG(FSM,
			"MD start request ioctl called by %s\n", current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FORCE_START_REQUEST, 0);
		break;
	case CCCI_IOC_DO_START_MD:
		MTK_INFO_LOG(FSM,
			"MD start ioctl called by %s\n", current->comm);
		ret = fsm_append_command(ctl, CCCI_COMMAND_START,
			FSM_CMD_FLAG_WAIT_FOR_COMPLETE);
		break;
	case CCCI_IOC_DO_STOP_MD:
		if (copy_from_user(&data,
			(void __user *)arg, sizeof(unsigned int))) {
			MTK_ERR_LOG(FSM,
				"CCCI_IOC_DO_STOP_MD: copy_from_user fail\n");
			ret = -EFAULT;
		} else {
			MTK_INFO_LOG(FSM,
				"MD stop ioctl called by %s %u\n",
				current->comm, data);
			ret = fsm_append_command(ctl, CCCI_COMMAND_PRE_STOP,
					FSM_CMD_FLAG_WAIT_FOR_COMPLETE |
					((data ? MD_FLIGHT_MODE_ENTER :
					MD_FLIGHT_MODE_NONE)
					== MD_FLIGHT_MODE_ENTER ?
					FSM_CMD_FLAG_FLIGHT_MODE : 0));
		}
		break;
	case CCCI_IOC_ENTER_DEEP_FLIGHT:
		MTK_INFO_LOG(FSM,
			"MD enter flight mode ioctl called by %s\n",
			current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FLIGHT_STOP_REQUEST, 0);
		break;
	case CCCI_IOC_LEAVE_DEEP_FLIGHT:
		MTK_INFO_LOG(FSM, "MD leave flight mode ioctl called by %s\n",
			current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FLIGHT_START_REQUEST, 0);
		break;
	case CCCI_IOC_ENTER_DEEP_FLIGHT_ENHANCED:
		MTK_INFO_LOG(FSM,
			"MD enter flight mode enhanced ioctl called by %s\n",
			current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FLIGHT_STOP_REQUEST, 0);
		break;
	case CCCI_IOC_LEAVE_DEEP_FLIGHT_ENHANCED:
		MTK_INFO_LOG(FSM,
			"MD leave flight mode enhanced ioctl called by %s\n",
			current->comm);
		ret = fsm_monitor_send_message(ctl->md_id,
			CCCI_MD_MSG_FLIGHT_START_REQUEST, 0);
		break;
	case CCCI_IOC_MDLOG_DUMP_DONE:
		MTK_INFO_LOG(FSM, "MD logger dump done ioctl called by %s\n",
			current->comm);
		ctl->ee_ctl.mdlog_dump_done = 1;
		break;
	case CCCI_IOC_GET_MD_EX_TYPE:
		ret = put_user((unsigned int)ctl->ee_ctl.ex_type,
			(unsigned int __user *)arg);
		MTK_INFO_LOG(FSM, "get modem exception type=%u ret=%d\n",
			ctl->ee_ctl.ex_type, ret);
		break;
	default:
		ret = fsm_md_data_ioctl(md_id, cmd, arg);
		break;
	}
	return ret;
}

