/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __DRV_AT_DPMAIF_H__
#define __DRV_AT_DPMAIF_H__


/*
 *	DPMAIF HW Initialization parameter structure
 */
struct dpmaif_hw_init_para {
	/* UL part */
	dma_addr_t drb_base_addr[MAIFQ_MAX_ULQ_NUM];
	unsigned int drb_size_cnt[MAIFQ_MAX_ULQ_NUM];

	/* DL part */
	dma_addr_t pkt_bat_base_addr[MAIFQ_MAX_DLQ_NUM];
	unsigned int pkt_bat_size_cnt[MAIFQ_MAX_DLQ_NUM];
	dma_addr_t frg_bat_base_addr[MAIFQ_MAX_DLQ_NUM];
	unsigned int frg_bat_size_cnt[MAIFQ_MAX_DLQ_NUM];
	dma_addr_t pit_base_addr[MAIFQ_MAX_DLQ_NUM];
	unsigned int pit_size_cnt[MAIFQ_MAX_DLQ_NUM];
};

/*
 *	DPMAIF HW interrupt type, it's a bitmask value
 */
enum dpmaif_hw_intr_type {
	DPF_INTR_INVALID_MIN = 0,

	/* uplink part */
	DPF_INTR_UL_DONE,
	DPF_INTR_UL_DRB_EMPTY,
	DPF_INTR_UL_MD_NOTREADY,
	DPF_INTR_UL_MD_PWR_NOTREADY,
	DPF_INTR_UL_LEN_ERR,

	/* donwlink part */
	DPF_INTR_DL_DONE,
	DPF_INTR_DL_SKB_LEN_ERR,
	DPF_INTR_DL_BATCNT_LEN_ERR,
	DPF_INTR_DL_PITCNT_LEN_ERR,
	DPF_INTR_DL_PKT_EMPTY_SET,
	DPF_INTR_DL_FRG_EMPTY_SET,
	DPF_INTR_DL_MTU_ERR,
	DPF_INTR_DL_FRGCNT_LEN_ERR,

	DPF_DL_INT_DLQ0_PITCNT_LEN_ERR,
	DPF_DL_INT_DLQ1_PITCNT_LEN_ERR,
	DPF_DL_INT_HPC_ENT_TYPE_ERR,
	DPF_INTR_DL_DLQ0_DONE,
	DPF_INTR_DL_DLQ1_DONE,

	DPF_INTR_INVALID_MAX
};

/*
 *	DPMAIF HW notification type
 */
enum dpmaif_hw_notify_type {
	DPF_NOTIFY_INVALID_MIN = 0,

	/* uplink part */
	DPF_NOTIFY_UL_ENABLE_INTR,

	/* downlink part */
	DPF_NOTIFY_DL_ENABLE_INTR,
	DPF_NOTIFY_DL_ADD_PKT_BAT_CNT,
	DPF_NOTIFY_DL_ADD_FRG_BAT_CNT,
	DPF_NOTIFY_DL_ADD_PIT_RMN_CNT,

	/* others */
	DPF_NOTIFY_CLEAR_IP_BUSY,

	DPF_NOTIFY_INVALID_MAX = DPF_NOTIFY_CLEAR_IP_BUSY
};

/*
 *	DPMAIF HW interrupt status parameter structure
 */
#define DPF_HW_INTR_COUNT\
	((DPF_INTR_INVALID_MAX) - (DPF_INTR_INVALID_MIN) - 1)

#define DPF_RX_QNO0			DPMAIF_DLQ0_NUM
#define DPF_RX_QNO1			DPMAIF_DLQ1_NUM
#define DPF_RX_QNO_DFT		DPF_RX_QNO0

struct dpmaif_hw_intr_st_para {
	unsigned int intr_cnt;
	enum dpmaif_hw_intr_type intr_types[DPF_HW_INTR_COUNT];
	// it's a bitmask value for queues
	unsigned int intr_queues[DPF_HW_INTR_COUNT];
};

/* === tx interrupt mask === */
#define DP_UL_INT_DONE_OFFSET       0
#define DP_UL_INT_EMPTY_OFFSET      5
#define DP_UL_INT_MD_NOTRDY_OFFSET  10
#define DP_UL_INT_PWR_NOTRDY_OFFSET 15
#define DP_UL_INT_LEN_ERR_OFFSET    20
#define DP_UL_QNUM_MSK          0x1F

#define DP_UL_INT_DONE(q_num)           (1 << (q_num+DP_UL_INT_DONE_OFFSET))
#define DP_UL_INT_EMPTY(q_num)          (1 << (q_num+DP_UL_INT_EMPTY_OFFSET))
#define DP_UL_INT_MD_NOTRDY(q_num) \
	(1 << (q_num+DP_UL_INT_MD_NOTRDY_OFFSET))
#define DP_UL_INT_PWR_NOTRDY(q_num) \
	(1 << (q_num+DP_UL_INT_PWR_NOTRDY_OFFSET))
#define DP_UL_INT_LEN_ERR(q_num)        (1 << (q_num+DP_UL_INT_LEN_ERR_OFFSET))

#define DP_UL_INT_QDONE_MSK         (DP_UL_QNUM_MSK << DP_UL_INT_DONE_OFFSET)
#define DP_UL_INT_EMPTY_MSK         (DP_UL_QNUM_MSK << DP_UL_INT_EMPTY_OFFSET)
#define DP_UL_INT_MD_NOTREADY_MSK \
	(DP_UL_QNUM_MSK << DP_UL_INT_MD_NOTRDY_OFFSET)
#define DP_UL_INT_MD_PWR_NOTREADY_MSK \
	(DP_UL_QNUM_MSK << DP_UL_INT_PWR_NOTRDY_OFFSET)
#define DP_UL_INT_ERR_MSK           (DP_UL_QNUM_MSK << DP_UL_INT_LEN_ERR_OFFSET)

/* === RX interrupt mask === */
#define DP_DL_INT_QDONE_MSK             (1 << 0)
#define DP_DL_INT_SKB_LEN_ERR           (1 << 1)
#define DP_DL_INT_BATCNT_LEN_ERR        (1 << 2)
#define DP_DL_INT_PITCNT_LEN_ERR        (1 << 3)
#define DP_DL_INT_PKT_EMPTY_MSK         (1 << 4)
#define DP_DL_INT_FRG_EMPTY_MSK         (1 << 5)
#define DP_DL_INT_MTU_ERR_MSK           (1 << 6)
#define DP_DL_INT_FRG_LENERR_MSK        (1 << 7)
#define DP_DL_INT_DLQ0_PITCNT_LEN_ERR   (0x01 << 8)
#define DP_DL_INT_DLQ1_PITCNT_LEN_ERR   (0x01 << 9)
#define DP_DL_INT_HPC_ENT_TYPE_ERR      (0x01 << 10)
#define DP_DL_INT_DLQ0_QDONE_SET        (0x01 << 13)
#define DP_DL_INT_DLQ1_QDONE_SET        (0x01 << 14)


#define DP_DL_DLQ0_STATUS_MASK \
	(DP_DL_INT_DLQ0_PITCNT_LEN_ERR | DP_DL_INT_DLQ0_QDONE_SET)

#define DP_DL_DLQ1_STATUS_MASK \
	(DP_DL_INT_DLQ1_PITCNT_LEN_ERR | DP_DL_INT_DLQ1_QDONE_SET)

#define DP_DL_INT_LENERR_ALL_MSK \
	(DP_DL_INT_SKB_LEN_ERR|DP_DL_INT_BATCNT_LEN_ERR| \
	DP_DL_INT_PITCNT_LEN_ERR|DP_DL_INT_MTU_ERR_MSK|DP_DL_INT_FRG_LENERR_MSK)

#define DP_DL_INT_EMPTY_ALL_MSK \
	(DP_DL_INT_PKT_EMPTY_MSK|DP_DL_INT_FRG_EMPTY_MSK)

/*************************************************************************************************
								Export APIs to Hif Layer
*************************************************************************************************/
int drv_dpmaif_hw_addr_init(struct dpmaif_hw_info *dpmaif_hw_info,
	struct pcie_hw_info *pcie_hw_info);
void drv_dpmaif_hw_init(struct dpmaif_hw_info *hw_info, void *para);

void drv_dpmaif_hw_stop_tx_queue(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_hw_stop_rx_queue(struct dpmaif_hw_info *hw_info);

void drv_dpmaif_start_hw(struct dpmaif_hw_info *hw_info);

int drv_dpmaif_dlq_mask_rx_pit_cnt_len_err_intr(struct dpmaif_hw_info *hw_info, unsigned char qno);
int drv_dpmaif_dlq_unmask_rx_pit_cnt_len_err_intr(struct dpmaif_hw_info *hw_info,
	unsigned char qno);

int drv_dpmaif_hw_dlq_mask_rx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char qno);
int drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char qno);

unsigned int drv_dpmaif_get_dl_interrupt_mask(struct dpmaif_hw_info *hw_info);
unsigned int drv_dpmaif_get_ul_interrupt_mask(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_hw_get_interrupt_status(struct dpmaif_hw_info *hw_info, void *para, int qno);
void drv_dpmaif_unmask_ul_que_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num);
void drv_dpmaif_hw_dump(struct dpmaif_hw_info *hw_info, void *para);
void drv_dpmaif_hw_dump_interrupt_status(struct dpmaif_hw_info *hw_info);
bool drv_dpmaif_hw_check_clr_ul_done_status(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_ul_mask_multiple_tx_done_intr(struct dpmaif_hw_info *hw_info,
	unsigned char que_mask);
unsigned int drv_dpmaif_ul_get_ridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num);
int drv_dpmaif_ul_add_wcnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int drb_entry_cnt);
void drv_dpmaif_clr_ul_all_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_clr_dl_all_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_clr_ip_busy_sts(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_unmask_dl_batcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_dl_add_bat_cnt(struct dpmaif_hw_info *hw_info, unsigned char q_num, unsigned int bat_entry_cnt);
unsigned int drv_dpmaif_dl_get_bat_ridx(struct dpmaif_hw_info *hw_info, unsigned char q_num);
unsigned int drv_dpmaif_dl_get_bat_wridx(struct dpmaif_hw_info *hw_info, unsigned char q_num);
void drv_dpmaif_dl_add_frg_cnt(struct dpmaif_hw_info *hw_info, unsigned char q_num, unsigned int frg_entry_cnt);
unsigned int drv_dpmaif_dl_get_frg_ridx(struct dpmaif_hw_info *hw_info, unsigned char q_num);
int drv_dpmaif_dl_add_dlq_pit_remain_cnt(struct dpmaif_hw_info *hw_info,
	unsigned int dlq_pit_idx, unsigned int pit_remain_cnt);
unsigned int drv_dpmaif_dl_dlq_pit_get_wridx(struct dpmaif_hw_info *hw_info, unsigned int dlq_pit_idx);
void drv_dpmaif_dump_all_config_regs(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_dump_debug_regs(struct dpmaif_hw_info *hw_info);


/*************************************************************************************************
								Reserve APIs
*************************************************************************************************/
unsigned int drv_dpmaif_ip_code_version(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_hw_isr_init(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_dl_set_wdma(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_ul_restore(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int restore_ridx);
unsigned int drv_dpmaif_ul_get_drb_size(struct dpmaif_hw_info *hw_info,
	unsigned int q_num);
void drv_dpmaif_ul_queue_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable);
void drv_dpmaif_dl_queue_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable);
unsigned int drv_dpmaif_ul_idle_check(struct dpmaif_hw_info *hw_info, unsigned char q_num);
unsigned int drv_dpmaif_get_ulq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num);
void drv_dpmaif_clr_ulq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num);
void drv_dpmaif_clr_dlq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num);
void drv_dpmaif_mask_dl_que_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num);
void drv_dpmaif_unmask_dl_que_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_unmask_ul_que_empty_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num);
void drv_dpmaif_mask_ul_que_empty_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num);
void drv_dpmaif_unmask_dl_pkt_empty_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_mask_dl_pkt_empty_interrupt(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_init_ul_intr(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_dl_add_pit_remain_cnt(struct dpmaif_hw_info *hw_info, 
	unsigned char q_num, unsigned int pit_remain_cnt);
DRV_BOOL drv_dpmaif_check_power_down(struct dpmaif_hw_info *hw_info);
void drv_dpmaif_ap_reorder_en(struct dpmaif_hw_info *hw_info);
DRV_BOOL drv_dpmaif_get_hw_hpc_cntl_mode(struct dpmaif_hw_info *hw_info);
unsigned int drv_dpmaif_dl_dlq_pit_get_rdidx(struct dpmaif_hw_info *hw_info, unsigned int dlq_pit_idx);
void drv_dpmaif_hw_clr_dl_intr_sts_frg_cnt_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_mtu_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_frg_empty(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_pkt_empty(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_pit_cnt_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_bat_cnt_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_skb_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_dl_intr_sts_dl_done(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_ul_intr_sts_drb_empty(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_ul_intr_sts_md_not_ready(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_ul_intr_sts_md_pwr_not_ready(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_ul_intr_sts_ul_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_clr_ul_intr_sts_ul_done(struct dpmaif_hw_info *hw_info, unsigned char qno);
void drv_dpmaif_hw_ul_unmask_multiple_tx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char que_mask);
int drv_dpmaif_hw_ul_mask_tx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char qno);
int drv_dpmaif_hw_dl_mask_rx_done_intr(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_hw_dl_unmask_rx_done_intr(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_hw_dl_mask_rx_bat_cnt_len_err_intr(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_hw_dl_mask_rx_pit_cnt_len_err_intr(struct dpmaif_hw_info *hw_info);
int drv_dpmaif_hw_dl_add_pit_remain_cnt(struct dpmaif_hw_info *hw_info, unsigned char qno, unsigned int count);

#endif

