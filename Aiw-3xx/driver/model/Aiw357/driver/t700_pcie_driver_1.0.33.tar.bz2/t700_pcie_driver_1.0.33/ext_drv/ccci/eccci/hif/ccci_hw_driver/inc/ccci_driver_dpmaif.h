/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __CCCI_DRIVER_DPMAIF_H__
#define __CCCI_DRIVER_DPMAIF_H__

#include <linux/device.h>
#include <linux/kernel.h>

#include "ccci_driver.h"
#include "dpmaif_hif_platform.h"

/*
 *	DPMAIF HW queues count
 */
#define DPF_HW_RX_QUE_CNT	1
#define DPF_HW_TX_QUE_CNT	5
extern hw_dpmaif_ctrl_t dpmaif_ctrl;


/*
 *	DPMAIF over PCIE HW information structure
 */
typedef struct dpmaif_pcie_hw_info {
	struct device *pcie_dev;	// pcie device for DMA address mapping
	u64 hw_base_addr;	// MTK device base address without mapping
	u64 hw_map_base_addr;	// MTK device base address on eAP after mapping
	unsigned char md_id;		// MD ID
} dpmaif_pcie_hw_info_t, *dpmaif_pcie_hw_info_ptr_t;

/*
 *	DPMAIF HW Initialization parameter structure
 */
typedef struct dpmaif_hw_init_para {
	/* UL part */
	dma_addr_t drb_base_addr[DPF_HW_TX_QUE_CNT];
	unsigned int drb_size_cnt[DPF_HW_TX_QUE_CNT];

	/* DL part */
	dma_addr_t pkt_bat_base_addr[DPF_HW_RX_QUE_CNT];
	unsigned int pkt_bat_size_cnt[DPF_HW_RX_QUE_CNT];
	dma_addr_t frg_bat_base_addr[DPF_HW_RX_QUE_CNT];
	unsigned int frg_bat_size_cnt[DPF_HW_RX_QUE_CNT];
	dma_addr_t pit_base_addr[DPF_HW_RX_QUE_CNT];
	unsigned int pit_size_cnt[DPF_HW_RX_QUE_CNT];
} dpmaif_hw_init_para_t, *dpmaif_hw_init_para_ptr_t;

/*
 *	DPMAIF HW read/write status type
 */
typedef enum dpmaif_hw_rw_st_type {
	RW_TYPE_INVALID_MIN = 0,

	/* uplink part */
	RW_TYPE_DRB_RD_IDX,

	/* downlink part */
	RW_TYPE_PKT_BAT_RD_IDX,
	RW_TYPE_PKT_BAT_WR_IDX,
	RW_TYPE_FRG_BAT_RD_IDX,
	RW_TYPE_FRG_BAT_WR_IDX,
	RW_TYPE_PIT_RD_IDX,
	RW_TYPE_PIT_WR_IDX,

	RW_TYPE_INVALID_MAX = RW_TYPE_PIT_WR_IDX + 1
} dpmaif_hw_rw_st_type_t, *dpmaif_hw_rw_st_type_ptr_t;

/*
 *	DPMAIF HW read/write status structure
 */
#define DP_HW_RW_ST_TYPE_COUNT\
	((RW_TYPE_INVALID_MAX) - (RW_TYPE_INVALID_MIN) - 1)
typedef struct dpmaif_hw_rw_st_para {
	unsigned char qno;		// queue index
	unsigned int count;	// how many counts of values to get
	dpmaif_hw_rw_st_type_t rw_types[DP_HW_RW_ST_TYPE_COUNT];
	unsigned int values[DP_HW_RW_ST_TYPE_COUNT];
} dpmaif_hw_rw_st_para_t, *dpmaif_hw_rw_st_para_ptr_t;

/*
 *	DPMAIF HW send data parameter
 */
typedef struct dpmaif_hw_send_para {
	unsigned short count;
	unsigned char qno;
} dpmaif_hw_send_para_t, *dpmaif_hw_send_para_ptr_t;

/*
 *	DPMAIF HW interrupt type, it's a bitmask value
 */
typedef enum dpmaif_hw_intr_type {
	DPF_INTR_INVALID_MIN = 0,

	/* uplink part */
	DPF_INTR_UL_DONE,
	DPF_INTR_UL_DRB_EMPTY,
	DPF_INTR_UL_MD_NOTREADY,
	DPF_INTR_UL_MD_PWR_NOTREADY,
	DPF_INTR_UL_LEN_ERR,

	/* donwlink part */
	DPF_INTR_DL_DONE,
	DPF_INTR_DL_SKB_LEN_ERR,
	DPF_INTR_DL_BATCNT_LEN_ERR,
	DPF_INTR_DL_PITCNT_LEN_ERR,
	DPF_INTR_DL_PKT_EMPTY_SET,
	DPF_INTR_DL_FRG_EMPTY_SET,
	DPF_INTR_DL_MTU_ERR,
	DPF_INTR_DL_FRGCNT_LEN_ERR,

	DPF_INTR_INVALID_MAX = DPF_INTR_DL_FRGCNT_LEN_ERR + 1
} dpmaif_hw_intr_type_t, *dpmaif_hw_intr_type_ptr_t;

/*
 *	DPMAIF HW interrupt status parameter structure
 */
#define DPF_HW_INTR_COUNT\
	((DPF_INTR_INVALID_MAX) - (DPF_INTR_INVALID_MIN) - 1)
#define DPF_RX_QNO_DFT		(0)
typedef struct dpmaif_hw_intr_st_para {
	unsigned int intr_cnt;
	dpmaif_hw_intr_type_t intr_types[DPF_HW_INTR_COUNT];
	// it's a bitmask value for queues
	unsigned int intr_queues[DPF_HW_INTR_COUNT];
} dpmaif_hw_intr_st_para_t, *dpmaif_hw_intr_st_para_ptr_t;

/*
 *	DPMAIF HW clear type
 */
typedef enum dpmaif_hw_clear_type {
	DPF_HW_CLR_INVALID = 0,
	DPF_HW_CLR_UL_INTR,
	DPF_HW_CLR_DL_INTR,
	DPF_HW_CLR_ALL_INTR
} dpmaif_hw_clear_type_t, *dpmaif_hw_clear_type_ptr_t;

/*
 *	DPMAIF HW clear parameter structure
 */
typedef struct dpmaif_hw_clear_para {
	dpmaif_hw_clear_type_t clr_type;
	dpmaif_hw_intr_type_t intr_type;
	unsigned int qno;	// queue number
} dpmaif_hw_clear_para_t, *dpmaif_hw_clear_para_ptr_t;

/*
 *	DPMAIF HW notification type
 */
typedef enum dpmaif_hw_notify_type {
	DPF_NOTIFY_INVALID_MIN = 0,

	/* uplink part */
	DPF_NOTIFY_UL_ENABLE_INTR,

	/* downlink part */
	DPF_NOTIFY_DL_ENABLE_INTR,
	DPF_NOTIFY_DL_ADD_PKT_BAT_CNT,
	DPF_NOTIFY_DL_ADD_FRG_BAT_CNT,
	DPF_NOTIFY_DL_ADD_PIT_RMN_CNT,

	/* others */
	DPF_NOTIFY_CLEAR_IP_BUSY,

	DPF_NOTIFY_INVALID_MAX = DPF_NOTIFY_CLEAR_IP_BUSY
} dpmaif_hw_notify_type_t, *dpmaif_hw_notify_type_ptr_t;

/*
 *	DPMAIF HW notification parameter structure
 */
#define DPF_NOTIFY_TYPE_COUNT\
	((DPF_NOTIFY_INVALID_MAX) - (DPF_NOTIFY_INVALID_MIN) - 1)
typedef struct dpmaif_hw_notify_para {
	unsigned int count;
	dpmaif_hw_notify_type_t ntf_type[DPF_NOTIFY_TYPE_COUNT];
	unsigned int qno;					// queue number
	// this parameter should ONLY be used for adding BAT count
	unsigned int para[DPF_NOTIFY_TYPE_COUNT];
	// and adding remain PIT count
} dpmaif_hw_notify_para_t, *dpmaif_hw_notify_para_ptr_t;


/*******************************************/
/********** HDAL Interfaces of DPMAIF *********/
/******************************************/
void dpmaif_driver_init(struct ccci_hw_ctrl *hw_ctrl);

void dpmaif_hw_init(void *para);

void dpmaif_hw_reset(void *para);

void dpmaif_hw_dump(void *para);

int dpmaif_hw_get_interrupt_status(void *para);

unsigned int dpmaif_hw_get_drb_rd_idx(unsigned char qno);

unsigned int dpmaif_hw_get_pkt_bat_rd_idx(unsigned char qno);

unsigned int dpmaif_hw_get_pkt_bat_wr_idx(unsigned char qno);

unsigned int dpmaif_hw_get_pit_rd_idx(unsigned char qno);

unsigned int dpmaif_hw_get_pit_wr_idx(unsigned char qno);

int dpmaif_hw_ul_add_wcnt(unsigned char qno, unsigned short add_count);

void dpmaif_hw_clr_dl_all_intr_sts(void);

void dpmaif_hw_clr_ul_all_intr_sts(void);

void dpmaif_hw_clr_dl_intr_sts_frg_cnt_err(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_mtu_err(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_frg_empty(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_pkt_empty(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_pit_cnt_len_err(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_bat_cnt_len_err(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_skb_len_err(unsigned char qno);

void dpmaif_hw_clr_dl_intr_sts_dl_done(unsigned char qno);

void dpmaif_hw_clr_ul_intr_sts_drb_empty(unsigned char qno);

void dpmaif_hw_clr_ul_intr_sts_md_not_ready(unsigned char qno);

void dpmaif_hw_clr_ul_intr_sts_md_pwr_not_ready(unsigned char qno);

void dpmaif_hw_clr_ul_intr_sts_ul_len_err(unsigned char qno);

void dpmaif_hw_clr_ul_intr_sts_ul_done(unsigned char qno);

void dpmaif_hw_ul_mask_multiple_tx_done_intr(unsigned char que_mask);

void dpmaif_hw_ul_unmask_multiple_tx_done_intr(unsigned char que_mask);

int dpmaif_hw_ul_mask_tx_done_intr(unsigned char qno);

int dpmaif_hw_ul_unmask_tx_done_intr(unsigned char qno);

int dpmaif_hw_dl_mask_rx_done_intr(void);

int dpmaif_hw_dl_unmask_rx_done_intr(void);

int dpmaif_hw_dl_mask_rx_bat_cnt_len_err_intr(void);

int dpmaif_hw_dl_unmask_rx_bat_cnt_len_err_intr(void);

int dpmaif_hw_dl_mask_rx_pit_cnt_len_err_intr(void);

int dpmaif_hw_dl_unmask_rx_pit_cnt_len_err_intr(void);

int dpmaif_hw_dl_add_pkt_bat_cnt(unsigned char qno, unsigned int count);

void dpmaif_hw_dl_add_frg_bat_cnt(unsigned char qno, unsigned int count);

int dpmaif_hw_dl_add_pit_remain_cnt(unsigned char qno, unsigned int count);

void dpmaif_hw_clear_ip_busy(void);

unsigned int dpmaif_hw_get_ul_done_status(void);

unsigned int dpmaif_hw_get_dl_done_status(void);

void dpmaif_hw_stop_tx_queue(void);

void dpmaif_hw_stop_rx_queue(void);

void dpmaif_hw_start_tx_queue(void);

void dpmaif_hw_start_rx_queue(void);


#endif
