/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __DRV_AT_DPMAIF_HISR_H__
#define __DRV_AT_DPMAIF_HISR_H__

/* === tx interrupt mask === */
#define DP_UL_INT_DONE_OFFSET       0
#define DP_UL_INT_EMPTY_OFFSET      5
#define DP_UL_INT_MD_NOTRDY_OFFSET  10
#define DP_UL_INT_PWR_NOTRDY_OFFSET 15
#define DP_UL_INT_LEN_ERR_OFFSET    20
#define DP_UL_QNUM_MSK          0x1F

#define DP_UL_INT_DONE(q_num)           (1 << (q_num+DP_UL_INT_DONE_OFFSET))
#define DP_UL_INT_EMPTY(q_num)          (1 << (q_num+DP_UL_INT_EMPTY_OFFSET))
#define DP_UL_INT_MD_NOTRDY(q_num) \
	(1 << (q_num+DP_UL_INT_MD_NOTRDY_OFFSET))
#define DP_UL_INT_PWR_NOTRDY(q_num) \
	(1 << (q_num+DP_UL_INT_PWR_NOTRDY_OFFSET))
#define DP_UL_INT_LEN_ERR(q_num)        (1 << (q_num+DP_UL_INT_LEN_ERR_OFFSET))

#define DP_UL_INT_QDONE_MSK         (DP_UL_QNUM_MSK << DP_UL_INT_DONE_OFFSET)
#define DP_UL_INT_EMPTY_MSK         (DP_UL_QNUM_MSK << DP_UL_INT_EMPTY_OFFSET)
#define DP_UL_INT_MD_NOTREADY_MSK \
	(DP_UL_QNUM_MSK << DP_UL_INT_MD_NOTRDY_OFFSET)
#define DP_UL_INT_MD_PWR_NOTREADY_MSK \
	(DP_UL_QNUM_MSK << DP_UL_INT_PWR_NOTRDY_OFFSET)
#define DP_UL_INT_ERR_MSK           (DP_UL_QNUM_MSK << DP_UL_INT_LEN_ERR_OFFSET)

/* === RX interrupt mask === */
#define DP_DL_INT_QDONE_MSK         (1 << 0)
#define DP_DL_INT_SKB_LEN_ERR           (1 << 1)
#define DP_DL_INT_BATCNT_LEN_ERR        (1 << 2)
#define DP_DL_INT_PITCNT_LEN_ERR        (1 << 3)
#define DP_DL_INT_PKT_EMPTY_MSK         (1 << 4)
#define DP_DL_INT_FRG_EMPTY_MSK         (1 << 5)
#define DP_DL_INT_MTU_ERR_MSK           (1 << 6)
#define DP_DL_INT_FRG_LENERR_MSK        (1 << 7)

#define DP_DL_INT_LENERR_ALL_MSK \
	(DP_DL_INT_SKB_LEN_ERR|DP_DL_INT_BATCNT_LEN_ERR| \
	DP_DL_INT_PITCNT_LEN_ERR|DP_DL_INT_MTU_ERR_MSK|DP_DL_INT_FRG_LENERR_MSK)

#define DP_DL_INT_EMPTY_ALL_MSK \
	(DP_DL_INT_PKT_EMPTY_MSK|DP_DL_INT_FRG_EMPTY_MSK)


#endif
