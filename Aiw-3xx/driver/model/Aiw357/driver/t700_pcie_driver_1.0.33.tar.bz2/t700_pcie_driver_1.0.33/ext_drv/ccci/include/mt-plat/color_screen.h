/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef _COLOR_SCREEN_H_
#define _COLOR_SCREEN_H_

typedef enum {
	CS_FG_RESET		= 0,
	CS_FG_BLACK		= 30,
	CS_FG_RED		= 31,
	CS_FG_GREEN		= 32,
	CS_FG_YELLOW	= 33,
	CS_FG_BLUE		= 34,
	CS_FG_MAGENTA	= 35,
	CS_FG_CYAN		= 36,
	CS_FG_WHITE		= 37,
} CS_FG_COLOR;

typedef enum {
	CS_BG_BLACK		= 40,
	CS_BG_RED		= 41,
	CS_BG_GREEN	= 42,
	CS_BG_YELLOW	= 43,
	CS_BG_BLUE		= 44,
	CS_BG_MAGENTA	= 45,
	CS_BG_CYAN		= 46,
	CS_BG_WHITE	= 47,
} CS_BG_COLOR;

// function prototype
void cs_color_str(CS_FG_COLOR fg, CS_BG_COLOR bg, char *str);
void cs_color_str_wxh(CS_FG_COLOR fg,
	CS_BG_COLOR bg, int width, int height, char *str);

#endif
