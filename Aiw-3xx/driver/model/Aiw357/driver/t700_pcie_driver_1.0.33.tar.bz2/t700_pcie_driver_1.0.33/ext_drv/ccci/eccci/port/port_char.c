// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/poll.h>
#ifdef CONFIG_COMPAT
#include <linux/compat.h>
#endif
#include "ccci_config.h"
#include "ccci_bm.h"
#include "port_proxy.h"
#include "port_char.h"
#include "ccci_fsm.h"

#include <mt-plat/mtk_ccci_common.h>

#define MAX_QUEUE_LENGTH 32


unsigned int port_char_dev_poll(struct file *fp, struct poll_table_struct *poll)
{
	struct port_t *port = fp->private_data;
	unsigned int mask = 0;
	int md_id = port->md_id;
	int md_state = ccci_fsm_get_md_state(md_id);

	MTK_DEBUG_LIMITED_LOG(CHAR, "poll on %s\n", port->name);
	poll_wait(fp, &port->rx_wq, poll);
	/* TODO: lack of poll wait for Tx */
	if (!skb_queue_empty(&port->rx_skb_list))
		mask |= POLLIN | POLLRDNORM;
	if (port_write_room_to_md(port) > 0)
		mask |= POLLOUT | POLLWRNORM;
	if (port->rx_ch == CCCI_UART1_RX &&
		md_state != READY &&
		md_state != EXCEPTION) {
		/* notify MD logger to save its log before md_init kills it */
		mask |= POLLERR;
		MTK_INFO_LOG(CHAR,
			"poll error for MD logger at state %d, mask=%u\n",
			md_state, mask);
	}

	return mask;
}

static const struct file_operations char_dev_fops = {
	.owner = THIS_MODULE,
	.open = &port_dev_open, /*use default API*/
	.read = &port_dev_read, /*use default API*/
	.write = &port_dev_write, /*use default API*/
	.release = &port_dev_close,/*use default API*/
	.unlocked_ioctl = &port_dev_ioctl,/*use default API*/
#ifdef CONFIG_COMPAT
	.compat_ioctl = &port_dev_compat_ioctl,/*use default API*/
#endif
	.poll = &port_char_dev_poll,/*use port char self API*/
};
static int port_char_init(struct port_t *port)
{
	struct cdev *dev;
	int ret = 0;

	MTK_DEBUG_LOG(CHAR, "char port %s is initializing\n", port->name);
	port->rx_length_th = MAX_QUEUE_LENGTH;
	port->skb_from_pool = 1;
	port->interception = 0;
	if (port->flags & PORT_F_WITH_CHAR_NODE) {
		dev = cdev_alloc();
		dev->ops = &char_dev_fops;
		dev->owner = THIS_MODULE;
		ret = cdev_add(dev, MKDEV(port->major, port->minor_base + port->minor), 1);
		if (ret)
			kobject_put(&dev->kobj);
		if (!(port->flags & PORT_F_RAW_DATA))
			port->flags |= PORT_F_ADJUST_HEADER;
		port->cdev = dev;
	}

	if (port->rx_ch == CCCI_UART2_RX)
		port->flags |= PORT_F_CH_TRAFFIC;
	else if (port->rx_ch == CCCI_FS_RX)
		port->flags |= (PORT_F_CH_TRAFFIC | PORT_F_DUMP_RAW_DATA);

	return ret;
}

static void port_char_uninit(struct port_t *port)
{
	unsigned long flags;
	struct sk_buff *skb = NULL;

	if (port->flags & PORT_F_WITH_CHAR_NODE) {
		if (port->cdev) {
			if (port->chn_crt_stat == CCCI_CHAN_ENABLE) {
				ccci_unregister_dev_node(port->major,
					port->minor_base + port->minor);
				spin_lock(&port->port_update_lock);
				port->chn_crt_stat = CCCI_CHAN_DISABLE;
				spin_unlock(&port->port_update_lock);
			}
			MTK_DEBUG_LOG(CHAR, "%s,kobject cnt %d\n",port->name,
						atomic_read(&port->cdev->kobj.kref.refcount.refs));
			cdev_del(port->cdev);
			port->cdev = NULL;
		}
	}

	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
	while ((skb = __skb_dequeue(&port->rx_skb_list)) != NULL)
		ccci_free_skb(skb);

	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);

}

static int port_char_recv_skb(struct port_t *port, struct sk_buff *skb)
{
	if (port->flags & PORT_F_WITH_CHAR_NODE) {
		if (!atomic_read(&port->usage_cnt)) {
			MTK_ERR_LOG(CHAR, "port %s is not opened, drop packets\n", port->name);
		return -CCCI_ERR_DROP_PACKET;
		}
	}
	return port_recv_skb(port, skb);
}

void port_char_dump_info(struct port_t *port, unsigned int flag)
{
	if (port == NULL) {
		MTK_ERR_LOG(CHAR, "invalid input: port is NULL\n");
		return;
	}
	if (atomic_read(&port->usage_cnt) == 0)
		return;
}
inline static int port_status_update(struct port_t *port)
{
	int err=0;

	if (port->flags & PORT_F_WITH_CHAR_NODE) {
		if (port->chan_enable == CCCI_CHAN_ENABLE) {
			MTK_DEBUG_LOG(CHAR, "port %s is created \n",port->name);
			port->flags &= ~PORT_F_ALLOW_DROP;
			err = ccci_register_dev_node(port->name, port->major, port->minor_base + port->minor);
			if (!err){
				port_broadcast_state(port, PORT_STATE_ENABLE);
				spin_lock(&port->port_update_lock);
				port->chn_crt_stat = CCCI_CHAN_ENABLE;
				spin_unlock(&port->port_update_lock);
			}
		} else {
			MTK_DEBUG_LOG(CHAR, "port %s is removed\n",port->name);
			port->flags |= PORT_F_ALLOW_DROP;
			ccci_unregister_dev_node(port->major, port->minor_base + port->minor);
			spin_lock(&port->port_update_lock);
			port->chn_crt_stat = CCCI_CHAN_DISABLE;
			spin_unlock(&port->port_update_lock);
			port_broadcast_state(port, PORT_STATE_DISABLE);
		}
	}
	return err;
}

static int port_char_enable_chl(struct port_t *port)
{
	int err = 0;
	spin_lock(&port->port_update_lock);
	port->chan_enable = CCCI_CHAN_ENABLE;
	spin_unlock(&port->port_update_lock);
	if(port->chn_crt_stat != port->chan_enable) {
		err = port_status_update(port);
	}
	return err;
}
static int	port_char_disable_chl(struct port_t *port)
{
	spin_lock(&port->port_update_lock);
	port->chan_enable = CCCI_CHAN_DISABLE;
	spin_unlock(&port->port_update_lock);
	if(port->chn_crt_stat != port->chan_enable) {
		port_status_update(port);
	}
	return 0;
}

void port_char_md_state_notify(struct port_t *port, unsigned int state)
{
	if (state == READY)
		port_status_update(port);
}

struct port_ops char_port_ops = {
	.init = &port_char_init,
	.recv_skb = &port_char_recv_skb,
	.dump_info = &port_char_dump_info,
	.uninit = &port_char_uninit,
	.enable_chl = &port_char_enable_chl,
	.disable_chl = &port_char_disable_chl,
	.md_state_notify = &port_char_md_state_notify,
};

