// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_config.h"
#include "ccci_hif.h"
#include "port_cfg.h"
#include "ccci_port.h"


#define EXP_CTRL_Q		6
#define DATA_TX_Q		0
#define DATA_RX_Q		0
#define DATA_TX_ACK_Q		1
#define DATA1_TX_Q		0
#define DATA1_RX_Q		0
#define DATA2_Q			2
#define DATA2_RX_Q		0
#define DATA_MDT_Q		0
#define DATA_C2K_PPP_Q	3
#define DATA_FSD_Q		4
#define DATA_AT_CMD_Q	5

#define SMEM_Q			AP_MD_CCB_WAKEUP

static struct port_t md1_ccci_ports[] = {
#if defined(M7X) && defined(CONFIG_MTK_NET_CCMNI)
/* network port first for performace */
	{CCCI_CCMNI1_TX, CCCI_CCMNI1_RX, DATA_TX_Q, DATA_RX_Q, 0xF0 | DATA_TX_ACK_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 0, "ccmni0",},
	{CCCI_CCMNI2_TX, CCCI_CCMNI2_RX, DATA1_TX_Q, DATA1_RX_Q, 0xF0 | DATA_TX_ACK_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 1, "ccmni1",},
	{CCCI_CCMNI3_TX, CCCI_CCMNI3_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 2, "ccmni2",},
	{CCCI_CCMNI4_TX, CCCI_CCMNI4_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 3, "ccmni3",},
	{CCCI_CCMNI5_TX, CCCI_CCMNI5_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 4, "ccmni4",},
	{CCCI_CCMNI6_TX, CCCI_CCMNI6_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 5, "ccmni5",},
	{CCCI_CCMNI7_TX, CCCI_CCMNI7_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 6, "ccmni6",},
	{CCCI_CCMNI8_TX, CCCI_CCMNI8_RX, DATA_TX_Q, DATA_RX_Q, 0xF0 | DATA_TX_ACK_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 7, "ccmni7",},
    {CCCI_CCMNI9_TX, CCCI_CCMNI9_RX, DATA_TX_Q, DATA_RX_Q, 0xF0 | DATA_TX_ACK_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 8, "ccmni8",},
	{CCCI_CCMNI10_TX, CCCI_CCMNI10_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 9, "ccmni9",},
	{CCCI_CCMNI11_TX, CCCI_CCMNI11_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 10, "ccmni10",},
	{CCCI_CCMNI12_TX, CCCI_CCMNI12_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 11, "ccmni11",},
	{CCCI_CCMNI13_TX, CCCI_CCMNI13_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 12, "ccmni12",},
	{CCCI_CCMNI14_TX, CCCI_CCMNI14_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 13, "ccmni13",},
	{CCCI_CCMNI15_TX, CCCI_CCMNI15_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 14, "ccmni14",},
	{CCCI_CCMNI16_TX, CCCI_CCMNI16_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 15, "ccmni15",},
	{CCCI_CCMNI17_TX, CCCI_CCMNI17_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 16, "ccmni16",},
	{CCCI_CCMNI18_TX, CCCI_CCMNI18_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 17, "ccmni17",},
	{CCCI_CCMNI19_TX, CCCI_CCMNI19_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 18, "ccmni18",},
	{CCCI_CCMNI20_TX, CCCI_CCMNI20_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 19, "ccmni19",},
	{CCCI_CCMNI21_TX, CCCI_CCMNI21_RX, DATA2_Q, DATA2_RX_Q, 0xF0 | DATA2_Q, 0xFF, HIF_PATH_DATA, 0,
		&net_port_ops, 20, "ccmni20",},
#endif
	/* char port, notes ccci_monitor must be first for get_port_by_minor() implement */
	{CCCI_UART2_TX, CCCI_UART2_RX, DATA_AT_CMD_Q, DATA_AT_CMD_Q, 0xFF, 0xFF, HIF_PATH_CTRL,
		PORT_F_WITH_CHAR_NODE, &tty_port_ops, 0, "ttyC0",},
	{CCCI_MD_LOG_TX, CCCI_MD_LOG_RX, 7, 7, 7, 7, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 2, "ttyCMdLog",},
	{CCCI_LB_IT_TX, CCCI_LB_IT_RX, 0, 0, 0xFF, 0xFF, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 3, "ccci_lb_it",},
	{CCCI_MIPC_TX, CCCI_MIPC_RX, 2, 2, 0, 0, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&tty_port_ops, 1, "ttyCMIPC0",},
	{CCCI_sAP_LBIT_TX, CCCI_sAP_LBIT_RX, 0, 0, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 5, "ccci_sap_lb_it",},
	{CCCI_sAP_GNSS_TX, CCCI_sAP_GNSS_RX, 0, 0, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 6, "ccci_sap_gnss",},
    {CCCI_sAP_META_TX, CCCI_sAP_META_RX, 1, 1, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 7, "ccci_sap_meta",},
	{CCCI_sAP_LOG_TX, CCCI_sAP_LOG_RX, 2, 2, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 8, "ccci_sap_log",},
    {CCCI_sAP_ADB_TX, CCCI_sAP_ADB_RX, 3, 3, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 9, "ccci_sap_adb",},
	{CCCI_MBIM_TX, CCCI_MBIM_RX, 2, 2, 0, 0, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 10, "ttyCMBIM0",},
	{CCCI_UART1_TX, CCCI_UART1_RX, 1, 1, 1, 1, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 11, "ttyCMdMeta",},
	{CCCI_sAP_MINIDUMP_NOTIFY_TX, CCCI_sAP_MINIDUMP_NOTIFY_RX, 5, 5, 0XFF, 0XFF, HIF_PATH_CTRL_1, 0,
		&char_port_ops, 12, DEVICE_MINIDUMP_NOTIFY_PORT_NAME,},
	{CCCI_DSS0_TX, CCCI_DSS0_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 13, "ttyCMBIMDSS0",},
	{CCCI_DSS1_TX, CCCI_DSS1_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 14, "ttyCMBIMDSS1",},
	{CCCI_DSS2_TX, CCCI_DSS2_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 15, "ttyCMBIMDSS2",},
	{CCCI_DSS3_TX, CCCI_DSS3_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 16, "ttyCMBIMDSS3",},
	{CCCI_DSS4_TX, CCCI_DSS4_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 17, "ttyCMBIMDSS4",},
	{CCCI_DSS5_TX, CCCI_DSS5_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 18, "ttyCMBIMDSS5",},
	{CCCI_DSS6_TX, CCCI_DSS6_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 19, "ttyCMBIMDSS6",},
	{CCCI_DSS7_TX, CCCI_DSS7_RX, 3, 3, 3, 3, HIF_PATH_CTRL, PORT_F_WITH_CHAR_NODE,
		&char_port_ops, 20, "ttyCMBIMDSS7",},

/* sys port */
	{CCCI_SYSTEM_TX, CCCI_SYSTEM_RX, 0, 0, 0xFF, 0xFF, HIF_PATH_CTRL, 0,
		&sys_port_ops, 0xFF, "ccci_sys",},
	{CCCI_CONTROL_TX, CCCI_CONTROL_RX, 0, 0, 0, 0, HIF_PATH_CTRL, 0,
		&ctl_port_ops, 0xFF, "ccci_ctrl",},
	{CCCI_STATUS_TX, CCCI_STATUS_RX, 0, 0, 0, 0, HIF_PATH_CTRL, 0,
		&poller_port_ops, 0xFF, "ccci_poll",},
	{CCCI_SAP_CONTROL_TX, CCCI_SAP_CONTROL_RX, 0, 0, 0, 0, HIF_PATH_CTRL_1, 0,
		&ctl_port_ops, 0xFF, "ccci_sap_ctrl",},
};

static struct port_t md1_ccci_early_ports[] = {
    {0xFFFF, 0xFFFF, 0, 0, 0, 0, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE|PORT_F_RAW_DATA,
		&char_port_ops, 1, "brom_download",},
    {0xFFFF, 0xFFFF, 1, 1, 1, 1, HIF_PATH_CTRL_1, PORT_F_WITH_CHAR_NODE|PORT_F_RAW_DATA,
		&char_port_ops, 0, DEVICE_POST_DUMP_PORT_NAME,},/*Dump Port for Exception Flow*/
};

int port_get_cfg(int md_id, struct port_t **ports,
	PORT_CFG_ENUM port_cfg_id)
{
	int port_number = 0;

	switch (md_id) {
	case MD_SYS1:
		switch (port_cfg_id) {
		case PORT_CFG0:
			*ports = md1_ccci_ports;
			port_number = ARRAY_SIZE(md1_ccci_ports);
			break;
		case PORT_CFG1:
			*ports = md1_ccci_early_ports;
			port_number = ARRAY_SIZE(md1_ccci_early_ports);
			break;
		default:
			*ports = md1_ccci_ports;
			port_number = ARRAY_SIZE(md1_ccci_ports);
			MTK_NOTICE_LOG(PORT,
				"md_port_cfg:Port Config id is error\n");
			break;
		}
		break;
	default:
		*ports = NULL;
		port_number = 0;
		MTK_ERR_LOG(PORT, "md_port_cfg:no md enable\n");
		break;
	}
	return port_number;
}
