// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/poll.h>
#ifdef CONFIG_COMPAT
#include <linux/compat.h>
#endif
#include "ccci_config.h"
#include "ccci_bm.h"
#include "port_proxy.h"
#include "ccci_fsm.h"
#include <mt-plat/mtk_ccci_common.h>
#include "port_tty.h"


#define GET_TTY_IDX(p) ((p)->minor - CCCI_TTY_MINOR_BASE)

static struct port_t *find_tty_port_by_tty_idx(int md_id, int tty_idx)
{
	return port_get_by_minor(md_id, tty_idx + CCCI_TTY_MINOR_BASE);
}

static int ccci_tty_send_pkt(int md_id,
	int tty_port_idx, const void *data, int len)
{
	struct port_t *port = NULL;
	struct ccci_header *ccci_h = NULL;
	struct sk_buff *skb = NULL;
	int actual_count = 0, alloc_size = 0;
	int ret = 0, header_len = 0;
	int blocking = 1;
	unsigned char from_skb_pool = 1;
	size_t txq_mtu = 0;

	/*find ccci port*/
	port = find_tty_port_by_tty_idx(md_id, tty_port_idx);
	if (!port) {
		MTK_ERR_LOG(TTY, "ccci port is NULL, idx=%d\n", tty_port_idx);
		ret = -1;
		goto err;
	}
	if (port->flags & PORT_F_RAW_DATA) {
		txq_mtu = ccci_hif_get_queue_mtu(port->md_id,
			port->path_id, port->txq_index);
		actual_count = len > txq_mtu ? txq_mtu : len;
		alloc_size = actual_count;
	} else {
		/*get skb info*/
		header_len = sizeof(struct ccci_header);
		actual_count = len > CCCI_MTU ? CCCI_MTU : len;
		alloc_size = actual_count + header_len;
	}

	skb = ccci_alloc_skb(alloc_size, from_skb_pool, blocking);
	if (skb) {
		if (!(port->flags & PORT_F_RAW_DATA)) {
			ccci_h = (struct ccci_header *)skb_put(skb,
				sizeof(struct ccci_header));
			ccci_h->data[0] = 0;
			ccci_h->data[1] = actual_count + header_len;
			ccci_h->channel = port->tx_ch;
			ccci_h->reserved = 0;
		}
	} else {
		MTK_ERR_LOG(TTY, "allock skb from pool failed.\n");
		ret = -2;
	goto err;
	}

	/*filling the skb data*/
	memcpy(skb_put(skb, actual_count), data, actual_count);

	/*send data*/
	port_inc_tx_seq_num(port, ccci_h);
	ret = port_send_skb_to_md(port, skb, blocking);
	if (ret) {
		MTK_ERR_LOG(TTY, "faild to send skb to md, ret = %d\n", ret);
		goto err;
	} else {
		/*record the port seq_num after the data is sent to HIF*/
		port->seq_nums[MTK_OUT]++;
	}
	return actual_count;

err:
	return ret;
}

/*for ccci tty driver callback*/
struct tty_ccci_ops eccci_tty1_ops = {
	.tty_num = TTY_PORT_NR,
	.name = CCCI_TTY_PORT_NAME_BASE,
	.md_ability = 0,
	.send_pkt = ccci_tty_send_pkt,
};

static int port_tty_init(struct port_t *port)
{
	int md_id = port->md_id;

	/*mapping the minor number to tty dev idx*/
	port->minor += CCCI_TTY_MINOR_BASE;

	/*init the tty driver*/
	if (tty_ops.tty_driver_status == false) {
		tty_ops.tty_driver_status = true;
		atomic_set(&tty_ops.port_installed_num, 0);
		tty_ops.init(md_id, &eccci_tty1_ops, port);
	}


	return 0;
}

static int port_tty_recv_skb(struct port_t *port, struct sk_buff *skb)
{
	int ret = 0;
	int actual_recv_len = 0;

	/*get skb data*/
		if (!(port->flags & PORT_F_RAW_DATA))
			skb_pull(skb, sizeof(struct ccci_header));
	/*send data to tty driver.  fix me*/
	actual_recv_len = tty_ops.rx_callback(port->md_id,
		GET_TTY_IDX(port), skb->data, skb->len);
	if (actual_recv_len != skb->len) {
		MTK_ERR_LOG(TTY, "ccci port[%s] recv skb fail.\n", port->name);
		skb_push(skb, sizeof(struct ccci_header));
		ret = -CCCI_ERR_PORT_RX_FULL;
		goto err;
	}

	/*free skb*/
	ccci_free_skb(skb);

err:
	return ret;
}

static void port_tty_queue_state_notify(struct port_t *port,
	int dir, int qno, unsigned int state)
{

}

static void port_tty_md_state_notify(struct port_t *port, unsigned int state)
{
	if (state == READY ) {
		if (port->chan_enable == CCCI_CHAN_ENABLE) {
			MTK_DEBUG_LOG(TTY, "%s is created.\n", port->name);
			port->flags &= ~PORT_F_ALLOW_DROP;
			/*creat a tty port*/
			tty_ops.tty_port_create(port->md_id,
				GET_TTY_IDX(port),
				port->name);
			atomic_inc(&tty_ops.port_installed_num);
			spin_lock(&port->port_update_lock);
			port->chn_crt_stat = CCCI_CHAN_ENABLE;
			spin_unlock(&port->port_update_lock);
		} else {
			MTK_DEBUG_LOG(TTY, "Dummy Function.\n");
		}
	}
}

static void port_tty_md_dump_info(struct port_t *port, unsigned int flag)
{

}

static void port_tty_uninit(struct port_t *port)
{
	int md_id = port->md_id;

	port->minor -= CCCI_TTY_MINOR_BASE;

	if (port->chn_crt_stat != CCCI_CHAN_ENABLE)
		return;

	/*destroy tty port*/
	tty_ops.tty_port_destroy(md_id,  port->minor);
	spin_lock(&port->port_update_lock);
	port->chn_crt_stat = CCCI_CHAN_DISABLE;
	spin_unlock(&port->port_update_lock);

	/*ccci tty driver exit*/
	if (atomic_dec_and_test(&tty_ops.port_installed_num)) {
		if (tty_ops.exit) {
			tty_ops.exit(md_id);
			tty_ops.tty_driver_status = false;
		}
	}
}

static int  port_tty_enable_chl(struct port_t *port)
{
	spin_lock(&port->port_update_lock);
	port->chan_enable = CCCI_CHAN_ENABLE;
	spin_unlock(&port->port_update_lock);
    if (port->chn_crt_stat != port->chan_enable) {
        port->flags &= ~PORT_F_ALLOW_DROP;
        /*creat a tty port*/
        tty_ops.tty_port_create(port->md_id,
            GET_TTY_IDX(port),
            port->name);
		spin_lock(&port->port_update_lock);
		port->chn_crt_stat = CCCI_CHAN_ENABLE;
		spin_unlock(&port->port_update_lock);
        atomic_inc(&tty_ops.port_installed_num);
    }

	return 0;
}

static int port_tty_disable_chl(struct port_t *port)
{
	spin_lock(&port->port_update_lock);
	port->chan_enable = CCCI_CHAN_DISABLE;
	spin_unlock(&port->port_update_lock);

	MTK_DEBUG_LOG(TTY, "Dummy Function.\n");
	return 0;
}


struct port_ops tty_port_ops = {
	.init = &port_tty_init,
	.recv_skb = &port_tty_recv_skb,
	.queue_state_notify = &port_tty_queue_state_notify,
	.md_state_notify = &port_tty_md_state_notify,
	.dump_info = &port_tty_md_dump_info,
	.uninit = &port_tty_uninit,
	.enable_chl = &port_tty_enable_chl,
	.disable_chl = &port_tty_disable_chl,
};


