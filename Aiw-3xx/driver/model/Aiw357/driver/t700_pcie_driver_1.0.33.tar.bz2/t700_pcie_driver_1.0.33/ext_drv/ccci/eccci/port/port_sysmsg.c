// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/device.h>
#include <linux/wait.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/kernel.h>
#include <linux/power_supply.h>

#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_bm.h"
#include "port_sysmsg.h"
#define MAX_QUEUE_LENGTH 16

#ifndef TEST_MESSAGE_FOR_BRINGUP
#define TEST_MESSAGE_FOR_BRINGUP
#endif

#ifdef TEST_MESSAGE_FOR_BRINGUP
static inline int port_sys_notify_md(struct port_t *port, unsigned int msg,
	unsigned int data)
{
	return port_send_msg_to_md(port, msg, data, 1);
}

static inline int port_sys_echo_test(struct port_t *port, int data)
{
	MTK_DEBUG_LOG(SYS,
		"system message: Enter ccci_sysmsg_echo_test data = %08x",
		data);
	port_sys_notify_md(port, TEST_MSG_ID_AP2MD, data);
	return 0;
}

static inline int port_sys_echo_test_l1core(struct port_t *port, int data)
{
	MTK_DEBUG_LOG(SYS,
		"system message: Enter ccci_sysmsg_echo_test_l1core data= %08x",
		data);
	port_sys_notify_md(port, TEST_MSG_ID_L1CORE_AP2MD, data);
	return 0;
}
#endif
/* for backward compatibility */
struct ccci_sys_cb_func_info ccci_sys_cb_table_100[MAX_MD_NUM][MAX_KERN_API];
struct ccci_sys_cb_func_info ccci_sys_cb_table_1000[MAX_MD_NUM][MAX_KERN_API];
int register_ccci_sys_call_back(int md_id, unsigned int id,
	ccci_sys_cb_func_t func)
{
	int ret = 0;
	struct ccci_sys_cb_func_info *info_ptr;

	if (md_id >= MAX_MD_NUM) {
		MTK_ERR_LOG(SYS,
			"register_sys_call_back fail: invalid md id\n");
		return -EINVAL;
	}

	if ((id >= 0x100) && ((id - 0x100) < MAX_KERN_API)) {
		info_ptr = &(ccci_sys_cb_table_100[md_id][id - 0x100]);
	} else if ((id >= 0x1000) && ((id - 0x1000) < MAX_KERN_API)) {
		info_ptr = &(ccci_sys_cb_table_1000[md_id][id - 0x1000]);
	} else {
		MTK_ERR_LOG(SYS,
			"register_sys_call_back fail: invalid func id(0x%x)\n",
			id);
		return -EINVAL;
	}

	if (info_ptr->func == NULL) {
		info_ptr->id = id;
		info_ptr->func = func;
	} else {
		MTK_ERR_LOG(SYS,
			"register_sys_call_back fail: func(0x%x) registered! %ps\n",
			id, info_ptr->func);
	}

	return ret;
}

void exec_ccci_sys_call_back(int md_id, int cb_id, int data)
{
	ccci_sys_cb_func_t func;
	int id;
	struct ccci_sys_cb_func_info *curr_table;

	if (md_id >= MAX_MD_NUM) {
		MTK_ERR_LOG(SYS, "exec_sys_cb fail: invalid md id\n");
		return;
	}

	id = cb_id & 0xFF;
	if (id >= MAX_KERN_API) {
		MTK_ERR_LOG(SYS,
			"exec_sys_cb fail: invalid func id(0x%x)\n", cb_id);
		return;
	}

	if ((cb_id & (0x1000 | 0x100)) == 0x1000) {
		curr_table = ccci_sys_cb_table_1000[md_id];
	} else if ((cb_id & (0x1000 | 0x100)) == 0x100) {
		curr_table = ccci_sys_cb_table_100[md_id];
	} else {
		MTK_ERR_LOG(SYS,
			"exec_sys_cb fail: invalid func id(0x%x)\n", cb_id);
		return;
	}

	func = curr_table[id].func;
	if (func != NULL)
		func(md_id, data);
	else
		MTK_ERR_LOG(SYS,
		"exec_sys_cb fail: func id(0x%x) not register!\n", cb_id);
}

int __weak pmic_get_battery_voltage(void)
{
	pr_debug("not supported!\n");
	return 0;
}
static int sys_msg_send_battery(struct port_t *port)
{
	int vbat = 0;

	vbat = pmic_get_battery_voltage();

	MTK_INFO_LOG(SYS, "get bat voltage %d\n", vbat);
	port_send_msg_to_md(port, MD_GET_BATTERY_INFO, vbat, 1);
	return 0;
}

static void sys_msg_handler(struct port_t *port, struct sk_buff *skb)
{
	struct ccci_header *ccci_h = (struct ccci_header *)skb->data;
	int md_id = port->md_id;

	MTK_INFO_LOG(SYS, "system message (%x %x %x %x)\n", ccci_h->data[0],
		ccci_h->data[1], ccci_h->channel, ccci_h->reserved);
#ifdef PORT_EVENT
	trace_sys_msg_handler(skb, ccci_h);
#endif /* PORT_EVENT */
	switch (ccci_h->data[1]) {
	case MD_WDT_MONITOR:
		/* abandoned */
		break;
#ifdef TEST_MESSAGE_FOR_BRINGUP
	case TEST_MSG_ID_MD2AP:
		port_sys_echo_test(port, ccci_h->reserved);
		break;
	case TEST_MSG_ID_L1CORE_MD2AP:
		port_sys_echo_test_l1core(port, ccci_h->reserved);
		break;
#endif

	case MD_SIM_TYPE:
		/* Fall through */
	case MD_TX_POWER:
		/* Fall through */
	case MD_RF_TEMPERATURE:
		/* Fall through */
	case MD_RF_TEMPERATURE_3G:
		/* Fall through */
	case SYSMSGSV_MD_THERM_NOTIFY:
		exec_ccci_sys_call_back(md_id, SYSMSGSV_MD_THERM_NOTIFY,
			ccci_h->reserved);
		break;
	case LWA_CONTROL_MSG:
		exec_ccci_sys_call_back(md_id, ccci_h->data[1],
			ccci_h->reserved);
		break;
	case SYSMSGSV_MD_BC_CDP_NOTIFY:
		exec_ccci_sys_call_back(md_id,
			SYSMSGSV_MD_BC_CDP_NOTIFY, ccci_h->reserved);
		break;
	case MD_GET_BATTERY_INFO:
		sys_msg_send_battery(port);
		break;
	};
	ccci_free_skb(skb);
}

static int port_sys_init(struct port_t *port)
{
	MTK_DEBUG_LOG(SYS, "kernel port %s is initializing\n", port->name);
	port->skb_handler = &sys_msg_handler;
	port->private_data = kthread_run(port_kthread_handler, port, "%s",
		port->name);
	port->rx_length_th = MAX_QUEUE_LENGTH;
	port->skb_from_pool = 1;
	port->thread = port->private_data;
	return 0;
}

static void port_sys_uninit(struct port_t *port)
{
	unsigned long flags;
	struct sk_buff *skb = NULL;

	if (port->thread)
		kthread_stop(port->thread);

	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
	while ((skb = __skb_dequeue(&port->rx_skb_list)) != NULL)
		ccci_free_skb(skb);

	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
}

struct port_ops sys_port_ops = {
	.init = &port_sys_init,
	.recv_skb = &port_recv_skb,
	.uninit = &port_sys_uninit,
};
