// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


//#include <sync_write.h>
#include <mtk_ccci_common.h>
#include <linux/slab.h>
#include <linux/kobject.h>
#include "ccci_util_log.h"
#include "ccci_util_lib_sys.h"
#include "ccci_util_lib_main.h"

#ifdef DATA_PATH_TP_CALC
#ifdef M7X
#include "ccci_hif_dpmaif_ut.h"
#else
#include "ccci_hif_dpmaif_ut_m80.h"
#endif
extern struct ccci_dp_tput_configure g_tput_config;
#endif


#if defined(CONFIG_XS_MOD) && defined(__arm64__)
extern unsigned int t700_index;
#else
#define CCCI_KOBJ_NAME "ccci"
#endif

static struct ccci_info *ccci_sys_info;

/*
 * for data path throughput statistics
 */
#ifdef DATA_PATH_TP_CALC
unsigned int ccci_dp_dl_tp_calc;
EXPORT_SYMBOL(ccci_dp_dl_tp_calc);
#endif

struct ccci_info {
	struct kobject kobj;
	unsigned int ccci_attr_count;
};

struct ccci_attribute {
	struct attribute attr;
	ssize_t (*show)(char *buf);
	ssize_t (*store)(const char *buf, size_t count);
};

#define CCCI_ATTR(_name, _mode, _show, _store)			\
static struct ccci_attribute ccci_attr_##_name = {		\
	.attr = {.name = __stringify(_name), .mode = _mode },	\
	.show = _show,						\
	.store = _store,					\
}

static void ccci_obj_release(struct kobject *kobj)
{
	struct ccci_info *ccci_info_temp =
		container_of(kobj, struct ccci_info, kobj);

	kfree(ccci_info_temp);
	ccci_sys_info = NULL;	/* as ccci_info_temp==ccci_sys_info */
}

static ssize_t ccci_attr_show(struct kobject *kobj,
	struct attribute *attr, char *buf)
{
	ssize_t len = 0;
	struct ccci_attribute *a =
		container_of(attr, struct ccci_attribute, attr);

	if (a->show)
		len = a->show(buf);

	return len;
}

static ssize_t ccci_attr_store(struct kobject *kobj,
	struct attribute *attr, const char *buf, size_t count)
{
	ssize_t len = 0;
	struct ccci_attribute *a =
		container_of(attr, struct ccci_attribute, attr);

	if (a->store)
		len = a->store(buf, count);

	return len;
}

static const struct sysfs_ops ccci_sysfs_ops = {
	.show = ccci_attr_show,
	.store = ccci_attr_store
};

/*======================================= */
/* CCCI common sys attribute part */
/*======================================= */
/* Sys -- boot status */
static get_status_func_t get_status_func[MAX_MD_NUM];
static boot_md_func_t boot_md_func[MAX_MD_NUM];

/* Sys -- enable status */
static ssize_t ccci_md_enable_show(char *buf)
{
	int i;
	char md_en[MAX_MD_NUM+1] = {0};

	for (i = 0; i < MAX_MD_NUM; i++) {
		if (get_modem_is_enabled(MD_SYS1 + i))
			md_en[i] = 'E';
		else
			md_en[i] = 'D';
	}

	/* Final string */
	return snprintf(buf, 32, "(MD0->MD%d)%s\n", MAX_MD_NUM-1, md_en);
}

static ssize_t ccci_md_enable_store(const char *buf, size_t count)
{
	return count;
}

CCCI_ATTR(md_en, 0660, &ccci_md_enable_show, &ccci_md_enable_store);

/* Sys -- dump buff usage */
static ssize_t ccci_dump_buff_usage_show(char *buf)
{
	return get_dump_buf_usage(buf, 4095);
}

static ssize_t ccci_dump_buff_usage_store(const char *buf, size_t count)
{
	return count;
}


CCCI_ATTR(dump_max, 0660,
	&ccci_dump_buff_usage_show, &ccci_dump_buff_usage_store);

/* Sys -- Versin */
/* Version is checked by user application */
static unsigned int ccci_port_ver = 6;
static ssize_t ccci_version_show(char *buf)
{
	return snprintf(buf, 16, "%d\n", ccci_port_ver);
}

static ssize_t ccci_version_store(const char *buf, size_t count)
{
	return count;
}

CCCI_ATTR(version, 0644, &ccci_version_show, &ccci_version_store);


#ifdef DATA_PATH_TP_CALC
/* Data path DL throughput statistics switch - begin */
static ssize_t data_hw_tput_config_show(char *buf)
{
	int curr = 0;
	curr = snprintf(buf, 256, "md_tput_mode:0x%x, md_start_dl_tput:%d, md_pkt_number_per_ms:%d, md_dl_tput_test_time:%d \n",
		g_tput_config.md_tput_mode, g_tput_config.md_start_dl_tput,
		g_tput_config.md_pkt_number_per_ms, g_tput_config.md_dl_tput_test_time);
	return curr;
}

static ssize_t data_hw_tput_config_store(const char *buf, size_t count)
{
	unsigned int user_setting;
	int ret = 0;

	ret = kstrtou32(buf, 16, &user_setting);
	if (ret) {
		pr_notice("Input string err! Please check input string format.");
		goto err;
	} else {
		pr_notice("Input string: 0x%x\n", user_setting);
	}

	/* tput mode */
	if (user_setting & T_DPMAIF_MD_TPUT_MODE_SET_MASK)
		g_tput_config.md_tput_mode = (user_setting >> T_DPMAIF_MD_TPUT_MODE_OFFSET) &
			T_DPMAIF_MD_TPUT_MODE_MASK;

	/* start/stop dl test */
	if (user_setting & T_DPMAIF_MD_TPUT_CTL_SET_MASK)
		g_tput_config.md_start_dl_tput= (user_setting >> T_DPMAIF_MD_DL_CTL_OFFSET) &
			T_DPMAIF_MD_DL_CTL_MASK;

	/* pkt_count/ms */
	if (user_setting & T_DPMAIF_MD_TPUT_PKT_SET_MASK)
		g_tput_config.md_pkt_number_per_ms = (user_setting >> T_DPMAIF_MD_PKT_OFFSET) &
			T_DPMAIF_MD_PKT_MASK;

	/* dl test time */
	if (user_setting & T_DPMAIF_MD_TPUT_TIME_SET_MASK)
		g_tput_config.md_dl_tput_test_time = (user_setting >> T_DPMAIF_MD_DL_TIME_OFFSET) &
			T_DPMAIF_MD_DL_TIME_MASK;

	pr_notice("md_tput_mode:%x, md_start_dl_tput:%d, md_pkt_number_per_ms:%d, md_dl_tput_test_time:%d \n",
		g_tput_config.md_tput_mode, g_tput_config.md_start_dl_tput,
		g_tput_config.md_pkt_number_per_ms, g_tput_config.md_dl_tput_test_time);

err:
	return count;
}

CCCI_ATTR(data_hw_tput_config, 0660, &data_hw_tput_config_show, &data_hw_tput_config_store);

/* Data path DL throughput statistics switch */
static ssize_t data_hw_tput_stats_show(char *buf)
{
	int curr = 0;
	curr = snprintf(buf, 16, "ul:%d, dl:%d\n",
		 g_tput_config.ul_tput_monitor_enable, g_tput_config.dl_tput_monitor_enable);
	return curr;
}

static ssize_t data_hw_tput_stats_store(const char *buf, size_t count)
{
	int ret = 0;
	unsigned int user_setting;

	ret = kstrtou32(buf, 16, &user_setting);
	if (ret) {
		pr_notice("Input string err! Please check input string format.");
		goto err;
	} else {
		pr_notice("Input string: 0x%x\n", user_setting);
	}

	g_tput_config.ul_tput_monitor_enable = (user_setting >> T_DPMAIF_UL_MONITOR_OFFSET) &
		T_DPMAIF_UL_MONITOR_MASK;
	g_tput_config.dl_tput_monitor_enable = (user_setting >> T_DPMAIF_DL_MONITOR_OFFSET) &
		T_DPMAIF_DL_MONITOR_MASK;


	pr_notice("ul:%d, dl:%d\n",
		 g_tput_config.ul_tput_monitor_enable, g_tput_config.dl_tput_monitor_enable);
err:
	return count;
}

CCCI_ATTR(data_hw_tput_stats, 0660, &data_hw_tput_stats_show, &data_hw_tput_stats_store);


extern unsigned int dpmaif_bat_burst_release_cnt;
extern unsigned int dpmaif_pit_burst_release_cnt;

static int bat_burst_release_test(int argc, char **argv)
{
	unsigned int tmp_val = 0;

	if (argc > 1) {
		kstrtou32(argv[1], 10, &tmp_val);
		dpmaif_bat_burst_release_cnt = tmp_val;
	}

	pr_notice("bat_burst_release_cnt:%d\n", dpmaif_bat_burst_release_cnt);
	return 0;
}

static int pit_burst_release_test(int argc, char **argv)
{
	unsigned int tmp_val = 0;

	if (argc > 1) {
		kstrtou32(argv[1], 10, &tmp_val);
		dpmaif_pit_burst_release_cnt = tmp_val;
	}

	pr_notice("pit_burst_release_cnt:%d\n", dpmaif_pit_burst_release_cnt);
	return 0;

}


#endif


#define MAX_ARG_CNT 10


struct CMD_TBL_T {
	char name[256];
	int (*cb_func)(int argc, char **argv);
};

struct CMD_TBL_T CcciarPCmdTbl[] = {
	{"ccci.port_enum", &port_enumeration_test},
	{"ccci.jp_bl_cmd", &brom_jp_bl_cmd_test},
	{"ccci.except_flow_test", &exception_flow_test},
	{"ccci.low_p_test", &cldma_low_power_test},	
	{"ccci.fsm_state_test", &fsm_state_test},
#ifdef DATA_PATH_TP_CALC
	{"data_path.bat_burst_cnt", &bat_burst_release_test},
	{"data_path.pit_burst_cnt", &pit_burst_release_test},
#endif
};

int ccci_test_attr_call_function(char *buf)
{
	int i, ret, match;
	int argc;
	char *argv[MAX_ARG_CNT];

	argc = 0;
	do {
		argv[argc] = strsep(&buf, " ");
		pr_notice("[%d] %s\n", argc, argv[argc]);
		argc++;
	} while (buf);

	match = 0;
	for (i = 0; i < sizeof(CcciarPCmdTbl)/sizeof(struct CMD_TBL_T); i++) {
		if ((!strcmp(CcciarPCmdTbl[i].name, argv[0])) &&
			(CcciarPCmdTbl[i].cb_func != NULL)) {
			ret = CcciarPCmdTbl[i].cb_func(argc, argv);
			for (i = 0; i < argc; i++)
				pr_notice("[%d] %s\n", i, argv[i]);
			pr_notice("RESULT: %s\n", (!ret ? "PASS" : "FAIL"));

			return ret;
		}
	}

	return -1;
}

static ssize_t ccci_test_show(char *buf)
{
	int i;
	unsigned int ptr;

	ptr = 0;
	for (i = 0; i < sizeof(CcciarPCmdTbl)/sizeof(struct CMD_TBL_T); i++) {
		sprintf(buf + ptr, "%s\n", CcciarPCmdTbl[i].name);
		ptr = ptr + strlen(CcciarPCmdTbl[i].name) + 1;
	}

	return ptr;

}

static ssize_t ccci_test_store(const char *buf, size_t n)
{
	int retval;
	char *ch;

	pr_notice("ccci_test is operated\n");
	ch = kmalloc(n, GFP_KERNEL);
	memcpy(ch, buf, n);
	if (ch[n-1] == '\n')
		ch[n-1] = '\0';

	retval = ccci_test_attr_call_function(ch);

	if (retval < 0) {
		pr_notice("pcie cli fail\n");
		kfree(ch);
		return -1;
	}

	kfree(ch);
	pr_notice("%s", buf);

	return n;
}

CCCI_ATTR(ccci_test, 0664, &ccci_test_show, &ccci_test_store);


/* Sys -- Add to group */
static struct attribute *ccci_default_attrs[] = {
	&ccci_attr_version.attr,
	&ccci_attr_md_en.attr,
	&ccci_attr_dump_max.attr,
#ifdef DATA_PATH_TP_CALC
	&ccci_attr_data_hw_tput_stats.attr,
	&ccci_attr_data_hw_tput_config.attr,
#endif
	&ccci_attr_ccci_test.attr,
	NULL
};

static struct kobj_type ccci_ktype = {
	.release = ccci_obj_release,
	.sysfs_ops = &ccci_sysfs_ops,
	.default_attrs = ccci_default_attrs
};

int ccci_sysfs_add_modem(int md_id, void *kobj, void *ktype,
	get_status_func_t get_sta_func, boot_md_func_t boot_func)
{
	int ret;
	static int md_add_flag;

	md_add_flag = 0;
	if (!ccci_sys_info) {
		CCCI_UTIL_ERR_MSG("common sys not ready\n");
		return -CCCI_ERR_SYSFS_NOT_READY;
	}

	if (md_add_flag & (1 << md_id)) {
		CCCI_UTIL_ERR_MSG("md%d sys dup add\n", md_id + 1);
		return -CCCI_ERR_SYSFS_NOT_READY;
	}

	ret = kobject_init_and_add((struct kobject *)kobj,
		(struct kobj_type *)ktype,
		&ccci_sys_info->kobj, "mdsys%d", md_id + 1);
	if (ret < 0) {
		kobject_put(kobj);
		CCCI_UTIL_ERR_MSG_WITH_ID(md_id,
			"fail to add md kobject\n");
	} else {
		md_add_flag |= (1 << md_id);
		get_status_func[md_id] = get_sta_func;
		boot_md_func[md_id] = boot_func;
	}

	return ret;
}

int ccci_sysfs_remove_modem(int md_id, void *kobj)
{
	int ret = 0;
	static int md_add_flag;

	md_add_flag = 0;
	if (!ccci_sys_info) {
		CCCI_UTIL_ERR_MSG("common sys not ready\n");
		return -CCCI_ERR_SYSFS_NOT_READY;
	}

	if (md_add_flag & (1 << md_id)) {
		CCCI_UTIL_ERR_MSG("md%d sys dup add\n", md_id + 1);
		return -CCCI_ERR_SYSFS_NOT_READY;
	}
	if (kobj)
		kobject_put(kobj);

	return ret;
}
EXPORT_SYMBOL(ccci_sysfs_remove_modem);

int ccci_common_sysfs_init(void)
{
	int ret = 0;
	int i;

	CCCI_UTIL_DBG_MSG("%s: entry\n", __func__);
	ccci_sys_info = kmalloc(sizeof(struct ccci_info), GFP_KERNEL);
	if (!ccci_sys_info)
		return -ENOMEM;

	memset(ccci_sys_info, 0, sizeof(struct ccci_info));

#if defined(CONFIG_XS_MOD) && defined(__arm64__)
	char new_ccci_sysfs[16];
	memset(new_ccci_sysfs,0,16);
	sprintf(new_ccci_sysfs,"ccci%d",t700_index);
	ret = kobject_init_and_add(&ccci_sys_info->kobj,
		&ccci_ktype, kernel_kobj, new_ccci_sysfs);	
#else
	ret = kobject_init_and_add(&ccci_sys_info->kobj,
		&ccci_ktype, kernel_kobj, CCCI_KOBJ_NAME);
#endif	
	if (ret < 0) {
		kobject_put(&ccci_sys_info->kobj);
		CCCI_UTIL_ERR_MSG("fail to add ccci kobject\n");
		return ret;
	}
	for (i = 0; i < MAX_MD_NUM; i++) {
		get_status_func[i] = NULL;
		boot_md_func[i] = NULL;
	}

	ccci_sys_info->ccci_attr_count = ARRAY_SIZE(ccci_default_attrs) - 1;
	CCCI_UTIL_DBG_MSG("ccci attr cnt %d\n", ccci_sys_info->ccci_attr_count);
	return ret;
}

void ccci_common_sysfs_rel(void)
{
	kobject_put(&ccci_sys_info->kobj);
	if (ccci_sys_info != NULL) {
		kfree(ccci_sys_info);
		ccci_sys_info = NULL;
	}
}
