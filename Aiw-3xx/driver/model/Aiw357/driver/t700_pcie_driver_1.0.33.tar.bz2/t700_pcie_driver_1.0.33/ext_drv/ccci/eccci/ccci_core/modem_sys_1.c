// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/time.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/random.h>

#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/syscore_ops.h>

#include "common.h"
#include "mhccif_reg.h"
#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_bm.h"
#include "ccci_platform.h"
#include "modem_sys.h"
#include "md_sys1_platform.h"
//#include "cldma_reg.h"
#include "modem_reg_base.h"
#include "ccci_debug.h"
#include "ccci_hif.h"

#include "ccci_driver.h"
#include "modem_sys_1.h"
#include "mhccif.h"
#include "ccci_hif_internal.h"
#include "ccci_fsm_internal.h"	 //delete when md_init ready
#include "port_proxy.h"
#include "ccci_driver_cldma.h"
#ifdef CONFIG_MTK_ECCCI_CLDMA
#include "ccci_hif_cldma.h"
#endif
#include "mtk-pci.h"
#include "mtk-pci-ext.h"
#include "ccci_event.h"
#include "ccci_modem.h"
#include "mtk-pci-rescan.h"
#ifndef M7X
#include "ccmni_m80.h"
#endif

//XSQUARE
#include <linux/version.h>


#define TAG "CCCI_SYS1"

extern unsigned short brom_dl_flag;

static void dump_runtime_rawdata(unsigned char *start, int length)
{
	int i;
	u32 *tmp_ptr;

	tmp_ptr = (u32 *)start;
	MTK_DEBUG_LOG(TAG, "dump runtime data start\n");
	for (i = 0; i < (length/32); i++) {
		MTK_DEBUG_LOG(TAG,
			"0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n",
			(u32)*tmp_ptr, (u32)*(tmp_ptr+1), (u32)*(tmp_ptr+2),
			(u32)*(tmp_ptr+3), (u32)*(tmp_ptr+4), (u32)*(tmp_ptr+5),
			(u32)*(tmp_ptr+6), (u32)*(tmp_ptr+7)
		);
		tmp_ptr += 8;
	}
	MTK_DEBUG_LOG(TAG, "dump runtime data end\n");
}

void ex_enable_irq(struct ccci_modem *md)
{
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;

	if (atomic_cmpxchg(&md_info->md_ex_irq_enabled, 0, 1) == 0) {
		enable_irq(md_info->md_ex_irq_id);
		MTK_DEBUG_LOG(TAG, "enable ex irq\n");
	}
}
void ex_disable_irq(struct ccci_modem *md)
{
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;

	if (atomic_cmpxchg(&md_info->md_ex_irq_enabled, 1, 0) == 1) {
		disable_irq_nosync(md_info->md_ex_irq_id);
		MTK_DEBUG_LOG(TAG, "disable ex irq\n");
	}
}

void wdt_enable_irq(struct ccci_modem *md)
{
	if (atomic_cmpxchg(&md->wdt_enabled, 0, 1) == 0) {
		enable_irq(md->md_wdt_irq_id);
		MTK_DEBUG_LOG(TAG, "enable wdt irq\n");
	}
}

void wdt_disable_irq(struct ccci_modem *md)
{
	if (atomic_cmpxchg(&md->wdt_enabled, 1, 0) == 1) {
		/*
		 * may be called in isr, so use disable_irq_nosync.
		 * if use disable_irq in isr, system will hang
		 */
		disable_irq_nosync(md->md_wdt_irq_id);
		MTK_DEBUG_LOG(TAG, "disable wdt irq\n");
	}
}
#ifdef ENABLE_CCCI_DRI_UT
/*simulate hardware interrupt*/
static void tasklet_md_isr(unsigned long data)
{
	struct ccci_modem *md = (struct ccci_modem *)data;
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;
	unsigned int hif_id = GET_HIF_ID(md->index, HIF_PATH_EX);//EX HIF

	md_info->exp_id = ccci_hif_get_event_id(md->index, hif_id);
#ifdef CCCI_CTL_TRACE
	trace_md_ex_isr(md_info->exp_id);
#endif /* CCCI_CTL_TRACE */
	if (md_info->exp_id & (1 << PORT_ENUM_SIGNAL))
		ccci_fsm_recv_md_interrupt(md->index, MD_IRQ_PORT_ENUM);

	if (md_info->exp_id & (1 << EXP_ID_EXCEPTION_INIT))
		ccci_fsm_recv_md_interrupt(md->index, MD_IRQ_CCIF_EX);

	MTK_DEBUG_LOG(TAG, "pcie mhccif interrupt\n");
	return 0;
}
static void tasklet_wdt_isr(unsigned long data)
{

}
#else
static int pcie_mhccif_isr(void *data)
{
	struct ccci_modem *md = (struct ccci_modem *)data;
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;
	unsigned int hif_id = GET_HIF_ID(md->index, HIF_PATH_EX);//EX HIF
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md->index);
	unsigned long flags;
	unsigned long int_sta;
	u32 mask;

	spin_lock_irqsave(&md_info->exp_spinlock, flags);
	int_sta = ccci_hif_get_event_id(md->index, hif_id);
	md_info->exp_id |= int_sta;
	MTK_INFO_LIMITED_LOG(TAG, "mhccif = 0x%lx, exp_id = 0x%lx\n",
						int_sta, md_info->exp_id);
#ifdef CCCI_CTL_TRACE
	trace_md_ex_isr(md_info->exp_id);
#endif /* CCCI_CTL_TRACE */
	if (md_info->exp_id & (1 << PORT_ENUM_SIGNAL)) {
		md_info->exp_id &= ~(1 << PORT_ENUM_SIGNAL);
		if (ctl->curr_state == CCCI_FSM_INIT
			 || ctl->curr_state == CCCI_FSM_PRE_STARTING
			 || ctl->curr_state == CCCI_FSM_STOPPED)
			ccci_fsm_recv_md_interrupt(md->index, MD_IRQ_PORT_ENUM);

	}

	if (md_info->exp_id & (1 << EXP_ID_EXCEPTION_INIT)) {
		if (ctl->md_state == 0 /*Added for MD early EE */
			|| ctl->md_state == BOOT_WAITING_FOR_HS1
			|| ctl->md_state == BOOT_WAITING_FOR_HS2
			|| ctl->md_state == READY) {
			md_info->exp_id &= ~(1 << EXP_ID_EXCEPTION_INIT);
			ccci_fsm_recv_md_interrupt(md->index, MD_IRQ_CCIF_EX);
		}
	} else {
		/*start handshake if MD not assert*/
		if (ctl->md_state == BOOT_WAITING_FOR_HS1) {
			mask = mhccif_mask_get(md->mtk_dev);
			MTK_INFO_LOG(TAG, "mhccif mask is %x.\n", mask);
			if ((md_info->exp_id & (1 << ASYNC_SAP_HK_SIGNAL)) && !(mask & (1 << ASYNC_SAP_HK_SIGNAL))) {
				md_info->exp_id &= ~(1 << ASYNC_SAP_HK_SIGNAL);
				queue_work(md->core_sap.worker, &(md->core_sap.core_work));

			}
			if ((md_info->exp_id & (1 << ASYNC_MD_HK_SIGNAL)) && !(mask & (1 << ASYNC_MD_HK_SIGNAL))) {
				md_info->exp_id &= ~(1 << ASYNC_MD_HK_SIGNAL);
				queue_work(md->core_md.worker, &(md->core_md.core_work));
			}
		}
	}


	spin_unlock_irqrestore(&md_info->exp_spinlock, flags);

	return 0;
}

#endif

static int __ccci_rgu_get_pcie_dev_info(struct mtk_pci_dev *mtk_dev, void __iomem **out, uint32_t phy_addr)
{
	struct mtk_addr_base *base_addr_ptr;

	base_addr_ptr = &(mtk_dev->base_addr);
	(*out) = (void __iomem *)(base_addr_ptr->pcie_ext_reg_base + (phy_addr - base_addr_ptr->pcie_dev_reg_trsl_addr));

	return 0;
}

void rgu_reset_device_via_pcie(struct mtk_pci_dev *mtk_dev)
{
	uint32_t val;
	int err = 0;
	void __iomem *rgu_mode_reg;
	void __iomem *rgu_swrst_reg;

#ifndef M8X75
	void __iomem *rgu_pciesta_reg;

	err = __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_mode_reg, TOPRGUWDT_MODE);
	err |= __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_swrst_reg, TOPRGUWDT_SWRST);
	err |= __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_pciesta_reg, TOPRGUTOPRGU_CH_PCIE_IRQ_STA);
	if (err) {
		MTK_ERR_LOG(TAG, "Could not remap RGU regs,mode:%p,swrst:%p,pciesta:%p\n",
					   rgu_mode_reg, rgu_swrst_reg, rgu_pciesta_reg);
		return;
	}

	/*disable dual mode, disable WDT timer, enable reset mode*/
	val = rgu_read32(rgu_mode_reg, 0x00);
	val &= ~((1 << 6) | (1 << 3) | (1 << 0));
	val |= 0x22000000;

	rgu_write32(rgu_mode_reg, 0x00, val);

	/*clear RGU PCIe IRQ state*/
	val = rgu_read32(rgu_pciesta_reg, 0x00);
	rgu_write32(rgu_pciesta_reg, 0x00, val);

#else
	void __iomem *rgu_latch_ctl2;
	err = __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_mode_reg, TOPRGUWDT_MODE);
	err |= __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_swrst_reg, TOPRGUWDT_SWRST);
	err |= __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_latch_ctl2, TOPRGUWDT_LATCH_CTL2);


	if (err) {
		MTK_ERR_LOG(TAG, "Could not remap RGU regs,mode:%p,swrst:%p,latch:%p\n",
					   rgu_mode_reg, rgu_swrst_reg, rgu_latch_ctl2);
		return;
	}

	/*disable dual mode*/
	val = rgu_read32(rgu_mode_reg, 0x00);
	MTK_NOTICE_LOG("RGU", "Addr(0X%X):0X%X", TOPRGUWDT_MODE, val);

	/*val &= ~(1 << 6);*/
	/*val |= 0x22000000;*/
	val = 0x22000035;
	MTK_NOTICE_LOG("RGU", "write Addr(0X%X):0X%X", TOPRGUWDT_MODE, val);
	rgu_write32(rgu_mode_reg, 0x00, val);
	val = rgu_read32(rgu_mode_reg, 0x00);
	MTK_NOTICE_LOG("RGU", "read Addr(0X%X):0X%X", TOPRGUWDT_MODE, val);

	/*clear DFD timeout*/
	val = 0x95000000;
	MTK_NOTICE_LOG("RGU", "write Addr(0X%X):0X%X", TOPRGUWDT_LATCH_CTL2, val);
	rgu_write32(rgu_latch_ctl2, 0x00, val);
	rgu_read32(rgu_latch_ctl2, 0x00);
	MTK_NOTICE_LOG("RGU", "read Addr(0X%X):0X%X", TOPRGUWDT_LATCH_CTL2, val);


#endif

	/*reset device*/
	val = TOPRGU_RESET_KEY;
	MTK_NOTICE_LOG("RGU", "write Addr(0X%X):0X%X", TOPRGUWDT_SWRST, val);
	rgu_write32(rgu_swrst_reg, 0x00, val);

	return;
}


static void __clr_device_irq_via_pcie(struct mtk_pci_dev *mtk_dev)
{
	uint32_t val = 0;
	int err = 0;
	void __iomem *rgu_pciesta_reg;

	err = __ccci_rgu_get_pcie_dev_info(mtk_dev, &rgu_pciesta_reg, TOPRGUTOPRGU_CH_PCIE_IRQ_STA);
	if(err) {
		MTK_ERR_LOG(TAG, "Could not remap RGU regs\n");
		return;
	}

	/*clear RGU PCIe IRQ state*/
	val = rgu_read32(rgu_pciesta_reg, 0x00);
	rgu_write32(rgu_pciesta_reg, 0x00, val);

	return;
}

int remove_driver_f(struct mtk_pci_dev *mtk_dev)
{
	mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, true);

	return 0;
}


int remove_driver_r(struct mtk_pci_dev *mtk_dev)
{

	return 0;
}

void mtk_clear_rgu_irq(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "Clear RGU IRQ\n");
    /*clear L2*/
	__clr_device_irq_via_pcie(mtk_dev);
	/*clear L1*/
	mtk_pcie_clr_ext_int_sts(mtk_dev, SAP_RGU_INT);
}

static int reset_device_via_pmic(struct mtk_pci_dev *mtk_dev)
{
	struct ccci_modem *md;
	unsigned int val;

	md = (struct ccci_modem *)(mtk_dev->ccci_md);

	/*[27:26] 1:cold reset, 2: warm reset, others: cold reset*/
	val = ccci_dummy_register_val_get(md, 0);
	MTK_INFO_LOG(TAG, "PCI dummy register val = 0X%X\n", val);
	val >>= 26;
	val &= 0x03;

	switch (val) {
	case 1:
		MTK_INFO_LOG(TAG, "Cold reset device by PLDR\n");
		mtk_acpi_pldr_func(mtk_dev);
		break;
	case 2:
		MTK_INFO_LOG(TAG, "Warm reset device by FLDR\n");
		mtk_acpi_fldr_func(mtk_dev);
		break;
	default:
		/*fix me, cold reset*/
		MTK_INFO_LOG(TAG, "Unsupported reset request, val = %d\n", val);
		break;
	}

	return 0;
}

static void rgu_irq_work_fn(struct work_struct *work)
{
	int ret;
	struct mtk_pci_dev *mtk_dev;
	struct ccci_modem *modem;
	struct ccci_fsm_ctl *ctl;
	struct delayed_work *irq_work;

	irq_work = to_delayed_work(work);
	modem = container_of(irq_work, struct ccci_modem, rgu_irq_work);
	mtk_dev = (struct mtk_pci_dev *)modem->mtk_dev;
	ctl = fsm_get_entity_by_md_id(0);

	msleep(10);
	reset_device_via_pmic(mtk_dev);
	ret = 1;//(int)mtk_dev_pci_check_resume_reg_state(mtk_dev);
	if (ret == 0) {
		MTK_DEBUG_LOG(TAG, "Re-Init after RGU IRQ arrived\n");
		atomic_set(&modem->rgu_irq_assered, 0);
		mtk_pcie_reinit(mtk_dev);
		fsm_append_command(ctl, CCCI_COMMAND_PRE_START, 0);
	} else {
		if (!mtk_dev->hp_enable) {
			MTK_DEBUG_LOG(TAG, "Re-Scan after RGU IRQ arrived\n");
			mtk_queue_rescan_work(mtk_dev->pdev);
		} else {
			MTK_DEBUG_LOG(TAG, "HotPlug Enabled,Not Re-Scan after RGU IRQ arrived\n");
		}
	}

	return;
}

static int rgu_handler_func(void *data)
{
	struct mtk_pci_dev *mtk_dev;
	struct ccci_modem *modem;

	mtk_dev = (struct mtk_pci_dev *)data;
	if(unlikely(mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid arguments!\n");
		return -EINVAL;
	}

	modem = (struct ccci_modem *)mtk_dev->ccci_md;

	MTK_NOTICE_LOG(TAG, "device RGU IRQ arrived\n");
	mtk_clear_rgu_irq(mtk_dev);

	if (atomic_read(&mtk_dev->rgu_pci_irq_en) == 0) {
		atomic_set(&modem->rgu_irq_assered_in_suspend, 1);
		goto exit;
	}

	atomic_set(&modem->rgu_irq_assered, 1);
	mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, true);
	queue_delayed_work(modem->rgu_workqueue, &modem->rgu_irq_work,
							msecs_to_jiffies(0));

exit:
	return IRQ_HANDLED;
}

static void mtk_pcie_register_rgu_isr(void *param)
{
	struct mtk_pci_dev *mtk_dev;
	struct ccci_modem *modem;

	mtk_dev = (struct mtk_pci_dev *)param;
	modem = (struct ccci_modem *)mtk_dev->ccci_md;

	modem->rgu_workqueue = create_singlethread_workqueue("rgu_workqueue");
	INIT_DELAYED_WORK(&(modem->rgu_irq_work), rgu_irq_work_fn);

	/* registers RGU callback isr with PCIE driver */
	mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, true);
	mtk_pcie_clr_ext_int_sts(mtk_dev, SAP_RGU_INT);
	mtk_pcie_register_ext_int_callback(mtk_dev, SAP_RGU_INT,
				rgu_handler_func, (void *)mtk_dev);
	mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, false);
}

static void md_exception(struct ccci_modem *md, HIF_EX_STAGE stage)
{
	int ex_hif_id = 0;

	ex_hif_id = GET_HIF_ID(md->index, HIF_PATH_EX);
	MTK_INFO_LOG(TAG, "EX CCIF HS state:%d\n", stage);
	switch (stage) {
	case HIF_EX_INIT:
		ccci_hif_exception(md->index, HIF_FLAG_CTRL_DATA, HIF_EX_INIT);
		ccci_hif_ex_handshake(md->index, ex_hif_id, HIF_EX_INIT);
		break;
	case HIF_EX_INIT_DONE:
		ccci_hif_exception(md->index,
			HIF_FLAG_CTRL_DATA, HIF_EX_INIT_DONE);
		ccci_hif_ex_handshake(md->index, ex_hif_id, HIF_EX_INIT_DONE);
		break;
	case HIF_EX_CLEARQ_DONE:
		/*give DHL some time to flush data*/
		msleep(2000);
		port_reset(md->index);
		ccci_hif_exception(md->index,
			HIF_FLAG_CTRL_DATA, HIF_EX_CLEARQ_DONE);
		ccci_hif_ex_handshake(md->index, ex_hif_id, HIF_EX_CLEARQ_DONE);
		break;
	case HIF_EX_ALLQ_RESET:
		md->per_md_data.is_in_ee_dump = 1;
		ccci_hif_exception(md->index,
			HIF_FLAG_CTRL_DATA, HIF_EX_ALLQ_RESET);
		ccci_hif_ex_handshake(md->index, ex_hif_id, HIF_EX_ALLQ_RESET);
		break;
	default:
		break;
	};
}

static int wait_hif_ex_hk_event(struct ccci_modem *md, int event_id)
{
	int cnt = 500; /*MD timeout is 10s*/
	int time_once = 10;
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;

	while (cnt > 0) {
		if (md_info->exp_id & (1 << event_id)) {
#ifdef CCCI_CTL_TRACE
			trace_wait_hif_ex_hk_event(md_info->exp_id);
#endif /* CCCI_CTL_TRACE */
			MTK_INFO_LOG(TAG,
				"EX CCIF HS poll RCHNUM 0x%-4lX\n",
				md_info->exp_id);
			return 0;
		}
		msleep(time_once);
		cnt--;
	}
	return -1;
}

static int md_ee_handshake(struct ccci_modem *md, int timeout)
{
	/* seems sometime MD send D2H_EXCEPTION_INIT_DONE and */
	/* D2H_EXCEPTION_CLEARQ_DONE together */
	/* polling_ready(md_ctrl, D2H_EXCEPTION_INIT);*/
	int ret = 0;

	MTK_NOTICE_LOG(TAG, "EX CCIF HS start.\n");
	md_exception(md, HIF_EX_INIT);
	ret = wait_hif_ex_hk_event(md, EXP_ID_EXCEPTION_INIT_DONE);
	if (-1 == ret) {
		MTK_ERR_LOG(TAG, "EX CCIF HS timeout, RCHNUM %d\n",
			EXP_ID_EXCEPTION_INIT_DONE);
	}

	md_exception(md, HIF_EX_INIT_DONE);

	ret = wait_hif_ex_hk_event(md, EXP_ID_EXCEPTION_CLEARQ_DONE);
	if (-1 == ret) {
		MTK_ERR_LOG(TAG, "EX CCIF HS timeout, RCHNUM %d\n",
			EXP_ID_EXCEPTION_CLEARQ_DONE);
	}

	md_exception(md, HIF_EX_CLEARQ_DONE);

	ret = wait_hif_ex_hk_event(md, EXP_ID_EXCEPTION_ALLQ_RESET);
	if (-1 == ret) {
		MTK_ERR_LOG(TAG, "EX CCIF HS timeout, RCHNUM %d\n",
			EXP_ID_EXCEPTION_ALLQ_RESET);
	}

	md_exception(md, HIF_EX_ALLQ_RESET);

	MTK_NOTICE_LOG(TAG, "EX CCIF HS DONE.\n");
	return 0;
}

static inline int md_sys1_sw_init(struct ccci_modem *md)
{
	int ret = 0;
	struct mtk_pci_dev *mtk_dev;

	mtk_dev = md->mtk_dev;
	mutex_init(&ctl_cfg_mutex);
#if defined(ENABLE_CCCI_DRI_UT)
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;

	if (0 == md->md_wdt_irq_id || 0 == md_info->md_ex_irq_id) {
		MTK_ERR_LOG(TAG,
			"request MD_WDT IRQ:%d, MD_EX_IRQ IRQ:%d\n",
			md->md_wdt_irq_id, md_info->md_ex_irq_id);
	} else {
		tasklet_init(&md->md_wdt_irq_task,
			tasklet_wdt_isr, (unsigned long)md);
		MTK_DEBUG_LOG(TAG,
			"start tasklet_wdt_isr, %p\n", tasklet_wdt_isr);
		tasklet_init(&md->md_irq_task,
			tasklet_md_isr, (unsigned long)md);
		MTK_DEBUG_LOG(TAG,
			"start tasklet_md_isr, %p\n", tasklet_md_isr);
	}
#else //ENABLE_CCCI_DRI_UT

	/* register the mhccif isr for md exception (bit 1~4),
	 * port enum notification (bit 5)
	 * async handshake notification(bit 15, 16)
	 */
	md_mhccif_mask_set(md, 0x1803E, 1);
	ret = mtk_pcie_register_mhccif_ext_int_callback(mtk_dev,
				CLDMA1_INT, 0x1803E, pcie_mhccif_isr, md);
	if (ret != 0)
		MTK_ERR_LOG(TAG, "failed to register the mhccif isr!\n");
	else
		md_mhccif_mask_set(md, 1 << PORT_ENUM_SIGNAL, 0);

	/*register rgu irq handler for sAP exception notification*/
	atomic_set(&mtk_dev->rgu_pci_irq_en, 1);
	mtk_pcie_register_rgu_isr((void *)mtk_dev);
#endif
	return ret;
}
struct feature_query {
	u32 head_pattern;
	struct ccci_feature_support feature_set[FEATURE_COUNT];
	u32 tail_pattern;
};

void prepare_host_rt_data_requry(struct core_sys_info *core)
{
	struct ccci_header *ccci_h;
	struct sk_buff *skb = NULL;
	struct ctrl_msg_header *ctrl_msg_h = NULL;
	struct feature_query *ft_query = NULL;
	int packet_size = 0;

	packet_size = sizeof(struct ccci_header) \
				  + sizeof(struct ctrl_msg_header)\
				  + sizeof(struct feature_query);
	skb = ccci_alloc_skb(packet_size, 0, 1);
	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "core%d, can't send hs1 message\n",
					core->index);
		return;
	}
	skb_put(skb, packet_size);
	/*fill ccci header*/
	ccci_h = (struct ccci_header *)skb->data;
	ccci_h->data[0] = 0;
	ccci_h->data[1] = packet_size;
	ccci_h->channel = core->ctl_port->tx_ch;
	ccci_h->seq_num = 0;
	ccci_h->reserved = 0;
	/*fild control message*/
	ctrl_msg_h = (struct ctrl_msg_header *)\
				 (skb->data + sizeof(struct ccci_header));
	ctrl_msg_h->ctrl_msg_id = CTL_ID_HS1_MSG;
	ctrl_msg_h->reserved= 0;
	ctrl_msg_h->data_length = sizeof(struct feature_query);
	/*fild feature query */
	ft_query = (struct feature_query *)\
			   (skb->data + sizeof(struct ccci_header)\
			   + sizeof(struct ctrl_msg_header));
	ft_query->head_pattern = MD_FEATURE_QUERY_PATTERN;
	memcpy(ft_query->feature_set, core->feature_set, \
			sizeof(struct ccci_feature_support)*FEATURE_COUNT);
	ft_query->tail_pattern = MD_FEATURE_QUERY_PATTERN;
	// send HS1 msg to device
	dump_runtime_rawdata(skb->data, skb->len);
	ccci_port_send_hif(core->ctl_port, skb, 0, 1);
}

int prepare_device_rt_data(struct core_sys_info *core,
			void *data, int data_length)
{
	struct feature_query *md_feature;
	struct sk_buff *skb = NULL;
	struct ccci_runtime_feature rt_feature;
	struct ccci_header *ccci_h;
	struct ctrl_msg_header *ctrl_msg_h;
	int packet_size = 0;
	int i;
	char *rt_data = NULL;

	skb = ccci_alloc_skb(SKB_4K, 0, 1);
	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "core%d, can't send hs1 message\n",
					core->index);
		return -1;
	}
	/*fill ccci header*/
	ccci_h = (struct ccci_header *)skb->data;
	ccci_h->data[0] = 0;
	ccci_h->channel = core->ctl_port->tx_ch;
	ccci_h->seq_num = 0;
	ccci_h->reserved = 0;
	/*fill control message header*/
	ctrl_msg_h = (struct ctrl_msg_header *)\
				 (skb->data + sizeof(struct ccci_header));
	ctrl_msg_h->ctrl_msg_id = CTL_ID_HS3_MSG;
	ctrl_msg_h->reserved = 0;
	rt_data = (skb->data + sizeof(struct ccci_header)\
				 + sizeof(struct ctrl_msg_header));

	/* parse md runtime data requry*/
	md_feature = (struct feature_query *)data;
	if (md_feature->head_pattern != MD_FEATURE_QUERY_PATTERN ||
		md_feature->tail_pattern != MD_FEATURE_QUERY_PATTERN) {
		MTK_ERR_LOG(TAG,
			"md_feature pattern is wrong: head 0x%x, tail 0x%x\n",
			md_feature->head_pattern, md_feature->tail_pattern);
		return -1;
	}
	/*fill runtime feature*/
	for (i = 0; i < FEATURE_COUNT; i++) {
		memset(&rt_feature, 0, sizeof(struct ccci_runtime_feature));
		rt_feature.feature_id = i;
		if (md_feature->feature_set[i].support_mask ==
			CCCI_FEATURE_NOT_EXIST) {
			rt_feature.support_info = md_feature->feature_set[i];
		} else if (md_feature->feature_set[i].support_mask ==
			CCCI_FEATURE_MUST_SUPPORT) {
			rt_feature.support_info = md_feature->feature_set[i];
		} else if (md_feature->feature_set[i].support_mask ==
			CCCI_FEATURE_OPTIONAL_SUPPORT) {
			if (md_feature->feature_set[i].version ==
				core->support_feature_set[i].version &&
				core->support_feature_set[i].support_mask >=
				CCCI_FEATURE_MUST_SUPPORT) {
				rt_feature.support_info.support_mask =
					CCCI_FEATURE_MUST_SUPPORT;
				rt_feature.support_info.version =
					core->support_feature_set[i].version;
			} else {
				rt_feature.support_info.support_mask =
					CCCI_FEATURE_NOT_SUPPORT;
				rt_feature.support_info.version =
					core->support_feature_set[i].version;
			}
		} else if (md_feature->feature_set[i].support_mask ==
			CCCI_FEATURE_SUPPORT_BACKWARD_COMPAT) {
			if (md_feature->feature_set[i].version >=
				core->support_feature_set[i].version) {
				rt_feature.support_info.support_mask
					= CCCI_FEATURE_MUST_SUPPORT;
				rt_feature.support_info.version =
					core->support_feature_set[i].version;
			} else {
				rt_feature.support_info.support_mask =
					CCCI_FEATURE_NOT_SUPPORT;
				rt_feature.support_info.version =
					core->support_feature_set[i].version;
			}
		}
		if (rt_feature.support_info.support_mask ==
			CCCI_FEATURE_MUST_SUPPORT) {
			switch (rt_feature.feature_id) {
			default:
				break;
			};
		} else {
			rt_feature.data_len = 0;
			append_runtime_feature(&rt_data, &rt_feature, NULL);
		}
		packet_size += (sizeof(struct ccci_runtime_feature)+rt_feature.data_len);
	}
	ctrl_msg_h->data_length = packet_size;
	ccci_h->data[1] = packet_size\
					  + sizeof(struct ctrl_msg_header)\
					  + sizeof(struct ccci_header);
	skb_put(skb, ccci_h->data[1]);
	// send HS3 msg to device
	dump_runtime_rawdata(skb->data, skb->len);
	ccci_port_send_hif(core->ctl_port, skb, 0, 1);
	return 0;
}

int parse_host_rt_data(struct core_sys_info *core,\
			void *data, int data_length)
{
	struct ccci_runtime_feature *rt_feature;
	unsigned char *rt_ft_data, *ft_data;
	int ft_id_index, ft_data_len, offset = 0;
	unsigned char ft_spt_st, ft_spt_cfg, cur_ft_spt=0;
	int ret = 0;

	offset = sizeof(struct feature_query);
	for (ft_id_index = 0;
		 ft_id_index < FEATURE_COUNT && offset < data_length;
		 ft_id_index++ ) {
		rt_ft_data = data + offset;
		rt_feature = (struct ccci_runtime_feature *)rt_ft_data;
		ft_spt_st = rt_feature->support_info.support_mask;
		ft_spt_cfg =
			core->feature_set[ft_id_index].support_mask;
		ft_data = rt_feature->data;
		ft_data_len = rt_feature->data_len;
		MTK_DEBUG_LOG(TAG, "runtime feature%d (%d,%d) \n",
					ft_id_index, ft_spt_cfg, ft_spt_st);
		if (ft_spt_cfg == CCCI_FEATURE_NOT_EXIST
			|| ft_spt_cfg == CCCI_FEATURE_NOT_SUPPORT) {
			offset += sizeof(struct ccci_runtime_feature)
				+ rt_feature->data_len;
			continue;
		}
		if (ft_spt_cfg == CCCI_FEATURE_MUST_SUPPORT) {
			if (ft_spt_st != CCCI_FEATURE_MUST_SUPPORT) {
				MTK_ERR_LOG(TAG, "dismatch: runtime feature%d (%d,%d) \n",
					ft_id_index, ft_spt_cfg, ft_spt_st);
				ret = -1;
				break;
			  }
		  cur_ft_spt = CCCI_FEATURE_MUST_SUPPORT;
		} else if (ft_spt_cfg
					== CCCI_FEATURE_OPTIONAL_SUPPORT) {
			  cur_ft_spt = ft_spt_cfg;
		} else if (ft_spt_cfg
					== CCCI_FEATURE_SUPPORT_BACKWARD_COMPAT) {
			if (ft_spt_st == CCCI_FEATURE_MUST_SUPPORT)
			  cur_ft_spt = CCCI_FEATURE_MUST_SUPPORT;
			else {
				MTK_ERR_LOG(TAG, "dismatch: runtime feature%d (%d,%d) \n",
					ft_id_index, ft_spt_cfg, ft_spt_st);
				ret = -1;
				break;
			}
		}

		if (cur_ft_spt == CCCI_FEATURE_MUST_SUPPORT) {
			switch (ft_id_index) {
			case RT_ID_MD_PORT_ENUM:
			case RT_ID_SAP_PORT_ENUM:
				ccci_port_status_update(core->ctl_port->md_id, ft_data);
				break;
			default:
				break;
			}
		}
		offset += sizeof(struct ccci_runtime_feature)\
				  + rt_feature->data_len;
	}
	return ret;
}

static struct core_ops ops_dec[CORE_ID_MAX] = {
	[CORE_ID_MD] = {
		.prepare_requry = &prepare_host_rt_data_requry,
		.parse_host_rtdata = &parse_host_rt_data,
		.prepare_rt_data = &prepare_device_rt_data,
	},
	[CORE_ID_SAP] = {
		.prepare_requry = &prepare_host_rt_data_requry,
		.parse_host_rtdata = &parse_host_rt_data,
		.prepare_rt_data = &prepare_device_rt_data,
	},
};

static void core_reset(struct core_sys_info *core_info)
{
	struct ccci_fsm_ctl *fsm_ctl = NULL;
	atomic_set(&core_info->ready, 0);
	fsm_ctl = fsm_get_entity_by_md_id(0);

	if (fsm_ctl == NULL) {
		MTK_ERR_LOG(TAG, "fsm ctrl isn't initialized/n");
		return;
	}
	/* Append HS2 EXIT event to exit the work "core_hk_handler" if the last
 	handshake wasn't done yet.
 	Remember to clear this event before entering the work "core_hk_handler". */
	if (atomic_read(&(core_info->handshake_ongoing)) == 1) {
		switch (core_info->index) {
		case CORE_ID_MD:
			fsm_append_event(fsm_ctl, CCCI_EVENT_MD_HS2_EXIT, NULL, 0);
			break;
		case CORE_ID_SAP:
			fsm_append_event(fsm_ctl, CCCI_EVENT_AP_HS2_EXIT, NULL, 0);
			break;
		default:
			break;
		}
	}
	atomic_set(&core_info->handshake_ongoing, 0);
}

static int core_init(struct core_sys_info *core_info,\
	const char *name, void (*func)(struct work_struct *work)) {
	atomic_set(&core_info->ready, 0);
	atomic_set(&core_info->handshake_ongoing, 0);
	core_info->worker =
		alloc_workqueue("%s", \
			WQ_UNBOUND|WQ_MEM_RECLAIM|WQ_HIGHPRI, 0, name);
    INIT_WORK(&core_info->core_work, func);
	switch (core_info->index) {
	case CORE_ID_MD:
		core_info->feature_set[RT_ID_MD_PORT_ENUM].support_mask
			= CCCI_FEATURE_MUST_SUPPORT;
		core_info->ops = &ops_dec[CORE_ID_MD];
		break;
	case CORE_ID_SAP:
		core_info->feature_set[RT_ID_SAP_PORT_ENUM].support_mask
			= CCCI_FEATURE_MUST_SUPPORT;
		core_info->ops = &ops_dec[CORE_ID_SAP];
		break;
	default:
		break;
	}
	return 0;
}

void core_hk_handler(struct core_sys_info *core_info,
			struct ccci_fsm_ctl *ctl, CCCI_FSM_EVENT event_id, CCCI_FSM_EVENT err_detect)
{
	struct ccci_fsm_event *event;
	unsigned long flags;
	int ret = 0;
	core_info->ops->prepare_requry(core_info);
	MTK_NOTICE_LOG(TAG, "core%d handshake 1 done", core_info->index);
	while (1) {
		spin_lock_irqsave(&ctl->event_lock, flags);
		if (!list_empty(&ctl->event_queue)) {
			event = list_first_entry(&ctl->event_queue, \
						struct ccci_fsm_event, entry);
			if (event->event_id == err_detect) {
				list_del(&event->entry);
				MTK_ERR_LOG(TAG, "core%d handshake 2 exit\n", core_info->index);
				spin_unlock_irqrestore(&ctl->event_lock, flags);
				kfree(event);
				return;
			}
			if (event->event_id == event_id) {
				list_del(&event->entry);
				spin_unlock_irqrestore(&ctl->event_lock, flags);
				if (atomic_read(&ctl->exp_flg))
					return;
				ret = core_info->ops->parse_host_rtdata(core_info, event->data, event->length);
				if (ret == 0) {
					MTK_NOTICE_LOG(TAG, "core%d handshake 2 done (%d)\n",\
								core_info->index, ret);
					if (atomic_read(&ctl->exp_flg))
						return;
					ret = core_info->ops->prepare_rt_data(core_info, event->data, event->length);
				} else {
					MTK_ERR_LOG(TAG, "core%d handshake 2 fail(%d)\n",\
								core_info->index, ret);
				}
				if (ret == 0) {
				// handshake successfully
					MTK_NOTICE_LOG(TAG, "core%d handshake 3 done", core_info->index);
					atomic_set(&core_info->ready, 1);
					atomic_set(&core_info->handshake_ongoing, 0);
					wake_up(&ctl->async_hk_wq);
				} else {
					MTK_ERR_LOG(TAG, "core%d handshake 3 fail(%d)",\
								core_info->index, ret);
				}
				MTK_INFO_LOG(FSM, "event %d is completed by %s",\
							event->event_id, __func__);
				kfree(event);
				break;
			} else
				spin_unlock_irqrestore(&ctl->event_lock, flags);
		} else {
			spin_unlock_irqrestore(&ctl->event_lock, flags);
			wait_event_interruptible(ctl->event_wq, \
						!list_empty(&ctl->event_queue));
		}
	}
}

void md_hk_wq(struct work_struct *work)
{
	struct core_sys_info *core_info = container_of(work,
			struct core_sys_info, core_work);
	struct ccci_modem *md = container_of(core_info,
			struct ccci_modem, core_md);
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md->index);
	/* Clear the HS2 EXIT event appended in core_reset(). */
	fsm_clear_event(ctl, CCCI_EVENT_MD_HS2_EXIT);
	ccci_switch_hif_cfg(md->index, HIF_PATH_CTRL, HIF_CFG1);
	ccci_hif_start(md->index, HIF_FLAG_CTRL);
	fsm_broadcast_state(ctl, BOOT_WAITING_FOR_HS2);
	atomic_set(&core_info->handshake_ongoing, 1);
	core_hk_handler(core_info, ctl, CCCI_EVENT_MD_HS2, CCCI_EVENT_MD_HS2_EXIT);
}

void sap_hk_wq(struct work_struct *work)
{
	struct core_sys_info *core_info = container_of(work,
			struct core_sys_info, core_work);
	struct ccci_modem *md = container_of(core_info,
			struct ccci_modem, core_sap);
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md->index);
	/* Clear the HS2 EXIT event appended in core_reset(). */
	fsm_clear_event(ctl, CCCI_EVENT_AP_HS2_EXIT);
	ccci_hif_stop(md->index, HIF_FLAG_CTRL_1);
	ccci_switch_hif_cfg(md->index, HIF_PATH_CTRL_1, HIF_CFG_DEF);
	ccci_hif_start(md->index, HIF_FLAG_CTRL_1);
	atomic_set(&core_info->handshake_ongoing, 1);
	core_hk_handler(core_info, ctl, CCCI_EVENT_SAP_HS2, CCCI_EVENT_AP_HS2_EXIT);
}

static int md_init(struct ccci_modem *md)
{
	md->core_md.index = CORE_ID_MD;
	md->core_sap.index = CORE_ID_SAP;
	core_init(&md->core_md, "md_hk_wq", md_hk_wq);
	core_init(&md->core_sap, "sap_hk_wq", sap_hk_wq);
	return 0;
}

static int md_uninit(struct ccci_modem *md)
{
	destroy_workqueue(md->core_sap.worker);
	destroy_workqueue(md->core_md.worker);
	destroy_workqueue(md->rgu_workqueue);
	return 0;
}

static int md_start(struct ccci_modem *md)
{
#ifdef CCCI_CTL_TRACE
	unsigned char trace_log[TRACE_LOG_LEN] = {0};
#endif /* CCCI_CTL_TRACE */
	if (md->per_md_data.config.setting & MD_SETTING_FIRST_BOOT) {
		md->per_md_data.config.setting &= ~MD_SETTING_FIRST_BOOT;
	}
	atomic_set(&md->reset_on_going, 0);
	md->per_md_data.md_dbg_dump_flag = MD_DBG_DUMP_AP_REG;
	ex_enable_irq(md);
	md_power_on(md);
	md_let_md_go(md);
	/* start CTRL/Data path HIF*/
	ccci_hif_start(md->index, HIF_FLAG_DATA);
#ifdef CCCI_CTL_TRACE
	snprintf(trace_log, TRACE_LOG_LEN, "modem 1 started");
	trace_md_start(trace_log);
#endif /* CCCI_CTL_TRACE */

	return 0;
}

static int md_pre_stop(struct ccci_modem *md, unsigned int stop_type)
{
	int	 ret = 0;
	u32 pending = 0;

	/* 1. mutex check */
	if (atomic_add_return(1, &md->reset_on_going) > 1) {
		MTK_INFO_LOG(TAG, "One reset flow is on-going\n");
		return -CCCI_ERR_MD_IN_RESET;
	}
	MTK_INFO_LOG(TAG,
		"%s:modem sys1 is entering to sleep mode\n", __func__);
	/* 2. disable WDT IRQ */
	wdt_disable_irq(md);
	/* only debug in Flight mode */
	if (stop_type == MD_FLIGHT_MODE_ENTER) {
		MTK_INFO_LOG(TAG, "MD enter sleep mode\n");
		if (pending) {
			MTK_INFO_LOG(TAG, "WDT IRQ occur.");
			ret = -1;
		}
	}
	MTK_INFO_LOG(TAG, "pre_stop MD state: %d\n",
		ccci_fsm_get_md_state(md->index));
	return ret;
}

static int md_stop(struct ccci_modem *md, unsigned int stop_type)
{
	int ret = 0;

	MTK_INFO_LOG(TAG, "modem sys1 is power off, stop_type=%u\n", stop_type);

	ccci_hif_stop(md->index, HIF_FLAG_CTRL);
	ex_disable_irq(md);
	/* power off MD */
	ret = md_power_off(md, stop_type == MD_FLIGHT_MODE_ENTER ? 100 : 0);
	MTK_INFO_LOG(TAG, "modem sys1 is power off done, %d\n", ret);
	ccci_hif_clear(md->index, HIF_FLAG_DATA);
	ccci_hif_reset(md->index, HIF_PATH_CTRL, 1);

	return 0;
}


static void dump_runtime_data_v2(struct ccci_modem *md,
	struct ap_query_md_feature *ap_feature)
{
	u8 i = 0;

	MTK_DEBUG_LOG(TAG, "head_pattern 0x%x\n", ap_feature->head_pattern);

	for (i = 0; i < AP_RUNTIME_FEATURE_ID_MAX; i++) {
		MTK_DEBUG_LOG(TAG,
			"feature %u: mask %u, version %u\n",
			i, ap_feature->feature_set[i].support_mask,
			ap_feature->feature_set[i].version);
	}
	MTK_DEBUG_LOG(TAG, "share_memory_support 0x%x\n",
		ap_feature->share_memory_support);
	MTK_DEBUG_LOG(TAG, "ap_runtime_data_addr 0x%x\n",
		ap_feature->ap_runtime_data_addr);
	MTK_DEBUG_LOG(TAG, "ap_runtime_data_size 0x%x\n",
		ap_feature->ap_runtime_data_size);
	MTK_DEBUG_LOG(TAG, "md_runtime_data_addr 0x%x\n",
		ap_feature->md_runtime_data_addr);
	MTK_DEBUG_LOG(TAG, "md_runtime_data_size 0x%x\n",
		ap_feature->md_runtime_data_size);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_start_addr 0x%x\n",
		ap_feature->set_md_mpu_start_addr);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_total_size 0x%x\n",
		ap_feature->set_md_mpu_total_size);
	MTK_DEBUG_LOG(TAG, "tail_pattern 0x%x\n", ap_feature->tail_pattern);
}

static void dump_runtime_data_v2_1(struct ccci_modem *md,
	struct ap_query_md_feature_v2_1 *ap_feature)
{
	u8 i = 0;

	MTK_DEBUG_LOG(TAG, "head_pattern 0x%x\n", ap_feature->head_pattern);

	for (i = 0; i < AP_RUNTIME_FEATURE_ID_MAX; i++) {
		MTK_DEBUG_LOG(TAG,
			"feature %u: mask %u, version %u\n",
			i, ap_feature->feature_set[i].support_mask,
			ap_feature->feature_set[i].version);
	}
	MTK_DEBUG_LOG(TAG, "share_memory_support 0x%x\n",
		ap_feature->share_memory_support);
	MTK_DEBUG_LOG(TAG, "ap_runtime_data_addr 0x%x\n",
		ap_feature->ap_runtime_data_addr);
	MTK_DEBUG_LOG(TAG, "ap_runtime_data_size 0x%x\n",
		ap_feature->ap_runtime_data_size);
	MTK_DEBUG_LOG(TAG, "md_runtime_data_addr 0x%x\n",
		ap_feature->md_runtime_data_addr);
	MTK_DEBUG_LOG(TAG, "md_runtime_data_size 0x%x\n",
		ap_feature->md_runtime_data_size);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_noncached_start_addr 0x%x\n",
		ap_feature->noncached_mpu_start_addr);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_noncached_total_size 0x%x\n",
		ap_feature->noncached_mpu_total_size);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_cached_start_addr 0x%x\n",
		ap_feature->cached_mpu_start_addr);
	MTK_DEBUG_LOG(TAG, "set_md_mpu_cached_total_size 0x%x\n",
		ap_feature->cached_mpu_total_size);
	MTK_DEBUG_LOG(TAG, "tail_pattern 0x%x\n", ap_feature->tail_pattern);
}

static void config_ap_runtime_data_v2(struct ccci_modem *md,
	struct ap_query_md_feature *ap_feature)
{
	struct ccci_smem_region *runtime_data =
		ccci_md_get_smem_by_user_id(md->index,
		SMEM_USER_RAW_RUNTIME_DATA);
	ap_feature->head_pattern = AP_FEATURE_QUERY_PATTERN;
	/*AP query MD feature set */
	ap_feature->share_memory_support = INTERNAL_MODEM;
	ap_feature->ap_runtime_data_addr = runtime_data->base_md_view_phy;
	ap_feature->ap_runtime_data_size = CCCI_SMEM_SIZE_RUNTIME_AP;
	ap_feature->md_runtime_data_addr =
		ap_feature->ap_runtime_data_addr + CCCI_SMEM_SIZE_RUNTIME_AP;
	ap_feature->md_runtime_data_size = CCCI_SMEM_SIZE_RUNTIME_MD;

	ap_feature->set_md_mpu_start_addr =
		md->mem_layout.md_bank4_noncacheable_total.base_md_view_phy;
	ap_feature->set_md_mpu_total_size =
		md->mem_layout.md_bank4_noncacheable_total.size;

	// Set Flag for modem on feature_set[1].version,
	//specially: [1].support_mask = 0
	ap_feature->feature_set[1].support_mask = 0;
	ap_feature->feature_set[1].version = 1;
	ap_feature->tail_pattern = AP_FEATURE_QUERY_PATTERN;
}

static void config_ap_runtime_data_v2_1(struct ccci_modem *md,
	struct ap_query_md_feature_v2_1 *ap_feature)
{
	struct ccci_feature_support s_info[4];

	memset(s_info, 0, sizeof(s_info));
	ap_feature->head_pattern = AP_FEATURE_QUERY_PATTERN;
	mt_reg_sync_writel(s_info[0].version << 4 | s_info[0].support_mask,
		&ap_feature->feature_set[0]);
	ap_feature->share_memory_support = 0;
	ap_feature->ap_runtime_data_addr = 0;
	ap_feature->ap_runtime_data_size = 0;
	ap_feature->md_runtime_data_addr = 0;
	ap_feature->md_runtime_data_size = 0;
	ap_feature->noncached_mpu_start_addr = 0;
	ap_feature->noncached_mpu_total_size = 0;
	ap_feature->cached_mpu_start_addr = 0;
	ap_feature->cached_mpu_total_size = 0;
	ap_feature->tail_pattern = AP_FEATURE_QUERY_PATTERN;
	if (ap_feature->ap_runtime_data_addr == 0 ||
		ap_feature->md_runtime_data_addr == 0){
		MTK_DEBUG_LOG(TAG, "there is not share memory\n");
	}
}

static struct sk_buff *md_init_rt_header(struct ccci_modem *md,
	int packet_size, unsigned int tx_ch, int skb_from_pool)
{
	struct ccci_header *ccci_h;
	struct sk_buff *skb = NULL;
	unsigned char *tmp_ptr = NULL;

	skb = ccci_alloc_skb(packet_size, skb_from_pool, 1);
	if (skb == NULL)
		return NULL;

	ccci_h = (struct ccci_header *)skb->data;
	/*header */
	ccci_h->data[0] = 0x00;
	ccci_h->data[1] = packet_size;
	ccci_h->reserved = MD_INIT_CHK_ID;
	ccci_h->channel = tx_ch;
	ccci_h->seq_num = 0;
	tmp_ptr = skb->data + sizeof(struct ap_query_md_feature_v2_1) +
		sizeof(struct ccci_header);
	memcpy(tmp_ptr, md->mem_layout.ccci_rt_smem_base,
		md->mem_layout.ccci_rt_smem_size);
	skb_put(skb, packet_size);
	return skb;
}

/*
 *support multi data struct to transfer runtime data
 */
static int md_send_runtime_data_v2(struct ccci_modem *md)
{
	int packet_size;
	//the channel id that sends runtime data
	unsigned int tx_ch = CCCI_CONTROL_TX;
	//the queue id that sends runtime data
	unsigned int txqno = 0;
	unsigned char skb_from_pool = 0;
	struct sk_buff *skb = NULL;
	struct ap_query_md_feature *ap_rt_data = NULL;
	struct ap_query_md_feature_v2_1 *ap_rt_data_v2_1 = NULL;
	struct port_proxy *proxy_p = GET_PORT_PROXY(md->index);
	int ret = 0;

	tx_ch = proxy_p->ctl_port->tx_ch;
	if (md->runtime_version < AP_MD_HS_V2) {
		MTK_ERR_LOG(TAG, "unsupported runtime version %d\n",
			md->runtime_version);
		return -CCCI_ERR_CCIF_INVALID_RUNTIME_LEN;
	}
	if (md->multi_md_mpu_support) {
		packet_size = sizeof(struct ap_query_md_feature_v2_1) +
			sizeof(struct ccci_header);
		ap_rt_data_v2_1 =
			(struct ap_query_md_feature_v2_1 *)get_rt_header(
			md->index, HIF_FLAG_CTRL, tx_ch,
			packet_size, txqno, skb_from_pool);
		if (ap_rt_data_v2_1 == NULL) {
			packet_size += md->mem_layout.ccci_rt_smem_size;
			skb = md_init_rt_header(md,
				packet_size, tx_ch, skb_from_pool);
			ap_rt_data_v2_1 = (struct ap_query_md_feature_v2_1 *)
				(skb->data + sizeof(struct ccci_header));
		}
		memset_io(ap_rt_data_v2_1, 0,
			sizeof(struct ap_query_md_feature_v2_1));
		config_ap_runtime_data_v2_1(md, ap_rt_data_v2_1);
		dump_runtime_rawdata(skb->data, skb->len);
		dump_runtime_data_v2_1(md, ap_rt_data_v2_1);
	} else {
		packet_size = sizeof(struct ap_query_md_feature) +
			sizeof(struct ccci_header);
		ap_rt_data = (struct ap_query_md_feature *)get_rt_header(
			md->index, HIF_FLAG_CTRL, tx_ch,
			packet_size, txqno, skb_from_pool);

		if (ap_rt_data == NULL) {
			packet_size += md->mem_layout.ccci_rt_smem_size;
			skb = md_init_rt_header(md,
				packet_size, tx_ch, skb_from_pool);
			ap_rt_data = (struct ap_query_md_feature *)(skb->data +
				sizeof(struct ccci_header));
		}
		memset_io(ap_rt_data, 0, sizeof(struct ap_query_md_feature));
		config_ap_runtime_data_v2(md, ap_rt_data);
		dump_runtime_data_v2(md, ap_rt_data);
	}
	/*when skb == null,the function is to trigger interrupt only */
#ifndef ENABLE_CCCI_DRI_UT
	ret = ccci_port_send_hif(proxy_p->ctl_port, skb, skb_from_pool, 1);
#endif
	return ret;
}

static int md_dump_info(struct ccci_modem *md,
	enum modem_dump_flag flag, void *buff, int length)
{
	if (flag & DUMP_FLAG_CTRL_HIF) {
		MTK_DEBUG_LOG(TAG, "Dump AP CTRL HIF REG\n");
		ccci_hif_dump_status(md->index,
			HIF_FLAG_CTRL, DUMP_FLAG_HIF, NULL, 0);
	}

	if (flag & DUMP_FLAG_DATA_HIF) {
		MTK_DEBUG_LOG(TAG, "Dump AP DATA HIF REG\n");
		ccci_hif_dump_status(md->index,
			HIF_FLAG_DATA, DUMP_FLAG_HIF, NULL, 0);
	}

	if (flag & DUMP_FLAG_CTRL_IRQ_STATUS) {
		MTK_DEBUG_LOG(TAG, "Dump AP CTRL IRQ status\n");
		ccci_hif_dump_status(md->index,
			HIF_FLAG_CTRL, DUMP_FLAG_IRQ_STATUS, NULL, 0);
	}

	if (flag & DUMP_FLAG_DATA_IRQ_STATUS) {
		MTK_DEBUG_LOG(TAG, "Dump AP DATA IRQ status\n");
		ccci_hif_dump_status(md->index,
			HIF_FLAG_DATA, DUMP_FLAG_IRQ_STATUS, NULL, 0);
	}

	return length;
}

int md_evt_notify_hd(struct ccci_modem *md, enum md_event_id evt_id)
{
	int ret = 0;
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md->index);
	struct md_sys1_info *md_info = (struct md_sys1_info *)md->private_data;
	unsigned int hif_id = GET_HIF_ID(md->index, HIF_PATH_EX);//EX HIF
	unsigned long flags;
	unsigned long int_sta;

	switch (evt_id) {
	case FSM_PRE_START:
		md_mhccif_mask_set(md, 1<<PORT_ENUM_SIGNAL , 0);
		break;
	case FSM_START:
		md_mhccif_mask_set(md, 1<<PORT_ENUM_SIGNAL , 1);
		spin_lock_irqsave(&md_info->exp_spinlock, flags);
		int_sta = ccci_hif_get_event_id(md->index, hif_id);
		md_info->exp_id |= int_sta;
		MTK_INFO_LIMITED_LOG(TAG, "mhccif = 0x%lx, exp_id = 0x%lx\n",
						int_sta, md_info->exp_id);
		if (md_info->exp_id & (1 << EXP_ID_EXCEPTION_INIT)) {
			atomic_set(&ctl->exp_flg, 1);
			md_info->exp_id &= ~(1 << EXP_ID_EXCEPTION_INIT);
			md_info->exp_id &= ~(1 << ASYNC_MD_HK_SIGNAL);
			md_info->exp_id &= ~(1 << ASYNC_SAP_HK_SIGNAL);
		} else if (atomic_read(&ctl->exp_flg)) {
			md_info->exp_id &= ~(1 << ASYNC_MD_HK_SIGNAL);
			md_info->exp_id &= ~(1 << ASYNC_SAP_HK_SIGNAL);
		} else {
			/*start handshake if MD not assert*/
			if (md_info->exp_id & (1 << ASYNC_SAP_HK_SIGNAL)) {
					queue_work(md->core_sap.worker, &(md->core_sap.core_work));
					md_info->exp_id &= ~(1 << ASYNC_SAP_HK_SIGNAL);
					REG_IO_WRITE32(REG_EP2RC_SW_INT_ACK(md->mtk_dev->base_addr.mhccif_rc_base),
								1 << ASYNC_SAP_HK_SIGNAL);
					md_mhccif_mask_set(md, 1 << ASYNC_SAP_HK_SIGNAL, 1);
				} else {
					/*unmask aysnc handshake interrupt*/
					md_mhccif_mask_set(md, 1<<ASYNC_SAP_HK_SIGNAL, 0);
				}

			if (md_info->exp_id & (1 << ASYNC_MD_HK_SIGNAL)) {
				queue_work(md->core_md.worker, &(md->core_md.core_work));
				md_info->exp_id &= ~(1 << ASYNC_MD_HK_SIGNAL);
				REG_IO_WRITE32(REG_EP2RC_SW_INT_ACK(md->mtk_dev->base_addr.mhccif_rc_base),
							1 << ASYNC_MD_HK_SIGNAL);
				md_mhccif_mask_set(md, 1 << ASYNC_MD_HK_SIGNAL, 1);
			} else {
				/*unmask aysnc handshake interrupt*/
				md_mhccif_mask_set(md, 1<<ASYNC_MD_HK_SIGNAL, 0);
			}
		}

		spin_unlock_irqrestore(&md_info->exp_spinlock, flags);
		/*unmask exception interrupt*/
		md_mhccif_mask_set(md, 1<<EXP_ID_EXCEPTION_INIT\
				|1<<EXP_ID_EXCEPTION_INIT_DONE\
				|1<<EXP_ID_EXCEPTION_CLEARQ_DONE\
				|1<<EXP_ID_EXCEPTION_ALLQ_RESET, 0);
		break;
	case FSM_READY:
		/*mask async handshake interrupt*/
		md_mhccif_mask_set(md, 1<<ASYNC_SAP_HK_SIGNAL\
					|1<<ASYNC_MD_HK_SIGNAL, 1);
		break;
	}
	return ret;
}
static struct ccci_modem_ops md_ops = {
	.init = &md_init,
	.uninit = &md_uninit,
	.start = &md_start,
	.stop = &md_stop,
	.pre_stop = &md_pre_stop,
	.send_runtime_data = &md_send_runtime_data_v2,
	.ee_handshake = &md_ee_handshake,
	.dump_info = &md_dump_info,
	.md_event_notify = &md_evt_notify_hd,
};

static ssize_t md_state_show(struct ccci_modem *md, char *buf)
{
	int count = 0;

	count = snprintf(buf, 256,
		"md id%d current state %d\n", \
		md->index, ccci_fsm_get_md_state(md->index));
	return count;
}

static ssize_t md_state_store(struct ccci_modem *md,
	const char *buf, size_t count)
{
	MTK_NOTICE_LOG(TAG, "write operation isn't supported\n");
	return count;
}

static ssize_t md_dump_show(struct ccci_modem *md, char *buf)
{
	int count = 0;

	count = snprintf(buf, 256,
		"support: ccif cldma register smem image layout\n");
	return count;
}

static ssize_t md_dump_store(struct ccci_modem *md,
	const char *buf, size_t count)
{
	int qno = 0; //default qno is 0

	mtk_pcie_msix_status_get(md->mtk_dev->base_addr.pcie_mac_ireg_base);
	/* echo "ctrlpath xx" ; xx present qno */
	if (strncmp(buf, "ctrlpath", 8) == 0) {
		if (count-1 > strlen("ctrlpath")) {
			/*one space between "ctrlpath" and "qno x"*/
			qno = buf[strlen("ctrlpath")+1]-'0';
			if ((qno > 7) || (qno < 0))
				qno = -1;

			MTK_DEBUG_LOG(TAG, "dump ctrl path: qno = %d\n", qno);
		}
		ccci_hif_dump_status(md->index,
			HIF_FLAG_CTRL|HIF_FLAG_CTRL_1,
			DUMP_FLAG_HIF, NULL, qno);
		}

	if (strncmp(buf, "datapath", count - 1) == 0) {
		ccci_hif_dump_status(md->index,
			HIF_FLAG_DATA, DUMP_FLAG_CLDMA, NULL, -1);
	}
	if (strncmp(buf, "mhccif", count - 1) == 0) {
		MTK_NOTICE_LOG(TAG, "control exp_id: %lx, dummy_register: %x\n",\
			ccci_hif_get_event_id(md->index, HIF_ID_PCIE),\
			ccci_dummy_register_val_get(md, 0));
	}
	return count;
}

static ssize_t md_control_show(struct ccci_modem *md, char *buf)
{
	int count = 0;

	count = snprintf(buf, 256,
		"support: datapath reset, data stop function\n");
	return count;
}

static ssize_t md_control_store(struct ccci_modem *md,
	const char *buf, size_t count)
{
	if (strncmp(buf, "datapath_reset", count - 1) == 0) {
		MTK_INFO_LOG(TAG, "reset datapath\n");
		ccci_hif_stop(md->index, HIF_FLAG_DATA);
		ccci_hif_clear_all_queue(md->index, HIF_FLAG_DATA, MTK_INOUT);
		ccci_hif_reset(md->index, HIF_FLAG_DATA, 0);
		ccci_hif_start(md->index, HIF_FLAG_DATA);
	}
	if (strncmp(buf, "datapath_stop", count - 1) == 0) {
		MTK_INFO_LOG(TAG, "stop CLDMA\n");
		ccci_hif_stop(md->index, HIF_FLAG_DATA);
	}
	return count;
}

static ssize_t md_parameter_show(struct ccci_modem *md, char *buf)
{
	int count = 0;

	count += snprintf(buf + count, 20,
		"modem parameter:\n");
	count += snprintf(buf + count, 20, "brom_dl_flag=%d\n", brom_dl_flag);
	return count;
}
static ssize_t md_parameter_store(struct ccci_modem *md,
	const char *buf, size_t count)
{
	char id = *buf-'0';
	//for change md status
	switch (id) {
	case 1:
		MTK_INFO_LOG(TAG, "set brom dl flag\n");
		brom_dl_flag = 1;
		break;
	case 2:
		MTK_INFO_LOG(TAG, "clear brom dl flag\n");
		brom_dl_flag = 0;
		break;
	default:
		break;
	}
	return count;
}

static ssize_t cldma_dbg_attr_show(struct ccci_modem *md, char *buf)
{
	return snprintf(buf, PAGE_SIZE, "%s", "CLDMA:Interrupt Mode\n");
}
static ssize_t cldma_dbg_attr_store(struct ccci_modem *md,
							const char *buf,
							size_t count)
{
	int arg = 0XFF;
	int err = 0;

	unsigned int L2TIMR0, L2RIMR0, L2TISAR0, L2RISAR0;

	struct md_cd_ctrl *cldma_ctrl = NULL;
	struct ccci_hw_ctrl *hw_ctrl = NULL;
	struct cldma_hw_info *hw_info = NULL;

	struct md_cd_queue *txq = NULL;
	struct md_cd_queue *rxq = NULL;
	struct cldma_tgpd *tgpd = NULL;
	struct cldma_rgpd *rgpd = NULL;



	cldma_ctrl = (struct md_cd_ctrl *)ccci_hif[0][HIF_ID_CLDMA0_PCIE];
	/*cldma_hw_info = (struct cldma_hw_info *)cldma_ctrl->hif_hw_info;*/
	hw_ctrl = ccci_hw_ctrl_info[0][HIF_ID_CLDMA0_PCIE];
	hw_info = (struct cldma_hw_info *)hw_ctrl->private;
	if (!cldma_ctrl || !hw_ctrl || !hw_info) {
		pr_err("No CLDMA Control, please check\n");
		goto exit;
	}

	err = kstrtoint(buf, 10, &arg);
	if (err) {
		pr_notice("invalid input\n");
		goto exit;
	}

	if (arg >= CLDMA_TXQ_NUM) {
		pr_notice("Queue number is invalid\n");
		goto exit;
	}

	txq = &cldma_ctrl->txq[arg];
	rxq = &cldma_ctrl->rxq[arg];

	tgpd = (struct cldma_tgpd *)txq->tr_done->gpd;
	rgpd = (struct cldma_rgpd *)rxq->tr_done->gpd;

	pr_notice("\n\n**L2 interrupt status:\n");
	L2TISAR0 =	cldma_hw_int_status(hw_ctrl,
		EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK, 0);
	L2RISAR0 =	cldma_hw_int_status(hw_ctrl,
		EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK, 1);
	L2TIMR0 = cldma_hw_eqirq_ismask(hw_ctrl, 0)|
		cldma_hw_txrxirq_ismask(hw_ctrl, 0);
	L2RIMR0 = cldma_hw_eqirq_ismask(hw_ctrl, 1)|
		cldma_hw_txrxirq_ismask(hw_ctrl, 1);

	pr_notice("L2TISAR0 = 0x%X, L2TIMR0 = 0x%X, TI Pending = 0x%X\n",
		L2TISAR0, L2TIMR0, (L2TISAR0 & L2TIMR0));
	pr_notice("L2RISAR0 = 0x%X, L2RIMR0 = 0x%x, RI Pending = 0x%X\n",
		L2RISAR0, L2RIMR0, (L2RISAR0 & L2RIMR0));

	pr_notice("**TX GPD:\n");
	pr_notice("TX GPD(flag) = 0x%X\n", tgpd->gpd_flags);
	pr_notice("TX HWO = 0x%X\n", tgpd->gpd_flags & 0x01);
	pr_notice("TX Transferred Length: 0x%X\n", tgpd->data_buff_len);

	pr_debug("**RX GPD:\n");
	pr_notice("RX GPD(flag) = 0x%X\n", rgpd->gpd_flags);
	pr_notice("RX HWO = 0x%X\n", rgpd->gpd_flags & 0x01);
	pr_notice("RX Received Length: 0x%X\n", rgpd->data_buff_len);


	pr_notice("CLDMA HW Registers:");
	pr_notice("CLDMA_AO_INDMA_AO_AP (0x%lX)\n",
		hw_info->cldma_phy_ao_base);
	pr_notice("CLDMA_INDMA_PD_AP (0x%lX)\n",
		hw_info->cldma_phy_pd_base);

	pr_notice("L2TISAR0  (0x%lX) = 0x%X\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2TISAR0,
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR0));
	pr_notice("L2RISAR0 (0x%lX) = 0x%X\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2RISAR0,
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR0));

	pr_notice("L2TIMR0(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2TIMR0,
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMR0));
	pr_notice("L2RIMR0(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_ao_base + REG_CLDMA_L2RIMR0,
		cldma_read32(hw_info->cldma_ap_ao_base, REG_CLDMA_L2RIMR0));

	pr_notice("L2TIMSR0,(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2TIMSR0,
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMSR0));
	pr_notice("L2RIMSR0(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_ao_base + REG_CLDMA_L2RIMSR0,
		cldma_read32(hw_info->cldma_ap_ao_base, REG_CLDMA_L2RIMSR0));

	pr_notice("L2TIMCR0(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_pd_base + REG_CLDMA_L2TIMCR0,
		cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMCR0));
	pr_notice("L2RIMCR0(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_ao_base + REG_CLDMA_L2RIMCR0,
		cldma_read32(hw_info->cldma_ap_ao_base, REG_CLDMA_L2RIMCR0));

	pr_notice("INT_EAP_USIP_MASK(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_ao_base + (0x0800+0x0160),
		cldma_read32(hw_info->cldma_ap_ao_base, (0x800 + 0x160)));
	pr_notice("BUSY_MASK(0x%lX) = 0x%X\n",
		hw_info->cldma_phy_ao_base + (0x800 + 0x154),
		cldma_read32(hw_info->cldma_ap_ao_base, (0x800 + 0x154)));

exit:
	return count;
}

CCCI_MD_ATTR(NULL, md_state, 0660, md_state_show, md_state_store);
CCCI_MD_ATTR(NULL, dump, 0660, md_dump_show, md_dump_store);
CCCI_MD_ATTR(NULL, control, 0660, md_control_show, md_control_store);
CCCI_MD_ATTR(NULL, parameter, 0660, md_parameter_show, md_parameter_store);
CCCI_MD_ATTR(NULL, cldma_debug, 0660,
	cldma_dbg_attr_show, cldma_dbg_attr_store);


static void md_sysfs_init(struct ccci_modem *md)
{
	int ret;

	ccci_md_attr_dump.modem = md;
	ret = sysfs_create_file(&md->kobj, &ccci_md_attr_dump.attr);
	if (ret)
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s %d\n",
			ccci_md_attr_dump.attr.name, ret);

	ccci_md_attr_control.modem = md;
	ret = sysfs_create_file(&md->kobj, &ccci_md_attr_control.attr);
	if (ret)
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s %d\n",
			ccci_md_attr_control.attr.name, ret);

	ccci_md_attr_parameter.modem = md;
	ret = sysfs_create_file(&md->kobj, &ccci_md_attr_parameter.attr);
	if (ret)
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s %d\n",
			ccci_md_attr_parameter.attr.name, ret);

	ccci_md_attr_cldma_debug.modem = md;
	ret = sysfs_create_file(&md->kobj, &ccci_md_attr_cldma_debug.attr);
	if (ret)
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s %d\n",
			ccci_md_attr_cldma_debug.attr.name, ret);

	ccci_md_attr_md_state.modem = md;
	ret = sysfs_create_file(&md->kobj, &ccci_md_attr_md_state.attr);
	if (ret)
		MTK_ERR_LOG(TAG, "fail to add sysfs node %s %d\n",
			ccci_md_attr_md_state.attr.name, ret);

}

static struct syscore_ops md_cldma_sysops = {
	.suspend = ccci_modem_syssuspend,
	.resume = ccci_modem_sysresume,
};


static inline void start_device(unsigned char md_id)
{
	u32 dummy_register = 0;

	struct ccci_fsm_ctl *fsm_ctl = fsm_get_entity_by_md_id(md_id);
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);

	if (fsm_ctl == NULL) {
		MTK_ERR_LOG(TAG, "fsm ctrl isn't initialized/n");
		return;
	}

	/*read PCIe Dummy Register*/
	dummy_register = ccci_dummy_register_val_get(md, 0);

	if (dummy_register == 0xffffffff) {
		MTK_ERR_LOG(TAG, "failed to read PCIe register/n");
		mtk_pci_read_pcistate_regs(md->mtk_dev);
		return;
	}

	ccci_port_init(md_id, PORT_CFG1);

	if (fsm_ctl != NULL) {
		fsm_append_command(fsm_ctl, CCCI_COMMAND_PRE_START, 0);
	}

}

static void ccci_md_structure_reset(struct ccci_modem *md)
{
	struct md_sys1_info *md_info;

	md->ops = &md_ops;
	/*initial modem private data*/
	md_info = (struct md_sys1_info *)md->private_data;
	md_info->exp_id = 0;
	spin_lock_init(&md_info->exp_spinlock);
	atomic_set(&md_info->md_ex_irq_enabled, 1);
	atomic_set(&md->reset_on_going, 1);
	/* IRQ is default enabled after request_irq */
	atomic_set(&md->wdt_enabled, 1);
}


static void ccci_md_structure_init(struct ccci_modem *md, struct ccci_dev_cfg *dev_cfg)
{
	md->index = dev_cfg->index;
	md->per_md_data.md_capability = dev_cfg->capability;
	ccci_md_structure_reset(md);
}

int ccci_pci_event_callback(u32 event, void *data)
{
	int ret = 0;
	struct mtk_pci_dev *mtk_dev = data;
	struct ccci_modem *md;
	struct ccci_fsm_ctl *fsm_ctl;

	if (unlikely(data == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid Arguments\n");
		return -EINVAL;
	}

	md = mtk_dev->ccci_md;
	fsm_ctl = fsm_get_entity_by_md_id(md->index);

	switch (event) {
	case __PCIE_EVENT_L3ENTER:
		MTK_INFO_LOG(TAG, "PCI L3ENTER EVENT\n");
		ret = fsm_append_command(fsm_ctl, CCCI_COMMAND_STOP, 1);
		break;
	case __PCIE_EVENT_L3EXIT:
		MTK_INFO_LOG(TAG, "PCI L3EXIT EVENT\n");
		mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, true);
		mtk_pcie_clr_ext_int_sts(mtk_dev, SAP_RGU_INT);
		atomic_set(&mtk_dev->rgu_pci_irq_en, 1);
		mtk_pcie_set_ext_int_mask(mtk_dev, SAP_RGU_INT, false);
		ret = fsm_append_command(fsm_ctl, CCCI_COMMAND_PRE_START, 0);
		break;
	default:
		MTK_INFO_LOG(TAG, "Unknow PCI event\n");
		break;
	}
	return ret;
}


int ccci_modem_reset(struct mtk_pci_dev *mtk_dev)
{
	int md_id;
	struct ccci_modem *md;
	//struct ccci_dev_cfg dev_cfg;
	struct ccci_fsm_ctl *fsm_ctl;

	if (unlikely(mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid arguments");
		return -EINVAL;
	}
	md = mtk_dev->ccci_md;
	ccci_md_reset(md);

	//need reget hw info?
	//err = md_get_mdsys1_hw_info(mtk_dev, &dev_cfg, md);
	ccci_md_structure_reset(md);

	md->mtk_dev = mtk_dev;
	ccci_md_register_reset(md);
	ccci_hif_reset(md->index, HIF_FLAG_CTRL_DATA, 0);//reset hif queue
	port_reset(md->index);

	/* hook up to device */
	mtk_dev->ccci_md = md;
	md->md_init_finish = 1;

	md_id = MD_SYS1;
	fsm_ctl = fsm_get_entity_by_md_id(md_id);
	MTK_INFO_LOG(TAG, "ccci modem reset done.\n");

	core_reset(&md->core_md);
	core_reset(&md->core_sap);
	return 0;
}

int ccci_modem_init(struct mtk_pci_dev *mtk_dev)
{
	struct ccci_modem *md;
	int md_id;
	struct ccci_dev_cfg dev_cfg;
	int err;
#ifdef CCCI_CTL_TRACE
	unsigned char trace_log[TRACE_LOG_LEN] = {0};

	snprintf(trace_log, TRACE_LOG_LEN,
		"ccci modem probe in.");
	trace_ccci_modem_probe(trace_log);
#endif /* CCCI_CTL_TRACE */
	/* Allocate md ctrl memory and do initialize */
	md = ccci_md_alloc(sizeof(struct md_sys1_info));
	if (md == NULL) {
		MTK_ERR_LOG(TAG,
			"failed to alloc memory for modem ctrl structure\n");
		return -1;
	}
	//get hw info from dts file,get hw info from dts file.
	//need to call hif init
	err = md_get_mdsys1_hw_info(mtk_dev, &dev_cfg, md);
	if (err) {
		MTK_ERR_LOG(TAG, "failed to get hw info, err:%d\n", err);
		kfree(md);
		return -1;
	}
#ifdef CCCI_CTL_TRACE
	memset(trace_log, 0, TRACE_LOG_LEN);
	snprintf(trace_log, TRACE_LOG_LEN, "md_get_mdsys1_hw_info ret:%d", err);
	trace_ccci_modem_probe(trace_log);
#endif /* CCCI_CTL_TRACE */
	/* initialize md ctrl block*/
	ccci_md_structure_init(md, &dev_cfg);
	ccci_md_register(md);

	md_id = dev_cfg.index;

#ifndef M7X
	/* init the data path */
	ccmni_init(md_id, mtk_dev);
#endif

	/* init HIF */
	ccci_hif_init(md_id, HIF_FLAG_CTRL_DATA);
	ccci_hif_init(md_id, HIF_FLAG_EX);
	/* register SYS CORE suspend resume call back */
	register_syscore_ops(&md_cldma_sysops);
	/* add sysfs entries */
	md_sysfs_init(md);
	/* hook up to device */
	md->mtk_dev = mtk_dev;
	mtk_dev->ccci_md = md;
	start_device(md_id);
	md_sys1_sw_init(md);
	/* register event callback to PCIE */
	mtk_pcie_register_event_callback(mtk_dev,
				ccci_pci_event_callback, (void *)mtk_dev);

	md->md_init_finish = 1;
	return 0;
}

int ccci_modem_exit(struct mtk_pci_dev *mtk_dev)
{
	struct ccci_fsm_ctl *fsm_ctl;
	struct ccci_modem *md = (struct ccci_modem *)(mtk_dev->ccci_md);


	fsm_ctl = fsm_get_entity_by_md_id(md->index);

	if (md && md->md_init_finish) {
		//change fsm state, stopping will auto jump to stopped
		fsm_append_command(fsm_ctl, CCCI_COMMAND_PRE_STOP, 1);
		//fsm_append_command(fsm_ctl, CCCI_COMMAND_STOP, 1);

#ifndef M7X
		/* remove the data path */
		ccmni_exit(md->index, mtk_dev);
#endif

		MTK_INFO_LOG(TAG, "ccci modem unregister.\n");
		ccci_md_unregister(md);

		unregister_syscore_ops(&md_cldma_sysops);
		MTK_INFO_LOG(TAG, "ccci hif exit.\n");
		ccci_hif_uninit(md->index, HIF_FLAG_CTRL_DATA);
		ccci_hif_uninit(md->index, HIF_FLAG_EX);
	}

	if (md && md->private_data) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(md->private_data);
#else		
		kzfree(md->private_data);
#endif		
		md->private_data = NULL;
	}

	if (md) {
		md->mtk_dev->ccci_md = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(md);
#else			
		kzfree(md);
#endif		
		modem_sys[0] = NULL;
	}
	return 0;
}

