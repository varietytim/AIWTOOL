// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_fsm_internal.h"
#include "port_proxy.h"

void mdee_set_ex_start_str(struct ccci_fsm_ee *ee_ctl,
	unsigned int type, char *str)
{
	u64 ts_nsec;
	unsigned long rem_nsec;

	ts_nsec = local_clock();
	rem_nsec = do_div(ts_nsec, 1000000000);
	snprintf(ee_ctl->ex_start_time,
		MD_EX_START_TIME_LEN, "Host detect handshake timeout:%5lu.%06lu\n",
		(unsigned long)ts_nsec, rem_nsec / 1000);
	MTK_NOTICE_LOG(FSM, "%s\n", ee_ctl->ex_start_time);
}

void fsm_md_bootup_timeout_handler(struct ccci_fsm_ee *ee_ctl)
{
	MTK_INFO_LOG(FSM, "Dump control channel\n");
	ccci_md_dump_info(ee_ctl->md_id,
		(DUMP_FLAG_QUEUE_0_1 | DUMP_MD_BOOTUP_STATUS |
		DUMP_FLAG_REG | DUMP_FLAG_CTRL_HIF), NULL, 0);
	MTK_INFO_LOG(FSM, "Dump MD ee boot failed info\n");
	ee_ctl->ops->dump_ee_info(ee_ctl, MDEE_DUMP_LEVEL_BOOT_FAIL, 0);
}

void fsm_md_exception_stage(struct ccci_fsm_ee *ee_ctl, int stage)
{
	unsigned long flags;

	if (stage == 0) { /* handshake fail */
		mdee_set_ex_start_str(ee_ctl, 0, NULL);
		ee_ctl->mdlog_dump_done = 0;
		ee_ctl->ee_info_flag = 0;
		spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
		ee_ctl->ee_info_flag |= (MD_EE_FLOW_START | MD_EE_SWINT_GET);
		if (ccci_fsm_get_md_state(ee_ctl->md_id) ==
			BOOT_WAITING_FOR_HS1)
			ee_ctl->ee_info_flag |= MD_EE_DUMP_IN_GPD;
		spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);
		/* set ex_flag */
		ee_ctl->ex_flag = 1;
	} else if (stage == 1) { /* got MD_EX_REC_OK or first timeout */
		int ee_case;
		unsigned int ee_info_flag = 0;
		unsigned int md_dump_flag = 0;
		int md_id = ee_ctl->md_id;

		MTK_INFO_LOG(FSM, "MD exception dump stage 1:start\n");
		MTK_DEBUG_LOG(FSM,
			"MD exception stage 1! ee=%x\n", ee_ctl->ee_info_flag);
		spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
		ee_info_flag = ee_ctl->ee_info_flag;
		spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);

		/* check the MD_EE type */
		if ((ee_info_flag & (MD_EE_SWINT_GET |
			MD_EE_MSG_GET | MD_EE_OK_MSG_GET)) ==
			(MD_EE_SWINT_GET | MD_EE_MSG_GET | MD_EE_OK_MSG_GET)) {
			ee_case = MD_EE_CASE_NORMAL;
			MTK_INFO_LOG(FSM,
				"Recv SWINT & MD_EX & MD_EX_REC_OK\n");
		} else if (ee_info_flag & MD_EE_MSG_GET) {
			ee_case = MD_EE_CASE_ONLY_EX;
			MTK_INFO_LOG(FSM, "Only recv MD_EX.\n");
		} else if (ee_info_flag & MD_EE_SWINT_GET) {
			ee_case = MD_EE_CASE_ONLY_SWINT;
			MTK_INFO_LOG(FSM, "Only recv SWINT.\n");
		} else if (ee_info_flag & MD_EE_PENDING_TOO_LONG) {
			ee_case = MD_EE_CASE_NO_RESPONSE;
		} else if (ee_info_flag & MD_EE_WDT_GET) {
			ee_case = MD_EE_CASE_WDT;
		} else {
			MTK_ERR_LOG(FSM,
				"Invalid MD_EX, ee_info=%x\n", ee_info_flag);
			goto _dump_done;
		}
		ee_ctl->ee_case = ee_case;

		/* Dump MD register */
		MTK_INFO_LOG(FSM, "dump HIF REGS in ONLY_SWINT.\n");
		if (ee_case == MD_EE_CASE_ONLY_SWINT)
			md_dump_flag |=
				(DUMP_FLAG_QUEUE_0 | DUMP_FLAG_CTRL_HIF);
		ccci_md_dump_info(md_id, md_dump_flag, NULL, 0);

		MTK_INFO_LOG(FSM, "dump HIF REGS in NO_RESPONSE.\n");
		if (ee_case == MD_EE_CASE_NO_RESPONSE)
			ccci_md_dump_info(md_id, DUMP_FLAG_CTRL_HIF, NULL, 0);
		MTK_ERR_LOG(FSM, "MD exception stage 1: end\n");
_dump_done:
		return;
	} else if (stage == 2) { /* got MD_EX_PASS or second timeout */
		int md_id = ee_ctl->md_id;
		unsigned long flags;
		int md_wdt_ee = 0;
		unsigned int md_dump_flag = 0;

		MTK_INFO_LOG(FSM, "MD exception stage 2: start\n");
		MTK_DEBUG_LOG(FSM,
			"MD exception stage 2! ee=%x\n", ee_ctl->ee_info_flag);

		spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
		if (MD_EE_WDT_GET & ee_ctl->ee_info_flag)
			md_wdt_ee = 1;
		spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);

		/* Dump MD register, only NO response case dump */
		MTK_INFO_LOG(FSM,
			"dump MD regs in NO_FRESPONSE, dump HIF regs in ON_SWINT\n");
		if (md_id == MD_SYS1 ||
			ee_ctl->ee_case == MD_EE_CASE_NO_RESPONSE)
			md_dump_flag = DUMP_FLAG_REG;
		if (ee_ctl->ee_case == MD_EE_CASE_ONLY_SWINT)
			md_dump_flag |=
				(DUMP_FLAG_QUEUE_0 | DUMP_FLAG_CTRL_HIF);
		ccci_md_dump_info(md_id, md_dump_flag, NULL, 0);

		/* check this first, as we overwrite share memory here */
		MTK_INFO_LOG(FSM, "dump HIF REGS in NO_RESPONSE.\n");
		if (ee_ctl->ee_case == MD_EE_CASE_NO_RESPONSE)
			ccci_md_dump_info(md_id, DUMP_FLAG_CTRL_HIF, NULL, 0);

		MTK_ERR_LOG(FSM, "MD exception stage 2: end\n");
		spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
		// this flag should be the last action of a
		//regular exception flow, clear flag for reset MD later
		ee_ctl->ee_info_flag = 0;
		spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);
	}
}
/*the handling will be implemented in the future(M80)*/
void fsm_md_wdt_handler(struct ccci_fsm_ee *ee_ctl)
{

}

void fsm_ee_message_handler(struct ccci_fsm_ee *ee_ctl, struct sk_buff *skb)
{
	struct ccci_fsm_ctl *ctl =
		container_of(ee_ctl, struct ccci_fsm_ctl, ee_ctl);
	struct ctrl_msg_header *ctrl_msg_h = (struct ctrl_msg_header *)skb->data;
	unsigned long flags;
	enum MD_STATE md_state = ccci_fsm_get_md_state(ee_ctl->md_id);

	if (md_state != EXCEPTION) {
		MTK_ERR_LOG(FSM,
			"receive invalid MD_EX %x when MD state is %d\n",
			ctrl_msg_h->reserved, md_state);
		return;
	}
	if (ctrl_msg_h->ctrl_msg_id == CTL_ID_MD_EX) {
		if (unlikely(ctrl_msg_h->reserved != MD_EX_CHK_ID)) {
			MTK_ERR_LOG(FSM,
				"receive invalid MD_EX %x\n", ctrl_msg_h->reserved);
		} else {
			spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
			ee_ctl->ee_info_flag |=
				(MD_EE_FLOW_START | MD_EE_MSG_GET);
			spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);
			ccci_port_send_msg_to_md(
				ee_ctl->md_id, CCCI_CONTROL_TX,
				CTL_ID_MD_EX, MD_EX_CHK_ID, 1);
			fsm_append_event(ctl, CCCI_EVENT_MD_EX, NULL, 0);
		}
	} else if (ctrl_msg_h->ctrl_msg_id == CTL_ID_MD_EX_REC_OK) {
		if (unlikely(ctrl_msg_h->reserved != MD_EX_REC_OK_CHK_ID)) {
			MTK_ERR_LOG(FSM,
				"receive invalid MD_EX_REC_OK %x\n",
				ctrl_msg_h->reserved);
		} else {
			spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
			ee_ctl->ee_info_flag |=
				(MD_EE_FLOW_START | MD_EE_OK_MSG_GET);
			spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);
			/* Keep exception info package from MD*/
			if (ee_ctl->ops->set_ee_pkg)
				ee_ctl->ops->set_ee_pkg(ee_ctl,
					skb_pull(skb,
					sizeof(struct ctrl_msg_header)),
					skb->len - sizeof(struct ctrl_msg_header));

			fsm_append_event(ctl, CCCI_EVENT_MD_EX_REC_OK, NULL, 0);
		}
	} else if (ctrl_msg_h->ctrl_msg_id == CTL_ID_MD_EX_PASS) {
		spin_lock_irqsave(&ee_ctl->ctrl_lock, flags);
		ee_ctl->ee_info_flag |= MD_EE_PASS_MSG_GET;
		spin_unlock_irqrestore(&ee_ctl->ctrl_lock, flags);
		fsm_append_event(ctl, CCCI_EVENT_MD_EX_PASS, NULL, 0);
	} else if (ctrl_msg_h->ctrl_msg_id == CCCI_DRV_VER_ERROR) {
		MTK_ERR_LOG(FSM, "AP/MD driver version mis-match\n");
	}
}

int fsm_check_ee_done(struct ccci_fsm_ee *ee_ctl, int timeout)
{
	int count = 0;
	bool is_ee_done = 0;
	int time_step = 200; /*ms*/
	int loop_max = timeout * 1000 / time_step;
	struct ccci_modem *md = ccci_md_get_modem_by_id(ee_ctl->md_id);

	MTK_INFO_LOG(FSM, "checking EE status,state:%d\n",
		ccci_fsm_get_md_state(ee_ctl->md_id));
	while (ccci_fsm_get_md_state(ee_ctl->md_id) == EXCEPTION) {
		if (ccci_port_get_critical_user(ee_ctl->md_id,
			CRIT_USR_MDLOG)) {
			MTK_INFO_LOG(FSM,
				"MD logger is running, waiting for EE dump done\n");
			is_ee_done = !(ee_ctl->ee_info_flag & MD_EE_FLOW_START)
				&& ee_ctl->mdlog_dump_done;
		} else
			is_ee_done = !(ee_ctl->ee_info_flag & MD_EE_FLOW_START);
		if (!is_ee_done && atomic_read(&md->rgu_irq_assered) == 0) {
			msleep(time_step);
			count++;
		} else
			break;

		if (loop_max && (count > loop_max)) {
			MTK_ERR_LOG(FSM, "wait EE done timeout\n");
			return -1;
		}
	}
	MTK_INFO_LOG(FSM, "check EE done,count %d\n", count);
	return 0;
}

int fsm_ee_reset(struct ccci_fsm_ee *ee_ctl)
{
	struct ccci_fsm_ctl *ctl =
		container_of(ee_ctl, struct ccci_fsm_ctl, ee_ctl);
	int ret = 0;

	ee_ctl->md_id = ctl->md_id;
	ee_ctl->port_en = 0;
	/*port time default align BOOTMISC0_CCCI_TIMEOUT (61)*/
	ee_ctl->port_maintain_sec = 61;
	ee_ctl->ex_flag = 0;
	ee_ctl->ex_buff = NULL;
	return ret;
}


int fsm_ee_init(struct ccci_fsm_ee *ee_ctl)
{
	int ret = 0;

	fsm_ee_reset(ee_ctl);
	spin_lock_init(&ee_ctl->ctrl_lock);
	ret = mdee_dumper_v3_alloc(ee_ctl);
	return ret;
}

int fsm_ee_uninit(struct ccci_fsm_ee *ee_ctl)
{
	mdee_dumper_v3_free(ee_ctl);
	return 0;
}
