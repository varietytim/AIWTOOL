/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MD_SYS1_PLATFORM_H__
#define __MD_SYS1_PLATFORM_H__

#include <linux/skbuff.h>
#include <mt_reg_base.h>
#include "modem_sys.h"

extern unsigned int mod_param_val;

/* this is the platform header file for CLDMA MODEM, not just CLDMA! */
#define SEC_AO_BASE_M  SECURITY_AO_BASE//0x1001A000

#define AP_REMAP_ADDR_FOR_MD_CLDMA 0xA0000000

/* Modem WDT */
/* BASE_ADDR_MDRSTCTL+ */
#define REG_MDRSTCTL_WDTCR            (0x0000) /*WDT_MODE*/
#define REG_MDRSTCTL_WDTRR            (0x0010) /*WDT_RESTART*/
#define REG_MDRSTCTL_WDTIR            (0x023C) /*LENGTH*/
#define REG_MDRSTCTL_WDTSR            (0x0034) /*WDT_STATUS*/
#define WDT_MD_MODE		REG_MDRSTCTL_WDTCR
#define WDT_MD_LENGTH           REG_MDRSTCTL_WDTIR
#define WDT_MD_RESTART          REG_MDRSTCTL_WDTRR
#define WDT_MD_STA              REG_MDRSTCTL_WDTSR
#define WDT_MD_MODE_KEY	        (0x55000030)
/* L1_BASE_ADDR_L1RGU+ */
#define REG_L1RSTCTL_WDT_MODE         (0x0000)
#define REG_L1RSTCTL_WDT_LENGTH       (0x0004)
#define REG_L1RSTCTL_WDT_RESTART      (0x0008)
#define REG_L1RSTCTL_WDT_STA          (0x000C)
#define REG_L1RSTCTL_WDT_SWRST        (0x001C)
#define L1_WDT_MD_MODE_KEY	(0x00002200)

/* MD1 PLL */
/* MD_CLKSW_BASE+ */
#define R_CLKSEL_CTL			(0x0024)
/*Bit 17: RF1_CKSEL, Bit 16: INTF_CKSEL, Bit 15: MD2G_CKSEL, Bit 14: DFE_CKSEL
 * Bit 13: CMP_CKSEL, Bit 12: ICC_CKSEL, Bit 11: IMC_CKSEL,  Bit 10: EQ_CKSEL
 * Bit  9: BRP_CKSEL, Bit 8: L1MCU_CKSEL, Bit 6-5: ATB_SRC_CKSEL,
 * Bit  4: ATB_CKSEL, Bit 3: DBG_CKSEL, Bit   2: ARM7_CKSEL
 * Bit  1: PSMCU_CKSEL,  Bit 0: BUS_CKSEL
 */
#define R_FLEXCKGEN_SEL0	(0x0028)
/* Bit  29-28: EQ_CLK src = EQPLL
 *	Bit  26-24: EQ+DIVSEL, divided-by bit[2:0]+1
 *	Bit  21-20: BRP_CLK src = IMCPLL
 *	Bit  13-12: ARM7_CLK src = DFEPLL
 *	Bit  5-4: BUS_CLK src = EQPLL
 *	Bit  2-0: BUS_DIVSEL, divided-by bit[2:0]+1
 */
#define R_FLEXCKGEN_SEL1		(0x002C)
#define R_FLEXCKGEN_SEL2		(0x0044)
/* Bit  0: PSMCUPLL_RDY, Bit  1: L1MCUPLL_RDY */
#define R_PLL_STS			(0x0040)
#define R_FLEXCKGEN_STS0		(0x0030)
	/* Bit  31: EQ_CK_RDY */
	/* Bit  23: BRP_CK_RDY */
	/* Bit  7: BUS_CK_RDY */
#define R_FLEXCKGEN_STS1		(0x0034)
/*  Bit  31: DFE_CK_RDY
 *	Bit  23: CMP_CK_RDY
 *	Bit  15: ICC_CK_RDY
 *	Bit  7:  IMC_CK_RDY
 */
#define R_FLEXCKGEN_STS2		(0x0048)
	/* Bit  15: INTF_CK_RDY, Bit  23: MD2G_CK_RDY */
/* PSMCU DCM: MD_GLOBAL_CON_DCM_BASE+ */
/* Bit 26-20: DBC_CNT, Bit 16-12: IDLE_FSEL, Bit 2: DBC_EN, Bit 1: DCM_EN */
#define R_PSMCU_DCM_CTL0		(0x0010)
/* Bit 5: APB_LOAD_TOG, Bit 4-0: APB_SEL */
#define R_PSMCU_DCM_CTL1		(0x0014)
/* MD_GLOBAL_CON_DCM_BASE+ */
/* Bit 26-20: DBC_CNT, Bit 16-12: IDLE_FSEL, Bit 2: DBC_EN, Bit 1: DCM_EN */
#define R_ARM7_DCM_CTL0			(0x0020)
#define R_ARM7_DCM_CTL1  (0x0024) /* Bit5: APB_LOAD_TOG, Bit 4-0: APB_SEL */
#define MD_GLOBAL_CON_DUMMY		(0x1000)
#define MD_PLL_MAGIC_NUM		(0x67550000)
/* MDSYS_CLKCTL_BASE+ */
#define R_DCM_SHR_SET_CTL		(0x0004)
/*  Bit  16: BUS_PLL_SWITCH
 *	Bit  15: BUS_QUARTER_FREQ_SEL
 *	Bit  14: BUS_SLOW_FREQ
 *	Bit 12-8: HFBUS_SFSEL
 *	Bit   4-0: HFBUS_FSEL
 */
#define R_LTEL2_BUS_DCM_CTL		(0x0010)
#define R_MDDMA_BUS_DCM_CTL		(0x0014)
#define R_MDREG_BUS_DCM_CTL		(0x0018)
#define R_MODULE_BUS2X_DCM_CTL		(0x001C)
#define R_MODULE_BUS1X_DCM_CTL		(0x0020)
#define R_MDINFRA_CKEN			(0x0044)
/* Bit 31: PSPERI_MAS_DCM_EN
 *	Bit  30: PSPERI_SLV_DCM_EN
 *	Bit  4: SOE_CKEN
 *	Bit  3: BUSREC_CKEN
 *	Bit  2: BUSMON_CKEN
 *	Bit  1: MDUART2_CKEN
 *	Bit  0: MDUART1_CKEN
 */
#define R_MDPERI_CKEN			(0x0048)
/* Bit 31: MDDBGSYS_DCM_EN
 *	Bit  21: USB0_LINK_CK_SEL
 *	Bit  20: USB1_LINK_CK_SEL
 *	Bit  17: TRACE_CKEN
 *	Bit  16: MDPERI_MISCREG_CKEN
 *	Bit  15: PCCIF_CKEN
 *	Bit  14: MDEINT_CKEN
 *	Bit  13: MDCFGCTL_CKEN
 *	Bit  12: MDRGU_CKEN
 *	Bit  11: A7OST_CKEN
 *	Bit  10: MDOST_CKEN
 *	Bit  9: MDTOPSM_CKEN
 *	Bit  8: MDCIRQ_CKEN
 *	Bit  7: MDECT_CKEN
 *	Bit  6: USIM2_CKEN
 *	Bit  5: USIM1_CKEN
 *	Bit  4: GPTMLITE_CKEN
 *	Bit  3: MDGPTM_CKEN
 *	Bit  2: I2C_CKEN
 *	Bit  1: MDGDMA_CKEN
 *	Bit  0: MDUART0_CKEN
 */
#define R_MDPERI_DCM_MASK		(0x0064)
/* Bit  12: MDRGU_DCM_MASK
 *	Bit  11: A7OST_DCM_MASK
 *	Bit  10: MDOST_DCM_MASK
 *	Bit  9: MDTOPSM_DCM_MASK
 */
#define R_PSMCU_AO_CLK_CTL		(0x00C0)
/* MD_PERI_MISC_BASE+ */
#define R_L1_PMS			(0x00C4)
/* PMDL1A0_BASE+ */
/* Bit 7: 0: clock do not from PLL, 1: clock from PLL */
#define REG_DCM_PLLCK_SEL	(0x0188)
#define R_L1MCU_PWR_AWARE		(0x0190)
#define R_L1AO_PWR_AWARE		(0x0194)
#define R_BUSL2DCM_CON3			(0x0198)
#define R_L1MCU_DCM_CON2		(0x0184)
#define R_L1MCU_DCM_CON			(0x0180)
/* ap_mixed_base+ */
#define AP_PLL_CON0	0x0	 /*((UINT32P)(APMIXED_BASE+0x0))*/
#define MDPLL1_CON0  0x3A0	/*((UINT32P)(APMIXED_BASE+0x02C8))*/


/*dpmaif regs, only for M70*/
#define DPMAIF_CLK_CFG_UPDATE (0x10000004)
#define DPMAIF_CLK_CFG_3 (0x10000070)
#define DPMAIF_CLK_MASK (0x07)
#define DPMAIF_CLK_OFST (16)
#define DPMAIF_CLK_SEL (0x05)
#define DPMAIF_CLK_UPDATE (1 << 14)
#define DPMAIF_BAT_CACHE_PRI (1 << 22)

#define TOPRGUWDT_MODE					(TOPRGU_BASE)//0x10007000
#define TOPRGUWDT_SWRST					(TOPRGU_BASE + 0X014)//0X10007014
#define TOPRGUWDT_NONRST_REG			(TOPRGU_BASE + 0X020)//0X10007020
#define TOPRGUWDT_LATCH_CTL2			(TOPRGU_BASE + 0X048) //0X10007048
#define TOPRGUTOPRGU_CH_PCIE_IRQ_STA	(TOPRGU_BASE + 0X90C)//0X1000790C

#define TOPRGU_RESET_KEY				(0x1209)
#define rgu_write32(b, a, v)		mt_reg_sync_writel(v, (b)+(a))
#define rgu_read32(b, a)	ioread32((void __iomem *)((b)+(a)))


struct ccci_clk_node {
	struct clk *clk_ref;
	unsigned char *clk_name;
};

struct md_pll_reg {
	void __iomem *md_top_clkSW;
	void __iomem *md_dcm;
	void __iomem *md_peri_misc;
	void __iomem *md_L1_a0;
	void __iomem *md_top_Pll;
	void __iomem *md_sys_clk;
	/*void __iomem *md_l1_conf;*/
	/* the follow is used for dump */
	void __iomem *md_dbg_sys;
	void __iomem *md_pc_mon1;
	void __iomem *md_pc_mon2;
	void __iomem *md_clkSW;
	void __iomem *md_clkSw0;
	void __iomem *md_clkSw1;
	void __iomem *md_clkSw2;
	void __iomem *md_clkSw3;
	void __iomem *md_pll_mixed_0;
	void __iomem *md_pll_mixed_1;
	void __iomem *md_pll_mixed_2;
	void __iomem *md_pll_mixed_3;
	void __iomem *md_pll_mixed_4;
	void __iomem *md_pll_mixed_5;
	void __iomem *md_pll_mixed_6;
	void __iomem *md_pll_mixed_7;
	void __iomem *md_pll_mixed_8;
	void __iomem *md_pll_mixed_9;
	void __iomem *md_pll_mixed_A;
	void __iomem *md_clk_ctl_0;
	void __iomem *md_clk_ctl_1;
	void __iomem *md_clk_ctl_2;
	void __iomem *md_clk_ctl_3;
	void __iomem *md_global_con_0;
	void __iomem *md_global_con_1;
	void __iomem *md_global_con_2;
	void __iomem *md_global_con_3;
	void __iomem *md_global_con_4;
	void __iomem *md_global_con_5;
	void __iomem *md_bus_reg_0;
	void __iomem *md_bus_reg_1;
	void __iomem *md_bus_reg_2;
	void __iomem *md_bus_reg_3;
	void __iomem *md_bus_reg_4;
	void __iomem *md_bus_rec_0;
	void __iomem *md_bus_rec_1;
	void __iomem *md_bus_rec_2;
	void __iomem *md_ect_0;
	void __iomem *md_ect_1;
	void __iomem *md_ect_2;
	void __iomem *md_ect_3;
	void __iomem *md_topsm_reg;
	void __iomem *md_rgu_reg_0;
	void __iomem *md_rgu_reg_1;
	void __iomem *md_ost_status;
	void __iomem *md_csc_reg;
	void __iomem *md_elm_reg;

	void __iomem *md_boot_stats0;
	void __iomem *md_boot_stats1;

	void __iomem *md_coretracer_base;
};

struct md_sys1_info {
		unsigned long exp_id;
		spinlock_t exp_spinlock;
		atomic_t md_ex_irq_enabled;
		unsigned int md_ex_irq_id;
		unsigned long md_ex_irq_flags;

		void __iomem *md_rgu_base;
		void __iomem *l1_rgu_base;
		void __iomem *md_global_con0;

#ifdef MD_PEER_WAKEUP
		void __iomem *md_peer_wakeup;
#endif
		void __iomem *md_bus_status;
		void __iomem *md_pc_monitor;
		void __iomem *md_topsm_status;
		void __iomem *md_ost_status;
		void __iomem *md_pll;
		struct md_pll_reg *md_pll_base;

		void __iomem *md_boot_slave_Vector;
		void __iomem *md_boot_slave_Key;
		void __iomem *md_boot_slave_En;

		void __iomem *ap_topclkgen_base;//[new]
		unsigned __iomem *ap_mixed_base;//[new]
};

enum STA_SPM_POWER {
	sta_power_on = 0,
	sta_power_off = 1
};

#define UNGATE_ADDRESS 0x20061100

int md_power_on(struct ccci_modem *md);
int md_power_off(struct ccci_modem *md, unsigned int timeout);
int md_soft_power_off(struct ccci_modem *md, unsigned int mode);
int md_soft_power_on(struct ccci_modem *md, unsigned int mode);
int md_let_md_go(struct ccci_modem *md);
void md_mhccif_mask_set(struct ccci_modem *md, u32 bitmask, bool ismask);
void md_dump_debug_register(struct ccci_modem *md);
int md_get_mdsys1_hw_info(struct mtk_pci_dev *mtk_dev,
	struct ccci_dev_cfg *dev_cfg, struct ccci_modem *md);
/* ADD_SYS_CORE */
int ccci_modem_syssuspend(void);
void ccci_modem_sysresume(void);
u32 ccci_dummy_register_val_get(struct ccci_modem *md, int n);
void ccci_dummy_register_val_write(struct ccci_modem *md, int n);

#endif				/* __CLDMA_PLATFORM_H__ */
