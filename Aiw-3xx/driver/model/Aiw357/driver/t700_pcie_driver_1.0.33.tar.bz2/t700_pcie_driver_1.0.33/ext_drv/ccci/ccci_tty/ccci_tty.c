// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/device.h>
#include <linux/serial.h>
#include <linux/tty.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/tty_flip.h>
#include <linux/version.h>
#include "ccci_tty.h"
#include "ccci_debug.h"


static struct tty_ctl_block *g_tty_ctl_blk[MAX_MD_NUM] = {0};
static struct tty_port_operations null_ops = {};

static int get_md_id_by_tty_driver(struct tty_driver *drv)
{
	int i = 0;
	int md_id = -1;
	struct tty_ctl_block *p_ctl = NULL;

	for (i = 0; i < MAX_MD_NUM; i++) {
		p_ctl = g_tty_ctl_blk[i];
		if ((p_ctl != NULL) && (p_ctl->driver == drv))
			md_id = i;
	}

	return md_id;
}

static int ccci_tty_open(struct tty_struct *tty, struct file *filp)
{
	int ret = 0;
	int tty_id = 0;
	struct tty_port *pport = NULL;
	struct tty_driver *drv = NULL;

	MTK_DEBUG_LOG(TTY, "open:%d, %p\n", tty->index, tty->driver);
	drv = tty->driver;
	tty_id = tty->index;
	pport = drv->ports[tty_id];
	if(pport)
		ret = tty_port_open(pport, tty, filp);

	return ret;
}

static void ccci_tty_close(struct tty_struct *tty, struct file *filp)
{
	int tty_id = 0;
	struct tty_port *pport = NULL;
	struct tty_driver *drv = NULL;

	MTK_DEBUG_LOG(TTY, "close:%d, %p\n", tty->index, tty->driver);
	drv = tty->driver;
	tty_id = tty->index;
	pport = drv->ports[tty_id];
	if(pport)
		tty_port_close(pport, tty, filp);
}

static int ccci_tty_write(struct tty_struct *tty,
	const unsigned char *buf, int count)
{
	int ret = 0;
	int md_id = 0;
	struct tty_ctl_block *ctlb = NULL;

	MTK_DEBUG_LOG(TTY, "write:%d, %p\n", tty->index, tty->driver);
	md_id = get_md_id_by_tty_driver(tty->driver);
	if (md_id < 0) {
		MTK_ERR_LOG(TTY, "tty write err:%d, %p\n",
			tty->index, tty->driver);
		goto err;
	}
	ctlb = g_tty_ctl_blk[md_id];

	/*send data*/
	ret = ctlb->ccci_ops->send_pkt(md_id, tty->index, buf, count);
	if (ret < 0)
		MTK_ERR_LOG(TTY, "tty write err, ret=%d\n", ret);

err:
	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
static unsigned int ccci_tty_write_room(struct tty_struct *tty)
#else
static int ccci_tty_write_room(struct tty_struct *tty)
#endif
{
	return CCCI_MTU;
}

static const struct tty_operations ccci_serial_ops = {
	.open = ccci_tty_open,
	.close = ccci_tty_close,
	.write = ccci_tty_write,
	.write_room = ccci_tty_write_room,
};

int ccci_tty_port_create(int md_id, int minor, char *port_name)
{
	struct tty_ctl_block *ctlb = NULL;
	struct tty_driver *tty_drv = NULL;
	struct tty_port *pport = NULL;
	int ret = 0;

	ctlb = g_tty_ctl_blk[md_id];
	tty_drv = ctlb->driver;

	tty_drv->name = port_name;

	pport = kzalloc(sizeof(struct tty_port), GFP_KERNEL);
	tty_port_init(pport);
	pport->ops = &null_ops;
	tty_port_link_device(pport, tty_drv, minor);
	tty_register_device(tty_drv, minor, NULL);
	return ret;
}

int ccci_tty_port_destroy(int md_id, int minor)
{
	struct tty_ctl_block *ctlb = NULL;
	struct tty_driver *tty_drv = NULL;
	struct tty_port *pport = NULL;
	struct tty_struct *tty;
	int ret = 0;

	ctlb = g_tty_ctl_blk[md_id];
	tty_drv = ctlb->driver;

	pport = tty_drv->ports[minor];
	if (!pport) {
		MTK_ERR_LOG(TTY, "Invalid tty mimor:%d\n", minor);
		return -EINVAL;
	}

	tty = tty_port_tty_get(pport);
	if (tty) {
		MTK_INFO_LOG(TTY, "Hangup tty port\n");
		tty_vhangup(tty);
		tty_kref_put(tty);
	}

	tty_unregister_device(tty_drv, minor);
	tty_port_destroy(pport);
	kfree(pport);
	tty_drv->ports[minor] = NULL;
	return ret;
}

static int tty_ccci_init(int md_id, struct tty_ccci_ops *ccci_info, struct port_t *port)
{
	int ret = 0;
	struct tty_driver *tty_drv = NULL;
	struct tty_ctl_block *ctlb = NULL;
	struct port_proxy *port_proxy_ptr;
	int port_nr = 0;

	if (unlikely(ccci_info == NULL || port == NULL)) {
		MTK_ERR_LOG(TTY, "Invalid arguments\n");
		return -EINVAL;
	}

	ctlb = kzalloc(sizeof(struct tty_ctl_block), GFP_KERNEL);
	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TTY, "alloc tty_ctl_struct fail\n");
		return -ENOMEM;
	}

	ctlb->ccci_ops = kzalloc(sizeof(struct tty_ccci_ops), GFP_KERNEL);
	if (unlikely(ctlb->ccci_ops == NULL)) {
		MTK_ERR_LOG(TTY, "alloc tty_ccci_ops struct fail\n");
		ret = -ENOMEM;
		goto alloc_mem_fail;
	}

	g_tty_ctl_blk[md_id] = ctlb;
	memcpy(ctlb->ccci_ops, ccci_info, sizeof(struct tty_ccci_ops));
	port_nr = ctlb->ccci_ops->tty_num;

	/*alloc the tty driver*/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
	tty_drv = tty_alloc_driver(port_nr, 0);
#else
	tty_drv = alloc_tty_driver(port_nr);
#endif
	if (!tty_drv) {
		MTK_ERR_LOG(TTY, "alloc_tty_driver failed\n");
		ret = -ENOMEM;
		goto alloc_tty_fail;
	}

	/*init tty driver*/
	port_proxy_ptr = port->port_proxy;
	ctlb->driver = tty_drv;
	tty_drv->driver_name = ctlb->ccci_ops->name;
	tty_drv->name = ctlb->ccci_ops->name;
	tty_drv->major = port_proxy_ptr->major;
	tty_drv->minor_start = CCCI_TTY_MINOR_BASE;
	tty_drv->type = TTY_DRIVER_TYPE_SERIAL;
	tty_drv->subtype = SERIAL_TYPE_NORMAL;
	tty_drv->flags = TTY_DRIVER_RESET_TERMIOS |
		TTY_DRIVER_REAL_RAW | TTY_DRIVER_DYNAMIC_DEV |
		TTY_DRIVER_UNNUMBERED_NODE;
	tty_drv->init_termios = tty_std_termios;
	tty_drv->init_termios.c_iflag = 0x00;
	tty_drv->init_termios.c_oflag = 0x00;
	tty_drv->init_termios.c_cflag |= CLOCAL;
	tty_drv->init_termios.c_lflag = 0x00;
	tty_set_operations(tty_drv, &ccci_serial_ops);

	/*register tty driver*/
	ret = tty_register_driver(tty_drv);
	if (ret < 0) {
		MTK_ERR_LOG(TTY, "Couldn't register tty driver\n");
		ret = -1;
		goto register_tty_fail;
	}

	return ret;

register_tty_fail:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
	tty_driver_kref_put(tty_drv);
#else
	put_tty_driver(tty_drv);
#endif

alloc_tty_fail:

alloc_mem_fail:
	if (ctlb) {
		kfree(ctlb->ccci_ops);
		ctlb->ccci_ops = NULL;

		kfree(ctlb);
		ctlb = NULL;
	}

return ret;
}

static void tty_ccci_uninit(int md_id)
{
	struct tty_driver *tty_drv = NULL;
	struct tty_ctl_block *ctlb = NULL;


	ctlb = g_tty_ctl_blk[md_id];
	if (ctlb != NULL) {
		tty_drv = ctlb->driver;
		tty_unregister_driver(tty_drv);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
		tty_driver_kref_put(tty_drv);
#else
		put_tty_driver(tty_drv);
#endif

		/*free memory*/
		if (ctlb->ccci_ops != NULL) {
			kfree(ctlb->ccci_ops);
			ctlb->ccci_ops = NULL;
		}

		kfree(ctlb);
		g_tty_ctl_blk[md_id] = NULL;
	}
}

int tty_rx_callback(int md_id, int tty_id, void *data, int len)
{
	int copied  = 0;
	struct tty_ctl_block *ctlb = NULL;
	struct tty_port *pport = NULL;
	struct tty_driver *drv = NULL;

	ctlb = g_tty_ctl_blk[md_id];
	drv = ctlb->driver;
	pport = drv->ports[tty_id];

	/*push data to tty port buffer*/
	if (pport == NULL) {
		MTK_ERR_LOG(TTY, "TTY Port isn't created, the packet is dropped\n");
		return len;
	}
	copied = tty_insert_flip_string(pport, data, len);
	if (copied != len)
		MTK_ERR_LOG(TTY,
			"ccci_tty[%d] drop data; skb_len[%d], copied[%d].\n",
			tty_id, len, copied);

	/*trigger port buffer -> line discipline buffer*/
	tty_flip_buffer_push(pport);

	return copied;
}

static void tty_md_state_callback(int md_id, int tty_idx, enum MD_STATE state)
{
}

static void tty_queue_state_callback(int md_id,
	int tty_idx, enum HIF_STATE state)
{
}

struct tty_dev_ops tty_ops = {
	.tty_driver_status = false,
	.init = &tty_ccci_init,
	.tty_port_create = &ccci_tty_port_create,
	.tty_port_destroy = &ccci_tty_port_destroy,
	.rx_callback = &tty_rx_callback,
	.md_state_callback = &tty_md_state_callback,
	.queue_state_callback = &tty_queue_state_callback,
	.exit = &tty_ccci_uninit,
};
