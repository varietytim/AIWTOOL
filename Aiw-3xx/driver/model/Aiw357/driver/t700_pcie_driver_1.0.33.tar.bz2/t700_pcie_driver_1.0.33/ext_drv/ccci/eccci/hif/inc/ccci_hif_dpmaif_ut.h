/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_HIF_DPMAIF_UT_H__
#define __CCCI_HIF_DPMAIF_UT_H__


#include <linux/skbuff.h>
#include <linux/types.h>
#include <uapi/linux/ip.h>
#include <linux/sched.h>

#include "dpmaif_hif_platform.h"


/*
 *  UT Compile Flags
 *
 *  DATA_PATH_UT_LOOPBACK: for CCMNI layer + HIF layer loopback UT
 *  DATA_PATH_UT_HW_LOOPBACK:
 * for CCMNI layer + HIF layer + HW layer loopback UT-IT
 */

#ifdef DATA_PATH_UT_LOOPBACK

typedef enum dpmaif_ut_packet_type {
	DPMF_UT_PKT_UNKNOWN = 0,
	DPMF_UT_PKT_ICMP,
	DPMF_UT_PKT_UDP,
	DPMF_UT_PKT_TCP
} dpmaif_ut_packet_type_t;

/*
 *  dpmaif_ut_get_packet_type - checks this IP packet's type
 *  @ skb: pakcet buffer
 *
 *  return this packet's type in dpmaif_ut_packet_type_t
 */
dpmaif_ut_packet_type_t dpmaif_ut_get_packet_type(const struct sk_buff *skb);

/*
 *  dpmaif_ut_reply_icmp_echo_pkt - generates ICMP echo reply
 * packet by modifying original packet
 *  @ skb: packet buffer to modify
 *
 *  return 0 for generating reply packet success;
 *  return -1 for this is NOT a ICMP echo packet;
 *  return others for generating reply packet failed.
 */
int dpmaif_ut_reply_icmp_echo_pkt(struct sk_buff *skb);


/*
 *  dpmaif_ut_loopback_pkt - loopback TX packets for RX packets
 *  @ skb: packet to loopback
 *
 *  return 0 for loopback this packet success;
 *  return -1 for this is NOT a ICMP/UDP/TCP packet;
 *  return others for loopback this packet failed.
 */
int dpmaif_ut_loopback_pkt(struct sk_buff *skb);

#endif  /* ifdef DATA_PATH_UT_LOOPBACK */


/* ====================================================== */
/* ====================================================== */

extern unsigned short dpmaif_ut_get_packet_id(struct iphdr *iph);

/* ====================================================== */
/* ====================================================== */
#ifdef DATA_PATH_DL_TP_CALC
extern unsigned int ccci_dp_dl_tp_calc;
#endif

struct dpmaif_tp_statistics {
	u64 rx_num;
	u64 tx_num;
	u64 rx_rec_start_tm;
	u64 tx_rec_start_tm;
	bool rx_rec_enable;
	bool tx_rec_enable;
	bool first_rx_pkt;
	bool first_tx_pkt;
};

#define DPMA_UT_TIME_NOW()      sched_clock()

/* ============================================================ */
/* ============================================================ */

#endif /* __CCCI_HIF_DPMAIF_UT_H__ */
