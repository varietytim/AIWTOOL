/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MODEM_SYS1_H__
#define __MODEM_SYS1_H__

extern int modem_sys_1_init(void);
extern void modem_sys_1_uninit(void);

int mtk_queue_rescan_work(struct pci_dev *dev);
int ccci_modem_reset(struct mtk_pci_dev *mtk_dev);
int ccci_modem_init(struct mtk_pci_dev *mtk_dev);
int ccci_modem_exit(struct mtk_pci_dev *mtk_dev);

void mtk_clear_rgu_irq(struct mtk_pci_dev *mtk_dev);
int remove_driver_f(struct mtk_pci_dev *mtk_dev);
int remove_driver_r(struct mtk_pci_dev *mtk_dev);
void rgu_reset_device_via_pcie(struct mtk_pci_dev *mtk_dev);
int mtk_acpi_fldr_func(struct mtk_pci_dev *mtk_dev);
int mtk_acpi_pldr_func(struct mtk_pci_dev *mtk_dev);



#define EXP_CHANNEL_CNT 8

enum event_id{
	EXP_ID_EXCEPTION_INIT = 1,
	EXP_ID_EXCEPTION_INIT_DONE = 2,
	EXP_ID_EXCEPTION_CLEARQ_DONE = 3,
	EXP_ID_EXCEPTION_ALLQ_RESET = 4,
	PORT_ENUM_SIGNAL = 5,
	ASYNC_SAP_HK_SIGNAL = 15,
	ASYNC_MD_HK_SIGNAL = 16,
};

enum core_id {
	CORE_ID_MD = 0,
	CORE_ID_SAP = 1,
	CORE_ID_MAX,
};

#endif	/* __CCCI_MODEM_H__ */
