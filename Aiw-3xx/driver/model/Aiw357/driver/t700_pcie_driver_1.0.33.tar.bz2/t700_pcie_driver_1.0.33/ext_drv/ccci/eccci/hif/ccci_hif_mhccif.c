// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/skbuff.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/random.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/version.h>


#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_modem.h"
#include "ccci_bm.h"
#include "ccci_platform.h"
#include "modem_reg_base.h"
#include "ccci_driver.h"
#include "ccci_driver_mhccif.h"
#include "ccci_hif_mhccif.h"


#include "modem_sys_1.h"


#define TAG "mhccif"


int ccci_mhccif_hif_start(unsigned char md_id, unsigned char hif_id)
{
	struct md_mhccif_ctrl *md_ctrl = NULL;
	int ret = 0;
	struct mhccif_hw_info *hw_info = NULL;
	unsigned int mhccif_irq_id = 0;

	md_ctrl = (struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	hw_info = (struct mhccif_hw_info *)md_ctrl->hif_hw_info;
	mhccif_irq_id = hw_info->irq_id;

	if (mhccif_irq_id == 0) {
		MTK_ERR_LOG(TAG, "md_sys1_probe:get hw info fail(%d)\n", ret);
		BUG();
	} else {
		if (atomic_cmpxchg(&hw_info->irq_enable, 0, 1) == 0) {
			enable_irq(mhccif_irq_id);
			MTK_NOTICE_LOG(TAG, "enable ccif hif irq.\n");
		}
	}
	return 0;
}

int ccci_mhccif_hif_stop(unsigned char md_id, unsigned char hif_id)
{
	struct md_mhccif_ctrl *md_ctrl = NULL;
	struct mhccif_hw_info *hw_info = NULL;

	md_ctrl = (struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	hw_info = (struct mhccif_hw_info *)md_ctrl->hif_hw_info;

	if (atomic_cmpxchg(&hw_info->irq_enable, 1, 0) == 1) {
		if (in_irq() || in_softirq() || irqs_disabled())
			disable_irq_nosync(hw_info->irq_id);
		else
			disable_irq(hw_info->irq_id);
		MTK_INFO_LOG(TAG, "disable ccif hif irq..\n");
	}
	return 0;
}
int ccci_mhccif_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	return 0;
}

int ccci_mhccif_ex_handshake(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	switch (stage) {
	case HIF_EX_INIT:
		ccci_hw_send(hw_ctrl, H2D_EXCEPTION_ACK);
		break;
	case HIF_EX_ACK:
		break;
	case HIF_EX_INIT_DONE:
		break;
	case HIF_EX_CLEARQ_DONE:
		ccci_hw_send(hw_ctrl, H2D_EXCEPTION_CLEARQ_ACK);
		break;
	case HIF_EX_CLEARQ_ACK:
		break;
	case HIF_EX_ALLQ_RESET:
		break;
	}
	return 0;
}


int ccci_mhccif_hif_init(unsigned char md_id, unsigned char hif_id)
{

	return 0;
}


int ccci_mhccif_hif_exit(unsigned char md_id, unsigned char hif_id)
{
	struct md_mhccif_ctrl *md_ctrl = NULL;

	if(unlikely(hif_id != HIF_ID_PCIE)) {
		MTK_ERR_LOG(TAG,"Invalid argumets\n");
		return -EINVAL;
	}
	//release allocated resource
	md_ctrl = (struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
	kfree_sensitive(md_ctrl);
#else	
	kzfree(md_ctrl);
#endif

	/*free hw_ctrl*/
	ccci_driver_uninit(md_id, hif_id);

	return 0;
}


int ccci_mhccif_hif_late_init(unsigned char md_id, unsigned char hif_id)
{
	return 0;
}
void ccci_mhccif_reset(u8 md_id, unsigned char hif_id, char is_hw)
{

}

void *ccci_mhccif_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *mtk_dev)
{
	struct mhccif_hw_info *hw_info = NULL;
	struct md_mhccif_ctrl *md_ctrl = NULL;
	struct ccci_hw_ctrl *hw_ctrl = NULL;

	if(unlikely(mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG,"Invalid argumets\n");
		return NULL;
	}

	md_ctrl = kzalloc(sizeof(struct md_mhccif_ctrl), GFP_KERNEL);
	ccci_hif[md_id][hif_id] = (void *)md_ctrl;
	hw_ctrl = kzalloc(sizeof(struct ccci_hw_ctrl), GFP_KERNEL);
	ccci_hw_ctrl_info[md_id][hif_id] = hw_ctrl;

	if (NULL != hw_ctrl && NULL != md_ctrl) {
		hw_info = kzalloc(sizeof(struct mhccif_hw_info), GFP_KERNEL);
		if(unlikely(hw_info == NULL))
			MTK_ERR_LOG(TAG,"hw info malloc fail\n");
		md_ctrl->hif_hw_info = hw_info;
		hw_ctrl->mtk_dev = mtk_dev;
		hw_ctrl->private = (void *)hw_info;
		hw_ctrl->hif_id = hif_id;
		mhccif_driver_init(hw_ctrl);
	} else {
		MTK_ERR_LOG(TAG,
			"hif_id is err, hif_id:%d , md_ctrl:%p\n",
			hif_id, md_ctrl);
		return NULL;
	}

	return hw_info;
}

unsigned long ccci_mhccif_get_int_id(unsigned char md_id, unsigned char hif_id)
{
	unsigned int ch_id = 0;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	ch_id = ccci_hw_rx_done(hw_ctrl, 0x1803E);
	return ch_id;
}


