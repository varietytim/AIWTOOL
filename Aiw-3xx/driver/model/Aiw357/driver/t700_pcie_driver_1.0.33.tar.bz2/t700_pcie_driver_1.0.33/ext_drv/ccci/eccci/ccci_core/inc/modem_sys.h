/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MODEM_SYS_H__
#define __MODEM_SYS_H__

#include <linux/wait.h>
#include <linux/skbuff.h>
#include <linux/timer.h>
#include <linux/types.h>
#include <linux/ktime.h>
#include <linux/netdevice.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include <mt-plat/mtk_ccci_common.h>
#include "ccci_core.h"
#include "ccci_modem.h"
#include "ccci_fsm.h"
#include "ccci_hif.h"
#include "ccci_port.h"

struct ccci_modem;
struct core_sys_info;

enum MD_COMM_TYPE {
	MHCCIF_INTR,
};
#define MD_COMM_TYPE int

enum MODEM_EE_FLAG {
	EE_FLAG_ENABLE_WDT = (1 << 0),
	EE_FLAG_DISABLE_WDT = (1 << 1),
};
#define MODEM_EE_FLAG int

enum LOGGING_MODE {
	MODE_UNKNOWN = -1, /* -1 */
	MODE_IDLE,			  /* 0 */
};
#define LOGGING_MODE int

#define NORMAL_BOOT_ID 0
#define META_BOOT_ID 1
#define FACTORY_BOOT_ID	2

#define MD_SETTING_ENABLE (1<<0)
#define MD_SETTING_RELOAD (1<<1)
#define MD_SETTING_FIRST_BOOT (1<<2)	/* this is the first time of boot up */

extern volatile int current_time_zone;

struct ccci_dev_cfg {
	unsigned int index;
	unsigned int capability;
};

enum md_event_id {
	FSM_PRE_START = 0,
	FSM_START = 1,
	FSM_READY = 2,
};

struct ccci_modem_ops {
	/* must-have */
	int (*init)(struct ccci_modem *md);
	int (*uninit)(struct ccci_modem *md);
	int (*start)(struct ccci_modem *md);
	int (*pre_stop)(struct ccci_modem *md, unsigned int stop_type);
	int (*stop)(struct ccci_modem *md, unsigned int stop_type);
	int (*soft_start)(struct ccci_modem *md, unsigned int mode);
	int (*soft_stop)(struct ccci_modem *md, unsigned int mode);
	int (*start_queue)(struct ccci_modem *md,
		unsigned char qno, enum direction dir);
	int (*stop_queue)(struct ccci_modem *md,
		unsigned char qno, enum direction dir);
	int (*send_runtime_data)(struct ccci_modem *md);
	int (*ee_handshake)(struct ccci_modem *md, int timeout);
	int (*force_assert)(struct ccci_modem *md, MD_COMM_TYPE type);
	int (*dump_info)(struct ccci_modem *md,
		enum modem_dump_flag flag, void *buff, int length);
	int (*ee_callback)(struct ccci_modem *md, MODEM_EE_FLAG flag);
	int (*md_event_notify)(struct ccci_modem *md, enum md_event_id evt_id);
};


struct core_ops {
	void (*prepare_requry)(struct core_sys_info *core);
	int (*parse_host_rtdata)(struct core_sys_info *core, void *data, int data_length);
	int (*prepare_rt_data)(struct core_sys_info *core, void *data, int data_length);
};

struct core_sys_info {
	u8 index;
	atomic_t ready;
	atomic_t handshake_ongoing;
	struct ccci_feature_support feature_set[FEATURE_COUNT];
	struct ccci_feature_support support_feature_set[FEATURE_COUNT];
	struct workqueue_struct *worker;
	struct work_struct core_work;
	struct port_t *ctl_port;
	struct core_ops *ops;
};

struct ccci_modem {
	unsigned char index;
	unsigned char *private_data;
	struct ccci_modem_ops *ops;
	struct kobject kobj;
	struct ccci_mem_layout mem_layout;
	unsigned int sbp_code;
	unsigned int mdlg_mode;
	struct mtk_pci_dev *mtk_dev;
	unsigned int is_in_ee_dump;
	unsigned int is_force_asserted;
	int runtime_version;
	int multi_md_mpu_support;
	unsigned int md_wdt_irq_id;
	unsigned long md_wdt_irq_flags;
	atomic_t wdt_enabled;
	atomic_t reset_on_going;
	struct core_sys_info core_md;
	struct core_sys_info core_sap;
	struct ccci_per_md per_md_data;
	int md_init_finish;
	atomic_t rgu_irq_assered;
	atomic_t rgu_irq_assered_in_suspend;

	struct workqueue_struct *rgu_workqueue;
	struct delayed_work rgu_irq_work;
#ifdef ENABLE_CCCI_DRI_UT
	// simulate the behavior of triggering ccif rx interrupt
	struct tasklet_struct md_irq_task;
	//simulate the behavior of triggering wdt interrupt
	struct tasklet_struct md_wdt_irq_task;
#endif
};

extern struct ccci_modem *modem_sys[MAX_MD_NUM];

/***************************************************************************/
/* API Region called by sub-modem class, reuseable API */
/***************************************************************************/
void ccci_md_reset(struct ccci_modem *md);
struct ccci_modem *ccci_md_alloc(int private_size);
int ccci_md_register_reset(struct ccci_modem *modem);
int ccci_md_register(struct ccci_modem *modem);
int ccci_md_unregister(struct ccci_modem *modem);
//int modem_sys_init(void);
void modem_sys_uninit(void);

static inline struct ccci_modem *ccci_md_get_modem_by_id(int md_id)
{
	if (md_id >= MAX_MD_NUM)
		return NULL;
	return modem_sys[md_id];
}

static inline int ccci_md_in_ee_dump(int md_id)
{
	if (md_id >= MAX_MD_NUM)
		return -CCCI_ERR_MD_INDEX_NOT_FOUND;
	return modem_sys[md_id]->per_md_data.is_in_ee_dump;
}

static inline int ccci_md_recv_skb(unsigned char md_id,
	unsigned char hif_id, struct sk_buff *skb)
{
	int flag = NORMAL_DATA;

	if (hif_id == CCCI_NET_HIF)
		flag = CLDMA_NET_DATA;

	return ccci_port_recv_skb(md_id, hif_id, skb, flag);
}

extern void append_runtime_feature(char **p_rt_data,
	struct ccci_runtime_feature *rt_feature, void *data);
#endif	/* __CCCI_MODEM_H__ */
