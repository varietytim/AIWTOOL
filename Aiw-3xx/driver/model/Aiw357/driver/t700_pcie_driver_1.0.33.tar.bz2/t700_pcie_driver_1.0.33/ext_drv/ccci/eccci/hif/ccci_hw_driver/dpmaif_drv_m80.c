// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include "ccci_driver_dpmaif_reg_m80.h"
#include "dpmaif_drv_m80.h"
#include "ccci_debug.h"


#define TAG "DATA"

/********** dpmaif interrupt ************/
static void drv_dpmaif_hw_dlq_err_interrupt_msk(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_HPC_INTR_MASK, 0xffff);
}

unsigned int drv_dpmaif_get_ul_interrupt_mask(struct dpmaif_hw_info *hw_info)
{
	return DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0);
}

unsigned int drv_dpmaif_get_dl_interrupt_mask(struct dpmaif_hw_info *hw_info)
{
	return DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0);
}


static void drv_dpmaif_init_intr(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int cfg = 0;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	/*Set UL interrupt*/
	p_isr_en_msk->AP_UL_L2INTR_En_Msk = DPMAIF_UL_INT_ERR_MSK |
		DPMAIF_UL_INT_QDONE_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);

	/*set interrupt enable mask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0,
		p_isr_en_msk->AP_UL_L2INTR_En_Msk);

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0,
		~(p_isr_en_msk->AP_UL_L2INTR_En_Msk));

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) &
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_intr-1 check fail\n");
			return;
		}
	}

	/*Set DL interrupt*/
	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk =
		DPMAIF_DL_INT_PITCNT_LEN_ERR(0) |
		DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	p_isr_en_msk->AP_DL_L2INTR_En_Msk = 0;

	if (DPMAIF_HPC_DLQ_PATH_DF >= DPMAIF_HPC_DLQ_PATH_MODE2) {
		p_isr_en_msk->AP_DL_L2INTR_En_Msk =
			DPMAIF_DL_INT_DLQ0_QDONE_MSK |
			DPMAIF_DL_INT_DLQ1_QDONE_MSK |
			DPMAIF_DL_INT_DLQ0_PITCNT_LEN_MSK |
			DPMAIF_DL_INT_DLQ1_PITCNT_LEN_MSK;
	} else {
		p_isr_en_msk->AP_DL_L2INTR_En_Msk |=
			p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk |
			DPMAIF_DL_INT_EMPTY_MSK | DPMAIF_DL_INT_QDONE_MSK;
	}


	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, 0xFFFFFFFF);

	/*set interrupt enable mask*/
	// DL ISR PD part
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0,
		~(p_isr_en_msk->AP_DL_L2INTR_En_Msk));

	/*check mask sts*/
	count = 0;
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_intr-2 check fail\n");
			return;
		}
	}

	// Set AP IP busy
	p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk = DPMAIF_UDL_IP_BUSY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);

	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DLUL_IP_BUSY_MASK,
	                        p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk);

	cfg = DPMAIF_READ_AO_DL(hw_info, NRL2_DPMAIF_AO_UL_AP_L1TIMR0);
	cfg |= (DPMAIF_DL_INT_Q2APTOP_MSK|DPMAIF_DL_INT_Q2TOQ1_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_UL_AP_L1TIMR0, cfg);
	drv_dpmaif_hw_dlq_err_interrupt_msk(hw_info);

	MTK_INFO_LOG(TAG,
		"AP_UL_L2INTR_En_Msk: 0x%x, AP_DL_L2INTR_ERR_En_Msk:0x%x\n",
		p_isr_en_msk->AP_UL_L2INTR_En_Msk,
		p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk);
	MTK_INFO_LOG(TAG,
		"AP_UDL_IP_BUSY_En_Msk:0x%x, AP_DL_L2INTR_En_Msk:0x%x\n",
		p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	count = 0;
	while(count < MAIFQ_MAX_DLQ_NUM){
		hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[count] = 0;
		count ++;
	}
}

void drv_dpmaif_init_ul_intr(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
	/*set interrupt enable mask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0,
		p_isr_en_msk->AP_UL_L2INTR_En_Msk);

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0,
		~(p_isr_en_msk->AP_UL_L2INTR_En_Msk));

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) &
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_ul_intr check fail\n");
			return;
		}
	}

	// Set AP IP busy
	p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk = DPMAIF_UDL_IP_BUSY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0);

}

static void drv_dpmaif_mask_ul_que_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_done_mask;
	int count = 0;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	ui_que_done_mask = (1 << (q_num + _UL_INT_DONE_OFFSET)) &
		DPMAIF_UL_INT_QDONE_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_done_mask;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0, ui_que_done_mask);
	
	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_done_mask) != ui_que_done_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_ul check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_que_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_done_mask = (1 << (q_num + _UL_INT_DONE_OFFSET)) &
		DPMAIF_UL_INT_QDONE_MSK;
	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_done_mask;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0, ui_que_done_mask);
}

static void drv_dpmaif_dl_set_ao_dl_interrupt_mask(struct dpmaif_hw_info *hw_info, unsigned int mask)
{

}


static void drv_dpmaif_mask_dl_batcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_batcnt_lenrr_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &=
		~(DPMAIF_DL_INT_BATCNT_LEN_ERR(q_num));
	di_batcnt_lenrr_mask = DPMAIF_DL_INT_BATCNT_LEN_ERR(0);
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_batcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_batcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_batcnt_lenrr_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	di_batcnt_lenrr_mask = DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, di_batcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

static void drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_pitcnt_lenrr_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &=
		~(DPMAIF_DL_INT_PITCNT_LEN_ERR(q_num));

	di_pitcnt_lenrr_mask = DPMAIF_DL_INT_PITCNT_LEN_ERR(0);
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_pitcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt(struct dpmaif_hw_info *hw_info)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_pitcnt_lenrr_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_PITCNT_LEN_ERR(0);

	di_pitcnt_lenrr_mask = DPMAIF_DL_INT_PITCNT_LEN_ERR(0);
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, di_pitcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info,
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_mask_dl_que_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_QDONE_MSK;
	di_que_done_mask = DPMAIF_DL_INT_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_que_interrupt(struct dpmaif_hw_info *hw_info)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_QDONE_MSK;
	di_que_done_mask = DPMAIF_DL_INT_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, di_que_done_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
	~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

static int drv_dpmaif_mask_dl_dlq0_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	
	di_que_done_mask = DPMAIF_DL_INT_DLQ0_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		di_que_done_mask) != di_que_done_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_dlq0 check fail\n");
			return -1;
		}

        /* try again */
        DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	}

    p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_DLQ0_QDONE_MSK;
    hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[0] = 0;

    return 0;
}

static int drv_dpmaif_mask_dl_dlq1_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;
	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	
	di_que_done_mask = DPMAIF_DL_INT_DLQ1_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		di_que_done_mask) != di_que_done_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_dlq1 check fail\n");
			return -1;
		}

        /* try again */
        DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	}

    p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_DLQ1_QDONE_MSK;
    hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[1] = 0;

    return 0;
}

int drv_dpmaif_hw_dlq_mask_rx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	if (qno == DPF_RX_QNO0)
		return drv_dpmaif_mask_dl_dlq0_interrupt(hw_info);
	else
		return drv_dpmaif_mask_dl_dlq1_interrupt(hw_info);
}


static void drv_dpmaif_unmask_dl_dlq0_interrupt(struct dpmaif_hw_info *hw_info)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	
	di_que_done_mask = DPMAIF_DL_INT_DLQ0_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, di_que_done_mask);

    p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_DLQ0_QDONE_MSK;
}

static void drv_dpmaif_unmask_dl_dlq1_interrupt(struct dpmaif_hw_info *hw_info)
{
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	
	di_que_done_mask = DPMAIF_DL_INT_DLQ1_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, di_que_done_mask);

    p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_DLQ1_QDONE_MSK;
}

int drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	if (qno == DPF_RX_QNO0)
		drv_dpmaif_unmask_dl_dlq0_interrupt(hw_info);
	else
		drv_dpmaif_unmask_dl_dlq1_interrupt(hw_info);
	return 0;
}

void drv_dpmaif_mask_ul_que_empty_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	ui_que_empty_mask = (1 << (q_num + _UL_INT_EMPTY_OFFSET)) &
		DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_empty_mask;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) != ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_ul_que_empty check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_que_empty_interrupt(struct dpmaif_hw_info *hw_info, unsigned int q_num)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	ui_que_empty_mask = (1 << (q_num + _UL_INT_EMPTY_OFFSET)) &
		DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_empty_mask;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0)
		& ui_que_empty_mask) == ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_ul_allque_empty check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_ul_allque_empty_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	ui_que_empty_mask = DPMAIF_UL_INT_EMPTY_MSK;
	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_empty_mask;

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0)
		& ui_que_empty_mask) != ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_pkt_empty check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_allque_empty_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;
	unsigned int ui_que_empty_mask = 0;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	ui_que_empty_mask = DPMAIF_UL_INT_EMPTY_MSK;
	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_empty_mask;

	// clear dummy register
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0,
		DPMAIF_UL_INT_EMPTY_MSK);

	// clear mask
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) == ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_ul_allque_empty check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_dl_pkt_empty_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_EMPTY_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_pkt_empty check fail\n");
			return;
		}
	}
}


void drv_dpmaif_mask_dl_pkt_empty_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_EMPTY_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) !=
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_pkt_empty check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_dl_lenerr_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_MTU_ERR_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_lenerr check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_dl_lenerr_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk =
		&hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_MTU_ERR_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, 
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) !=
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_lenerr check fail\n");
			return;
		}
	}
}

static unsigned int drv_dpmaif_get_ul_lv2_sts(struct dpmaif_hw_info *hw_info)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0);
	return sts;
}

unsigned int drv_dpmaif_get_ulq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num)
{
	unsigned int sts;
	sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0);
	sts &= (DPMAIF_UL_INT_QDONE_MSK & (1 << (q_num + _UL_INT_DONE_OFFSET)));

	return sts;
}

void drv_dpmaif_clr_ulq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num)
{
	unsigned int sts;
	sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0);
	sts &= (DPMAIF_UL_INT_QDONE_MSK & (1 << (q_num + _UL_INT_DONE_OFFSET)));
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, sts);
}

void drv_dpmaif_clr_dlq_done_sts(struct dpmaif_hw_info *hw_info, unsigned char q_num)
{
	unsigned int sts;
	sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0);
	sts &= DPMAIF_DL_INT_QDONE_MSK;
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, sts);
}

void drv_dpmaif_clr_ip_busy_sts(struct dpmaif_hw_info *hw_info)
{
	unsigned int ip_busy_sts;

	/*Get AP IP busy sts*/
	ip_busy_sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY);
	/*Clear AP IP busy*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY, ip_busy_sts);
}

void drv_dpmaif_clr_ul_all_interrupt(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
}

static unsigned int drv_dpmaif_get_dl_lv2_sts(struct dpmaif_hw_info *hw_info)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0);
	return sts;
}

void drv_dpmaif_clr_dl_all_interrupt(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, 0xFFFFFFFF);
}

void drv_dpmaif_mask_ul_l1_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	unsigned int isr;

	isr = DPMAIF_UL_INT_ERR_MSK | DPMAIF_UL_INT_MD_NOTREADY_MSK |
		DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK |
		DPMAIF_UL_INT_QDONE_MSK | DPMAIF_UL_INT_EMPTY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISR0, isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) & isr) != isr) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_ul_l1 check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_l1_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	unsigned int isr;

	isr = DPMAIF_UL_INT_ERR_MSK | DPMAIF_UL_INT_MD_NOTREADY_MSK |
		DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK |
		DPMAIF_UL_INT_QDONE_MSK | DPMAIF_UL_INT_EMPTY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TICR0, isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TIMR0) & isr) == isr) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_ul_l1 check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_dl_l1_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	unsigned int isr;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk = 0;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk = 0;

	isr = DPMAIF_DL_INT_SKB_LEN_ERR(0) | DPMAIF_DL_INT_PITCNT_LEN_ERR(0) |
		DPMAIF_DL_INT_BATCNT_LEN_ERR(0) | DPMAIF_DL_INT_EMPTY_MSK |
		DPMAIF_DL_INT_MTU_ERR_MSK | DPMAIF_DL_INT_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISR0, isr);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) & isr) != isr) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_l1 check fail\n");
			return;
		}
	}

}

void drv_dpmaif_unmask_dl_l1_interrupt(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	unsigned int isr;
	struct dpmaif_isr_en_mask *p_isr_en_msk;

	p_isr_en_msk = &hw_info->dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk = DPMAIF_DL_INT_SKB_LEN_ERR(0) |
		DPMAIF_DL_INT_PITCNT_LEN_ERR(0);
	p_isr_en_msk->AP_DL_L2INTR_En_Msk =
		p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk |
		DPMAIF_DL_INT_EMPTY_MSK | DPMAIF_DL_INT_MTU_ERR_MSK |
		DPMAIF_DL_INT_QDONE_MSK;

	isr = p_isr_en_msk->AP_DL_L2INTR_En_Msk;

	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TICR0, isr);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(hw_info, ~isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TIMR0) & isr) == isr) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_l1 check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_ap_ip_busy(struct dpmaif_hw_info *hw_info)
{
	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0x3);
}

void drv_dpmaif_unmask_ap_ip_busy(struct dpmaif_hw_info *hw_info)
{
	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0);
}


void drv_dpmaif_hw_ul_mask_multiple_tx_done_intr(struct dpmaif_hw_info *hw_info,
	unsigned char que_mask)
{
	unsigned int index = 0;

	for (index = 0; index < MAIFQ_MAX_ULQ_NUM; index++) {
		if (que_mask & (1 << index))
			drv_dpmaif_mask_ul_que_interrupt(hw_info, index);
	}
}

static void drv_dpmaif_hw_check_tx_interrupt(struct dpmaif_hw_info *hw_info, 
	unsigned int l2_txisar0,
	struct dpmaif_hw_intr_st_para *para)
{
	unsigned int value = 0;

	value = l2_txisar0 & DP_UL_INT_QDONE_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_DONE;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_DONE_OFFSET & DP_UL_QNUM_MSK;

		/* we mask TX queue interrupt immediately after it occurs */
		drv_dpmaif_hw_ul_mask_multiple_tx_done_intr(hw_info, 
			para->intr_queues[para->intr_cnt]);

		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_EMPTY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_DRB_EMPTY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_EMPTY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_MD_NOTREADY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_MD_NOTREADY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_MD_NOTRDY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_MD_PWR_NOTREADY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_MD_PWR_NOTREADY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_PWR_NOTRDY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_ERR_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_LEN_ERR;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_LEN_ERR_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

}

static void drv_dpmaif_hw_check_rx_interrupt(struct dpmaif_hw_info *hw_info, 
	unsigned int *pl2_rxisar0, struct dpmaif_hw_intr_st_para *para, int qno)
{
	unsigned int value = 0;
    unsigned int l2_rxisar0 = *pl2_rxisar0;

	if (qno == DPF_RX_QNO_DFT) {
		value = l2_rxisar0 & DP_DL_INT_SKB_LEN_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_SKB_LEN_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_BATCNT_LEN_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_BATCNT_LEN_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;

			/* mask this interrupt */
			drv_dpmaif_mask_dl_batcnt_len_err_interrupt(hw_info,
				DPF_RX_QNO_DFT);
		}

		value = l2_rxisar0 & DP_DL_INT_PITCNT_LEN_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_PITCNT_LEN_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;

			/* mask this interrupt */
			drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(hw_info,
				DPF_RX_QNO_DFT);
		}

		value = l2_rxisar0 & DP_DL_INT_PKT_EMPTY_MSK;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_PKT_EMPTY_SET;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_FRG_EMPTY_MSK;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_FRG_EMPTY_SET;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_MTU_ERR_MSK;
		if (value != 0) {
			para->intr_types[para->intr_cnt] = DPF_INTR_DL_MTU_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_FRG_LENERR_MSK;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_FRGCNT_LEN_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_DLQ0_PITCNT_LEN_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_DL_INT_DLQ0_PITCNT_LEN_ERR;
			para->intr_queues[para->intr_cnt] = 0x01 << qno;
			para->intr_cnt++;

			/* mask this interrupt */
			drv_dpmaif_dlq_mask_rx_pit_cnt_len_err_intr(hw_info, qno);
		}

		value = l2_rxisar0 & DP_DL_INT_HPC_ENT_TYPE_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_DL_INT_HPC_ENT_TYPE_ERR;
			para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
			para->intr_cnt++;
		}

		value = l2_rxisar0 & DP_DL_INT_DLQ0_QDONE_SET;
		if (value != 0) {
			/* we mask RX done interrupt
			 *immediately after it occures
			 */
			if (!drv_dpmaif_hw_dlq_mask_rx_done_intr(hw_info, qno)) {
                para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_DLQ0_DONE;
    			para->intr_queues[para->intr_cnt] = 0x01 << qno;
    			para->intr_cnt++;
            } else {
                /* mask failed, so we try mask in next interrupt and we cannot clear it now */
                *pl2_rxisar0 = l2_rxisar0 & (~DP_DL_INT_DLQ0_QDONE_SET);
            }
		}
	} else {
		value = l2_rxisar0 & DP_DL_INT_DLQ1_PITCNT_LEN_ERR;
		if (value != 0) {
			para->intr_types[para->intr_cnt] =
				DPF_DL_INT_DLQ1_PITCNT_LEN_ERR;
			para->intr_queues[para->intr_cnt] = 0x01 << qno;
			para->intr_cnt++;

			/* mask this interrupt */
			drv_dpmaif_dlq_mask_rx_pit_cnt_len_err_intr(hw_info, qno);
		}

		value = l2_rxisar0 & DP_DL_INT_DLQ1_QDONE_SET;
		if (value != 0) {
			/* we mask RX done interrupt
			 * immediately after it occures
			 */
			if (!drv_dpmaif_hw_dlq_mask_rx_done_intr(hw_info, qno)) {
                para->intr_types[para->intr_cnt] =
				DPF_INTR_DL_DLQ1_DONE;
    			para->intr_queues[para->intr_cnt] = 0x01 << qno;
    			para->intr_cnt++;
            } else {
                /* mask failed, so we try mask in next interrupt and we cannot clear it now */
                *pl2_rxisar0 = l2_rxisar0 & (~DP_DL_INT_DLQ1_QDONE_SET);
            }
		}
	}

	MTK_DEBUG_LOG(TAG, "[BEFORE]l2_rxisar0:0x%x, [AFTER]l2_rxisar0:0x%x, intr_cnt:%u\n",
		l2_rxisar0, *pl2_rxisar0, para->intr_cnt);
    DPMA_FT_LOG("[BEFORE]l2_rxisar0:0x%x, [AFTER]l2_rxisar0:0x%x, intr_cnt:%u\n",
		l2_rxisar0, *pl2_rxisar0, para->intr_cnt);
}

int drv_dpmaif_hw_get_interrupt_status(
	struct dpmaif_hw_info *hw_info, void *para, int qno)
{
	struct dpmaif_hw_intr_st_para *intr_para = NULL;
	unsigned int L2RISAR0 = 0, L2TISAR0 = 0;
	unsigned int L2RIMR0 = 0, L2TIMR0 = 0;

	/* checks input firstly */
	if (unlikely(para == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!\n");
		goto error;
	}

	intr_para = (struct dpmaif_hw_intr_st_para *)para;

	/* initializes value */
	memset(intr_para, 0, sizeof(struct dpmaif_hw_intr_st_para));

	/* gets interrupt status from HW */
	/* RX interrupt status */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	L2RIMR0 = (unsigned int)drv_dpmaif_get_dl_interrupt_mask(hw_info);

	/* TX interrupt status*/
	if (qno == DPF_RX_QNO_DFT) {
        /* all ULQ interrupts and DLQ0 interrupts use the same interrupt source */
        /* there is no need to check ULQ interrupts when we found a DLQ1 interrupt occurred */
		L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);
		L2TIMR0 = (unsigned int)drv_dpmaif_get_ul_interrupt_mask(hw_info);
	}

	MTK_DEBUG_LOG(TAG, "L2RISAR0=0x%x, L2RIMR0=0x%x, L2TISAR0=0x%x, L2TIMR0=0x%x\n",
		L2RISAR0, L2RIMR0, L2TISAR0, L2TIMR0);

	DPMA_FT_LOG("BEFORE CHECK: L2RISAR0=0x%x, L2RIMR0=0x%x, L2TISAR0=0x%x, L2TIMR0=0x%x\n",
		L2RISAR0, L2RIMR0, L2TISAR0, L2TIMR0);

	/* clear IP busy register wake up cpu case */
	drv_dpmaif_clr_ip_busy_sts(hw_info);

	/* check UL interrupt status*/
	if (qno == DPF_RX_QNO_DFT) {
		 /* we don't want to schedule
            bottom half again or clear UL
			interrupt status
            when we have already masked it*/
		L2TISAR0 &= (~L2TIMR0);
		if (L2TISAR0) {
			drv_dpmaif_hw_check_tx_interrupt(hw_info, L2TISAR0, intr_para);

			/* clear interrupt status */
			DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, L2TISAR0);
		}
	}

	/* check DL interrupt status*/
	if (L2RISAR0) {
		if (qno == DPF_RX_QNO0) {
			L2RISAR0 &= DP_DL_DLQ0_STATUS_MASK;

            if (L2RIMR0 & DPMAIF_DL_INT_DLQ0_QDONE_MSK) {
				/* for debug: DLQ0 isr occur, but DLQ0 irq has been masked. */
				if ((!L2TISAR0) && (!(L2RISAR0 & DP_DL_INT_DLQ0_PITCNT_LEN_ERR)) && (L2RISAR0 & DP_DL_INT_DLQ0_QDONE_SET)) {
                    hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno]++;
                    MTK_INFO_LIMITED_LOG(TAG, "dlq%d masked, but irq occur %u, L2RISAR0=0x%x, L2RIMR0 =0x%x", 
                                qno, hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno], L2RISAR0, L2RIMR0);
                    DPMA_FT_LOG("dlq%d masked, but irq occur %u, L2RISAR0=0x%x, L2RIMR0 =0x%x", 
                                qno, hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno], L2RISAR0, L2RIMR0);
                    
                    if (hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno] >= DPMA_MASK_FAIL_CNT_MAX)
                        DPMAIF_HW_ASSERT(hw_info);
                }
                L2RISAR0 &= (~DP_DL_INT_DLQ0_QDONE_SET); /* we don't want to schedule
                                                                bottom half again or clear DL
                                                                queue done interrupt status
                                                                when we have already masked it*/
			}
		} else {
			L2RISAR0 &= DP_DL_DLQ1_STATUS_MASK;

            if (L2RIMR0 & DPMAIF_DL_INT_DLQ1_QDONE_MSK) {
				/* for debug: DLQ1 isr occur, but DLQ1 irq has been masked. */
				if ((!(L2RISAR0 & DP_DL_INT_DLQ1_PITCNT_LEN_ERR)) && (L2RISAR0 & DP_DL_INT_DLQ1_QDONE_SET)) {
					hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno]++;
                    MTK_INFO_LIMITED_LOG(TAG, "dlq%d masked, but irq occur %u, L2RISAR0=0x%x, L2RIMR0 =0x%x", 
                                qno, hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno], L2RISAR0, L2RIMR0);
                    DPMA_FT_LOG("dlq%d masked, but irq occur %u, L2RISAR0=0x%x, L2RIMR0 =0x%x", 
                                qno, hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno], L2RISAR0, L2RIMR0);
                    
                    if (hw_info->dpmaif_drv_ctrl.dlq_mask_fail_cnt[qno] >= DPMA_MASK_FAIL_CNT_MAX)
                        DPMAIF_HW_ASSERT(hw_info);
                }
                L2RISAR0 &= (~DP_DL_INT_DLQ1_QDONE_SET); /* we don't want to schedule
                                                                bottom half again or clear DL
                                                                queue done interrupt status
                                                                when we have already masked it*/
            }
        }

		/* have interrupt event*/
		if (L2RISAR0) {
			drv_dpmaif_hw_check_rx_interrupt(hw_info, &L2RISAR0, intr_para, qno);
			/* always clear BATCNT_ERR */
			L2RISAR0 |= DP_DL_INT_BATCNT_LEN_ERR;
			/* clear interrupt status */
			DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, L2RISAR0);
		}
	}

    
    DPMA_FT_LOG("AFTER CHECK: L2RISAR0=0x%x, L2RIMR0=0x%x, L2TISAR0=0x%x, L2TIMR0=0x%x\n",
            L2RISAR0, L2RIMR0, L2TISAR0, L2TIMR0);

	return intr_para->intr_cnt;

error:
	return -1;
}

/*AP_L1TIMR0*/
#define DP_AP_TOP_WAKEC		(1 << 7)
#define DP_AP_TOP_WAKES		(1 << 8)
#define DP_UL_TOP_PCIE_INTC (1 << 11)
#define DP_DL_TOP_PCIE_INTC (1 << 12)
#define DP_UL_TOP_PCIE_INTS (1 << 13)
#define DP_DL_TOP_PCIE_INTS (1 << 14)
#define DP_UL_TOP_MDMCU_INTC	(1 << 17)
#define DP_DL_TOP_MDMCU_INTC	(1 << 18)
#define DP_UL_TOP_MDMCU_INTS	(1 << 19)
#define DP_DL_TOP_MDMCU_INTS	(1 << 20)

#define DP_UL_TOP_AP_INTM	(1 << 0)
#define DP_DL_TOP_AP_INTM	(1 << 1)
#define DP_AP_TOP_WAKEM		(1 << 6)
#define DP_UL_TOP_PCIE_INTM (1 << 9)
#define DP_DL_TOP_PCIE_INTM (1 << 10)
#define DP_UL_TOP_MDMCU_INTM	(1 << 15)
#define DP_DL_TOP_MDMCU_INTM	(1 << 16)

#define DP_AP_ISR_PCIE\
	(DP_UL_TOP_AP_INTM|DP_DL_TOP_AP_INTM|\
	DP_DL_TOP_MDMCU_INTM|DP_UL_TOP_MDMCU_INTM)
#define DP_AP_ISR_MDEMI\
	(DP_UL_TOP_AP_INTM|DP_DL_TOP_AP_INTM|\
	DP_UL_TOP_PCIE_INTM|DP_DL_TOP_PCIE_INTM)
#define DP_AP_ISR_AP\
	(DP_UL_TOP_PCIE_INTM|DP_DL_TOP_PCIE_INTM|\
	DP_DL_TOP_MDMCU_INTM|DP_UL_TOP_MDMCU_INTM)


void drv_dpmaif_hw_clr_dl_intr_sts_frg_cnt_err(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_FRG_LENERR_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_mtu_err(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_MTU_ERR_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_frg_empty(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_FRG_EMPTY_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_pkt_empty(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_PKT_EMPTY_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_pit_cnt_len_err(struct dpmaif_hw_info *hw_info,unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_PITCNT_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_bat_cnt_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_BATCNT_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_skb_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_SKB_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_dl_intr_sts_dl_done(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts(hw_info);
	intr_value = L2RISAR0 & DP_DL_INT_QDONE_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_ul_intr_sts_drb_empty(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);
	intr_value = L2TISAR0 & DP_UL_INT_EMPTY_MSK &
		(1 << (DP_UL_INT_EMPTY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_ul_intr_sts_md_not_ready(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);
	intr_value = L2TISAR0 & DP_UL_INT_MD_NOTREADY_MSK &
		(1 << (DP_UL_INT_MD_NOTRDY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_ul_intr_sts_md_pwr_not_ready(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);
	intr_value = L2TISAR0 & DP_UL_INT_MD_PWR_NOTREADY_MSK &
		(1 << (DP_UL_INT_PWR_NOTRDY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_ul_intr_sts_ul_len_err(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);
	intr_value = L2TISAR0 & DP_UL_INT_ERR_MSK &
		(1 << (DP_UL_INT_LEN_ERR_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

void drv_dpmaif_hw_clr_ul_intr_sts_ul_done(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);

	intr_value = L2TISAR0 & DP_UL_INT_QDONE_MSK &
		(1 << (DP_UL_INT_DONE_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

int drv_dpmaif_hw_addr_init(struct dpmaif_hw_info *dpmaif_hw_info, struct pcie_hw_info *pcie_hw_info)
{
	int ret = 0;
	if (pcie_hw_info == NULL || dpmaif_hw_info == NULL) {
		MTK_ERR_LOG(TAG, "Invalid HW info: NULL pointer!\n");
		ret = -1;
		goto exit;
	}

	/* gets PCIe device base address offset*/
	dpmaif_hw_info->pcie_base_offset = pcie_hw_info->hw_map_base_addr - pcie_hw_info->hw_base_addr;

	MTK_DEBUG_LOG(TAG, "PCIe dev base offset 0x%lx(0x%llx - 0x%llx)\n",
		(unsigned long)dpmaif_hw_info->pcie_base_offset, 
		pcie_hw_info->hw_map_base_addr, pcie_hw_info->hw_base_addr);

exit:
	return ret;
}

static void drv_dpmaif_sram_init(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;
	unsigned int count = 0;

	value = DPMAIF_READ_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_MEM_CLR);
	value |= DPMAIF_MEM_CLR_MASK;
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_MEM_CLR, value);

	while ((DPMAIF_READ_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_MEM_CLR) &
		DPMAIF_MEM_CLR_MASK)) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "sram_init check fail\n");
			break;
		}
	}
}

static void drv_dpmaif_tick_delay(unsigned int tick)
{
	unsigned int tmp;

	tmp = tick;
	if (tmp <= 0)
		return;

	while (1) {
		tmp = tmp - 1;
		if (tmp <= 0)
			return;
	}
}

static void drv_dpmaif_hw_reset(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_RGU(hw_info, DPMAIF_AP_AO_RGU_ASSERT, DPMAIF_AP_AO_RST_BIT);
	drv_dpmaif_tick_delay(100);
	DPMAIF_WRITE_RGU(hw_info, DPMAIF_AP_RGU_ASSERT, DPMAIF_AP_RST_BIT);
	drv_dpmaif_tick_delay(100);
	DPMAIF_WRITE_RGU(hw_info, DPMAIF_AP_AO_RGU_DEASSERT, DPMAIF_AP_AO_RST_BIT);
	drv_dpmaif_tick_delay(100);
	DPMAIF_WRITE_RGU(hw_info, DPMAIF_AP_RGU_DEASSERT, DPMAIF_AP_RST_BIT);
	drv_dpmaif_tick_delay(100);
}

static void drv_dpmaif_hw_config(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;

	drv_dpmaif_hw_reset(hw_info);
	drv_dpmaif_sram_init(hw_info);

	/*Set DPMAIF AP port mode*/
	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);
	value &= ~(DPMAIF_PORT_MODE_MSK);
	value |= DPMAIF_PORT_MODE_PCIE;
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, value);

	/*Set CG en*/
	DPMAIF_WRITE_PD_UL(hw_info, NRL2_DPMAIF_AP_MISC_CG_EN, 0x7f);
}

static void dpmaif_drv_pcie_dpmaif_sign(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_UL(hw_info, NRL2_DPMAIF_UL_RESERVE_AO_RW,
		DPMAIF_PCIE_MODE_SET_VALUE);
}

static void dpmaif_drv_dl_performance(struct dpmaif_hw_info *hw_info)
{
	unsigned int tmp;

	/*BAT cache enable*/
	tmp = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1);
	tmp |= DPMAIF_DL_BAT_CACHE_PRI;
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1, tmp);

	/*PIT burst en*/
	tmp = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);
	tmp |= DPMAIF_DL_BURST_PIT_EN;
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, tmp);
}

void drv_dpmaif_dl_set_wdma(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;

	/*Set WDMA OSTD*/
	value = DPMAIF_READ_PD_WDMA(hw_info, NRL2_DPMAIF_WDMA_WR_CHNL_CMD_CON3);
	value &= ~(DPMAIF_DL_WDMA_CTRL_OSTD_MSK <<
		DPMAIF_DL_WDMA_CTRL_OSTD_OFST);
	value |= (DPMAIF_DL_WDMA_CTRL_OSTD_VALUE <<
		DPMAIF_DL_WDMA_CTRL_OSTD_OFST);
	DPMAIF_WRITE_PD_WDMA(hw_info, NRL2_DPMAIF_WDMA_WR_CHNL_CMD_CON3, value);

	/*Clear CTRL_INTVAL_AVG/CTRL_INTVAL_MIN*/
	value = DPMAIF_READ_PD_WDMA(hw_info, NRL2_DPMAIF_WDMA_WR_CMD_CON0);
	value &= (0xFFFF0000);
	DPMAIF_WRITE_PD_WDMA(hw_info, NRL2_DPMAIF_WDMA_WR_CMD_CON0, value);
}

static void drv_dpmaif_common_hw_init(struct dpmaif_hw_info *hw_info)
{
	dpmaif_drv_pcie_dpmaif_sign(hw_info);
	dpmaif_drv_dl_performance(hw_info);
}


/***********************************************************************
 *	DPMAIF DL DLQ part HW setting
 *
 ***********************************************************************/
static void drv_dpmaif_hw_hpc_cntl_set(struct dpmaif_hw_info *hw_info)
{
	unsigned int cfg = 0;

	cfg = ((DPMAIF_HPC_DLQ_PATH_DF & 0x3) << 0);
	cfg |= ((DPMAIF_HPC_ADD_MODE_DF & 0x3) << 2);
	cfg |= ((DPMAIF_HASH_PRIME_DF & 0xf) << 4);
	cfg |= ((DPMAIF_HPC_TOTAL_NUM & 0xff) << 8);
	//cfg include hpcdlq path, hpc add mode, hash prime, hpc total num
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_HPC_CNTL, cfg);
}

static void drv_dpmaif_hw_agg_cfg_set(struct dpmaif_hw_info *hw_info)
{
	unsigned int cfg = 0;

	cfg = ((DPMAIF_AGG_MAX_LEN_DF & 0xffff) << 0);
	cfg |= ((DPMAIF_AGG_TBL_ENT_NUM_DF & 0xffff) << 16);

	//cfg include agg max length, agg table num
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQ_AGG_CFG, cfg);
}

static void drv_dpmaif_hw_hash_bit_choose_set(struct dpmaif_hw_info *hw_info)
{
	unsigned int cfg = 0;
	cfg = ((DPMAIF_DLQ_HASH_BIT_CHOOSE_DF & 0x7) << 0);
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQPIT_INIT_CON5, cfg);
}

static void drv_dpmaif_hw_mid_pit_timeout_thres_set(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQPIT_TIMEOUT0,
		DPMAIF_MID_TIMEOUT_THRES_DF);
}

static void drv_dpmaif_hw_dlq_timeout_thres_set(struct dpmaif_hw_info *hw_info)
{
	unsigned int tmp, idx;

	for (idx = 0; idx < DPMAIF_HPC_MAX_TOTAL_NUM; idx++) {
		tmp = DPMAIF_READ_AO_DL(hw_info,
			NRL2_DPMAIF_AO_DL_DLQPIT_TIMEOUT1+4*(idx/2));

		if (idx%2) {	//odd idx
			tmp = ((tmp & 0xFFFF) |
				(DPMAIF_DLQ_TIMEOUT_THRES_DF<<16));
		} else {	//even idx
			tmp = ((tmp & 0xFFFF0000) |
				(DPMAIF_DLQ_TIMEOUT_THRES_DF));
		}
		DPMAIF_WRITE_AO_DL(hw_info,
			NRL2_DPMAIF_AO_DL_DLQPIT_TIMEOUT1 +
			(4 * (idx / 2)), tmp);
	}
}

static void drv_dpmaif_hw_dlq_start_prs_thres_set(struct dpmaif_hw_info *hw_info)
{
	unsigned int cfg = 0;
	cfg = (DPMAIF_DLQ_PRS_THRES_DF & 0x3FFFF);
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQPIT_TRIG_THRES, cfg);
}

static void drv_dpmaif_dl_dlq_hpc_hw_init(struct dpmaif_hw_info *hw_info)
{
	drv_dpmaif_hw_hpc_cntl_set(hw_info);
	drv_dpmaif_hw_agg_cfg_set(hw_info);
	drv_dpmaif_hw_hash_bit_choose_set(hw_info);
	drv_dpmaif_hw_mid_pit_timeout_thres_set(hw_info);
	drv_dpmaif_hw_dlq_timeout_thres_set(hw_info);
	drv_dpmaif_hw_dlq_start_prs_thres_set(hw_info);
}

/***********************************************************************
 *	DPMAIF DL Part HW setting
 *
 ***********************************************************************/
static void drv_dpmaif_dl_bat_init_done(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL frg_en)
{
	unsigned int dl_bat_init = 0;
	unsigned int count = 0;

	if (frg_en == DRV_TRUE)
		dl_bat_init |= DPMAIF_DL_BAT_FRG_INIT;

	dl_bat_init |= DPMAIF_DL_BAT_INIT_ALLSET;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info,
				DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_bat_init_done check fail-1\n");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) == DPMAIF_DL_BAT_INIT_NOT_READY){
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_bat_init_done check fail-2\n");
			break;
		}

	}

}

static void drv_dpmaif_dl_pit_init_done(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int dl_pit_init = 0;
	unsigned int count = 0;

	dl_pit_init |= DPMAIF_DL_PIT_INIT_ALLSET;
	dl_pit_init |= DPMAIF_DL_PIT_INIT_EN;

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT) &
			DPMAIF_DL_PIT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info,
				DPMAIF_PD_DL_PIT_INIT, dl_pit_init);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_pit_init_done check fail-1\n");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT) &
		DPMAIF_DL_PIT_INIT_NOT_READY) == DPMAIF_DL_PIT_INIT_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_pit_init_done check fail-2\n");
			break;
		}
	}

}

static void drv_dpmaif_dl_set_bat_base_addr(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON0, lb_addr);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON3, hb_addr);
}

static void drv_dpmaif_dl_set_bat_size(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1);
	value &= ~(DPMAIF_BAT_SIZE_MSK);
	value |= (size & DPMAIF_BAT_SIZE_MSK);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1, value);
}

static void drv_dpmaif_dl_bat_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1);
	if (enable == DRV_TRUE)
		value |= DPMAIF_BAT_EN_MSK;
	else
		value &= ~DPMAIF_BAT_EN_MSK;
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1, value);

}

static void drv_dpmaif_dl_set_pit_base_addr(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON0, lb_addr);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON4, hb_addr);
}

static void drv_dpmaif_dl_set_pit_size(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON1);
	value &= ~(DPMAIF_PIT_SIZE_MSK);
	value |= (size & DPMAIF_PIT_SIZE_MSK);
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON1, value);
}

static void drv_dpmaif_dl_pit_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON3);
	if (enable == DRV_TRUE)
		value |= DPMAIF_PIT_EN_MSK;
	else
		value &= ~DPMAIF_PIT_EN_MSK;
	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_PIT_INIT_CON3, value);
}

static void drv_dpmaif_dl_set_ao_bid_maxcnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int cnt)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CONO);
	value &= ~(DPMAIF_BAT_BID_MAXCNT_MSK);
	value |= ((cnt << 16) & DPMAIF_BAT_BID_MAXCNT_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CONO, value);
}

static void drv_dpmaif_dl_set_ao_mtu(struct dpmaif_hw_info *hw_info, 
	unsigned int mtu_sz)
{
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON1, mtu_sz);
}

static void drv_dpmaif_dl_set_ao_pit_chknum(
	struct dpmaif_hw_info *hw_info, unsigned char q_num,
	unsigned int number)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2);
	value &= ~(DPMAIF_PIT_CHK_NUM_MSK);
	value |= ((number << 24) & DPMAIF_PIT_CHK_NUM_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2, value);
}

static void drv_dpmaif_dl_set_ao_remain_minsz(
	struct dpmaif_hw_info *hw_info, 
	unsigned char q_num, unsigned int sz)
{
	unsigned int value;
	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CONO);
	value &= ~(DPMAIF_BAT_REMAIN_MINSZ_MSK);
	value |= (((sz/DPMAIF_BAT_REMAIN_SZ_BASE) << 8) &
		DPMAIF_BAT_REMAIN_MINSZ_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CONO, value);
}

static void drv_dpmaif_dl_set_ao_bat_bufsz(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int buf_sz)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2);
	value &= ~(DPMAIF_BAT_BUF_SZ_MSK);
	value |= (((buf_sz/DPMAIF_BAT_BUFFER_SZ_BASE) << 8) &
		DPMAIF_BAT_BUF_SZ_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2, value);
}

static void drv_dpmaif_dl_set_ao_bat_rsv_length(struct dpmaif_hw_info *hw_info,
	unsigned char q_num,
	unsigned int length)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2);
	value &= ~(DPMAIF_BAT_RSV_LEN_MSK);
	value |= (length & DPMAIF_BAT_RSV_LEN_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_PKTINFO_CON2, value);
}

static void drv_dpmaif_dl_set_pkt_alignment(struct dpmaif_hw_info *hw_info,
	unsigned char q_num,
	DRV_BOOL enable, unsigned int mode)
{
	unsigned int value;

	if (mode >= 2)
		ASSERT(0);

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);
	value &= ~(DPMAIF_PKT_ALIGN_MSK);
	if (enable == DRV_TRUE) {
		value |= DPMAIF_PKT_ALIGN_EN;
		value |= ((mode << 22) & DPMAIF_PKT_ALIGN_MSK);
	}
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

static void drv_dpmaif_dl_set_pkt_checksum(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);
	value |= DPMAIF_DL_PKT_CHECKSUM_EN;
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

static void drv_dpmaif_dl_set_ao_frg_check_thres(struct dpmaif_hw_info *hw_info,
	unsigned char q_num,
	unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES);
	value &= ~(DPMAIF_FRG_CHECK_THRES_MSK);
	value |= (size & DPMAIF_FRG_CHECK_THRES_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES, value);
}

static void drv_dpmaif_dl_set_ao_frg_bufsz(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int buf_sz)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES);
	value &= ~(DPMAIF_FRG_BUF_SZ_MSK);
	value |= (((buf_sz/DPMAIF_FRG_BUFFER_SZ_BASE) << 8) &
		DPMAIF_FRG_BUF_SZ_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES, value);
}

static void drv_dpmaif_dl_frg_ao_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES);
	if (enable == DRV_TRUE)
		value |= DPMAIF_FRG_EN_MSK;
	else
		value &= ~DPMAIF_FRG_EN_MSK;
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_FRG_CHK_THRES, value);
}

static void drv_dpmaif_dl_set_ao_bat_check_thres(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);
	value &= ~(DPMAIF_BAT_CHECK_THRES_MSK);
	value |= ((size << 16) & DPMAIF_BAT_CHECK_THRES_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

static void drv_dpmaif_dl_set_pit_seqnum(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int seq)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_PIT_SEQ_END);
	value &= ~(DPMAIF_DL_PIT_SEQ_MSK);
	value |= (seq & DPMAIF_DL_PIT_SEQ_MSK);
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_PIT_SEQ_END, value);
}

static void drv_dpmaif_dl_set_dlq_pit_base_addr(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);

	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON0, lb_addr);
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON4, hb_addr);
}

static void drv_dpmaif_dl_set_dlq_pit_size(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON1);
	value &= ~(DPMAIF_PIT_SIZE_MSK);
	value |= (size & DPMAIF_PIT_SIZE_MSK);
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON1, value);

	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON2, 0);
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON3, 0);
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON5, 0);
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON6, 0);
}

static void drv_dpmaif_dl_dlq_pit_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON3);
	if (enable == DRV_TRUE)
		value |= DPMAIF_DLQPIT_EN_MSK;
	else
		value &= ~DPMAIF_DLQPIT_EN_MSK;
	DPMAIF_WRITE_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT_CON3, value);
}

static void drv_dpmaif_dl_dlq_pit_init_done(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int pit_idx)
{
	int count = 0;
	unsigned int dl_pit_init = 0;

	dl_pit_init |= DPMAIF_DL_PIT_INIT_ALLSET;
	dl_pit_init |= (pit_idx<<DPMAIF_DLQPIT_CHAN_OFS);
	dl_pit_init |= DPMAIF_DL_PIT_INIT_EN;

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT) &
			DPMAIF_DL_PIT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, 
				NRL2_DPMAIF_DL_DLQPIT_INIT, dl_pit_init);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_dlq_pit_init_done check fail-1");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_INIT) &
		DPMAIF_DL_PIT_INIT_NOT_READY) == DPMAIF_DL_PIT_INIT_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_dlq_pit_init_done check fail-2");
			break;
		}
	}
}

static void drv_dpmaif_config_dlq_pit_hw(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, struct hifdpmaif_dl_st *p_dl_que)
{
	unsigned int pit_idx = q_num;

	drv_dpmaif_dl_set_dlq_pit_base_addr(hw_info, q_num,
		(unsigned long)p_dl_que->pit_base);
	drv_dpmaif_dl_set_dlq_pit_size(hw_info, q_num, p_dl_que->pit_size_cnt);
	drv_dpmaif_dl_dlq_pit_en(hw_info, q_num, DRV_TRUE);
	drv_dpmaif_dl_dlq_pit_init_done(hw_info, q_num, pit_idx);
}

static void drv_dpmaif_config_all_dlq_hw(struct dpmaif_hw_info *hw_info)
{
	int i = 0;
	struct hifdpmaif_property *p_property = &hw_info->dpmaif_property;

	for (i = 0; i < MAIFQ_MAX_DLQ_NUM; i++)
		drv_dpmaif_config_dlq_pit_hw(hw_info, i, &p_property->dl_que[i]);
}

static void drv_dpmaif_dl_all_queue_en(struct dpmaif_hw_info *hw_info,
	DRV_BOOL enable)
{
	unsigned int dl_bat_init = 0;
	unsigned int value;
	unsigned int count = 0;

	value = DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1);

	if (enable == DRV_TRUE)
		value |= DPMAIF_BAT_EN_MSK;
	else
		value &= ~DPMAIF_BAT_EN_MSK;

	DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT_CON1, value);
	dl_bat_init |= DPMAIF_DL_BAT_INIT_ONLY_ENABLE_BIT;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	/*update DL bat setting to HW*/
	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dpmaif_dl_all_queue_en check fail-1\n");
			break;
		}
	}
	/*wait HW updating*/
	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) ==
		DPMAIF_DL_BAT_INIT_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dpmaif_dl_all_queue_en check fail-2\n");
			break;
		}
	}

}

static void drv_dpmaif_config_dlq_hw(struct dpmaif_hw_info *hw_info)
{
	struct hifdpmaif_property *p_property = &hw_info->dpmaif_property;

	unsigned int que_cnt;
	struct hifdpmaif_dl_st *p_dl_que;
	struct hifdpmaif_dl_hwq *p_dl_hw;

	drv_dpmaif_dl_dlq_hpc_hw_init(hw_info);
	for (que_cnt = 0 ; que_cnt < MAIFQ_MAX_DLQ_NUM ; que_cnt++) {
		/*all queue share one bat/frag bat table.*/
		if (que_cnt != 0)
			break;
		p_dl_que = &p_property->dl_que[que_cnt];
		p_dl_hw = &p_property->dl_que_hw[que_cnt];
		if (p_dl_que->que_started == DRV_TRUE) {
			drv_dpmaif_dl_set_ao_remain_minsz(hw_info,
				que_cnt, p_dl_hw->bat_remain_size);

			drv_dpmaif_dl_set_ao_bat_bufsz(hw_info,
				que_cnt, p_dl_hw->bat_pkt_bufsz);

			drv_dpmaif_dl_set_ao_frg_bufsz(hw_info,
				que_cnt, p_dl_hw->frg_pkt_bufsz);

			drv_dpmaif_dl_set_ao_bat_rsv_length(hw_info,
				que_cnt, p_dl_hw->bat_rsv_length);

			drv_dpmaif_dl_set_ao_bid_maxcnt(hw_info, que_cnt,
				p_dl_hw->pkt_bid_max_cnt);

			if (p_dl_hw->pkt_alignment == 64) {
				drv_dpmaif_dl_set_pkt_alignment(hw_info, que_cnt,
					DRV_TRUE, DPMAIF_PKT_ALIGN64_MODE);
			} else if (p_dl_hw->pkt_alignment == 128) {
				drv_dpmaif_dl_set_pkt_alignment(hw_info, que_cnt,
					DRV_TRUE, DPMAIF_PKT_ALIGN128_MODE);
			} else {
				drv_dpmaif_dl_set_pkt_alignment(hw_info,
					que_cnt, DRV_FALSE, 0);
			}

			drv_dpmaif_dl_set_pit_seqnum(hw_info, que_cnt,
				DPMAIF_DL_PIT_SEQ_VALUE);

			drv_dpmaif_dl_set_ao_mtu(hw_info, p_dl_hw->mtu_size);


			drv_dpmaif_dl_set_ao_pit_chknum(hw_info, que_cnt,
				p_dl_hw->chk_pit_num);
			drv_dpmaif_dl_set_ao_bat_check_thres(hw_info, que_cnt,
				p_dl_hw->chk_bat_num);
			drv_dpmaif_dl_set_ao_frg_check_thres(hw_info, que_cnt,
				p_dl_hw->chk_frg_num);

			/*Enable Frg feature*/
			drv_dpmaif_dl_frg_ao_en(hw_info, que_cnt, DRV_TRUE);

			/*init frg use same BAT register*/
			drv_dpmaif_dl_set_bat_base_addr(hw_info, que_cnt,
				(unsigned long)p_dl_que->frg_base);
			drv_dpmaif_dl_set_bat_size(hw_info, que_cnt,
				p_dl_que->frg_size_cnt);
			drv_dpmaif_dl_bat_en(hw_info, que_cnt, DRV_TRUE);
			drv_dpmaif_dl_bat_init_done(hw_info, que_cnt, DRV_TRUE);

			/*normal bat init*/
			drv_dpmaif_dl_set_bat_base_addr(hw_info, que_cnt,
				(unsigned long)p_dl_que->bat_base);
			drv_dpmaif_dl_set_bat_size(hw_info, que_cnt,
				p_dl_que->bat_size_cnt);
			/*Enable BAT*/
			drv_dpmaif_dl_bat_en(hw_info, que_cnt, DRV_FALSE);
			/*notify HW init/setting done*/
			drv_dpmaif_dl_bat_init_done(hw_info, que_cnt, DRV_FALSE);

			/*init pit (two pit table)*/
			if (DPMAIF_HPC_DLQ_PATH_DF <
				DPMAIF_HPC_DLQ_PATH_MODE2) {
				drv_dpmaif_dl_set_pit_base_addr(hw_info, que_cnt,
					(unsigned long)p_dl_que->pit_base);
				drv_dpmaif_dl_set_pit_size(hw_info,
					que_cnt, p_dl_que->pit_size_cnt);
				/*Enable PIT*/
				drv_dpmaif_dl_pit_en(hw_info, que_cnt, DRV_TRUE);
				/*notify HW init/setting done*/
				drv_dpmaif_dl_pit_init_done(hw_info, que_cnt);
			} else {
				drv_dpmaif_config_all_dlq_hw(hw_info);
			}

			drv_dpmaif_dl_all_queue_en(hw_info, DRV_TRUE);
		}
	}

	drv_dpmaif_dl_set_pkt_checksum(hw_info);
}

static void drv_dpmaif_ul_update_drb_size(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int size)
{
	unsigned int old_size;
	old_size = DPMAIF_READ_PD_UL(hw_info, DPMAIF_UL_DRBSIZE_ADDRH_n(q_num));
	old_size &= ~DPMAIF_DRB_SIZE_MSK;
	old_size |= (size & DPMAIF_DRB_SIZE_MSK);
	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_UL_DRBSIZE_ADDRH_n(q_num), old_size);
}

static void drv_dpmaif_ul_update_drb_base_addr(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);
	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_ULQSAR_n(q_num), lb_addr);
	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_UL_DRB_ADDRH_n(q_num), hb_addr);
}

static void drv_dpmaif_ul_rdy_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL ready)
{
	unsigned int ul_rdy_en;
	ul_rdy_en = DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0);
	if (ready == DRV_TRUE)
		ul_rdy_en |= (1 << q_num);
	else
		ul_rdy_en &= ~(1 << q_num);

	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0, ul_rdy_en);
}

static void drv_dpmaif_ul_arb_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int ul_arb_en;

	ul_arb_en = DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0);

	if (enable == DRV_TRUE)
		ul_arb_en |= (1 << (q_num + 8));
	else
		ul_arb_en &= ~(1 << (q_num + 8));

	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0, ul_arb_en);
}


static void drv_dpmaif_config_ulq_hw(struct dpmaif_hw_info *hw_info)
{
	struct hifdpmaif_property *p_property = &hw_info->dpmaif_property;
	unsigned int que_cnt;
	struct hifmaif_ul_st *p_ul_que;

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];
		if (p_ul_que->que_started == DRV_TRUE) {
			drv_dpmaif_ul_update_drb_size(hw_info,
				que_cnt, (p_ul_que->drb_size_cnt *
				DPMAIF_UL_DRB_ENTRY_WORD));
			drv_dpmaif_ul_update_drb_base_addr(hw_info, que_cnt,
				(unsigned long)p_ul_que->drb_base);
			drv_dpmaif_ul_rdy_en(hw_info, que_cnt, DRV_TRUE);
			drv_dpmaif_ul_arb_en(hw_info, que_cnt, DRV_TRUE);
		} else {
			drv_dpmaif_ul_arb_en(hw_info, que_cnt, DRV_FALSE);
		}
	}
}

static void drv_dpmaif_hw_init_done(struct dpmaif_hw_info *hw_info)
{
	unsigned int reg_value = 0;
	unsigned int count = 0;

	/*sync default value to SRAM*/
	reg_value = DPMAIF_READ_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_OVERWRITE_CFG);
	reg_value |= (DPMAIF_SRAM_SYNC_MASK);
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_OVERWRITE_CFG, reg_value);

	/*polling status*/
	while ((DPMAIF_READ_PD_MISC(hw_info, NRL2_DPMAIF_AP_MISC_OVERWRITE_CFG) &
		DPMAIF_SRAM_SYNC_MASK)) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif hw_init_done check fail\n");
			break;
		}
	}

	/*UL cfg done*/
	DPMAIF_WRITE_AO_UL(hw_info, NRL2_DPMAIF_AO_UL_INIT_SET,
		DPMAIF_UL_INIT_DONE_MASK);
	/*DL cfg done*/
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_INIT_SET,
		DPMAIF_DL_INIT_DONE_MASK);
}

static DRV_BOOL drv_dpmaif_config_que_hw(struct dpmaif_hw_info *hw_info)
{
	drv_dpmaif_common_hw_init(hw_info);
	drv_dpmaif_config_dlq_hw(hw_info);
	drv_dpmaif_config_ulq_hw(hw_info);
	drv_dpmaif_hw_init_done(hw_info);
	return DRV_TRUE;
}

DRV_BOOL drv_dpmaif_config_tx_que_hw(struct dpmaif_hw_info *hw_info)
{
	struct hifdpmaif_property *p_property = &hw_info->dpmaif_property;
	unsigned int que_cnt;
	struct hifmaif_ul_st *p_ul_que;

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];
		if (p_ul_que->que_started == DRV_TRUE) {
			drv_dpmaif_ul_update_drb_size(hw_info,
				que_cnt, (p_ul_que->drb_size_cnt *
				DPMAIF_UL_DRB_ENTRY_WORD));
			drv_dpmaif_ul_update_drb_base_addr(hw_info, que_cnt,
				(unsigned long)p_ul_que->drb_base);
			drv_dpmaif_ul_rdy_en(hw_info, que_cnt, DRV_TRUE);
			drv_dpmaif_ul_arb_en(hw_info, que_cnt, DRV_TRUE);
		} else {
			drv_dpmaif_ul_arb_en(hw_info, que_cnt, DRV_FALSE);
		}
	}
	return DRV_TRUE;
}


/***********************************************************************
 *	DPMAIF Common HW setting
 *
 ***********************************************************************/
unsigned int drv_dpmaif_ip_code_version(struct dpmaif_hw_info *hw_info)
{
	unsigned int ret = 0;

	/* ToDo */
	return ret;
}

/***********************************************************************
 *	DPMAIF UL/DL HW setting
 *
 ***********************************************************************/
void drv_dpmaif_dl_queue_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	unsigned int dl_bat_init = 0;
	unsigned int count = 0;

	dl_bat_init |= DPMAIF_DL_BAT_INIT_ONLY_ENABLE_BIT;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	if (enable == DRV_TRUE)
		drv_dpmaif_dl_bat_en(hw_info, q_num, DRV_TRUE);
	else
		drv_dpmaif_dl_bat_en(hw_info, q_num, DRV_FALSE);

	/*update DL bat setting to HW*/
	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_dl_queue_en check fail-1\n");
			break;
		}
	}

	/*wait HW updating*/
	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) == DPMAIF_DL_BAT_INIT_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_dl_queue_en check fail-2\n");
			break;
		}
	}

}

static unsigned int drv_dpmaif_dl_idle_check(struct dpmaif_hw_info *hw_info)
{
	unsigned int ret;

	ret = (DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_DBG_STA1) & DPMAIF_DL_IDLE_STS);

	/*if total queue idle, UL all idle*/
	if (ret == DPMAIF_DL_IDLE_STS)
		ret = 0; /*idle*/
	else
		ret = 1; /*not idle*/

	return ret;
}

void drv_dpmaif_ul_queue_en(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, DRV_BOOL enable)
{
	drv_dpmaif_ul_arb_en(hw_info, q_num, enable);
}

static void drv_dpmaif_ul_all_queue_en(struct dpmaif_hw_info *hw_info,
	DRV_BOOL enable)
{
	unsigned int ul_arb_en;
	ul_arb_en = DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0);

	if (enable == DRV_TRUE)
		ul_arb_en |= DPMAIF_UL_ALL_QUE_ARB_EN;
	else
		ul_arb_en &= ~DPMAIF_UL_ALL_QUE_ARB_EN;
	DPMAIF_WRITE_PD_UL(hw_info, DPMAIF_PD_UL_CHNL_ARB0, ul_arb_en);

}

unsigned int drv_dpmaif_ul_idle_check(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int ret, ul_dbg_sta;

	ul_dbg_sta = DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_DBG_STA2);

	/*if total queue idle, UL all idle*/
	if ((ul_dbg_sta & DPMAIF_UL_IDLE_STS_MSK) == DPMAIF_UL_IDLE_STS) {
		ret = 1;
	} else {
		/*check per queue channel active?*/
		if ((ul_dbg_sta & DPMAIF_UL_CHNL_ACTIVE_MSK) ==
			DPMAIF_UL_CHNL_ACTIVE_n(q_num)) {
			ret = 0;
		} else {
			ret = 1;
		}
	}
	return ret;
}

static unsigned int drv_dpmaif_ul_all_idle_check(struct dpmaif_hw_info *hw_info)
{
	unsigned int ret, ul_dbg_sta;

	ul_dbg_sta = DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_DBG_STA2);
	/*if total queue idle, UL all idle*/
	if ((ul_dbg_sta & DPMAIF_UL_IDLE_STS_MSK) == DPMAIF_UL_IDLE_STS)
		ret = 0; /*idle*/
	else
		ret = 1; /*busy*/

	return ret;
}

/***********************************************************************
 *	DPMAIF UL Part HW setting
 *
 ***********************************************************************/
int drv_dpmaif_ul_add_wcnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int drb_entry_cnt)
{
	unsigned int ul_update;
	unsigned int count = 0;

	ul_update = (drb_entry_cnt & 0x0000ffff);
	ul_update |= DPMAIF_UL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_UL(hw_info, DPMAIF_ULQ_ADD_DESC_CH_n(q_num)) &
			DPMAIF_UL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_UL(hw_info,
				DPMAIF_ULQ_ADD_DESC_CH_n(q_num), ul_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for UL add wcnt(%u) to queue%d failed! reg:0x%x!\n",
				drb_entry_cnt, q_num, DPMAIF_READ_PD_UL(hw_info, DPMAIF_ULQ_ADD_DESC_CH_n(q_num)));
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_UL(hw_info, DPMAIF_ULQ_ADD_DESC_CH_n(q_num)) &
		DPMAIF_UL_ADD_NOT_READY) == DPMAIF_UL_ADD_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"UL add wcnt(%u) for queue%d failed! reg:0x%x!\n",
				drb_entry_cnt, q_num, DPMAIF_READ_PD_UL(hw_info, DPMAIF_ULQ_ADD_DESC_CH_n(q_num)));
			return HW_REG_CHK_FAIL;
		}
	}

	return 0;
}

unsigned int drv_dpmaif_ul_get_ridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int ridx;
	ridx = DPMAIF_UL_DRB_GET_RIDX(hw_info, q_num);
	return ridx;
}


void drv_dpmaif_ul_restore(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int restore_ridx)
{
	unsigned int ul_restore;
	unsigned int count = 0;

	ul_restore = (restore_ridx & 0x0003ffff);

	while (1) {
		if ((DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_RESTORE_RIDX) &
			DPMAIF_UL_RESTORE_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_UL(hw_info,
				DPMAIF_PD_UL_RESTORE_RIDX, ul_restore);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_ul_restore check fail-1\n");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_RESTORE_RIDX) &
		DPMAIF_UL_ADD_NOT_READY) == DPMAIF_UL_RESTORE_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_ul_restore check fail-2\n");
			break;
		}
	}

}

unsigned int drv_dpmaif_ul_get_drb_size(struct dpmaif_hw_info *hw_info,
	unsigned int q_num)
{
	unsigned int size;

	size = DPMAIF_READ_PD_UL(hw_info, DPMAIF_UL_DRBSIZE_ADDRH_n(q_num));
	size &= DPMAIF_DRB_SIZE_MSK;
	return size;
}

int drv_dpmaif_dl_add_pit_remain_cnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int pit_remain_cnt)
{
	unsigned int dl_update;
	unsigned int count = 0;

	dl_update = (pit_remain_cnt & 0x0003ffff);
	dl_update |= DPMAIF_DL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, 
				DPMAIF_PD_DL_PIT_ADD, dl_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"polling ready for adding pit remain count(%u) to queue%d failed\n",
				pit_remain_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_PIT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) == DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"polling ready for adding pit remain count(%u) to queue%d failed\n",
				pit_remain_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	return 0;
}

int drv_dpmaif_dl_add_dlq_pit_remain_cnt(struct dpmaif_hw_info *hw_info,
	unsigned int dlq_pit_idx, unsigned int pit_remain_cnt)
{
	int count = 0;
	unsigned int dl_update;

	dl_update = (pit_remain_cnt & 0x0003ffff);
	dl_update |= (DPMAIF_DL_ADD_UPDATE |
		(dlq_pit_idx << DPMAIF_ADD_DLQ_PIT_CHAN_OFS));

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, 
				NRL2_DPMAIF_DL_DLQPIT_ADD, dl_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dl_add_dlq_pit_remain_cnt check failed-1\n");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, NRL2_DPMAIF_DL_DLQPIT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) ==
		DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dl_add_dlq_pit_remain_cnt check failed-2\n");
			break;
		}
	}

	return 0;
}

unsigned int drv_dpmaif_dl_dlq_pit_get_wridx(struct dpmaif_hw_info *hw_info,
	unsigned int dlq_pit_idx)
{
	unsigned int widx;

	widx = ((DPMAIF_READ_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQ_STA5 +
		dlq_pit_idx * 0x20)) & DPMAIF_DL_PIT_WRIDX_MSK);
	return widx;
}

unsigned int drv_dpmaif_dl_dlq_pit_get_rdidx(struct dpmaif_hw_info *hw_info,
	unsigned int dlq_pit_idx)
{
	unsigned int ridx;

	ridx = ((DPMAIF_READ_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_DLQ_STA6 +
		dlq_pit_idx * 0x20)) & DPMAIF_DL_PIT_WRIDX_MSK);
	return ridx;
}

static unsigned int drv_dpmaif_dl_get_wridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int widx;

	widx = ((DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PIT_STA3)) &
		DPMAIF_DL_PIT_WRIDX_MSK);
	return widx;
}

static unsigned int drv_dpmaif_dl_get_pit_ridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int ridx;

	ridx = ((DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_PIT_STA2)) &
		DPMAIF_DL_PIT_WRIDX_MSK);
	return ridx;
}

int drv_dpmaif_dl_add_bat_cnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int bat_entry_cnt)
{
	unsigned int dl_bat_update;
	unsigned int count = 0;

	dl_bat_update = (bat_entry_cnt & 0xffff);
	dl_bat_update |= DPMAIF_DL_ADD_UPDATE;
	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD, dl_bat_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for DL adding bat cnt(%u) to queue%d failed!",
				bat_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) ==
		DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for DL adding bat cnt(%u) to queue%d failed!",
				bat_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	MTK_DEBUG_LOG(TAG, "drv_dpmaif_dl_add_bat_cnt--qno: %d, cnt: %d",
			q_num, bat_entry_cnt);
	return 0;
}

unsigned int drv_dpmaif_dl_get_bat_ridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int ridx;

	ridx = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_BAT_STA2) &
		DPMAIF_DL_BAT_WRIDX_MSK;
	return ridx;
}

unsigned int drv_dpmaif_dl_get_bat_wridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int widx;

	widx = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_BAT_STA3) &
		DPMAIF_DL_BAT_WRIDX_MSK;
	return widx;
}

void drv_dpmaif_dl_add_frg_cnt(struct dpmaif_hw_info *hw_info,
	unsigned char q_num, unsigned int frg_entry_cnt)
{
	unsigned int dl_frg_update;
	unsigned int count = 0;

	dl_frg_update = (frg_entry_cnt & 0xffff);
	dl_frg_update |= DPMAIF_DL_FRG_ADD_UPDATE;
	dl_frg_update |= DPMAIF_DL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD, dl_frg_update);
			break;
		}
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_add_frg_cnt check fail-1\n");
			break;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_BAT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) ==
		DPMAIF_DL_ADD_NOT_READY) {
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dl_add_frg_cnt check fail-2");
			break;
		}
	}

}

unsigned int drv_dpmaif_dl_get_frg_ridx(struct dpmaif_hw_info *hw_info,
	unsigned char q_num)
{
	unsigned int ridx;

	ridx = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_FRG_STA2) &
		DPMAIF_DL_FRG_WRIDX_MSK;
	return ridx;
}

DRV_BOOL drv_dpmaif_check_power_down(struct dpmaif_hw_info *hw_info)
{
	DRV_BOOL ret;
	unsigned int check_value;

	check_value = DPMAIF_READ_PD_UL(hw_info, DPMAIF_ULQSAR_n(0));

	if (check_value == 0)
		ret = DRV_TRUE;
	else
		ret = DRV_FALSE;

	return ret;
}


#define DPMAIF_REORDER_EN_MSK		   (0x1F << 8)
#define DP_RO_EN_4GN	(1 << 8)
#define DP_RO_EN_4GH	(1 << 9)
#define DP_RO_EN_5GU	(1 << 10)
#define DP_RO_EN_5GSW	(1 << 11)
#define DP_RO_EN_LFSW	(1 << 12)

#define DP_RO_EN_QUE_SET (DP_RO_EN_5GU|DP_RO_EN_5GSW)

void drv_dpmaif_ap_reorder_en(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;

	/*Set HW queue channel for reorder*/
	value = DPMAIF_READ_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES);

	value &= ~(DPMAIF_REORDER_EN_MSK);
	value |= DP_RO_EN_QUE_SET;
	DPMAIF_WRITE_AO_DL(hw_info, DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

DRV_BOOL drv_dpmaif_get_hw_hpc_cntl_mode(struct dpmaif_hw_info *hw_info)
{
	unsigned int mode;

	mode = DPMAIF_READ_AO_DL(hw_info, NRL2_DPMAIF_AO_DL_HPC_CNTL);
	mode &= 0x3;

	if (mode >= DPMAIF_HPC_DLQ_PATH_MODE2)
		return DRV_TRUE;
	else
		return DRV_FALSE;
}

/*-------- DLQ interrupt use------------------------------*/
static void drv_dpmaif_mask_dlq0_pit_lenerr(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AO_UL_APDL_L2TIMSR0,
		DPMAIF_DL_INT_DLQ0_PITCNT_LEN_MSK);
}

static void drv_dpmaif_mask_dlq1_pit_lenerr(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AO_UL_APDL_L2TIMSR0,
		DPMAIF_DL_INT_DLQ1_PITCNT_LEN_MSK);
}

int drv_dpmaif_dlq_mask_rx_pit_cnt_len_err_intr(
	struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	if (qno == DPF_RX_QNO0)
		drv_dpmaif_mask_dlq0_pit_lenerr(hw_info);
	else
		drv_dpmaif_mask_dlq1_pit_lenerr(hw_info);

	return 0;
}


static void drv_dpmaif_unmask_dlq0_pit_lenerr(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AO_UL_APDL_L2TIMCR0,
		DPMAIF_DL_INT_DLQ0_PITCNT_LEN_MSK);
}

static void drv_dpmaif_unmask_dlq1_pit_lenerr(struct dpmaif_hw_info *hw_info)
{
	DPMAIF_WRITE_PD_MISC(hw_info, NRL2_DPMAIF_AO_UL_APDL_L2TIMCR0,
		DPMAIF_DL_INT_DLQ1_PITCNT_LEN_MSK);
}

int drv_dpmaif_dlq_unmask_rx_pit_cnt_len_err_intr(
	struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	if (qno == DPF_RX_QNO0)
		drv_dpmaif_unmask_dlq0_pit_lenerr(hw_info);
	else
		drv_dpmaif_unmask_dlq1_pit_lenerr(hw_info);

	return 0;
}

static DRV_BOOL drv_dpmaif_set_queue_property(struct dpmaif_hw_info *hw_info,
	struct dpmaif_hw_init_para *init_para)
{
	struct hifdpmaif_property *p_property = &hw_info->dpmaif_property;
	unsigned int que_cnt;
	struct hifdpmaif_dl_st *p_dl_que;
	struct hifmaif_ul_st *p_ul_que;
	struct hifdpmaif_dl_hwq *p_dl_hwq;

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_DLQ_NUM; que_cnt++) {
		p_dl_que = &p_property->dl_que[que_cnt];
		p_dl_hwq = &p_property->dl_que_hw[que_cnt];

		/*init dlq queue setting*/
		memset(p_dl_hwq, 0, sizeof(struct hifdpmaif_dl_hwq));
		p_dl_hwq->bat_remain_size = DPMAIF_HW_BAT_REMAIN;
		p_dl_hwq->bat_pkt_bufsz = DPMAIF_HW_BAT_PKTBUF;
		p_dl_hwq->frg_pkt_bufsz = DPMAIF_HW_FRG_PKTBUF;
		p_dl_hwq->bat_rsv_length = DPMAIF_HW_BAT_RSVLEN;
		p_dl_hwq->pkt_bid_max_cnt = DPMAIF_HW_PKT_BIDCNT;
		p_dl_hwq->pkt_alignment = DPMAIF_HW_PKT_ALIGN;
		p_dl_hwq->mtu_size = DPMAIF_HW_MTU_SIZE;

		p_dl_hwq->chk_bat_num = DPMAIF_HW_CHK_BAT_NUM;
		p_dl_hwq->chk_frg_num = DPMAIF_HW_CHK_FRG_NUM;
		p_dl_hwq->chk_pit_num = DPMAIF_HW_CHK_PIT_NUM;

		p_dl_que->bat_base =
			(unsigned int *)(init_para->pkt_bat_base_addr[que_cnt]);
		p_dl_que->bat_size_cnt = init_para->pkt_bat_size_cnt[que_cnt];
		p_dl_que->pit_base =
			(unsigned int *)(init_para->pit_base_addr[que_cnt]);
		p_dl_que->pit_size_cnt = init_para->pit_size_cnt[que_cnt];
		p_dl_que->frg_base =
			(unsigned int *)(init_para->frg_bat_base_addr[que_cnt]);
		p_dl_que->frg_size_cnt = init_para->frg_bat_size_cnt[que_cnt];

		p_dl_que->que_started = DRV_TRUE;
	}

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];

		p_ul_que->drb_base =
			(unsigned int *)(init_para->drb_base_addr[que_cnt]);
		p_ul_que->drb_size_cnt = init_para->drb_size_cnt[que_cnt];

		p_ul_que->que_started = DRV_TRUE;
	}

	return DRV_TRUE;
}

void drv_dpmaif_hw_stop_tx_queue(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	int ret = 0;

	/* Disable HW arb and check idle */
	drv_dpmaif_ul_all_queue_en(hw_info, false);
	do {
		ret = drv_dpmaif_ul_all_idle_check(hw_info);

		/* retry handler */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "Stop TX failed, 0x%x\n",
				DPMAIF_READ_PD_UL(hw_info, DPMAIF_PD_UL_DBG_STA2));
			break;
		}
	} while (ret != 0);
}

void drv_dpmaif_hw_stop_rx_queue(struct dpmaif_hw_info *hw_info)
{
	int count = 0;
	int ret = 0;
	unsigned int wridx;
	unsigned int ridx;

	/* Disable HW arb and check idle */
	drv_dpmaif_dl_all_queue_en(hw_info, false);
	do {
		ret = drv_dpmaif_dl_idle_check(hw_info);

		/* retry handler */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "Stop RX failed, 0x%x\n",
				DPMAIF_READ_PD_DL(hw_info, DPMAIF_PD_DL_DBG_STA1));
			break;
		}
	} while (ret != 0);

	/*check middle pit sync done*/
	count = 0;
	do {
		wridx = drv_dpmaif_dl_get_wridx(hw_info, 0);
		ridx = drv_dpmaif_dl_get_pit_ridx(hw_info, 0);
		if (wridx == ridx)
			break;

		/* retry handler */
		if (++count >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG, "check middle pit sync fail.\n");
			break;
		}
	} while (1);
}

void drv_dpmaif_start_hw(struct dpmaif_hw_info *hw_info)
{
	MTK_DEBUG_LOG(TAG, "dpmaif: start tx/rx queue HW\n");
	drv_dpmaif_ul_all_queue_en(hw_info, true);
	drv_dpmaif_dl_all_queue_en(hw_info, true);
}

void drv_dpmaif_hw_isr_init(struct dpmaif_hw_info *hw_info)
{
	unsigned int value;

	/*init TOP ISR for PCIE or MDCPU*/
	value = DP_AP_ISR_PCIE;
	DPMAIF_WRITE_AO_DL(hw_info, NRL2_DPMAIF_AO_UL_AP_L1TIMR0, value);
}


void drv_dpmaif_hw_init(struct dpmaif_hw_info *hw_info, void *para)
{
	struct dpmaif_hw_init_para *init_para = NULL;

	/* checks input firstly */
	if (unlikely(para == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!\n");
		goto exit;
	}

	init_para = (struct dpmaif_hw_init_para *)para;

	/* port mode & clock config */
	drv_dpmaif_hw_config(hw_info);

	/* HW interrupt init */
	drv_dpmaif_init_intr(hw_info);

	/* HW queue config */
	drv_dpmaif_set_queue_property(hw_info, init_para);
	drv_dpmaif_config_que_hw(hw_info);

exit:
	return;
}

static void dump_device_register(struct dpmaif_hw_info *hw_info, unsigned long start_addr, int len)
{
	int i = 0;
	unsigned long base_addr = 0;
	int b4_fix_num = (len + 4) / 4;
	int b16_fix_num = b4_fix_num / 4;
	int b16_tail_num = b4_fix_num % 4;
	unsigned char line_data[128] = {0};

	if ((len <= 0) || (!hw_info)) {
		MTK_ERR_LOG(TAG, "the dump len err!");
		return;
	}

	MTK_DEBUG_LOG(TAG, "===start address:0x%lx, len(32bit):0x%x===", start_addr, len);

	for (i = 0; i < b16_fix_num; i++) {
		base_addr = hw_info->pcie_base_offset +
			start_addr + i * 16;

		MTK_ERR_LOG(TAG, "0x%04X: %08X %08X %08X %08X\n",
			i * 16, dpmaif_read32(base_addr + 0), dpmaif_read32(base_addr + 4),
			dpmaif_read32(base_addr + 8), dpmaif_read32(base_addr + 12));
	}

	if (b16_tail_num) {
		base_addr = hw_info->pcie_base_offset + start_addr + i * 16; 
		sprintf(line_data, "0x%04X:", i * 16);
		for (i = 0; i < b16_tail_num; i++) {
			sprintf((line_data + 7 + i * 9), " %08X", dpmaif_read32(base_addr + i * 4));
		}

		MTK_ERR_LOG(TAG, "%s\n", line_data);
	}
}

void drv_dpmaif_dump_all_config_regs(struct dpmaif_hw_info *hw_info)
{
	MTK_ERR_LOG(TAG,"=============dpmaif configure dump start============\n");

	/* BASE_NADDR_NRL2_DPMAIF_PD_SRAM_DL ~ BASE_NADDR_NRL2_DPMAIF_PD_SRAM_MISC  */
	MTK_ERR_LOG(TAG, "BASE_NADDR_NRL2_DPMAIF_PD_SRAM_MISC ~ BASE_NADDR_NRL2_DPMAIF_PD_SRAM_DL");
	dump_device_register(hw_info, BASE_NADDR_NRL2_DPMAIF_PD_SRAM_DL, 
		(BASE_NADDR_NRL2_DPMAIF_PD_SRAM_MISC - BASE_NADDR_NRL2_DPMAIF_PD_SRAM_DL));

	MTK_ERR_LOG(TAG,"============dpmaif configure dump end===============\n");
}


#ifdef M8X80
void drv_dpmaif_dump_debug_regs(struct dpmaif_hw_info *hw_info)
{
	// todo
	MTK_ERR_LOG(TAG,"M8x80 debug registers dump!\n");
}
#elif M8X75
static void drv_dpmaif_delay(unsigned int us)
{
	if (in_interrupt())
		udelay(us);
	else
		usleep_range(us, us+5);
}

void drv_dpmaif_dump_debug_regs(struct dpmaif_hw_info *hw_info)
{
	unsigned long base_addr = 0;
	int len = 0;
	unsigned int delay_us = 50;

	if (hw_info == NULL) {
		MTK_ERR_LOG(TAG,"hw_info NULL pointer!\n");
		return;
	}

	MTK_ERR_LOG(TAG,"===dpmaif regs dump start===\n");
	base_addr = 0x10014000;
	len = 0x9c;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_ul_ao_cfg_mmw: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);
	
	base_addr = 0x10014400;
	len = 0x74;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_dl_ao_cfg_mmw: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x10014800;
	len = 0x64;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_misc_ao_cfg_mmw: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D000;
	len = 0xE0;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_ul_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D100;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_dl_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D400;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_ap_misc_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D500;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_dl_reorder_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D600;
	len = 0x1FC;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_hpc: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022DC00;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_pd_sram_dl_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022DD00;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_pd_sram_ul_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022DE00;
	len = 0x5C;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_pd_sram_misc_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022C100;
	len = 0xDC;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_md_dl_reorder_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);	

	base_addr = 0x1022C000;
	len = 0x54;
	MTK_ERR_LOG(TAG, "nrl2_dpmaif_md_misc_cfg: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D900;
	len = 0xFC;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_dl: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D300;
	len = 0x78;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_dma_wr_config: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022D200;
	len = 0xC8;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_dma_rd_config: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	base_addr = 0x1022E000;
	len = 0x910;
	MTK_ERR_LOG(TAG, "mmw_dpmaif_dl_rd_config: 0x%lx, 0x00 - 0x%x", base_addr, len);
	dump_device_register(hw_info, base_addr, len);
	drv_dpmaif_delay(delay_us);

	MTK_ERR_LOG(TAG,"===dpmaif regs dump end===\n");
}
#endif

void drv_dpmaif_hw_dump_interrupt_status(struct dpmaif_hw_info *hw_info)
{
	unsigned int status = 0;
	status = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0);
	MTK_ERR_LOG(TAG, "Dpmaif UL status: 0x%x \n", status);
	status = DPMAIF_READ_PD_MISC(hw_info, DPMAIF_PD_AP_DL_L2TISAR0);
	MTK_ERR_LOG(TAG, "Dpmaif DL status: 0x%x \n", status);
}

void drv_dpmaif_hw_dump(struct dpmaif_hw_info *hw_info, void *para)
{
	unsigned int qno = 0;

	/*
	 * hw _ctrl won't be used here, we don't have to check it's value
	 * we use this interface to dump some DPMAIF HW registers' value
	 */
	MTK_DEBUG_LOG(TAG,
		"====== DPMAIF HW Register Value Dump Start ======\n");

	/* uplink part */
	for (qno = 0; qno < MAIFQ_MAX_ULQ_NUM; qno++)
		MTK_DEBUG_LOG(TAG, "uplink read index: %u\n",
			drv_dpmaif_ul_get_ridx(hw_info, qno));

	MTK_DEBUG_LOG(TAG, "uplink interrupt status: %u\n",
		drv_dpmaif_get_ul_lv2_sts(hw_info));
	MTK_DEBUG_LOG(TAG, "uplink interrupt mask: %u\n",
		drv_dpmaif_get_ul_interrupt_mask(hw_info));

	/* downlink part */
	for (qno = 0; qno < MAIFQ_MAX_DLQ_NUM; qno++) {
		MTK_DEBUG_LOG(TAG, "downlink PKT_BAT read index: %u\n",
			drv_dpmaif_dl_get_bat_ridx(hw_info, DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PKT_BAT write index: %u\n",
			drv_dpmaif_dl_get_bat_wridx(hw_info, DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink FRG_BAT read index: %u\n",
			drv_dpmaif_dl_get_frg_ridx(hw_info, DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PIT read index: %u\n",
			drv_dpmaif_dl_get_pit_ridx(hw_info, DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PIT write index: %u\n",
			drv_dpmaif_dl_get_wridx(hw_info, DPF_RX_QNO_DFT));
	}
	MTK_DEBUG_LOG(TAG, "downlink interrupt status: %u\n",
		drv_dpmaif_get_dl_lv2_sts(hw_info));
	MTK_DEBUG_LOG(TAG, "downlink interrupt mask: %u\n",
		drv_dpmaif_get_dl_interrupt_mask(hw_info));

	MTK_DEBUG_LOG(TAG, "====== DPMAIF HW Register Value Dump End ======\n");

}

bool drv_dpmaif_hw_check_clr_ul_done_status(struct dpmaif_hw_info *hw_info, unsigned char qno)
{
	bool ret;
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts(hw_info);

	intr_value = L2TISAR0 & DP_UL_INT_QDONE_MSK &
		(1 << (DP_UL_INT_DONE_OFFSET + qno));
	
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WRITE_PD_MISC(hw_info, DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
		ret = true;
	} else {
		ret = false;
	}

	return ret;
}


