/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_MODEM_H__
#define __CCCI_MODEM_H__

#include <mt-plat/mtk_ccci_common.h>

enum MD_FORCE_ASSERT_TYPE {
	MD_FORCE_ASSERT_RESERVE = 0x000,
	MD_FORCE_ASSERT_BY_MD_NO_RESPONSE	= 0x100,
	MD_FORCE_ASSERT_BY_MD_SEQ_ERROR		= 0x200,
	MD_FORCE_ASSERT_BY_AP_Q0_BLOCKED	= 0x300,
	MD_FORCE_ASSERT_BY_USER_TRIGGER		= 0x400,
	MD_FORCE_ASSERT_BY_MD_WDT			= 0x500,
	MD_FORCE_ASSERT_BY_AP_MPU			= 0x600,
	MD_FORCE_ASSERT_BY_AP_KE			= 0x700,
};
#define MD_FORCE_ASSERT_TYPE int

enum modem_dump_flag {
	DUMP_FLAG_CCIF = (1 << 0),
	/* tricky part, use argument length as queue index */
	DUMP_FLAG_CLDMA = (1 << 1),
	DUMP_FLAG_REG = (1 << 2),
	DUMP_FLAG_SMEM_EXP = (1 << 3),
	DUMP_FLAG_IMAGE = (1 << 4),
	DUMP_FLAG_LAYOUT = (1 << 5),
	DUMP_FLAG_QUEUE_0 = (1 << 6),
	DUMP_FLAG_QUEUE_0_1 = (1 << 7),
	DUMP_FLAG_CCIF_REG = (1 << 8),
	DUMP_FLAG_SMEM_MDSLP = (1 << 9),
	DUMP_FLAG_MD_WDT = (1 << 10),
	DUMP_FLAG_SMEM_CCISM = (1<<11),
	DUMP_MD_BOOTUP_STATUS = (1<<12),
	DUMP_FLAG_CTRL_IRQ_STATUS = (1<<13),
	DUMP_FLAG_SMEM_CCB_CTRL = (1<<14),
	DUMP_FLAG_SMEM_CCB_DATA = (1<<15),
	DUMP_FLAG_PCCIF_REG = (1 << 16),
	DUMP_FLAG_CTRL_HIF = (1 << 17),
	DUMP_FLAG_DATA_HIF = (1 << 18),
	DUMP_FLAG_HIF = (1 << 19),
	DUMP_FLAG_DATA_IRQ_STATUS = (1<<20),
	DUMP_FLAG_IRQ_STATUS = (1 << 21),
	DUMP_FLAG_SRAM = (1 << 22)
};

enum {
	MD_DBG_DUMP_INVALID = -1,
	/*AP side reg 0~15*/
	MD_DBG_DUMP_PCMON = 0,
	MD_DBG_DUMP_BUSREC,
	MD_DBG_DUMP_BUS,
	MD_DBG_DUMP_PLL,
	MD_DBG_DUMP_ECT,

	MD_DBG_DUMP_SMEM,
	/*md side reg 16~23*/
	MD_DBG_DUMP_TOPSM = 16,
	MD_DBG_DUMP_MDRGU,
	MD_DBG_DUMP_OST,
	/*misc*/
	MD_DBG_DUMP_PORT = 24,
	/*bit map*/
	MD_DBG_DUMP_AP_REG = 0xFFFF,
	MD_DBG_DUMP_ALL = 0x7FFFFFFF,
};

enum md_boot_mode {
	MD_BOOT_MODE_INVALID = 0,
	MD_BOOT_MODE_NORMAL,
	MD_BOOT_MODE_META,
	MD_BOOT_MODE_MAX,
};

enum {
	MD_CFG_MDLOG_MODE,
	MD_CFG_SBP_CODE,
	MD_CFG_DUMP_FLAG,
};

enum {
	ALL_CCIF = 0,
	AP_MD1_CCIF,
	AP_MD3_CCIF,
	MD1_MD3_CCIF,
};

enum {
	AP_MD_HS_V2 = 2,
};

enum {
	SMF_CLR_RESET = (1 << 0), /* clear when reset modem */
	SMF_NCLR_FIRST = (1 << 1), /* do not clear even in MD first boot up */
	SMF_MD3_RELATED = (1<<2), /* MD3 related share memory */
};

struct ccci_mem_region {
	phys_addr_t base_md_view_phy;
	phys_addr_t base_ap_view_phy;
	void __iomem *base_ap_view_vir;
	unsigned int size;
};

struct ccci_smem_region {
	/* pre-defined */
	unsigned int id;
	unsigned int offset; /* in bank4 */
	unsigned int size;
	unsigned int flag;
	/* runtime calculated */
	phys_addr_t base_md_view_phy;
	phys_addr_t base_ap_view_phy;
	void __iomem *base_ap_view_vir;
};

struct ccci_mem_layout {
	/* MD RO and RW (bank0) */
	struct ccci_mem_region md_bank0;

	/* share memory (bank4) */
	struct ccci_mem_region md_bank4_noncacheable_total;
	struct ccci_mem_region md_bank4_cacheable_total;

	/* share memory detail */
	struct ccci_smem_region *md_bank4_noncacheable;
	struct ccci_smem_region *md_bank4_cacheable;

	/* runtime data memory*/
	unsigned char *ccci_rt_smem_base;
	unsigned int   ccci_rt_smem_size;
};

enum CCCI_RUNTIME_FEATURE_SUPPORT_TYPE {
	CCCI_FEATURE_NOT_EXIST = 0,
	CCCI_FEATURE_NOT_SUPPORT = 1,
	CCCI_FEATURE_MUST_SUPPORT = 2,
	CCCI_FEATURE_OPTIONAL_SUPPORT = 3,
	CCCI_FEATURE_SUPPORT_BACKWARD_COMPAT = 4,
};

enum MD_CCCI_RUNTIME_FEATURE_ID {
	RT_ID_MD_PORT_ENUM= 0,
	RT_ID_SAP_PORT_ENUM,
	RT_ID_MAX,
};

enum AP_CCCI_RUNTIME_FEATURE_ID {
	AT_CHANNEL_NUM = 0,
	AP_RUNTIME_FEATURE_ID_MAX,
};

/* Rutime data common part */
enum MISC_FEATURE_STATE {
	FEATURE_NOT_EXIST = 0,
	FEATURE_NOT_SUPPORT,
	FEATURE_SUPPORT,
	FEATURE_PARTIALLY_SUPPORT,
};

struct ccci_feature_support {
	u8 support_mask:4;
	u8 version:4;
};

#define FEATURE_COUNT 64
#define MD_FEATURE_QUERY_PATTERN 0x49434343
#define AP_FEATURE_QUERY_PATTERN 0x43434349
#define CCCI_AP_RUNTIME_RESERVED_SIZE 120
#define CCCI_MD_RUNTIME_RESERVED_SIZE 152

struct md_query_ap_feature {
	u32 head_pattern;
	struct ccci_feature_support feature_set[FEATURE_COUNT];
	u32 tail_pattern;
	u8  reserved[CCCI_MD_RUNTIME_RESERVED_SIZE];
};

struct ap_query_md_feature {
	u32 head_pattern;
	struct ccci_feature_support feature_set[FEATURE_COUNT];
	u32 share_memory_support;
	u32 ap_runtime_data_addr;
	u32 ap_runtime_data_size;
	u32 md_runtime_data_addr;
	u32 md_runtime_data_size;
	u32 set_md_mpu_start_addr;
	u32 set_md_mpu_total_size;
	u32 tail_pattern;
	u8  reserved[CCCI_AP_RUNTIME_RESERVED_SIZE];
};

struct ap_query_md_feature_v2_1 {
	u32 head_pattern;
	struct ccci_feature_support feature_set[FEATURE_COUNT];
	u32 share_memory_support;
	u32 ap_runtime_data_addr;
	u32 ap_runtime_data_size;
	u32 md_runtime_data_addr;
	u32 md_runtime_data_size;
	u32 noncached_mpu_start_addr;
	u32 noncached_mpu_total_size;
	u32 cached_mpu_start_addr;
	u32 cached_mpu_total_size;
	u32 reserve_addr[12];
	u32 tail_pattern;
};

typedef enum {
	HIF_EX_INIT = 0, /* interrupt */
	HIF_EX_ACK, /* AP->MD */
	HIF_EX_INIT_DONE, /* polling */
	HIF_EX_CLEARQ_DONE, /* interrupt */
	HIF_EX_CLEARQ_ACK, /* AP->MD */
	HIF_EX_ALLQ_RESET, /* polling */
} HIF_EX_STAGE;

enum {
	P_CORE = 0,
	VOLTE_CORE,
};

enum SHARE_MEMORY_SUPPORT {
	EXTERNAL_MODEM = 0,
	INTERNAL_MODEM = 1,
	MULTI_MD_MPU_SUPPORT = 2,
};

/* runtime data format uses EEMCS's version, NOT the same with legacy CCCI */
struct modem_runtime {
	u32 Prefix;			 /* "CCIF" */
	u32 Platform_L;		 /* Hardware Platform String ex: "TK6516E0" */
	u32 Platform_H;
	u32 DriverVersion;	  /* 0x00000923 since W09.23 */
	u32 BootChannel;		/* Channel to ACK AP with boot ready */
	u32 BootingStartID; /* MD is booting. NORMAL_BOOT_ID or META_BOOT_ID */

	/* not using in EEMCS */
	u32 BootAttributes;	 /* Attributes passing from AP to MD Booting */
	/* MD response ID if boot successful and ready */
	u32 BootReadyID;
	u32 FileShareMemBase;
	u32 FileShareMemSize;
	u32 ExceShareMemBase;
	u32 ExceShareMemSize;
	u32 CCIFShareMemBase;
	u32 CCIFShareMemSize;
	u32 DHLShareMemBase; /* For DHL */
	u32 DHLShareMemSize;
	u32 MD1MD3ShareMemBase; /* For MD1 MD3 share memory */
	u32 MD1MD3ShareMemSize;
	u32 TotalShareMemBase;
	u32 TotalShareMemSize;
	u32 CheckSum;

	u32 Postfix; /* "CCIF" */

	/* misc region */
	u32 misc_prefix;	/* "MISC" */
	u32 support_mask;
	u32 index;
	u32 next;
	u32 feature_0_val[4];
	u32 feature_1_val[4];
	u32 feature_2_val[4];
	u32 feature_3_val[4];
	u32 feature_4_val[4];
	u32 feature_5_val[4];
	u32 feature_6_val[4];
	u32 feature_7_val[4];
	u32 feature_8_val[4];
	u32 feature_9_val[4];
	u32 feature_10_val[4];
	u32 feature_11_val[4];
	u32 feature_12_val[4];
	u32 feature_13_val[4];
	u32 feature_14_val[4];
	u32 feature_15_val[4];
	u32 reserved_2[3];
	u32 misc_postfix;	/* "MISC" */

} __packed;

struct ccci_runtime_feature {
	u8 feature_id;	/*for debug only*/
	struct ccci_feature_support support_info;
	u8 reserved[2];
	u32 data_len;
	u8 data[0];
};

struct ccci_runtime_boot_info {
	u32 boot_channel;
	u32 booting_start_id;
	u32 boot_attributes;
	u32 boot_ready_id;
};

struct ccci_runtime_share_memory {
	u32 addr;
	u32 size;
};

struct ccci_misc_info_element {
	u32 feature[4];
};

enum FLIGHT_STAGE {
	MD_FLIGHT_MODE_NONE = 0,
	MD_FLIGHT_MODE_ENTER = 1,
	MD_FLIGHT_MODE_LEAVE = 2
};

struct ccci_modem_cfg {
	unsigned int load_type;
	unsigned int load_type_saving;
	unsigned int setting;
};

struct ccci_sim_setting {
	int sim_mode;
	int slot1_mode;		/* 0:CDMA 1:GSM 2:WCDMA 3:TDCDMA */
	int slot2_mode;		/* 0:CDMA 1:GSM 2:WCDMA 3:TDCDMA */
};

/*per modem data*/
struct ccci_per_md {
	unsigned int md_capability;
	unsigned int md_dbg_dump_flag;
	enum md_boot_mode md_boot_mode;
	char img_post_fix[IMG_POSTFIX_LEN];
	struct ccci_image_info img_info[IMG_NUM];
	unsigned int md_boot_data[16];
	unsigned int sim_type;
	struct ccci_modem_cfg config;
	unsigned int md_img_exist[MAX_IMG_NUM];
	unsigned int md_img_type_is_set;
	struct ccci_sim_setting sim_setting;
	int data_usb_bypass;
	int dtr_state; /* only for usb bypass */
	unsigned int is_in_ee_dump;

	unsigned long long latest_isr_time;
	unsigned long long latest_q0_isr_time;
	unsigned long long latest_q0_rx_time;
#ifdef CCCI_SKB_TRACE
	unsigned long long netif_rx_profile[8];
#endif
};

/*external interface */
struct ccci_per_md *ccci_get_per_md_data(unsigned char md_id);
static inline int ccci_md_get_cap_by_id(int md_id)
{
	struct ccci_per_md *per_md_data = ccci_get_per_md_data(md_id);

	if (per_md_data == NULL)
		return -CCCI_ERR_MD_INDEX_NOT_FOUND;
	return per_md_data->md_capability;
}
struct ccci_mem_layout *ccci_md_get_mem(int md_id);
struct ccci_smem_region *ccci_md_get_smem_by_user_id(int md_id,
	enum SMEM_USER_ID user_id);
int ccci_md_start(unsigned char md_id);
int ccci_md_soft_start(unsigned char md_id, unsigned int sim_mode);
int ccci_md_send_runtime_data(unsigned char md_id);
void ccci_md_dump_info(unsigned char md_id,
	enum modem_dump_flag flag, void *buff, int length);
int ccci_md_pre_stop(unsigned char md_id, unsigned int stop_type);
int ccci_md_stop(unsigned char md_id, unsigned int stop_type);
int ccci_md_soft_stop(unsigned char md_id, unsigned int sim_mode);
int ccci_md_force_assert(unsigned char md_id,
	MD_FORCE_ASSERT_TYPE type, char *param, int len);
int ccci_md_prepare_runtime_data(unsigned char md_id,
	unsigned char *data, int length);
void ccci_md_exception_handshake(unsigned char md_id, int timeout);
int ccci_md_parse_rt_feature(unsigned char md_id,
	struct ccci_runtime_feature *rt_feature, void *data, u32 data_len);
struct ccci_runtime_feature *ccci_md_get_rt_feature_by_id(unsigned char md_id,
	u8 feature_id, u8 ap_query_md);

#endif
