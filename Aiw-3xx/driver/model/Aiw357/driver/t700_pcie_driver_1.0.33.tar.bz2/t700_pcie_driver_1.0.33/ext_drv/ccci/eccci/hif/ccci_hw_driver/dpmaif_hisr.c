// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/jiffies.h>

#include "dpmaif_hif_platform.h"
#include "ccci_driver_dpmaif_reg.h"
#include "dpmaif_drv.h"
#include "ccci_driver_dpmaif.h"

#define		TAG			"DATA"


void drv_dpmaif_init_intr(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	/*Set UL interrupt*/
	p_isr_en_msk->AP_UL_L2INTR_En_Msk =
		DPMAIF_UL_INT_ERR_MSK | DPMAIF_UL_INT_MD_NOTREADY_MSK |
		DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK |
		DPMAIF_UL_INT_QDONE_MSK | DPMAIF_UL_INT_EMPTY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
	/*set interrupt enable mask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0,
		p_isr_en_msk->AP_UL_L2INTR_En_Msk);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0,
		~(p_isr_en_msk->AP_UL_L2INTR_En_Msk));

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_intr-1 mask check fail\n");
			return;
		}
	}

	/*Set DL interrupt*/
	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk =
		DPMAIF_DL_INT_PITCNT_LEN_ERR(0);
	p_isr_en_msk->AP_DL_L2INTR_En_Msk =
		p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk |
		DPMAIF_DL_INT_EMPTY_MSK | DPMAIF_DL_INT_MTU_ERR_MSK |
		DPMAIF_DL_INT_QDONE_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISAR0, 0xFFFFFFFF);
	/*clear interrupt enable mask*/
	//DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TICR0,
		//p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*set interrupt enable mask*/
	// DL ISR PD part
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0,
		~(p_isr_en_msk->AP_DL_L2INTR_En_Msk));
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~(p_isr_en_msk->AP_DL_L2INTR_En_Msk));

	/*check mask sts*/
	count = 0;
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_intr-2 mask check fail\n");
			return;
		}
	}

	// Set AP IP busy
	p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk = DPMAIF_UDL_IP_BUSY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0);

	MTK_ERR_LOG(TAG,
		"AP_UL_L2INTR_En_Msk: 0x%x, AP_DL_L2INTR_ERR_En_Msk:0x%x\n",
		p_isr_en_msk->AP_UL_L2INTR_En_Msk,
		p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk);

	MTK_ERR_LOG(TAG,
		"AP_UDL_IP_BUSY_En_Msk:0x%x, AP_DL_L2INTR_En_Msk:0x%x\n",
		p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);

}

void drv_dpmaif_init_ul_intr(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	// Set UL interrupt
	//p_isr_en_msk->AP_UL_L2INTR_En_Msk = DPMAIF_UL_INT_ERR_MSK |
	//DPMAIF_UL_INT_MD_NOTREADY_MSK | DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK
	//| DPMAIF_UL_INT_EMPTY_MSK | DPMAIF_UL_INT_QDONE_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
	/*set interrupt enable mask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0,
		p_isr_en_msk->AP_UL_L2INTR_En_Msk);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0,
		~(p_isr_en_msk->AP_UL_L2INTR_En_Msk));

	/*check mask sts*/
	count = 0;
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_UL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "init_ul_intr mask check fail\n");
			return;
		}
	}


	// Set AP IP busy
	p_isr_en_msk->AP_UDL_IP_BUSY_En_Msk = DPMAIF_UDL_IP_BUSY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0);
}

void drv_dpmaif_mask_ul_que_interrupt(unsigned int q_num)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_done_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_done_mask = (1 << (q_num + _UL_INT_DONE_OFFSET)) &
		DPMAIF_UL_INT_QDONE_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_done_mask;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0, ui_que_done_mask);
}

void drv_dpmaif_unmask_ul_que_interrupt(unsigned int q_num)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_done_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_done_mask = (1 << (q_num + _UL_INT_DONE_OFFSET)) &
		DPMAIF_UL_INT_QDONE_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_done_mask;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0, ui_que_done_mask);
}

void drv_dpmaif_mask_dl_batcnt_len_err_interrupt(unsigned int q_num)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_batcnt_lenrr_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &=
		~(DPMAIF_DL_INT_BATCNT_LEN_ERR(q_num));

	di_batcnt_lenrr_mask = DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0, di_batcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_batcnt_len_err_interrupt(void)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_batcnt_lenrr_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	di_batcnt_lenrr_mask = DPMAIF_DL_INT_BATCNT_LEN_ERR(0);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0, di_batcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(unsigned int q_num)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_pitcnt_lenrr_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &=
		~(DPMAIF_DL_INT_PITCNT_LEN_ERR(q_num));

	di_pitcnt_lenrr_mask = DPMAIF_DL_INT_PITCNT_LEN_ERR(0);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0, di_pitcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt(void)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_pitcnt_lenrr_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_PITCNT_LEN_ERR(0);

	di_pitcnt_lenrr_mask = DPMAIF_DL_INT_PITCNT_LEN_ERR(0);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0, di_pitcnt_lenrr_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_mask_dl_que_interrupt(unsigned int q_num)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_QDONE_MSK;

	di_que_done_mask = DPMAIF_DL_INT_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0, di_que_done_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_unmask_dl_que_interrupt(void)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int di_que_done_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_QDONE_MSK;

	di_que_done_mask = DPMAIF_DL_INT_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0, di_que_done_mask);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);
}

void drv_dpmaif_mask_ul_que_empty_interrupt(unsigned int q_num)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_empty_mask = (1 << (q_num + _UL_INT_EMPTY_OFFSET)) &
		DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_empty_mask;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) != ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_ul_que_empty mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_que_empty_interrupt(unsigned int q_num)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_empty_mask = (1 << (q_num + _UL_INT_EMPTY_OFFSET)) &
		DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_empty_mask;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) == ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"unmask_ul_que_empty mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_ul_allque_empty_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_empty_mask;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_empty_mask = DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk &= ~ui_que_empty_mask;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) != ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"mask_ul_allque_empty mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_allque_empty_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;
	unsigned int ui_que_empty_mask = 0;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	ui_que_empty_mask = DPMAIF_UL_INT_EMPTY_MSK;

	p_isr_en_msk->AP_UL_L2INTR_En_Msk |= ui_que_empty_mask;

	// clear dummy register
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0,
		DPMAIF_UL_INT_EMPTY_MSK);

	// clear mask
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0, ui_que_empty_mask);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) &
		ui_que_empty_mask) == ui_que_empty_mask) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"unmask_ul_allque_empty mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_dl_pkt_empty_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_EMPTY_MSK;
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"unmask_dl_pkt_empty mask check fail\n");
			return;
		}
	}
}


void drv_dpmaif_mask_dl_pkt_empty_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_EMPTY_MSK;
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) !=
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_pkt_empty mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_dl_lenerr_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk |= DPMAIF_DL_INT_MTU_ERR_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		~p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) ==
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_lenerr mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_dl_lenerr_interrupt(void)
{
	int count = 0;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk &= ~DPMAIF_DL_INT_MTU_ERR_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0,
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(
		p_isr_en_msk->AP_DL_L2INTR_En_Msk);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) &
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) !=
		p_isr_en_msk->AP_DL_L2INTR_En_Msk) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_lenerr mask check fail\n");
			return;
		}
	}
}

unsigned int drv_dpmaif_get_ul_lv2_sts(void)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0);

	return sts;
}

unsigned int drv_dpmaif_get_ulq_done_sts(unsigned char q_num)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0);

	sts &= (DPMAIF_UL_INT_QDONE_MSK & (1 << (q_num + _UL_INT_DONE_OFFSET)));

	return sts;
}

void drv_dpmaif_clr_ulq_done_sts(unsigned char q_num)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0);

	sts &= (DPMAIF_UL_INT_QDONE_MSK & (1 << (q_num + _UL_INT_DONE_OFFSET)));

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0, sts);
}

void drv_dpmaif_clr_dlq_done_sts(unsigned char q_num)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TISAR0);

	sts &= DPMAIF_DL_INT_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISAR0, sts);
}

void drv_dpmaif_clr_ip_busy_sts(void)
{
	unsigned int ip_busy_sts;

	/*Get AP IP busy sts*/
	ip_busy_sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_IP_BUSY);
	/*Clear AP IP busy*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_IP_BUSY, ip_busy_sts);
}

void drv_dpmaif_clr_ul_all_interrupt(void)
{
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);
}

unsigned int drv_dpmaif_get_dl_lv2_sts(void)
{
	unsigned int sts;

	sts = DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TISAR0);
	return sts;
}

void drv_dpmaif_clr_dl_all_interrupt(void)
{
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISAR0, 0xFFFFFFFF);
}

void drv_dpmaif_dl_set_ao_dl_interrupt_mask(unsigned int mask)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);

	value &= ~(DPMAIF_AO_DL_ISR_MSK);
	value |= ((mask) & DPMAIF_AO_DL_ISR_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

void drv_dpmaif_mask_ul_l1_interrupt(void)
{
	int count = 0;
	unsigned int isr;

	isr = DPMAIF_UL_INT_ERR_MSK | DPMAIF_UL_INT_MD_NOTREADY_MSK |
		DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK |
		DPMAIF_UL_INT_QDONE_MSK | DPMAIF_UL_INT_EMPTY_MSK;

	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TISR0, isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) & isr) != isr) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_ul_l1 mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_ul_l1_interrupt(void)
{
	int count = 0;
	unsigned int isr;

	isr = DPMAIF_UL_INT_ERR_MSK | DPMAIF_UL_INT_MD_NOTREADY_MSK |
		DPMAIF_UL_INT_MD_PWR_NOTREADY_MSK |
		DPMAIF_UL_INT_QDONE_MSK | DPMAIF_UL_INT_EMPTY_MSK;

	/*clear dummy sts*/
	//DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, 0xFFFFFFFF);

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_UL_L2TICR0, isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_UL_L2TIMR0) & isr) == isr) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_ul_l1 mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_dl_l1_interrupt(void)
{
	int count = 0;
	unsigned int isr;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk = 0;
	p_isr_en_msk->AP_DL_L2INTR_En_Msk = 0;

	isr = DPMAIF_DL_INT_SKB_LEN_ERR(0) |
		DPMAIF_DL_INT_PITCNT_LEN_ERR(0) |
		DPMAIF_DL_INT_BATCNT_LEN_ERR(0) |
		DPMAIF_DL_INT_EMPTY_MSK | DPMAIF_DL_INT_MTU_ERR_MSK |
		DPMAIF_DL_INT_QDONE_MSK;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TISR0, isr);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) & isr) != isr) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "mask_dl_l1 mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_unmask_dl_l1_interrupt(void)
{
	int count = 0;
	unsigned int isr;
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;

	p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk =
		DPMAIF_DL_INT_SKB_LEN_ERR(0) | DPMAIF_DL_INT_PITCNT_LEN_ERR(0);
	p_isr_en_msk->AP_DL_L2INTR_En_Msk =
		p_isr_en_msk->AP_DL_L2INTR_ERR_En_Msk |
		DPMAIF_DL_INT_EMPTY_MSK | DPMAIF_DL_INT_MTU_ERR_MSK
		| DPMAIF_DL_INT_QDONE_MSK;

	isr = p_isr_en_msk->AP_DL_L2INTR_En_Msk;

	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DL_L2TICR0, isr);
	// DL ISR AO part
	drv_dpmaif_dl_set_ao_dl_interrupt_mask(~isr);

	/*check mask sts*/
	while ((DPMAIF_READ_PD_MISC(DPMAIF_PD_AP_DL_L2TIMR0) & isr) == isr) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "unmask_dl_l1 mask check fail\n");
			return;
		}
	}
}

void drv_dpmaif_mask_ap_ip_busy(void)
{
	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0x3);
}

void drv_dpmaif_unmask_ap_ip_busy(void)
{
	/*clear dummy sts*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_IP_BUSY, 0xFFFFFFFF);
	/*set IP busy unmask*/
	DPMAIF_WRITE_PD_MISC(DPMAIF_PD_AP_DLUL_IP_BUSY_MASK, 0);
}


