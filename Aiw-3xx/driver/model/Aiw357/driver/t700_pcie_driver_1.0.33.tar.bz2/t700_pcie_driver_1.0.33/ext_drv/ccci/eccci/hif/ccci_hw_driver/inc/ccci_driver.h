/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_CCCIDRV_H__
#define __MODEM_CCCIDRV_H__

#include "mt-plat/mtk_ccci_common.h"
#include "ccci_hif.h"
#include "mtk-pci.h"

typedef enum {
	AP_TO_MD = 0,
	MD_TO_AP = 1,
	sAP_TO_eAP = 2,
} dir_enum;

typedef enum {
	MODE_BIT_32 = 0,
	MODE_BIT_36 = 1,
	MODE_BIT_40 = 2,
	MODE_BIT_64 = 3,
} hw_mode_enum;
extern struct ccci_hw_ctrl *ccci_hw_ctrl_info[MAX_MD_NUM][HIF_ID_MAX];

struct irq_ops{
	void (*register_isr)(struct ccci_hw_ctrl *hw_ctrl, int(*)(void*), void *param);
	void (*enable_irqs)(struct ccci_hw_ctrl *hw_ctrl);
	void (*disable_irq)(struct ccci_hw_ctrl *hw_ctrl);
};
struct ccci_irq_hd {
	int (*usr_hd)(void *);
	void *param;
};

struct ccci_hw_ctrl {
	u8 hif_id;
	struct device *dma_dev;
	struct mtk_pci_dev *mtk_dev;
	void *private;
	spinlock_t spinlock;
	struct ccci_irq_hd irqhd;
	struct irq_ops irqops;
	struct ccci_hw_ops *opts;
};

int ccci_cldma_get_dev_info(struct ccci_hw_ctrl *hw_ctrl);
struct cldma_hw_info *cldma_driver_init(struct ccci_hw_ctrl *hw_ctrl);

struct ccci_hw_ops {
	/* must-have */
	void (*ccci_hw_init)(struct ccci_hw_ctrl *hw_ctrl);
	void (*ccci_hw_reset)(struct ccci_hw_ctrl *hw_ctrl);
	void (*ccci_hw_dump)(struct ccci_hw_ctrl *hw_ctrl);
	int (*ccci_hw_clear)(struct ccci_hw_ctrl *hw_ctrl);
	void (*ccci_hw_send)(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno);
	void (*ccci_hw_start)(struct ccci_hw_ctrl *hw_ctrl, unsigned char tx_rx);
	int (*ccci_hw_stop)(struct ccci_hw_ctrl *hw_ctrl, unsigned char tx_rx, unsigned char is_for_ee);
	void (*ccci_hw_start_queue)(struct ccci_hw_ctrl *hw_ctrl,u8 qno,unsigned char tx_rx);
	void (*ccci_hw_stop_queue)(struct ccci_hw_ctrl *hw_ctrl,u8 qno,unsigned char rx_tx);
	int (*ccci_hw_resume_queue)(struct ccci_hw_ctrl *hw_ctrl ,unsigned char qno,unsigned char tx_rx);
	unsigned int (*ccci_hw_rx_done)(struct ccci_hw_ctrl *hw_ctrl,unsigned int bitmask);
	unsigned int (*ccci_hw_tx_done)(struct ccci_hw_ctrl *hw_ctrl,unsigned int bitmask);
	int (*ccci_hw_get_status)(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno);
	int (*ccci_hw_get_interrupt_status)(struct ccci_hw_ctrl *hw_ctrl);
	int (*ccci_hw_notify)(struct ccci_hw_ctrl *hw_ctrl);
};

void ccci_driver_init(unsigned char md_id,
	unsigned char hif_id, void *hw_info);
void *ccci_hw_ctrl_get_by_id(unsigned char md_id, unsigned char hif_id);

void ccci_hw_init(struct ccci_hw_ctrl *hw_ctrl);
void ccci_hw_reset(struct ccci_hw_ctrl *hw_ctrl);
void ccci_hw_dump(struct ccci_hw_ctrl *hw_ctrl);
int ccci_hw_clear(struct ccci_hw_ctrl *hw_ctrl);
void ccci_hw_send(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno);
void ccci_hw_start(struct ccci_hw_ctrl *hw_ctrl, unsigned char tx_rx);
int ccci_hw_stop(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char tx_rx, unsigned char is_for_ee);
void ccci_hw_start_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char tx_rx);
void ccci_hw_stop_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char rx_tx);
int ccci_hw_resume_queue(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx);

unsigned int ccci_hw_rx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask);
unsigned int ccci_hw_tx_done(struct ccci_hw_ctrl *hw_ctrl,
	unsigned int bitmask);

int ccci_hw_get_status(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno);
int ccci_hw_get_interrupt_status(struct ccci_hw_ctrl *hw_ctrl);
int ccci_hw_notify(struct ccci_hw_ctrl *hw_ctrl);
void ccci_driver_uninit(unsigned char md_id, unsigned char hif_id);


#endif
