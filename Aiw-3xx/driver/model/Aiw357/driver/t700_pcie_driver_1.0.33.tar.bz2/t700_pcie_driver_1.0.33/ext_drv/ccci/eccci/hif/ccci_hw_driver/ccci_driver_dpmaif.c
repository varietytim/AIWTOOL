// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/string.h>

#include "ccci_driver_dpmaif.h"
#include "dpmaif_drv.h"
#include "dpmaif_hisr.h"
#include "ccci_debug.h"
#include "dpmaif_hif_platform.h"
#include "ccci_driver_dpmaif_reg.h"

#define		TAG		"DATA"

/*
 *	MD ID
 */
unsigned char g_md_id;

/*
 *	DPMAIF base register address
 */
unsigned long g_DPMAIF_PD_BASE;
unsigned long g_DPMAIF_AO_BASE;

/*
*  RGU base register address
*/
unsigned long g_RGU_AO_BASE = 0;

/*
 *	HW DPMAIF CTRL
 */
hw_dpmaif_ctrl_t dpmaif_ctrl;

void dpmaif_driver_init(struct ccci_hw_ctrl *hw_ctrl)
{
	dpmaif_pcie_hw_info_ptr_t hw_info = NULL;

	if (hw_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!\n");
		goto exit;
	}

	hw_info = (dpmaif_pcie_hw_info_ptr_t)hw_ctrl->private;
	if (hw_info == NULL) {
		MTK_ERR_LOG(TAG, "Invalid HW info: NULL pointer!\n");
		goto exit;
	}

	g_md_id = hw_info->md_id;

	/* gets DPMAIF HW base address */
	g_DPMAIF_PD_BASE = hw_info->hw_map_base_addr +
		(unsigned long)DPMAIF_DEV_PD_BASE - hw_info->hw_base_addr;
	g_DPMAIF_AO_BASE = hw_info->hw_map_base_addr +
		(unsigned long)DPMAIF_DEV_AO_BASE - hw_info->hw_base_addr;

	MTK_DEBUG_LOG(TAG, "DPMAIF_PD_BASE 0x%lx(0x%llx + 0x%lx -0x%llx)\n",
		DPMAIF_PD_BASE, hw_info->hw_map_base_addr,
		(unsigned long)DPMAIF_DEV_PD_BASE, hw_info->hw_base_addr);
	MTK_DEBUG_LOG(TAG, "DPMAIF_AO_BASE 0x%lx(0x%llx + 0x%lx -0x%llx)\n",
		DPMAIF_AO_BASE, hw_info->hw_map_base_addr,
		(unsigned long)DPMAIF_DEV_AO_BASE, hw_info->hw_base_addr);

	/* gets RGU HW base address */
	g_RGU_AO_BASE =  hw_info->hw_map_base_addr + RGU_DEV_AO_BASE - hw_info->hw_base_addr;
	MTK_DEBUG_LOG(TAG, "RGU_AO_BASE 0x%lx(0x%llx + 0x%lx -0x%llx)\n",
		RGU_AO_BASE, hw_info->hw_map_base_addr, RGU_DEV_AO_BASE, hw_info->hw_base_addr);

exit:
	return;
}

/***********************************************************************
 *	DPMAIF Common queue sw init API
 *
 ***********************************************************************/
DRV_BOOL dpmaifq_set_queue_property(hifdpmaif_property_t *p_property,
	dpmaif_hw_init_para_ptr_t init_para)
{
	unsigned int que_cnt;
	hifmaif_dl_st_t *p_dl_que;
	hifmaif_ul_st_t *p_ul_que;
	hifmaif_dl_hwq_t *p_dl_hwq;

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_DLQ_NUM; que_cnt++) {
		p_dl_que = &p_property->dl_que[que_cnt];
		p_dl_hwq = &p_property->dl_que_hw[que_cnt];

		/*init DLQ queue setting*/
		memset(p_dl_hwq, 0, sizeof(hifmaif_dl_hwq_t));
		p_dl_hwq->bat_remain_size = DPMAIF_HW_BAT_REMAIN;
		p_dl_hwq->bat_pkt_bufsz = DPMAIF_HW_BAT_PKTBUF;
		p_dl_hwq->bat_rsv_length = DPMAIF_HW_BAT_RSVLEN;
		p_dl_hwq->pkt_bid_max_cnt = DPMAIF_HW_PKT_BIDCNT;
		p_dl_hwq->pkt_alignment = DPMAIF_HW_PKT_ALIGN;
		p_dl_hwq->mtu_size = DPMAIF_HW_MTU_SIZE;

		p_dl_hwq->chk_bat_num = DPMAIF_HW_CHK_BAT_NUM;
		p_dl_hwq->chk_frg_num = DPMAIF_HW_CHK_FRG_NUM;
		p_dl_hwq->chk_pit_num = DPMAIF_HW_CHK_PIT_NUM;

		p_dl_que->bat_base =
			(unsigned int *)(init_para->pkt_bat_base_addr[que_cnt]);
		p_dl_que->bat_size_cnt = init_para->pkt_bat_size_cnt[que_cnt];
		p_dl_que->pit_base =
			(unsigned int *)(init_para->pit_base_addr[que_cnt]);
		p_dl_que->pit_size_cnt = init_para->pit_size_cnt[que_cnt];

		p_dl_que->frg_base = NULL;
		p_dl_que->frg_size_cnt = 0;

		p_dl_que->que_started = DRV_TRUE;
	}

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];

		p_ul_que->drb_base =
			(unsigned int *)(init_para->drb_base_addr[que_cnt]);
		p_ul_que->drb_size_cnt = init_para->drb_size_cnt[que_cnt];

		p_ul_que->que_started = DRV_TRUE;
	}

	return DRV_TRUE;
}

/*AP_L1TIMR0*/
#define DP_AP_TOP_WAKEC		(1 << 7)
#define DP_AP_TOP_WAKES		(1 << 8)
#define DP_UL_TOP_PCIE_INTC (1 << 11)
#define DP_DL_TOP_PCIE_INTC (1 << 12)
#define DP_UL_TOP_PCIE_INTS (1 << 13)
#define DP_DL_TOP_PCIE_INTS (1 << 14)
#define DP_UL_TOP_MDMCU_INTC	(1 << 17)
#define DP_DL_TOP_MDMCU_INTC	(1 << 18)
#define DP_UL_TOP_MDMCU_INTS	(1 << 19)
#define DP_DL_TOP_MDMCU_INTS	(1 << 20)

#define DP_UL_TOP_AP_INTM	(1 << 0)
#define DP_DL_TOP_AP_INTM	(1 << 1)
#define DP_AP_TOP_WAKEM		(1 << 6)
#define DP_UL_TOP_PCIE_INTM (1 << 9)
#define DP_DL_TOP_PCIE_INTM (1 << 10)
#define DP_UL_TOP_MDMCU_INTM	(1 << 15)
#define DP_DL_TOP_MDMCU_INTM	(1 << 16)

#define DP_AP_ISR_PCIE\
	(DP_UL_TOP_AP_INTM|DP_DL_TOP_AP_INTM|\
	DP_DL_TOP_MDMCU_INTM|DP_UL_TOP_MDMCU_INTM)
#define DP_AP_ISR_MDEMI\
	(DP_UL_TOP_AP_INTM|DP_DL_TOP_AP_INTM|\
	DP_UL_TOP_PCIE_INTM|DP_DL_TOP_PCIE_INTM)
#define DP_AP_ISR_AP\
	(DP_UL_TOP_PCIE_INTM|DP_DL_TOP_PCIE_INTM|\
	DP_DL_TOP_MDMCU_INTM|DP_UL_TOP_MDMCU_INTM)


void drv_dpmaif_hw_isr_init(void)
{
	unsigned int value;

	/*init TOP ISR for PCIE or MDCPU*/
	value = DP_AP_ISR_PCIE;
	DPMAIF_WriteReg32(NRL2_DPMAIF_AO_UL_AP_L1TIMR0, value);
}


void dpmaif_hw_init(void *para)
{
	dpmaif_hw_init_para_ptr_t init_para = NULL;

	/* checks input firstly */
	if (unlikely(para == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!\n");
		goto exit;
	}

	init_para = (dpmaif_hw_init_para_ptr_t)para;

	/*
	 *now begin to config dpmaif HW
	 */

	/* port mode & clock config */
	drv_dpmaif_hw_init();

	/* HW interrupt init */
	drv_dpmaif_init_intr();

	/* HW queue config */
	dpmaifq_set_queue_property(&dpmaif_ctrl.dpmaif_property, init_para);
	drv_dpmaif_config_que_hw(&dpmaif_ctrl.dpmaif_property);

exit:
	return;
}

void dpmaif_hw_reset(void *para)
{

}

inline unsigned int dpmaif_hw_get_drb_rd_idx(unsigned char qno)
{
	return drv_dpmaif_ul_get_ridx(qno);
}

inline unsigned int dpmaif_hw_get_pkt_bat_rd_idx(unsigned char qno)
{
	return drv_dpmaif_dl_get_bat_ridx(qno);
}

inline unsigned int dpmaif_hw_get_pkt_bat_wr_idx(unsigned char qno)
{
	return drv_dpmaif_dl_get_bat_wridx(qno);
}

inline unsigned int dpmaif_hw_get_pit_rd_idx(unsigned char qno)
{
	return drv_dpmaif_dl_get_pit_ridx(qno);
}

inline unsigned int dpmaif_hw_get_pit_wr_idx(unsigned char qno)
{
	return drv_dpmaif_dl_get_wridx(qno);
}

inline int dpmaif_hw_ul_add_wcnt(unsigned char qno, unsigned short add_count)
{
	return drv_dpmaif_ul_add_wcnt(qno,
		(unsigned short)(add_count * DPMAIF_UL_DRB_ENTRY_WORD));
}

static void dpmaif_hw_check_tx_interrupt(unsigned int l2_txisar0,
	dpmaif_hw_intr_st_para_ptr_t para)
{
	unsigned int value = 0;

	value = l2_txisar0 & DP_UL_INT_QDONE_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_DONE;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_DONE_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;

		/* we mask TX queue interrupt immediately after it occurs */
		dpmaif_hw_ul_mask_multiple_tx_done_intr(
			para->intr_queues[para->intr_cnt]);
	}

	value = l2_txisar0 & DP_UL_INT_EMPTY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_DRB_EMPTY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_EMPTY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_MD_NOTREADY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_MD_NOTREADY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_MD_NOTRDY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_MD_PWR_NOTREADY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_MD_PWR_NOTREADY;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_PWR_NOTRDY_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

	value = l2_txisar0 & DP_UL_INT_ERR_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_UL_LEN_ERR;
		para->intr_queues[para->intr_cnt] =
			value >> DP_UL_INT_LEN_ERR_OFFSET & DP_UL_QNUM_MSK;
		para->intr_cnt++;
	}

}

static void dpmaif_hw_check_rx_interrupt(unsigned int l2_rxisar0,
	dpmaif_hw_intr_st_para_ptr_t para)
{
	unsigned int value = 0;

	MTK_DEBUG_LOG(TAG, "l2_rxisar0 = 0x%08x\n", l2_rxisar0);

	value = l2_rxisar0 & DP_DL_INT_QDONE_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_DONE;
		para->intr_queues[para->intr_cnt] = 0x01 << DPF_RX_QNO_DFT;
		para->intr_cnt++;

		/* we mask RX done interrupt immediately after it occures */
		drv_dpmaif_mask_dl_que_interrupt(DPF_RX_QNO_DFT);
	}

	value = l2_rxisar0 & DP_DL_INT_SKB_LEN_ERR;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_SKB_LEN_ERR;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;
	}

	value = l2_rxisar0 & DP_DL_INT_BATCNT_LEN_ERR;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_BATCNT_LEN_ERR;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;

		/* mask this interrupt */
		drv_dpmaif_mask_dl_batcnt_len_err_interrupt(DPF_RX_QNO_DFT);
	}

	value = l2_rxisar0 & DP_DL_INT_PITCNT_LEN_ERR;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_PITCNT_LEN_ERR;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;

		/* mask this interrupt */
		drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(DPF_RX_QNO_DFT);
	}

	value = l2_rxisar0 & DP_DL_INT_PKT_EMPTY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_PKT_EMPTY_SET;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;
	}

	value = l2_rxisar0 & DP_DL_INT_FRG_EMPTY_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_FRG_EMPTY_SET;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;
	}

	value = l2_rxisar0 & DP_DL_INT_MTU_ERR_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_MTU_ERR;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;
	}

	value = l2_rxisar0 & DP_DL_INT_FRG_LENERR_MSK;
	if (value != 0) {
		para->intr_types[para->intr_cnt] = DPF_INTR_DL_FRGCNT_LEN_ERR;
		para->intr_queues[para->intr_cnt] = DPF_RX_QNO_DFT;
		para->intr_cnt++;
	}

	MTK_DEBUG_LOG(TAG, "Interrupt count: %u\n", para->intr_cnt);

}

unsigned int drv_dpmaif_get_dl_interrupt_mask(void)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	return (~p_isr_en_msk->AP_DL_L2INTR_En_Msk) & 0xFFFFFFFF;
}

unsigned int drv_dpmaif_get_ul_interrupt_mask(void)
{
	dpmaif_isr_en_mask_t *p_isr_en_msk;

	p_isr_en_msk = &dpmaif_ctrl.dpmaif_drv_ctrl.dpmaif_isr_en_mask;
	return (~p_isr_en_msk->AP_UL_L2INTR_En_Msk) & 0xFFFFFFFF;
}

inline void dpmaif_hw_clr_dl_all_intr_sts(void)
{
	drv_dpmaif_clr_dl_all_interrupt();
}

inline void dpmaif_hw_clr_ul_all_intr_sts(void)
{
	drv_dpmaif_clr_ul_all_interrupt();
}

inline void dpmaif_hw_clr_dl_intr_sts_frg_cnt_err(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_FRG_LENERR_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_mtu_err(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_MTU_ERR_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_frg_empty(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_FRG_EMPTY_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_pkt_empty(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_PKT_EMPTY_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_pit_cnt_len_err(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_PITCNT_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_bat_cnt_len_err(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_BATCNT_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_skb_len_err(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_SKB_LEN_ERR;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_dl_intr_sts_dl_done(unsigned char qno)
{
	unsigned int L2RISAR0 = 0;
	unsigned int intr_value = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	intr_value = L2RISAR0 & DP_DL_INT_QDONE_MSK;
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_ul_intr_sts_drb_empty(unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	intr_value = L2TISAR0 & DP_UL_INT_EMPTY_MSK &
		(1 << (DP_UL_INT_EMPTY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_ul_intr_sts_md_not_ready(unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	intr_value = L2TISAR0 & DP_UL_INT_MD_NOTREADY_MSK &
		(1 << (DP_UL_INT_MD_NOTRDY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_ul_intr_sts_md_pwr_not_ready(unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	intr_value = L2TISAR0 & DP_UL_INT_MD_PWR_NOTREADY_MSK &
		(1 << (DP_UL_INT_PWR_NOTRDY_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_ul_intr_sts_ul_len_err(unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	intr_value = L2TISAR0 & DP_UL_INT_ERR_MSK &
		(1 << (DP_UL_INT_LEN_ERR_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}

inline void dpmaif_hw_clr_ul_intr_sts_ul_done(unsigned char qno)
{
	unsigned int L2TISAR0 = 0;
	unsigned int intr_value = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	intr_value = L2TISAR0 & DP_UL_INT_QDONE_MSK &
		(1 << (DP_UL_INT_DONE_OFFSET + qno));
	if (intr_value != 0) {
		// write 1 clear 0
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, intr_value);
	}
}


void dpmaif_hw_dump(void *para)
{
	unsigned int qno = 0;

	/*
	 * hw _ctrl won't be used here, we don't have to check it's value
	 * we use this interface to dump some DPMAIF HW registers' value
	 */
	MTK_DEBUG_LOG(TAG,
		"====== DPMAIF HW Register Value Dump Start ======\n");

	/* uplink part */
	for (qno = 0; qno < DPF_HW_TX_QUE_CNT; qno++)
		MTK_DEBUG_LOG(TAG, "uplink read index: %ul\n",
			drv_dpmaif_ul_get_ridx(qno));

	MTK_DEBUG_LOG(TAG, "uplink interrupt status: %ul\n",
		drv_dpmaif_get_ul_lv2_sts());
	MTK_DEBUG_LOG(TAG, "uplink interrupt mask: %ul\n",
		drv_dpmaif_get_ul_interrupt_mask());

	/* downlink part */
	for (qno = 0; qno < DPF_HW_RX_QUE_CNT; qno++) {
		MTK_DEBUG_LOG(TAG, "downlink PKT_BAT read index: %ul\n",
			drv_dpmaif_dl_get_bat_ridx(DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PKT_BAT write index: %ul\n",
			drv_dpmaif_dl_get_bat_wridx(DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PIT read index: %ul\n",
			drv_dpmaif_dl_get_pit_ridx(DPF_RX_QNO_DFT));
		MTK_DEBUG_LOG(TAG, "downlink PIT write index: %ul\n",
			drv_dpmaif_dl_get_wridx(DPF_RX_QNO_DFT));
	}
	MTK_DEBUG_LOG(TAG, "downlink interrupt status: %ul\n",
		drv_dpmaif_get_dl_lv2_sts());
	MTK_DEBUG_LOG(TAG, "downlink interrupt mask: %ul\n",
		drv_dpmaif_get_dl_interrupt_mask());

	MTK_DEBUG_LOG(TAG, "====== DPMAIF HW Register Value Dump End ======\n");

}

int dpmaif_hw_get_interrupt_status(void *para)
{
	dpmaif_hw_intr_st_para_ptr_t intr_para = NULL;
	unsigned int L2RISAR0, L2TISAR0;
	unsigned int L2RIMR0, L2TIMR0;

	/* checks input firstly */
	if (unlikely(para ==  NULL)) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!\n");
		goto error;
	}

	intr_para = (dpmaif_hw_intr_st_para_ptr_t)para;

	/* initializes value */
	memset(intr_para, 0, sizeof(dpmaif_hw_intr_st_para_t));

	/*
	 *	gets interrupt status from HW
	 */

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();
	L2RIMR0 = (unsigned int)drv_dpmaif_get_dl_interrupt_mask();
	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();
	L2TIMR0 = (unsigned int)drv_dpmaif_get_ul_interrupt_mask();

	MTK_DEBUG_LOG(TAG, "before clear: L2RISAR0 = 0x%x, L2RIMR0 = 0x%x\n",
		L2RISAR0, L2RIMR0);
	MTK_DEBUG_LOG(TAG, "L2TISAR0 = 0x%x, L2TIMR0 = 0x%x",
		L2TISAR0, L2TIMR0);

	/* clear IP busy register wake up cpu case */
	drv_dpmaif_clr_ip_busy_sts();

	/* check UL interrupt*/
	if (L2TISAR0) {
		/*L2TISAR0 &= ~(L2TIMR0);*/
		/* NEED MORE CONSIDERATION */
		dpmaif_hw_check_tx_interrupt(L2TISAR0, intr_para);
		DPMAIF_WriteReg32(DPMAIF_PD_AP_UL_L2TISAR0, L2TISAR0);
	}

	/* check DL interrupt*/
	if (L2RISAR0) {
		/*L2RISAR0 &= ~(L2RIMR0);*/
		/* NEED MORE CONSIDERATION */
		dpmaif_hw_check_rx_interrupt(L2RISAR0, intr_para);
		DPMAIF_WriteReg32(DPMAIF_PD_AP_DL_L2TISAR0, L2RISAR0);
	}

	return intr_para->intr_cnt;

error:
	return -1;
}


inline void dpmaif_hw_ul_mask_multiple_tx_done_intr(unsigned char que_mask)
{
	unsigned int index = 0;

	for (index = 0; index < DPF_HW_TX_QUE_CNT; index++) {
		if (que_mask & (1 << index))
			drv_dpmaif_mask_ul_que_interrupt(index);
	}
}

inline void dpmaif_hw_ul_unmask_multiple_tx_done_intr(unsigned char que_mask)
{
	unsigned int index = 0;

	for (index = 0; index < DPF_HW_TX_QUE_CNT; index++) {
		if (que_mask & (1 << index))
			drv_dpmaif_unmask_ul_que_interrupt(index);
	}
}

inline int dpmaif_hw_ul_mask_tx_done_intr(unsigned char qno)
{
	drv_dpmaif_mask_ul_que_interrupt(qno);
	return 0;
}

inline int dpmaif_hw_ul_unmask_tx_done_intr(unsigned char qno)
{
	drv_dpmaif_unmask_ul_que_interrupt(qno);
	return 0;
}

inline int dpmaif_hw_dl_mask_rx_done_intr(void)
{
	drv_dpmaif_mask_dl_que_interrupt(DPF_RX_QNO_DFT);
	return 0;
}

inline int dpmaif_hw_dl_unmask_rx_done_intr(void)
{
	drv_dpmaif_unmask_dl_que_interrupt();
	return 0;
}

inline int dpmaif_hw_dl_mask_rx_bat_cnt_len_err_intr(void)
{
	drv_dpmaif_mask_dl_batcnt_len_err_interrupt(DPF_RX_QNO_DFT);
	return 0;
}

inline int dpmaif_hw_dl_unmask_rx_bat_cnt_len_err_intr(void)
{
	drv_dpmaif_unmask_dl_batcnt_len_err_interrupt();
	return 0;
}

inline int dpmaif_hw_dl_mask_rx_pit_cnt_len_err_intr(void)
{
	drv_dpmaif_mask_dl_pitcnt_len_err_interrupt(DPF_RX_QNO_DFT);
	return 0;
}

inline int dpmaif_hw_dl_unmask_rx_pit_cnt_len_err_intr(void)
{
	drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt();
	return 0;
}

inline int dpmaif_hw_dl_add_pkt_bat_cnt(unsigned char qno, unsigned int count)
{
	return drv_dpmaif_dl_add_bat_cnt(qno, count);
}

inline int dpmaif_hw_dl_add_pit_remain_cnt(unsigned char qno,
	unsigned int count)
{
	return drv_dpmaif_dl_add_pit_remain_cnt(qno, count);
}

inline void dpmaif_hw_clear_ip_busy(void)
{
	drv_dpmaif_clr_ip_busy_sts();
}

inline unsigned int dpmaif_hw_get_ul_done_status(void)
{
	unsigned int L2TISAR0;
	unsigned int value = 0;
	unsigned int result = 0;

	/* TX interrupt */
	L2TISAR0 = (unsigned int)drv_dpmaif_get_ul_lv2_sts();

	value = L2TISAR0 & DP_UL_INT_QDONE_MSK;
	if (value != 0)
		result = value >> DP_UL_INT_DONE_OFFSET & DP_UL_QNUM_MSK;

	return result;
}


inline unsigned int dpmaif_hw_get_dl_done_status(void)
{
	unsigned int L2RISAR0;
	unsigned int result = 0;

	/* RX interrupt */
	L2RISAR0 = (unsigned int)drv_dpmaif_get_dl_lv2_sts();

	if (L2RISAR0 & DP_DL_INT_QDONE_MSK)
		result = 0x01;	// ONLY ONE DL QUEUE

	return result;
}

void dpmaif_hw_stop_tx_queue(void)
{
	int count = 0;
	int ret = 0;

	/* Disable HW arb and check idle */
	drv_dpmaif_ul_all_queue_en(false);
	do {
		ret = drv_dpmaif_ul_all_idle_check();

		/* retry handler */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "stop TX failed, 0x%x\n",
				DPMAIF_ReadReg32(
					DPMAIF_PD_UL_DBG_STA2));
			break;
		}
	} while (ret != 0);
}

void dpmaif_hw_stop_rx_queue(void)
{
	int count = 0;
	int ret = 0;

	/* Disable HW arb and check idle */
	drv_dpmaif_dl_all_queue_en(false);
	do {
		ret = drv_dpmaif_dl_idle_check();

		/* retry handler */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "stop RX failed, 0x%x\n",
				DPMAIF_ReadReg32(
					DPMAIF_PD_DL_DBG_STA1));
			break;
		}
	} while (ret != 0);
}

void dpmaif_hw_start_tx_queue(void)
{
	/* Enable HW tx */
	drv_dpmaif_ul_all_queue_en(true);
}

void dpmaif_hw_start_rx_queue(void)
{
	/* Enalbe HW rx */
	drv_dpmaif_dl_all_queue_en(true);
}
