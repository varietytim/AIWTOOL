/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __CCCI_FSM_H__
#define __CCCI_FSM_H__
#include "ccci_modem.h"
typedef enum {
	MD_IRQ_WDT,
	MD_IRQ_CCIF_EX,
	MD_IRQ_PORT_ENUM,
} MD_IRQ_TYPE;

struct fsm_notifier_block 
{
	struct list_head entry;
	int (*notifier_fn)(enum MD_STATE state, void *);
	void *data;
};

extern unsigned int mod_param_val;

int ccci_fsm_init(int md_id);
int ccci_fsm_reset(int md_id);
int ccci_fsm_uninit(int md_id);
int ccci_fsm_recv_control_packet(int md_id, unsigned int ctrl_msg_id, struct sk_buff *skb);
int ccci_fsm_recv_status_packet(int md_id, struct sk_buff *skb);
int ccci_fsm_recv_md_interrupt(int md_id, MD_IRQ_TYPE type);
long ccci_fsm_ioctl(int md_id, unsigned int cmd, unsigned long arg);
enum MD_STATE ccci_fsm_get_md_state(int md_id);
unsigned int ccci_fsm_get_current_state(int md_id);
enum MD_STATE_FOR_USER ccci_fsm_get_md_state_for_user(int md_id);
int fsm_notifier_register(int md_id, struct fsm_notifier_block *notifier);
int fsm_notifier_unregister(int md_id, struct fsm_notifier_block *notifier);

#endif /* __CCCI_FSM_H__ */

