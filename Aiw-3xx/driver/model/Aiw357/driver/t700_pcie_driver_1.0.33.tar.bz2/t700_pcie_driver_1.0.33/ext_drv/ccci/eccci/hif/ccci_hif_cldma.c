// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/random.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/syscore_ops.h>
#include <linux/version.h>

#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_modem.h"
#include "ccci_bm.h"
#include "ccci_platform.h"
#include "ccci_hif_cldma.h"
#include "modem_reg_base.h"
#include "ccci_driver.h"
#include "mtk-pci-ext.h"
#include "mhccif.h"
#define CREATE_TRACE_POINTS
#include "ccci_event.h"
#include "ccci_hif.h"
#include "port_proxy.h"

#if defined(CLDMA_TRACE) || defined(CCCI_SKB_TRACE)
#include "modem_cldma_events.h"
#endif
unsigned int trace_sample_time = 200000000;
extern bool da_down_stage_flag;

#define TAG "HIF_CLDMA"
#define MAX_TX_BUDGET 16
#define MAX_RX_BUDGET 16


/*****************extra symbols***********************/


/***************************************************/
struct mutex ctl_cfg_mutex;

Q_TYPE_ENUM normal_rx_queue_type[CLDMA_RXQ_NUM] = {
	SHARED_Q, SHARED_Q, SHARED_Q, SHARED_Q, SHARED_Q,
	SHARED_Q, SHARED_Q, SHARED_Q};
Q_TYPE_ENUM normal_tx_queue_type[CLDMA_TXQ_NUM] = {
	SHARED_Q, SHARED_Q, SHARED_Q, SHARED_Q, SHARED_Q,
	SHARED_Q, SHARED_Q, SHARED_Q};
int normal_rx_queue_buffer_size[CLDMA_RXQ_NUM] = {
	SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K};
int normal_tx_queue_buffer_size[CLDMA_TXQ_NUM] = {
	SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K, SKB_4K};
static int normal_rx_queue_buffer_number[CLDMA_RXQ_NUM] = {
	MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET, MAX_RX_BUDGET };
static int normal_tx_queue_buffer_number[CLDMA_TXQ_NUM] = {
	MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET, MAX_TX_BUDGET };

static int normal_rx_queue2ring[CLDMA_RXQ_NUM] = { 0, 1, 2, 3, 4, 5, 6, 7 };
static int normal_tx_queue2ring[CLDMA_TXQ_NUM] = { 0, 1, 2, 3, 4, 5, 6, 7 };
static int normal_rx_ring2queue[NORMAL_RXQ_NUM] = { 0, 1, 2, 3, 4, 5, 6, 7};
static int normal_tx_ring2queue[NORMAL_TXQ_NUM] = { 0, 1, 2, 3, 4, 5, 6, 7};

#define NORMAL_TX_QUEUE_MASK 0xFF
#define NORMAL_RX_QUEUE_MASK 0xFF
/* Rx, for convenience, queue 0,1,2,3 are non-stop */
#define NONSTOP_QUEUE_MASK 0xF0
#define NONSTOP_QUEUE_MASK_32 0xF0F0F0F0

static int md_cldma_dump_status(unsigned char md_id, unsigned char hif_id,
	enum modem_dump_flag flag, void *data, int length);

static inline void cldma_tgpd_set_data_ptr(
	struct cldma_tgpd *tgpd, dma_addr_t data_ptr)
{
	cldma_write32(&tgpd->data_buff_bd_ptr_h, 0, (u32)(data_ptr>>32));
	cldma_write32(&tgpd->data_buff_bd_ptr_l, 0, (u32)data_ptr);
}
static inline void cldma_tgpd_set_next_ptr(
	struct cldma_tgpd *tgpd, dma_addr_t next_ptr)
{
	cldma_write32(&tgpd->next_gpd_ptr_h, 0, (u32)(next_ptr >> 32));
	cldma_write32(&tgpd->next_gpd_ptr_l, 0, (u32)next_ptr);
}

static inline void cldma_rgpd_set_data_ptr(
	struct cldma_rgpd *rgpd, dma_addr_t data_ptr)
{
	cldma_write32(&rgpd->data_buff_bd_ptr_h, 0, (u32)(data_ptr>>32));
	cldma_write32(&rgpd->data_buff_bd_ptr_l, 0, (u32)data_ptr);
}

static inline void cldma_rgpd_set_next_ptr(
	struct cldma_rgpd *rgpd, dma_addr_t next_ptr)
{
	cldma_write32(&rgpd->next_gpd_ptr_h, 0, (u32)(next_ptr >> 32));
	cldma_write32(&rgpd->next_gpd_ptr_l, 0, (u32)next_ptr);
	MTK_DEBUG_LOG(TAG, "L:0x%x, H:0x%x, DMA address:0x%llx\n",
		rgpd->next_gpd_ptr_l, rgpd->next_gpd_ptr_h, next_ptr);
}
static inline void cldma_tbd_set_data_ptr(
	struct cldma_tbd *tbd, dma_addr_t data_ptr)
{
	cldma_write32(&tbd->data_buff_ptr_h, 0, (u32)(data_ptr >> 32));
	cldma_write32(&tbd->data_buff_ptr_l, 0, (u32) data_ptr);
}

static inline void cldma_tbd_set_next_ptr(
	struct cldma_tbd *tbd, dma_addr_t next_ptr)
{
	cldma_write32(&tbd->next_bd_ptr_h, 0, (u32)(next_ptr >> 32));
	cldma_write32(&tbd->next_bd_ptr_l, 0, (u32)next_ptr);
}

static inline void cldma_rbd_set_data_ptr(
	struct cldma_rbd *rbd, dma_addr_t data_ptr)
{
	cldma_write32(&rbd->data_buff_ptr_h, 0, (u32)(data_ptr >> 32));
	cldma_write32(&rbd->data_buff_ptr_l, 0, (u32)data_ptr);
}

static inline void cldma_rbd_set_next_ptr(
	struct cldma_rbd *rbd, dma_addr_t next_ptr)
{
	cldma_write32(&rbd->next_bd_ptr_h, 0, (u32)(next_ptr >> 32));
	cldma_write32(&rbd->next_bd_ptr_l, 0, (u32)next_ptr);

}

static inline struct cldma_request *cldma_ring_step_forward(
	struct cldma_ring *ring, struct cldma_request *req)
{
	struct cldma_request *next_req;

	if (req->entry.next == &ring->gpd_ring)
		next_req = list_first_entry(&ring->gpd_ring,
			struct cldma_request, entry);
	else
		next_req = list_entry(req->entry.next,
			struct cldma_request, entry);
	return next_req;
}

static inline struct cldma_request *cldma_ring_step_backward(
	struct cldma_ring *ring, struct cldma_request *req)
{
	struct cldma_request *prev_req;

	if (req->entry.prev == &ring->gpd_ring)
		prev_req = list_last_entry(&ring->gpd_ring,
			struct cldma_request, entry);
	else
		prev_req = list_entry(req->entry.prev,
			struct cldma_request, entry);
	return prev_req;
}

#ifdef ENABLE_CCCI_DRI_UT

static int cldma_ut_tx_collect(struct md_cd_queue *queue, int blocking)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(queue->modem->index,
		queue->hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		queue->modem->index, queue->hif_id);
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	struct cldma_request *req;
	struct cldma_request *rx_req;
	struct cldma_tgpd *tgpd;
	struct cldma_rgpd *rgpd;
	struct ccci_header *ccci_h;
	struct sk_buff *tx_skb;
	struct md_cd_queue *rx_queue = &md_ctrl->rxq[queue->index];

	rx_req = rx_queue->tr_done;
	req = queue->tr_done;
	while (1) {
		tgpd = (struct cldma_tgpd *)req->gpd;
		rgpd = (struct cldma_rgpd *)rx_req->gpd;
		if(!((tgpd->gpd_flags & 0x1) == 1 && req->skb)) {
			MTK_DEBUG_LOG("CLD_LP", "there is not Wait_send GPD in TX queue,gpd_flags: %x, skb: %p , req: %p\n", \
				tgpd->gpd_flags, req->skb , req);
			break;
		}
		if(!((rgpd->gpd_flags & 0x1) == 1 && rx_req->skb != NULL)){
			MTK_DEBUG_LOG("CLD_LP", "there is not GPD in RX queue, gpd_flags: %x, skb: %p, req: %p\n", \
				rgpd->gpd_flags, rx_req->skb, rx_req);
			break;
		}
		tx_skb = req->skb;
		ccci_h = (struct ccci_header *)tx_skb->data;
		ccci_h->channel -= 1;
		/* transfer data to rx queue*/
		memcpy(rx_req->skb->data, tx_skb->data, tx_skb->len);
		rgpd->data_buff_len = tx_skb->len;
		cldma_hw_send(hw_ctrl, queue->index, 0);
		tasklet_hi_schedule(&hw_info->cldma_irq_task);
		/* Change TX_HWO=0, RX_HWO=0*/
		cldma_write8(&tgpd->gpd_flags, 0, cldma_read8(&tgpd->gpd_flags, 0) & (~0x1));
		cldma_write8(&rgpd->gpd_flags, 0, cldma_read8(&rgpd->gpd_flags, 0) & (~0x1));
		queue->tr_ring->handle_tx_done(queue, 0, 0);
		/* step forward */
		rx_req = cldma_ring_step_forward(rx_queue->tr_ring, rx_req);
		req = cldma_ring_step_forward(queue->tr_ring, req);
	}
	return 0;
}
void cldma_ut_lp_work(struct work_struct *work)
{
	struct md_cd_queue *queue =
		container_of(work, struct md_cd_queue, lp_qwork);

	if (test_and_set_bit(0, &queue->ut_tx_on_going)) {
		MTK_DEBUG_LOG(TAG, "Q%d ut_tx is on-going(%lu)\n",
			queue->index, queue->ut_tx_on_going);
	} else {
		cldma_ut_tx_collect(queue, 1);
		test_and_clear_bit(0, &queue->ut_tx_on_going);
	}
}
void cldma_ut_lp_func(struct md_cd_queue *queue)
{

	if (test_and_set_bit(0, &queue->ut_tx_on_going)) {
		MTK_DEBUG_LOG(TAG, "Q%d ut_tx is on-going(%lu)1\n",
			queue->index, queue->ut_tx_on_going);
	} else {
		cldma_ut_tx_collect(queue, 1);
		test_and_clear_bit(0, &queue->ut_tx_on_going);
	}

}
#endif

void *cldma_hif_fill_rt_header(unsigned char md_id, unsigned char hif_id,
	int packet_size, unsigned int tx_ch, unsigned int txqno)
{
	return NULL;
}

static void cldma_dump_gpd_queue(struct md_cd_ctrl *md_ctrl, unsigned int qno)
{
	unsigned int *tmp;
	unsigned int index_i;
	struct cldma_request *req = NULL;
	unsigned int length = sizeof(struct cldma_tgpd);
#ifdef CLDMA_DUMP_BD
	struct cldma_request *req_bd = NULL;
#endif
	struct cldma_rgpd *rgpd;

	/* use request's link head to traverse */
	MTK_ERR_LOG(TAG,
		" dump txq %u, tr_done=0x%p/0x%llx, tx_xmit=0x%p/0x%llx\n", qno,
		md_ctrl->txq[qno].tr_done->gpd,
		md_ctrl->txq[qno].tr_done->gpd_addr,
		md_ctrl->txq[qno].tx_xmit->gpd,
		md_ctrl->txq[qno].tx_xmit->gpd_addr);
	list_for_each_entry(req, &md_ctrl->txq[qno].tr_ring->gpd_ring, entry) {
		tmp = (unsigned int *)req->gpd;
		if (length < (4 * 6))
			MTK_ERR_LOG(TAG,
				"GPD length(%d) is err(<32 bytes)\n", length);
		for (index_i = 0; index_i < length/(4 * 6); index_i++) {
			MTK_ERR_LOG(TAG, " 0x%p: %X %X %X %X %X %X\n", req->gpd,
			*tmp, *(tmp + 1), *(tmp + 2),
			*(tmp + 3), *(tmp + 4), *(tmp + 5));
			tmp += 4;
		}
#ifdef CLDMA_DUMP_BD
		list_for_each_entry(req_bd, &req->bd, entry) {
			tmp = (unsigned int *)req_bd->gpd;
			MTK_ERR_LOG(TAG, "-0x%p: %X %X %X %X\n", req_bd->gpd,
				*tmp, *(tmp + 1), *(tmp + 2), *(tmp + 3));
		}
#endif
	}

	/* use request's link head to traverse */
	/*maybe there is more txq than rxq*/
	if (qno >= CLDMA_RXQ_NUM) {
		MTK_ERR_LOG(TAG, "invalid rxq%d\n", qno);
		return;
	}
	MTK_ERR_LOG(TAG,
		"dump rxq %u, tr_done=0x%p/0x%llx, rx_refill=0x%p/0x%llx\n",
		qno, md_ctrl->rxq[qno].tr_done->gpd,
		md_ctrl->rxq[qno].tr_done->gpd_addr,
		md_ctrl->rxq[qno].rx_refill->gpd,
		md_ctrl->rxq[qno].rx_refill->gpd_addr);
	list_for_each_entry(req, &md_ctrl->rxq[qno].tr_ring->gpd_ring, entry) {
		tmp = (unsigned int *)req->gpd;
		MTK_ERR_LOG(TAG,
			" 0x%p: %X %X %X %X %X %X\n", req->gpd,
			*tmp, *(tmp + 1), *(tmp + 2),
			*(tmp + 3), *(tmp + 4), *(tmp + 5));
		rgpd = (struct cldma_rgpd *)req->gpd;
		if ((cldma_read8(&rgpd->gpd_flags, 0) & 0x1) == 0 && req->skb) {
			tmp = (unsigned int *)req->skb->data;
			MTK_ERR_LOG(TAG, " 0x%p: %X %X %X %X\n", req->skb->data,
			   *tmp, *(tmp + 1), *(tmp + 2), *(tmp + 3));
		}
	}
}

static void cldma_dump_all_gpd(struct md_cd_ctrl *md_ctrl)
{
	int i;

	for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++)
		cldma_dump_gpd_queue(md_ctrl, i);
}

static void cldma_dump_packet_history(struct md_cd_ctrl *md_ctrl)
{
	int i;

	for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
		MTK_ERR_LOG(TAG,
			"Current txq%d pos: tr_done=0x%llx, tx_xmit=0x%llx\n",
			i, md_ctrl->txq[i].tr_done->gpd_addr,
			md_ctrl->txq[i].tx_xmit->gpd_addr);
	}
	for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
		MTK_ERR_LOG(TAG,
			"Current rxq%d pos: tr_done=0x%llx, rx_refill=0x%llx\n",
			i, md_ctrl->rxq[i].tr_done->gpd_addr,
			md_ctrl->rxq[i].rx_refill->gpd_addr);
	}
	ccci_md_dump_log_history(md_ctrl->md_id,
		&md_ctrl->traffic_info, 1, QUEUE_LEN(md_ctrl->txq),
		QUEUE_LEN(md_ctrl->rxq));
}

static void cldma_dump_queue_history(struct md_cd_ctrl *md_ctrl,
	unsigned int qno)
{
	MTK_DEBUG_LOG(TAG,
		"Current txq%u pos: tr_done=0x%llx, tx_xmit=0x%llx\n", qno,
		md_ctrl->txq[qno].tr_done->gpd_addr,
		md_ctrl->txq[qno].tx_xmit->gpd_addr);
	MTK_DEBUG_LOG(TAG,
		"Current rxq%u pos: tr_done=0x%llx, rx_refill=0x%llx\n", qno,
		md_ctrl->rxq[qno].tr_done->gpd_addr,
		md_ctrl->rxq[qno].rx_refill->gpd_addr);
	ccci_md_dump_log_history(md_ctrl->md_id,
		&md_ctrl->traffic_info, 0, qno, qno);
}

static int cldma_queue_broadcast_state(struct md_cd_ctrl *md_ctrl,
	enum MD_STATE state, enum direction dir, int index)
{
	ccci_port_queue_status_notify(md_ctrl->md_id,
		md_ctrl->hif_id, index, dir, state);
	return 0;
}

/* may be called from workqueue or NAPI or tasklet (queue0) context,
 *only NAPI and tasklet with blocking=false
 */
int cldma_gpd_rx_collect(struct md_cd_queue *queue, int budget, int blocking)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(queue->modem->index,
		queue->hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		queue->modem->index, queue->hif_id);
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	struct cldma_request *req;
	struct cldma_rgpd *rgpd;
	struct sk_buff *skb = NULL;
	struct sk_buff *new_skb = NULL;
	int ret = 0, count = 0, rxbytes = 0;
	int over_budget = 0;
	unsigned long long skb_bytes = 0;
	unsigned long flags;
	unsigned int L2RISAR0 = 0;
	unsigned int skb_size;
	unsigned char hwo_polling_count = 0;
	unsigned long long gpd_addr_h_inreg = 0;
	unsigned long long gpd_addr_l_inreg = 0;
	int cpu_num = -1;
#ifdef CLDMA_TRACE
	unsigned long long port_recv_time = 0;
	unsigned long long skb_alloc_time = 0;
	unsigned long long total_handle_time = 0;
	unsigned long long temp_time = 0;
	unsigned long long total_time = 0;
	unsigned int rx_interal;
	static unsigned long long last_leave_time[CLDMA_RXQ_NUM] = { 0 };
	static unsigned int sample_time[CLDMA_RXQ_NUM] = { 0 };
	static unsigned int sample_bytes[CLDMA_RXQ_NUM] = { 0 };

	total_time = sched_clock();
	if (last_leave_time[queue->index] == 0)
		rx_interal = 0;
	else
		rx_interal = total_time - last_leave_time[queue->index];
#endif
    CTRL_GET_CUR_CPU(&cpu_num);
again:
	while (1) {
#ifdef CLDMA_TRACE
		total_handle_time = port_recv_time = sched_clock();
#endif
		req = queue->tr_done;
		if (unlikely(!req)) {
			MTK_ERR_LOG(TAG, "RXQ was released\n");
			return ALL_CLEAR;
		}

		rgpd = (struct cldma_rgpd *)req->gpd;
		/*new way*/
		if (!((cldma_read8(&rgpd->gpd_flags, 0) & 0x1) ==
			0 && req->skb)) {

			MTK_DEBUG_LOG(TAG, "=======rx_collect enter gpd_flags %d skb %p\n",\
						(cldma_read8(&rgpd->gpd_flags, 0) & 0x1), req->skb);
			/*check addr*/
			gpd_addr_h_inreg = cldma_read32( hw_info->cldma_ap_ao_base,
				REG_CLDMA_SO_CURRENT_ADDRH_0 + queue->index * 8);
			gpd_addr_l_inreg = cldma_read32( hw_info->cldma_ap_ao_base,
				REG_CLDMA_SO_CURRENT_ADDRL_0 + queue->index * 8);

			if (gpd_addr_l_inreg == 0xFFFFFFFF && gpd_addr_h_inreg == 0xFFFFFFFF) {
				MTK_ERR_LOG(TAG,"PCIe Link disconnect!\n");
				return ALL_CLEAR;
			}

			if ((unsigned long long)queue->tr_done->gpd_addr !=
				((gpd_addr_h_inreg << 32) + gpd_addr_l_inreg) &&
				(hwo_polling_count++ < 100)) {
				udelay(1);
				continue;
			} else {
				MTK_DEBUG_LOG(TAG,
				"hwo_polling_count %d, current address:0x%llx, tr_done:0x%llx\n",
				hwo_polling_count,(gpd_addr_h_inreg << 32) + gpd_addr_l_inreg,
				queue->tr_done->gpd_addr);
				hwo_polling_count = 0;
				break;
			}
		}
		hwo_polling_count = 0;
		skb = req->skb;
		/* update skb */
		skb_size = skb_data_size(skb);

		if (req->data_buffer_ptr_saved != 0) {
			dma_unmap_single(hw_ctrl->dma_dev,
				req->data_buffer_ptr_saved,
				skb_data_size(skb), DMA_FROM_DEVICE);
			req->data_buffer_ptr_saved = 0;
		}

		/*init skb struct*/
		skb->len = 0;
		skb_reset_tail_pointer(skb);
		/*set data len*/
		skb_put(skb, rgpd->data_buff_len);
		skb_bytes = skb->len;
		/* check wakeup source */
		if (atomic_cmpxchg(&md_ctrl->wakeup_src, 1, 0) == 1)
			MTK_NOTICE_LOG(TAG,
				"CLDMA_MD wakeup source:(%d)\n", queue->index);
				
		MTK_INFO_LOG(TAG, " rxq:%u,%x,%x,(%d)\n",
	    	queue->index,
	    	*(unsigned int *)(skb->data+4),
	    	*(unsigned int *)(skb->data+8),
	    	cpu_num);
	    MTK_DEBUG_LOG(TAG,
	    	"recv rx msg (refill: 0x%llx, tr_done 0x%llx:)\n",
	    	queue->rx_refill->gpd_addr, queue->tr_done->gpd_addr);
	    MTK_DEBUG_LOG(TAG,
			"gpd_rx_len=%u, qtype=%d",
			rgpd->data_buff_len, queue->q_type);
			
#ifdef CCCI_CTL_TRACE
		trace_cldma_gpd_rx_collect(queue->index,
			rgpd->data_buff_len, skb, rgpd);
#endif /* CCCI_CTL_TRACE */
		/* upload skb */
		if (queue->q_type == SHARED_Q) {
			ret = ccci_md_recv_skb(md_ctrl->md_id, md_ctrl->hif_id, skb);
		} else if(queue->q_type == DEDICATED_Q){
			ret = port_recv_skb_from_dedicatedQ(md_ctrl->md_id, md_ctrl->hif_id, queue->index, skb);
		}
#ifdef CLDMA_TRACE
		port_recv_time =
			((skb_alloc_time = sched_clock()) - port_recv_time);
#endif
		new_skb = NULL;
		if (ret >= 0 || ret == -CCCI_ERR_DROP_PACKET) {
			new_skb = ccci_alloc_skb(queue->tr_ring->pkt_size,
				1, blocking);
		    if (!new_skb)
				MTK_ERR_LOG(TAG,
					"alloc skb fail on q%d\n",
					queue->index);
		}
		
		if (new_skb) {
			/* mark cldma_request as available */
			req->skb = NULL;
			cldma_rgpd_set_data_ptr(rgpd, 0);
			/* step forward */
			queue->tr_done = cldma_ring_step_forward(queue->tr_ring, req);
			/* update log */
			rxbytes += skb_bytes;

			/* refill */
			req = queue->rx_refill;
			rgpd = (struct cldma_rgpd *)req->gpd;
			req->data_buffer_ptr_saved =
				dma_map_single(hw_ctrl->dma_dev, new_skb->data,
					skb_data_size(new_skb), DMA_FROM_DEVICE);
			if (dma_mapping_error(hw_ctrl->dma_dev, req->data_buffer_ptr_saved)) {
				MTK_ERR_LOG(TAG, "error dma mapping\n");
				req->data_buffer_ptr_saved = 0;
				ccci_free_skb(new_skb);
				return -1;
			}

			cldma_rgpd_set_data_ptr(rgpd, req->data_buffer_ptr_saved);
			cldma_write16(&rgpd->data_buff_len, 0, 0);
			/* set HWO, no need to hold ring_lock as no racer */
			cldma_write8(&rgpd->gpd_flags, 0, 0x81);
			/* mark cldma_request as available */
			req->skb = new_skb;
			/* step forward */
			queue->rx_refill = cldma_ring_step_forward(queue->tr_ring, req);
		} else {
			MTK_INFO_LIMITED_LOG(TAG,"alloc skb fail on q%d\n",
					queue->index);
			msleep(10);
			return ONCE_MORE;
		}
#ifdef CLDMA_TRACE
		temp_time = sched_clock();
		skb_alloc_time = temp_time - skb_alloc_time;
		total_handle_time = temp_time - total_handle_time;
		trace_cldma_rx(queue->index, 0,
			count, port_recv_time, skb_alloc_time,
			total_handle_time, skb_bytes);
#endif
		/* check budget and if need rescheduled
		 * over_budget=1 means they can be scheduled again
		 */
		if (++count >= budget && need_resched()) {
			over_budget = 1;
			break;
		}
	}

	ret = ALL_CLEAR;
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (md_ctrl->rxq_active & (1 << queue->index)) {
		/* resume Rx queue */
		if (!cldma_hw_queue_isactive(hw_ctrl, queue->index, 1)) {
			MTK_DEBUG_LOG(TAG, "resume queue, L2RISAR0: 0x%x\n",
				cldma_hw_int_status(hw_ctrl, 0xFFFF, 1));
			cldma_hw_resume_queue(hw_ctrl, queue->index, 1);
		}
		/* greedy mode */
		L2RISAR0 = cldma_hw_int_status(hw_ctrl, (1 << queue->index), 1);

		/* where are we going */
		if (over_budget) {
			/*need be scheduled again, avoid the soft lockup*/
			if(L2RISAR0){
				cldma_hw_rx_done(hw_ctrl, L2RISAR0);
				MTK_INFO_LOG(TAG, "ONCE_MORE\n");
				ret = ONCE_MORE;
			}
			else{
				MTK_INFO_LOG(TAG, "ALL_CLEAR\n");
				ret = ALL_CLEAR;
			}
		} else {
			if (L2RISAR0) {
				/* clear IP busy register wake up cpu case */
				cldma_hw_rx_done(hw_ctrl, L2RISAR0);
				spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
				MTK_INFO_LIMITED_LOG(TAG, "goto again\n");
				goto again;
			} else {
				ret = ALL_CLEAR;
			}
		}
	}
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);

#ifdef CLDMA_TRACE
	if (count) {
		last_leave_time[queue->index] = sched_clock();
		total_time = last_leave_time[queue->index] - total_time;
		sample_time[queue->index] += (total_time + rx_interal);
		sample_bytes[queue->index] += rxbytes;
		trace_cldma_rx_done(queue->index,
			rx_interal, total_time, count, rxbytes, 0, ret);
		if (sample_time[queue->index] >= trace_sample_time) {
			trace_cldma_rx_done(queue->index, 0, 0, 0, 0,
				sample_time[queue->index],
				sample_bytes[queue->index]);
			sample_time[queue->index] = 0;
			sample_bytes[queue->index] = 0;
		}
	} else {
		trace_cldma_error(queue->index, -1, 0, __LINE__);
	}
#endif
	return ret;
}

void cldma_rx_done(struct work_struct *work)
{
	struct ccci_modem *modem;
	struct md_cd_queue *queue;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;
	int ret;

	modem = ccci_md_get_modem_by_id(0);
	if (unlikely(!modem)) {
		MTK_ERR_LOG(TAG, "modem is NULL!\n");
		return;
	}

	queue = container_of(work, struct md_cd_queue, cldma_rx_work);

	md_ctrl = ccci_hif_get_by_id(modem->index, queue->hif_id);
	hw_ctrl = ccci_hw_ctrl_get_by_id(modem->index, queue->hif_id);

	md_ctrl->traffic_info.latest_q_rx_time[queue->index] = local_clock();
	ret = queue->tr_ring->handle_rx_done(queue, queue->budget, 1);
	if (ret != ALL_CLEAR) {
		if (md_ctrl->rxq_active & (1 << queue->index)) {
			queue_work(queue->worker, &queue->cldma_rx_work);
			return;
		}
	}
	/* clear IP busy register wake up cpu case */
	clear_ip_busy(hw_ctrl);
	/* enable RX_DONE && EMPTY interrupt */
	cldma_hw_dismask_txrxirq(hw_ctrl, queue->index, 1);
	cldma_hw_dismask_eqirq(hw_ctrl, queue->index, 1);
	mtk_pm_runtime_put(hw_ctrl->mtk_dev);
}

/* this function may be called from both workqueue and ISR (timer) */
int cldma_gpd_tx_collect(struct md_cd_queue *queue, int budget, int blocking)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(queue->modem->index,
		queue->hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		queue->modem->index, queue->hif_id);
	unsigned long flags;
	struct cldma_request *req;
	struct cldma_tgpd *tgpd;
	int count = 0;
	struct sk_buff *skb_free;
	dma_addr_t dma_free;
	unsigned int dma_len;

	while (1) {
		spin_lock_irqsave(&queue->ring_lock, flags);
		req = queue->tr_done;
		if (unlikely(!req)) {
			MTK_ERR_LOG(TAG, "TXQ was released\n");
			spin_unlock_irqrestore(&queue->ring_lock, flags);
			break;
		}
		tgpd = (struct cldma_tgpd *)req->gpd;
		if (!((tgpd->gpd_flags & 0x1) == 0 && req->skb)) {
			spin_unlock_irqrestore(&queue->ring_lock, flags);
			break;
		}
		/* restore IOC setting */
		if (req->ioc_override & 0x80) {
			if (req->ioc_override & 0x1)
				tgpd->gpd_flags |= 0x80;
			else
				tgpd->gpd_flags &= 0x7F;
			MTK_NOTICE_LOG(TAG,
				"qno%u, req->ioc_override=0x%x,tgpd->gpd_flags=0x%x\n",
				queue->index, req->ioc_override,
				tgpd->gpd_flags);
		}
		tgpd->non_used = 2;
		/* update counter */
		queue->budget++;
		/* save skb reference */
		dma_free = req->data_buffer_ptr_saved;
		dma_len = tgpd->data_buff_len;
		skb_free = req->skb;
		/* mark cldma_request as available */
		req->skb = NULL;
		/* step forward */
		queue->tr_done = cldma_ring_step_forward(queue->tr_ring, req);
		if (likely(ccci_md_get_cap_by_id(md_ctrl->md_id) &
			MODEM_CAP_TXBUSY_STOP))
			cldma_queue_broadcast_state(md_ctrl,
			TX_IRQ, MTK_OUT, queue->index);
		spin_unlock_irqrestore(&queue->ring_lock, flags);
		count++;
		dma_unmap_single(hw_ctrl->dma_dev,
			dma_free, dma_len, DMA_TO_DEVICE);
		/* check wakeup source */
		if (atomic_cmpxchg(&md_ctrl->wakeup_src, 1, 0) == 1)
			MTK_NOTICE_LOG(TAG,
				"CLDMA_AP wakeup source:%d\n", queue->index);
#ifdef CCCI_CTL_TRACE
		trace_cldma_gpd_tx_collect(skb_free, queue->index,
			queue->budget, count);
#endif /* CCCI_CTL_TRACE */
		MTK_INFO_LOG(TAG,
			"txq:%u,%d,%x,%x\n",
		queue->index, queue->budget,
		*(unsigned int *)(skb_free->data+4),
		*(unsigned int *)(skb_free->data+8));

		ccci_free_skb(skb_free);
	}
	if (count)
		wake_up_nr(&queue->req_wq, count);
	return count;
}

static void cldma_tx_queue_empty_handler(struct md_cd_queue *queue)
{
	unsigned long flags;
	struct cldma_request *req;
	struct cldma_tgpd *tgpd;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;
	struct cldma_hw_info *hw_info;
	u32 ul_curr_addr_l;
	u32 ul_curr_addr_h;
	dma_addr_t ul_curr_addr;
	dma_addr_t tgpd_addr;
	int pending_gpd = 0;
	int md_id = queue->modem->index;

	md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, queue->hif_id);
	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, queue->hif_id);
	hw_info = (struct cldma_hw_info *)hw_ctrl->private;

	if (md_ctrl->txq_active & (1 << queue->index)) {
		/* check if there is any pending TGPD with HWO=1 */
		spin_lock_irqsave(&queue->ring_lock, flags);
		req = cldma_ring_step_backward(queue->tr_ring, queue->tx_xmit);
		tgpd = (struct cldma_tgpd *)req->gpd;
		tgpd_addr = req->gpd_addr;
		if ((tgpd->gpd_flags & 0x1) && req->skb)
			pending_gpd = 1;
		spin_unlock_irqrestore(&queue->ring_lock, flags);


		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
		if (pending_gpd) {
			/*Check current processing TGPD*/
			ul_curr_addr_l = cldma_read32(hw_info->cldma_ap_pdn_base,
								REG_CLDMA_UL_CURRENT_ADDRL_0 + (queue->index) * 8);
			ul_curr_addr_h = cldma_read32(hw_info->cldma_ap_pdn_base,
								REG_CLDMA_UL_CURRENT_ADDRH_0 + (queue->index) * 8);
			ul_curr_addr = ((dma_addr_t)(ul_curr_addr_h) << 32) | (dma_addr_t)ul_curr_addr_l;
			if (tgpd_addr != ul_curr_addr) {
				MTK_ERR_LOG(TAG, "CLDMA%d Q%d TGPD addr, SW:%llX, HW:%llX\n",
					hw_ctrl->hif_id, queue->index, tgpd_addr, ul_curr_addr);
			} else {
				/* retry*/
				cldma_hw_resume_queue(hw_ctrl, queue->index, 0);
				MTK_INFO_LIMITED_LOG(TAG, "resume CLDMA%d Q%d in tx empty\n",
								hw_ctrl->hif_id, queue->index);
			}
		}
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}
}

static void cldma_tx_done(struct work_struct *work)
{
	struct delayed_work *dwork = to_delayed_work(work);
	struct ccci_modem *modem;
	struct md_cd_queue *queue =
		container_of(dwork, struct md_cd_queue, cldma_tx_work);
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;

	int count;
	unsigned int L2TISAR0 = 0;
#ifndef CLDMA_NO_TX_IRQ
	unsigned long flags;
#endif

#ifdef CLDMA_TRACE
	unsigned long long total_time = 0;
	unsigned int tx_interal;
	static unsigned long long leave_time[CLDMA_TXQ_NUM] = { 0 };

	total_time = sched_clock();
	leave_time[queue->index] = total_time;
	if (leave_time[queue->index] == 0)
		tx_interal = 0;
	else
		tx_interal = total_time - leave_time[queue->index];
#endif

	modem = ccci_md_get_modem_by_id(0);
	if (unlikely(!modem)) {
		MTK_ERR_LOG(TAG, "modem is NULL!\n");
		return;
	}

	md_ctrl = ccci_hif_get_by_id(modem->index, queue->hif_id);
	hw_ctrl = ccci_hw_ctrl_get_by_id(modem->index, queue->hif_id);

	count = queue->tr_ring->handle_tx_done(queue, 0, 0);
	if (count && md_ctrl->tx_busy_warn_cnt)
		md_ctrl->tx_busy_warn_cnt = 0;
	/* greedy mode */
	L2TISAR0 = cldma_hw_int_status(hw_ctrl,(1 << queue->index)|((1 << queue->index) << EQ_STA_BIT_OFFSET), 0);
	MTK_DEBUG_LOG(TAG, "tx(qno:%d) greedy mode check: L2TISAR0=0x%x\n",\
        queue->index, L2TISAR0);
	if (L2TISAR0 & EMPTY_STATUS_BITMASK & ((1 << queue->index) << EQ_STA_BIT_OFFSET)){
		cldma_hw_tx_done(hw_ctrl,((1 << queue->index) << EQ_STA_BIT_OFFSET));
		cldma_tx_queue_empty_handler(queue);
	}
	if (L2TISAR0 & TXRX_STATUS_BITMASK & (1 << queue->index)) {
		cldma_hw_tx_done(hw_ctrl, (1 << queue->index));
		queue_delayed_work(queue->worker,
				&queue->cldma_tx_work, msecs_to_jiffies(0));
		return;
	}

#ifndef CLDMA_NO_TX_IRQ
	/* enable TX_DONE interrupt */
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (md_ctrl->txq_active & (1 << queue->index)) {
		clear_ip_busy(hw_ctrl);
		cldma_hw_dismask_eqirq(hw_ctrl, queue->index, 0);
		cldma_hw_dismask_txrxirq(hw_ctrl, queue->index, 0);
	}
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
#endif

	mtk_pm_runtime_put(hw_ctrl->mtk_dev);
#ifdef CLDMA_TRACE
	if (count) {
		leave_time[queue->index] = sched_clock();
		total_time = leave_time[queue->index] - total_time;
		trace_cldma_tx_done(queue->index,
			tx_interal, total_time, count);
	} else {
		trace_cldma_error(queue->index, -1, 0, __LINE__);
	}
#endif
}
void fill_cldma_request(struct cldma_request *item)
{
	item->gpd = (void *)0xacacacacacacacac;
	item->gpd_addr = 0xbbbbbbbbbbbbbbbb;
	item->skb = (void *)0x2222222222222222;
	item->data_buffer_ptr_saved = 0x3333333333333333;
	item->ioc_override = 0x66;
	MTK_DEBUG_LOG(TAG,
		"%p, 0x%llx, %p, 0x%llx, %p, %p, 0x%x\n",
		item->gpd, item->gpd_addr, item->skb,
		item->data_buffer_ptr_saved, &item->entry,
		&item->bd, item->ioc_override);
}
static void cldma_rx_ring_init(struct md_cd_ctrl *md_ctrl,
	struct cldma_ring *ring)
{
	int i;
	struct cldma_request *item, *first_item = NULL;
	struct cldma_rgpd *gpd = NULL, *prev_gpd = NULL;
	unsigned long flags;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_ctrl->md_id,
		md_ctrl->hif_id);

	if (ring->type == RING_GPD) {
		for (i = 0; i < ring->length; i++) {
			item = kzalloc(
				sizeof(struct cldma_request), GFP_KERNEL);
			if (item != NULL) {
				item->gpd = dma_pool_alloc(md_ctrl->gpd_dmapool,
					GFP_KERNEL, &item->gpd_addr);
				item->skb = ccci_alloc_skb(
					ring->pkt_size, 1, 1);
				gpd = (struct cldma_rgpd *)item->gpd;
				memset(gpd, 0, sizeof(struct cldma_rgpd));
				spin_lock_irqsave(
					&md_ctrl->cldma_timeout_lock, flags);
				item->data_buffer_ptr_saved = dma_map_single(
					hw_ctrl->dma_dev,
					item->skb->data,
					skb_data_size(item->skb),
					DMA_FROM_DEVICE);
				if (dma_mapping_error(hw_ctrl->dma_dev,
					item->data_buffer_ptr_saved)) {
					MTK_ERR_LOG(TAG, "error dma mapping\n");
					item->data_buffer_ptr_saved = 0;
					spin_unlock_irqrestore(
						&md_ctrl->cldma_timeout_lock,
						flags);
					ccci_free_skb(item->skb);
					dma_pool_free(md_ctrl->gpd_dmapool,
						item->gpd, item->gpd_addr);
					kfree(item);
					return;
				}
				spin_unlock_irqrestore(
					&md_ctrl->cldma_timeout_lock, flags);
				cldma_rgpd_set_data_ptr(gpd,
					item->data_buffer_ptr_saved);
				gpd->data_allow_len = ring->pkt_size;
				gpd->gpd_flags = 0x81;	/* IOC|HWO */
				if (i == 0)
					first_item = item;
				else
					cldma_rgpd_set_next_ptr(prev_gpd,
						item->gpd_addr);
				INIT_LIST_HEAD(&item->entry);
				list_add_tail(&item->entry, &ring->gpd_ring);
				prev_gpd = gpd;
			} else {
				MTK_ERR_LOG(TAG,
					"rx cldma_request alloc fail\n");
				break;
			}
		}
		if (first_item)
			cldma_rgpd_set_next_ptr(gpd, first_item->gpd_addr);
	}
}

static void cldma_tx_ring_init(struct md_cd_ctrl *md_ctrl,
	struct cldma_ring *ring)
{
	int i, j;
	struct cldma_request *item = NULL, *bd_item = NULL, *first_item = NULL;
	struct cldma_tgpd *tgpd = NULL, *prev_gpd = NULL;
	struct cldma_tbd *bd = NULL, *prev_bd = NULL;

	if (ring->type == RING_GPD) {
		for (i = 0; i < ring->length; i++) {
			item = (struct cldma_request *)kzalloc(sizeof(struct cldma_request), GFP_KERNEL);
            if (item != NULL) {
                item->gpd = dma_pool_alloc(md_ctrl->gpd_dmapool, GFP_KERNEL, &item->gpd_addr);
                tgpd = (struct cldma_tgpd *)item->gpd;
    			memset(tgpd, 0, sizeof(struct cldma_tgpd));
    			tgpd->gpd_flags = 0x80;	/* IOC */
    			if (i == 0)
    				first_item = item;
    			else
    				cldma_tgpd_set_next_ptr(prev_gpd, item->gpd_addr);
    			INIT_LIST_HEAD(&item->bd);
    			INIT_LIST_HEAD(&item->entry);
    			list_add_tail(&item->entry, &ring->gpd_ring);
    			prev_gpd = tgpd;
            } else {
                MTK_ERR_LOG(TAG, "tx cldma_request alloc fail\n");
            }
		}
		if (first_item != NULL)
			cldma_tgpd_set_next_ptr(tgpd, first_item->gpd_addr);
	}
	if (ring->type == RING_GPD_BD) {
		for (i = 0; i < ring->length; i++) {
			item = kzalloc(sizeof(struct cldma_request),
				GFP_KERNEL);
			item->gpd = dma_pool_alloc(md_ctrl->gpd_dmapool,
				GFP_KERNEL, &item->gpd_addr);
			tgpd = (struct cldma_tgpd *)item->gpd;
			memset(tgpd, 0, sizeof(struct cldma_tgpd));
			tgpd->gpd_flags = 0x82;	/* IOC|BDP */
			if (i == 0)
				first_item = item;
			else
				cldma_tgpd_set_next_ptr(prev_gpd, item->gpd_addr);
			INIT_LIST_HEAD(&item->bd);
			INIT_LIST_HEAD(&item->entry);
			list_add_tail(&item->entry, &ring->gpd_ring);
			prev_gpd = tgpd;
			/* add BD */
			for (j = 0; j < MAX_BD_NUM + 1; j++) {	/* extra 1 BD for skb head */
				bd_item = kzalloc(sizeof(struct cldma_request), GFP_KERNEL);
				bd_item->gpd = dma_pool_alloc(md_ctrl->gpd_dmapool, GFP_KERNEL, &bd_item->gpd_addr);
				bd = (struct cldma_tbd *)bd_item->gpd;
				memset(bd, 0, sizeof(struct cldma_tbd));
				if (j == 0)
					cldma_tgpd_set_data_ptr(tgpd, bd_item->gpd_addr);
				else
					cldma_tbd_set_next_ptr(prev_bd, bd_item->gpd_addr);
				INIT_LIST_HEAD(&bd_item->entry);
				list_add_tail(&bd_item->entry, &item->bd);
				prev_bd = bd;
			}
			bd->bd_flags |= 0x1;	/* EOL */
		}
		if (first_item != NULL)
			cldma_tgpd_set_next_ptr(tgpd, first_item->gpd_addr);
	}
}

static void cldma_ring_uninit(struct md_cd_ctrl *md_ctrl,
	struct cldma_ring *ring, int dir)
{
	struct cldma_request *req_cur = NULL, *req_next = NULL;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_ctrl->md_id,
		md_ctrl->hif_id);

	if (ring->type == RING_GPD) {
		list_for_each_entry_safe(req_cur, req_next,
			&ring->gpd_ring, entry) {
			if (req_cur) {
				if ((req_cur->data_buffer_ptr_saved != 0) &&
					(req_cur->skb)) {
					if (dir == 1)
						dma_unmap_single(hw_ctrl->dma_dev, req_cur->data_buffer_ptr_saved,
							skb_data_size(req_cur->skb), DMA_FROM_DEVICE);
					else
						dma_unmap_single(hw_ctrl->dma_dev, req_cur->data_buffer_ptr_saved,
							skb_data_size(req_cur->skb), DMA_TO_DEVICE);
					req_cur->data_buffer_ptr_saved = 0;
				}
				if (req_cur->skb)
					ccci_free_skb(req_cur->skb);

				if (req_cur->gpd)
					dma_pool_free(md_ctrl->gpd_dmapool, req_cur->gpd, req_cur->gpd_addr);

				list_del(&req_cur->entry);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
				kfree_sensitive(req_cur);
#else				
				kzfree(req_cur);
#endif				
			}
		}
	}
}

static void cldma_queue_switch_ring(struct md_cd_queue *queue)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(queue->modem->index,
		queue->hif_id);
	struct cldma_request *req;

	if (queue->dir == MTK_OUT) {
		queue->tr_ring = &md_ctrl->normal_tx_ring[normal_tx_queue2ring[queue->index]];
		req = list_first_entry(&queue->tr_ring->gpd_ring,
			struct cldma_request, entry);
		queue->tr_done = req;
		queue->tx_xmit = req;
		queue->budget = queue->tr_ring->length;
	} else if (queue->dir == MTK_IN) {
		queue->tr_ring = &md_ctrl->normal_rx_ring[normal_rx_queue2ring[queue->index]];
		req = list_first_entry(&queue->tr_ring->gpd_ring,
			struct cldma_request, entry);
		queue->tr_done = req;
		queue->rx_refill = req;
		queue->budget = queue->tr_ring->length;
	}

}

static void cldma_rx_queue_init(struct md_cd_queue *queue)
{
	queue->dir = MTK_IN;
	cldma_queue_switch_ring(queue);
	queue->q_type = normal_rx_queue_type[queue->index];
}

static void cldma_tx_queue_init(struct md_cd_queue *queue)
{
	queue->dir = MTK_OUT;
	cldma_queue_switch_ring(queue);
	queue->q_type = normal_tx_queue_type[queue->index];
}

static inline void cldma_enable_irq(struct md_cd_ctrl *md_ctrl,
	struct ccci_hw_ctrl *hw_ctrl)
{
	if (atomic_cmpxchg(&md_ctrl->cldma_irq_enabled, 0, 1) == 0)
		hw_ctrl->irqops.enable_irqs(hw_ctrl);
}

static inline void cldma_disable_irq(struct md_cd_ctrl *md_ctrl,
	struct ccci_hw_ctrl *hw_ctrl)
{
	if (atomic_cmpxchg(&md_ctrl->cldma_irq_enabled, 1, 0) == 1)
		hw_ctrl->irqops.disable_irq(hw_ctrl);
}

static void cldma_rx_worker_start(struct md_cd_ctrl *md_ctrl, int qno)
{
	int ret = 0;

	ret = queue_work(md_ctrl->rxq[qno].worker,
					&md_ctrl->rxq[qno].cldma_rx_work);

}


void cldma_debug_dump(struct md_cd_ctrl *md_ctrl)
{
	struct ccci_hw_ctrl *hw_ctrl;
	struct cldma_hw_info *hw_info;

	hw_ctrl = ccci_hw_ctrl_get_by_id(md_ctrl->md_id, md_ctrl->hif_id);
	hw_info = (struct cldma_hw_info *)hw_ctrl->private;

	/*INDMA PD	084 UL_STATS (host tx)   active status (device rx out ao 0xF8)*/
	MTK_INFO_LIMITED_LOG(TAG, "host tx active:0X%X, dev rx active:0X%X, dev out pd 0x14C:0X%X\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x84),
		cldma_read32(hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET, 0x400 + 0xF8),
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x400 + 0x14C));

	/*host side L2 TX interrupt status  misc pd  0x10 0x14 0x30 0x34(optional)*/
	MTK_INFO_LIMITED_LOG(TAG, "host misc pd 0x10:0X%X,0x14:0X%X,0x30:0X%X,0x34:0X%X\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x800 + 0x10),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x800 + 0x14),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x800 + 0x30),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x800 + 0x34));

	/*device side L2 RX interupt status*/
	//misc pd  0x50 0x54 0x70 0x74 0xB4
	MTK_INFO_LIMITED_LOG(TAG, "dev misc pd 0x50:0X%X,0x54:0X%X,0x70:0X%X,0x74:0X%X,0xB4:0X%X\n",
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x800 + 0x50),
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x800 + 0x54),
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x800 + 0x70),
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x800 + 0x74),
		cldma_read32(hw_info->cldma_ap_pdn_base + RIGHT_CLDMA_OFFSET, 0x800 + 0xB4));

	//host/device CLDMA1 Q7 TX/RX start address, current address,
	MTK_INFO_LIMITED_LOG(TAG, "host tx start addr:0X%X,0X%X, curr addr:0X%X,0X%X " \
		"dev rx start addr:0X%X,0X%X, curr addr:0X%X,0X%X\n",
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x3C),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x40),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x7C),
		cldma_read32(hw_info->cldma_ap_pdn_base, 0x80),
		cldma_read32(hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET, 0x400 + 0xB0),
		cldma_read32(hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET, 0x400 + 0xB4),
		cldma_read32(hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET, 0x400 + 0xF0),
		cldma_read32(hw_info->cldma_ap_ao_base + RIGHT_CLDMA_OFFSET, 0x400 + 0xF4));
}


static int cldma_irq_work_cb(void *data)
{
	int i, ret = 0;
	unsigned int L2TIMR0, L2RIMR0, L2TISAR0, L2RISAR0;
	unsigned int L3TISAR0, L3TISAR1;
	unsigned int L3RISAR0, L3RISAR1;
	struct cldma_hw_info *hw_info;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;

	md_ctrl = (struct md_cd_ctrl *)data;
	hw_ctrl = ccci_hw_ctrl_get_by_id(md_ctrl->md_id, md_ctrl->hif_id);
	hw_info = (struct cldma_hw_info *)hw_ctrl->private;
	md_ctrl->traffic_info.latest_isr_time = local_clock();


	/*L2 raw interrupt status */
	L2TISAR0 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TISAR0);
	L2RISAR0 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2RISAR0);
	L2TIMR0 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L2TIMR0);
	L2RIMR0 = cldma_read32(hw_info->cldma_ap_ao_base, REG_CLDMA_L2RIMR0);

	MTK_DEBUG_LOG(TAG, "CLDMA%d L2TISAR0:%X, L2RISAR0:%X, L2TIMR:%X, L2RIMR:%X\n",
			md_ctrl->hif_id, L2TISAR0, L2RISAR0, L2TIMR0, L2RIMR0);

	if (unlikely((L2TISAR0 | L2RISAR0) == 0)) {
		MTK_ERR_LOG(TAG, "Waring: CLDMA%d false interrupt\n", md_ctrl->hif_id);
		return ret;
	}

	L2TISAR0 &= (~L2TIMR0);
	L2RISAR0 &= (~L2RIMR0);
	// clear_ip_busy(hw_ctrl);
	if (L2TISAR0) {
#ifdef CLDMA_TRACE
		trace_cldma_irq(CCCI_TRACE_TX_IRQ,
			(L2TISAR0 & TXRX_STATUS_BITMASK));
#endif
#ifdef CCCI_CTL_TRACE
		trace_cldma_irq_work_cb("TX", (L2TISAR0 & TXRX_STATUS_BITMASK));
#endif /* CCCI_CTL_TRACE */
		if (md_ctrl->tx_busy_warn_cnt &&
			(L2TISAR0 & TXRX_STATUS_BITMASK))
			md_ctrl->tx_busy_warn_cnt = 0;
		if (L2TISAR0 & (TQ_ERR_INT_BITMASK | TQ_ACTIVE_START_ERR_INT_BITMASK)) {
			/*read and clear L3 TX interrupt status*/
			L3TISAR0 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR0);
			cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR0, L3TISAR0);
			L3TISAR1 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR1);
			cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3TISAR1, L3TISAR1);

			MTK_INFO_LIMITED_LOG(TAG, "CLDMA%d TX ERR, L2:0X%X, L3TISAR0:0X%X, L3TISAR1:0X%X\n",
					md_ctrl->hif_id, L2TISAR0, L3TISAR0, L3TISAR1);
			//cldma_debug_dump(md_ctrl);
			/* need dump more CLDMA registers for debugging if TX ERR received. */
			md_cldma_dump_status(md_ctrl->md_id, md_ctrl->hif_id, DUMP_FLAG_HIF, NULL, 0);
		}
		cldma_hw_tx_done(hw_ctrl, L2TISAR0);


		if (likely(L2TISAR0 & (TXRX_STATUS_BITMASK | EMPTY_STATUS_BITMASK))) {
			for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
				if (L2TISAR0 & TXRX_STATUS_BITMASK & (1 << i)) {
					mtk_pm_runtime_get(hw_ctrl->mtk_dev);
					/* disable TX_DONE interrupt */
					cldma_hw_mask_eqirq(hw_ctrl, i, 0);
					cldma_hw_mask_txrxirq(hw_ctrl, i, 0);
					ret = queue_delayed_work(md_ctrl->txq[i].worker,
							&md_ctrl->txq[i].cldma_tx_work,
							msecs_to_jiffies(0));
				}
				if (L2TISAR0 & (EMPTY_STATUS_BITMASK &
					(((1 << i) << EQ_STA_BIT_OFFSET)))) {
					cldma_tx_queue_empty_handler(&md_ctrl->txq[i]);
				}
			}
		}
	}

	if (L2RISAR0) {
#ifdef CLDMA_TRACE
		trace_cldma_irq(CCCI_TRACE_RX_IRQ,
			(L2RISAR0 & TXRX_STATUS_BITMASK));
#endif
#ifdef CCCI_CTL_TRACE
		trace_cldma_irq_work_cb("RX", (L2RISAR0 & TXRX_STATUS_BITMASK));
#endif /* CCCI_CTL_TRACE */
		/* clear IP busy register wake up cpu case */
		if (L2RISAR0 & (RQ_ERR_INT_BITMASK | RQ_ACTIVE_START_ERR_INT_BITMASK)) {
			/*read and clear L3 RX interrupt status*/
			L3RISAR0 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR0);
			cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR0, L3RISAR0);
			L3RISAR1 = cldma_read32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR1);
			cldma_write32(hw_info->cldma_ap_pdn_base, REG_CLDMA_L3RISAR1, L3RISAR1);
			MTK_INFO_LIMITED_LOG(TAG, "CLDMA%d RX ERR,L2:0X%X, L3RISAR0:0X%X, L3RISAR1:0X%X\n",
				md_ctrl->hif_id, L2RISAR0, L3RISAR0, L3RISAR1);
			cldma_debug_dump(md_ctrl);
		}
		cldma_hw_rx_done(hw_ctrl, L2RISAR0);
		if (likely(L2RISAR0 & (TXRX_STATUS_BITMASK | EMPTY_STATUS_BITMASK))) {
			for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
				if ((L2RISAR0 & (1 << i)) || (L2RISAR0 &
					((1 << i) << EQ_STA_BIT_OFFSET))) {
					md_ctrl->traffic_info.latest_q_rx_isr_time[i] =
						local_clock();
					mtk_pm_runtime_get(hw_ctrl->mtk_dev);
					/* disable RX_DONE and QUEUE_EMPTY interrupt */
					cldma_hw_mask_eqirq(hw_ctrl, i, 1);
					cldma_hw_mask_txrxirq(hw_ctrl, i, 1);
					/*always start work due to no napi*/
					cldma_rx_worker_start(md_ctrl, i);
				}
			}
		}
	}
	return ret;
}

void md_cldma_stop_datatf(unsigned char md_id, unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	unsigned long flags;

	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (md_ctrl && hw_ctrl) {
		/* stop all Tx and Rx queues */
		md_ctrl->txq_active &= (~TXRX_STATUS_BITMASK);
		md_ctrl->rxq_active &= (~TXRX_STATUS_BITMASK);
		cldma_hw_stop_queue(hw_ctrl, 0xFF, 0);
		cldma_hw_stop_queue(hw_ctrl, 0xFF, 1);
		/*disable all interrupt*/
		cldma_hw_stop(hw_ctrl, 0);
		cldma_hw_stop(hw_ctrl, 1);
		/* flush work */
		cldma_disable_irq(md_ctrl, hw_ctrl);
	}
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
}

static int md_cldma_stop(unsigned char md_id, unsigned char hif_id)
{
	int i;
	int cnt;
	unsigned int tx_active;
	unsigned int rx_active;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;

	md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	if (unlikely(!md_ctrl)) {
		MTK_ERR_LOG(TAG, "invalid input\n");
		return -EINVAL;
	}

	/*stop tx rx queue*/
	md_ctrl->rxq_active = 0;
	cldma_hw_stop_queue(hw_ctrl, 0xFF, 1);
	md_ctrl->txq_active = 0;
	cldma_hw_stop_queue(hw_ctrl, 0xFF, 0);
	md_ctrl->txq_started = 0;

	/*disable L1 and L2 interrupt*/
	cldma_disable_irq(md_ctrl, hw_ctrl);
	cldma_hw_stop(hw_ctrl, 1);
	cldma_hw_stop(hw_ctrl, 0);

	/*clear tx/rx/empty interrupt status*/
	cldma_hw_tx_done(hw_ctrl, 0xFFFF);
	cldma_hw_rx_done(hw_ctrl, 0xFFFF);

	if (md_ctrl->is_late_init) {
		for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++)
			flush_delayed_work(&md_ctrl->txq[i].cldma_tx_work);

		for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++)
			flush_work(&md_ctrl->rxq[i].cldma_rx_work);
	}

	cnt = 0;
	do {
		tx_active = cldma_hw_queue_isactive(hw_ctrl, 0xFF, 0);
		rx_active = cldma_hw_queue_isactive(hw_ctrl, 0xFF, 1);
		if ((tx_active || rx_active)
			&& (tx_active != 0xFFFFFFFF)
			&& (rx_active != 0xFFFFFFFF)) {
			msleep(10);
			cnt++;
		} else
			break;
	} while (cnt < 1000);

	if (tx_active || rx_active) {
		MTK_ERR_LOG(TAG, "Could not stop CLDMA%d queue,tx=0X%X,rx=0X%X\n",
					hw_ctrl->hif_id, tx_active, rx_active);

		return -EAGAIN;
	}

	return 0;
}

static int md_cldma_stop_for_ee(unsigned char md_id, unsigned char hif_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	unsigned long flags;
	int index = 0;

	MTK_INFO_LOG(TAG, "from %ps\n", __builtin_return_address(0));
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	/* stop all Tx and Rx queues, but non-stop Rx ones */
	md_ctrl->txq_active &= (~TXRX_STATUS_BITMASK);
	cldma_hw_stop_queue(hw_ctrl, 0xFF, 0);
	cldma_hw_mask_txrxirq(hw_ctrl, 0xFF, 0);
	cldma_hw_mask_eqirq(hw_ctrl, 0xFF, 0);
	md_ctrl->rxq_active &= (~(TXRX_STATUS_BITMASK & NONSTOP_QUEUE_MASK));
	for (index = 0; index < QUEUE_LEN(md_ctrl->rxq); index++) {
		if (!((1 << index) & NONSTOP_QUEUE_MASK)) {
			cldma_hw_stop_queue(hw_ctrl, index, 1);
			cldma_hw_mask_txrxirq(hw_ctrl, index, 1);
			cldma_hw_mask_eqirq(hw_ctrl, index, 1);
		}
	}
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);

	return 0;
}

static inline void ccci_cldma_late_uninit(struct md_cd_ctrl *md_ctrl)
{
	int i;
	
	unsigned long flags;
	if (md_ctrl == NULL)
		return;
	if (md_ctrl->is_late_init) {
		/*free all tx/rx cldma request/gdb/skb buff*/
		for (i = 0; i < NORMAL_TXQ_NUM; i++)
			cldma_ring_uninit(md_ctrl,
				&md_ctrl->normal_tx_ring[i], 0);

		for (i = 0; i < NORMAL_RXQ_NUM; i++)
			cldma_ring_uninit(md_ctrl,
				&md_ctrl->normal_rx_ring[i], 1);
		/*destroy dma pool*/
		dma_pool_destroy(md_ctrl->gpd_dmapool);
		md_ctrl->gpd_dmapool = NULL;		
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);	
		md_ctrl->is_late_init = 0;
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}

	MTK_DEBUG_LOG(TAG, "is_late_init = %d\n", md_ctrl->is_late_init);
}

static int md_cldma_hif_sw_reset(unsigned char md_id, unsigned char hif_id)
{
	int i;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;
	struct ccci_modem *md;
	unsigned long flags;

	md = (struct ccci_modem *)ccci_md_get_modem_by_id(md_id);
	md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	if (md_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "invalid input: md_ctrl is NULL\n");
		return -1;
	}
	
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags); 
	md_ctrl->md_id = md_id;
	md_ctrl->hif_id = hif_id;
	md_ctrl->txq_active = 0;
	md_ctrl->rxq_active = 0;
	md_ctrl->cfg_id = -1;
	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	cldma_disable_irq(md_ctrl, hw_ctrl);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	/*reset HIF queue structure*/
	for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
		md_ctrl->txq[i].modem = ccci_md_get_modem_by_id(md_id);
		cancel_delayed_work_sync(&(md_ctrl->txq[i].cldma_tx_work));
		
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);	
		md_cd_queue_struct_reset(&md_ctrl->txq[i],
					md_ctrl->hif_id, MTK_OUT, i);
		
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}

	for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
		md_ctrl->rxq[i].modem = ccci_md_get_modem_by_id(md_id);
		cancel_work_sync(&(md_ctrl->rxq[i].cldma_rx_work));
		
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);	
		md_cd_queue_struct_reset(&md_ctrl->rxq[i],
					md_ctrl->hif_id, MTK_IN, i);
		
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}
	ccci_cldma_late_uninit(md_ctrl);
	md_ctrl->tx_busy_warn_cnt = 0;

	/*initialize CLDMA hardware*/
	//cldma_hw_init(hw_ctrl);
	return 0;
}

static int md_cldma_reset(unsigned char md_id,
	unsigned char hif_id, unsigned char is_hw)
{
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	if (is_hw == 0)
		md_cldma_hif_sw_reset(md_id, hif_id);
	else if (is_hw == 1)
		cldma_hw_reset(hw_ctrl);

	return 0;
}

static int md_cldma_start(unsigned char md_id, unsigned char hif_id)
{
	int i;
	unsigned long flags;
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);	
	if (md_ctrl->is_late_init) {		
		cldma_enable_irq(md_ctrl, hw_ctrl);
		/* set start address */
		for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
			if (md_ctrl->txq[i].tr_done) {	
				cldma_hw_set_start_address(hw_ctrl, i, md_ctrl->txq[i].tr_done->gpd_addr, 0);
			}
		}

		for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
			if (md_ctrl->rxq[i].tr_done) {	
				cldma_hw_set_start_address(hw_ctrl,
					i, md_ctrl->rxq[i].tr_done->gpd_addr, 1);
			}
		}

		/* start all Rx queues and enable L2 interrupt */
		cldma_hw_start_queue(hw_ctrl, 0xFF, 1);
		cldma_hw_start(hw_ctrl);
		/* wait write done */
		wmb();
		md_ctrl->txq_started = 0;
		md_ctrl->txq_active |= TXRX_STATUS_BITMASK;
		md_ctrl->rxq_active |= TXRX_STATUS_BITMASK;
	}
	
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	return 0;
}

static int md_cldma_allQreset_work(unsigned char md_id, unsigned char hif_id)
{
	/* re-start CLDMA */

	md_cldma_reset(md_id, hif_id, 0);
	md_cldma_reset(md_id, hif_id, 1);
	md_cldma_start(md_id, hif_id);
	return 0;
}


/* only allowed when cldma is stopped */
static int md_cldma_clear_all_queue(unsigned char md_id,
	unsigned char hif_id, enum direction dir)
{
	int i;
	struct cldma_request *req = NULL;
	struct cldma_tgpd *tgpd;
	unsigned long flags;
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	if (dir == MTK_OUT) {
		for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
			spin_lock_irqsave(&md_ctrl->txq[i].ring_lock, flags);
			req = list_first_entry(
				&md_ctrl->txq[i].tr_ring->gpd_ring,
				struct cldma_request, entry);
			md_ctrl->txq[i].tr_done = req;
			md_ctrl->txq[i].tx_xmit = req;
			md_ctrl->txq[i].budget =
				md_ctrl->txq[i].tr_ring->length;
#if PACKET_HISTORY_DEPTH
			md_ctrl->traffic_info.tx_history_ptr[i] = 0;
#endif
			list_for_each_entry(req,
				&md_ctrl->txq[i].tr_ring->gpd_ring, entry) {
				tgpd = (struct cldma_tgpd *)req->gpd;
				cldma_write8(&tgpd->gpd_flags, 0,
					cldma_read8(&tgpd->gpd_flags, 0)
					& ~0x1);
				if (md_ctrl->txq[i].tr_ring->type !=
					RING_GPD_BD)
					cldma_tgpd_set_data_ptr(tgpd, 0);
				cldma_write16(&tgpd->data_buff_len, 0, 0);
				if (req->skb) {
					ccci_free_skb(req->skb);
					req->skb = NULL;
				}
			}
			spin_unlock_irqrestore(
				&md_ctrl->txq[i].ring_lock, flags);
		}
	} else if (dir == MTK_IN) {
		struct cldma_rgpd *rgpd;

		for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
			spin_lock_irqsave(&md_ctrl->rxq[i].ring_lock, flags);
			req = list_first_entry(
				&md_ctrl->rxq[i].tr_ring->gpd_ring,
				struct cldma_request, entry);
			md_ctrl->rxq[i].tr_done = req;
			md_ctrl->rxq[i].rx_refill = req;
#if PACKET_HISTORY_DEPTH
			md_ctrl->traffic_info.rx_history_ptr[i] = 0;
#endif
			list_for_each_entry(req,
				&md_ctrl->rxq[i].tr_ring->gpd_ring, entry) {
				rgpd = (struct cldma_rgpd *)req->gpd;
				cldma_write8(&rgpd->gpd_flags, 0, 0x81);
				cldma_write16(&rgpd->data_buff_len, 0, 0);
				if (req->skb != NULL) {
					req->skb->len = 0;
					skb_reset_tail_pointer(req->skb);
				}
			}
			spin_unlock_irqrestore(
				&md_ctrl->rxq[i].ring_lock, flags);
			list_for_each_entry(req,
				&md_ctrl->rxq[i].tr_ring->gpd_ring, entry) {
				rgpd = (struct cldma_rgpd *)req->gpd;
				if (req->skb == NULL) {
					struct md_cd_queue *queue = &md_ctrl->rxq[i];
					/*which queue*/
					MTK_INFO_LOG(TAG, "skb NULL in Rx queue %d/%u\n",
							i, queue->index);
					req->skb = ccci_alloc_skb(queue->tr_ring->pkt_size, 1, 1);
					req->data_buffer_ptr_saved =
						dma_map_single(hw_ctrl->dma_dev, req->skb->data,
								skb_data_size(req->skb), DMA_FROM_DEVICE);
					if (dma_mapping_error(hw_ctrl->dma_dev,
						req->data_buffer_ptr_saved)) {
						MTK_ERR_LOG(TAG, "err dma mapping\n");
						return 0;
					}
					cldma_rgpd_set_data_ptr(rgpd, req->data_buffer_ptr_saved);
				}
			}
		}
	}
	return 0;
}

static int md_cldma_stop_queue(unsigned char md_id,
	unsigned char hif_id, unsigned char qno, enum direction dir)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	unsigned long flags;

	if (dir == MTK_IN) {
		/* disable RX_DONE and QUEUE_EMPTY interrupt */
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
		cldma_hw_mask_eqirq(hw_ctrl, qno, 1);
		cldma_hw_mask_txrxirq(hw_ctrl, qno, 1);
		if (qno == 0xFF)
			md_ctrl->rxq_active &= ~TXRX_STATUS_BITMASK;
		else
			md_ctrl->rxq_active &=
				(~(TXRX_STATUS_BITMASK & (1 << qno)));

		cldma_hw_stop_queue(hw_ctrl, qno, 1);
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	} else if (dir == MTK_OUT) {
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
		cldma_hw_mask_eqirq(hw_ctrl, qno, 0);
		cldma_hw_mask_txrxirq(hw_ctrl, qno, 0);
		if (qno == 0xFF)
			md_ctrl->txq_active &= ~TXRX_STATUS_BITMASK;
		else
			md_ctrl->txq_active &=
				(~(TXRX_STATUS_BITMASK & (1 << qno)));

		cldma_hw_stop_queue(hw_ctrl, qno, 0);
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}
	return 0;
}

static int md_cldma_start_queue(unsigned char md_id,
	unsigned char hif_id, unsigned char qno, enum direction dir)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	struct cldma_request *req = NULL;
	struct cldma_rgpd *rgpd;
	unsigned long flags;
	enum MD_STATE md_state;

	if (dir == MTK_OUT && qno >= QUEUE_LEN(md_ctrl->txq))
		return -CCCI_ERR_INVALID_QUEUE_INDEX;
	if (dir == MTK_IN && qno >= QUEUE_LEN(md_ctrl->rxq))
		return -CCCI_ERR_INVALID_QUEUE_INDEX;

	if (dir == MTK_IN) {
		/* reset Rx ring buffer */
		req = list_first_entry(&md_ctrl->rxq[qno].tr_ring->gpd_ring,
			struct cldma_request, entry);
		md_ctrl->rxq[qno].tr_done = req;
		md_ctrl->rxq[qno].rx_refill = req;
#if PACKET_HISTORY_DEPTH
		md_ctrl->traffic_info.rx_history_ptr[qno] = 0;
#endif
		list_for_each_entry(req,
			&md_ctrl->txq[qno].tr_ring->gpd_ring, entry) {
			rgpd = (struct cldma_rgpd *)req->gpd;
			cldma_write8(&rgpd->gpd_flags, 0, 0x81);
			cldma_write16(&rgpd->data_buff_len, 0, 0);
			req->skb->len = 0;
			skb_reset_tail_pointer(req->skb);
		}
		/* enable queue and RX_DONE interrupt */
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
		md_state = ccci_fsm_get_md_state(md_ctrl->md_id);
		if (md_state != WAITING_TO_STOP &&
			md_state != STOPPED && md_state != INVALID) {
			cldma_hw_set_start_address(hw_ctrl, qno,
				md_ctrl->rxq[qno].tr_done->gpd_addr, 1);
			cldma_hw_start_queue(hw_ctrl, qno, 1);
			cldma_hw_dismask_eqirq(hw_ctrl, qno, 1);
			cldma_hw_dismask_txrxirq(hw_ctrl, qno, 1);
			md_ctrl->rxq_active |=
				(TXRX_STATUS_BITMASK & (1 << qno));
		}
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	}
	return 0;
}

static int md_cldma_give_more(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	unsigned long flags;

	if (qno >= QUEUE_LEN(md_ctrl->rxq))
		return -CCCI_ERR_INVALID_QUEUE_INDEX;
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (md_ctrl->rxq_active & (1 << md_ctrl->rxq[qno].index))
		cldma_rx_worker_start(md_ctrl, qno);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	return 0;
}

static int md_cldma_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (qno >= QUEUE_LEN(md_ctrl->txq))
		return -CCCI_ERR_INVALID_QUEUE_INDEX;
	return md_ctrl->txq[qno].budget;
}

/* only run this in thread context, as we use flush_work in it */
static int md_cldma_clear_hif(unsigned char md_id, unsigned char hif_id)
{
	return 0;
}

void poll_cldma_status(void)
{
	unsigned int L2TIMR0, L2RIMR0, L2TISAR0, L2RISAR0;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(0, 3);

	if (hw_ctrl != NULL) {
		L2TISAR0 =  cldma_hw_tx_done(hw_ctrl, EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK);
		L2RISAR0 =  cldma_hw_rx_done(hw_ctrl, EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK);
		L2TIMR0 = cldma_hw_eqirq_ismask(hw_ctrl,0)|cldma_hw_txrxirq_ismask(hw_ctrl,0);
		L2RIMR0 = cldma_hw_eqirq_ismask(hw_ctrl,1)|cldma_hw_txrxirq_ismask(hw_ctrl,1);
	}
}
/* this is called inside queue->ring_lock */
int cldma_gpd_handle_tx_request(struct md_cd_queue *queue,
	struct cldma_request *tx_req, struct sk_buff *skb,
	unsigned int ioc_override)
{
	unsigned long flags;
	struct cldma_tgpd *tgpd;
	struct md_cd_ctrl *md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(queue->modem->index, queue->hif_id);
	struct ccci_hw_ctrl *hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(queue->modem->index, queue->hif_id);
	tgpd = tx_req->gpd;
	/* override current IOC setting */
	if (ioc_override & 0x80) {
		/* backup current IOC setting */
		tx_req->ioc_override = 0x80 | (!!(tgpd->gpd_flags & 0x80));
		if (ioc_override & 0x1)
			tgpd->gpd_flags |= 0x80;
		else
			tgpd->gpd_flags &= 0x7F;
	}
	/* update GPD */
	tx_req->data_buffer_ptr_saved =
	    dma_map_single(hw_ctrl->dma_dev, skb->data, skb->len, DMA_TO_DEVICE);
	if (dma_mapping_error(hw_ctrl->dma_dev, tx_req->data_buffer_ptr_saved)) {
		MTK_ERR_LOG(TAG, "error dma mapping\n");
		return -1;
	}
	cldma_tgpd_set_data_ptr(tgpd, tx_req->data_buffer_ptr_saved);
	cldma_write16(&tgpd->data_buff_len, 0, skb->len);
	tgpd->non_used = 1;
	/*
	 * set HWO
	 * use cldma_timeout_lock to avoid race conditon with cldma_stop.
	 * this lock must cover TGPD setting, as even without a resume
	 * operation, CLDMA still can start sending next HWO=1 TGPD
	 * if last TGPD was just finished.
	 */
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (md_ctrl->txq_active & (1 << queue->index))
		cldma_write8(&tgpd->gpd_flags, 0,
		cldma_read8(&tgpd->gpd_flags, 0) | 0x1);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	/* mark cldma_request as available */
	tx_req->skb = skb;
	return 0;
}
static inline void cldma_hw_start_send(unsigned char md_id,
	unsigned char hif_id, u8 qno)
{
	struct cldma_request *req;
	struct ccci_hw_ctrl *hw_ctrl;
	struct md_cd_ctrl *md_ctrl;

	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	// check wheater the device was power off
	if (unlikely(cldma_hw_pd_check(hw_ctrl, qno) != 0)) {
		MTK_INFO_LOG(TAG, "device cldma was powered down\n");
		cldma_hw_init(hw_ctrl);
		req = cldma_ring_step_backward(md_ctrl->txq[qno].tr_ring,
							md_ctrl->txq[qno].tx_xmit);
		cldma_hw_set_start_address(hw_ctrl, qno,
								req ->gpd_addr, 0);
		md_ctrl->txq_started &= ~(1<<qno);
	}

	/*resume or start queue*/
	if (!cldma_hw_queue_isactive(hw_ctrl, qno, 0)) {
		MTK_DEBUG_LOG(TAG, "CLDMA%d Q%d start_status:0x%X",
					hif_id, qno, md_ctrl->txq_started);
		if (md_ctrl->txq_started & (1 << qno))
			cldma_hw_resume_queue(hw_ctrl, qno, 0);
		else
			cldma_hw_start_queue(hw_ctrl, qno, 0);
		md_ctrl->txq_started |= 1 << qno;
	}
}

int ccci_cldma_write_room(unsigned char md_id, \
			unsigned char hif_id, unsigned char qno)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct md_cd_queue *queue = NULL;

	if (!md_ctrl)
		return -1;
	queue = &md_ctrl->txq[qno];
	if (!queue)
		return -1;
	MTK_DEBUG_LIMITED_LOG(TAG, "write_room(%d): budget=%d\n",da_down_stage_flag, queue->budget);
	if (likely(!da_down_stage_flag))
		return queue->budget; 
	else {
		if (queue->budget > (MAX_TX_BUDGET-1))
			return 1;
		else
			return 0;
	}
}

static int md_cldma_send_skb(unsigned char md_id, unsigned char hif_id,
	int qno, struct sk_buff *skb, int skb_from_pool, int blocking)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	struct md_cd_queue *queue;
	struct cldma_request *tx_req;
	int ret = 0;
	unsigned int ioc_override = 0;
	unsigned long flags;
	unsigned int tx_bytes = 0;
	struct ccci_buffer_ctrl *buf_ctrl = NULL;
#ifdef CLDMA_TRACE
	static unsigned long long last_leave_time[CLDMA_TXQ_NUM] = { 0 };
	static unsigned int sample_time[CLDMA_TXQ_NUM] = { 0 };
	static unsigned int sample_bytes[CLDMA_TXQ_NUM] = { 0 };
	unsigned long long total_time = 0;
	unsigned int tx_interal;

	total_time = sched_clock();
	if (last_leave_time[qno] == 0)
		tx_interal = 0;
	else
		tx_interal = total_time - last_leave_time[qno];
#endif
	mtk_pm_runtime_get_sync(hw_ctrl->mtk_dev);
	mtk_pci_l_resource_lock(hw_ctrl->mtk_dev, L_RES_USER_CTRL);
	if (qno >= QUEUE_LEN(md_ctrl->txq)) {
		ret = -CCCI_ERR_INVALID_QUEUE_INDEX;
		goto __EXIT_FUN;
	}
	ioc_override = 0x0;
	if (skb_from_pool && skb_headroom(skb) == NET_SKB_PAD) {
		buf_ctrl = (struct ccci_buffer_ctrl *)skb_push(skb,
			sizeof(struct ccci_buffer_ctrl));
		if (likely(buf_ctrl->head_magic == CCCI_BUF_MAGIC))
			ioc_override = buf_ctrl->ioc_override;
		skb_pull(skb, sizeof(struct ccci_buffer_ctrl));
	} else
		MTK_DEBUG_LOG(TAG,
			"send request: skb %p use default value!\n", skb);

	queue = &md_ctrl->txq[qno];
	tx_bytes = skb->len;

	//check if queue is active
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	if (!(md_ctrl->txq_active & (1 << qno))) {
		MTK_DEBUG_LOG(TAG,"Queue %d is inactive, skb fail to send\n", qno);
		ret = -EBUSY;
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
		goto __EXIT_FUN;
	}
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);

 retry:
	spin_lock_irqsave(&queue->ring_lock, flags);
	tx_req = queue->tx_xmit;
	if (queue->budget > 0 && tx_req->skb == NULL) {
		queue->budget--;
		queue->tr_ring->handle_tx_request(queue,
			tx_req, skb, ioc_override);
		/* step forward */
		queue->tx_xmit =
			cldma_ring_step_forward(queue->tr_ring, tx_req);
		spin_unlock_irqrestore(&queue->ring_lock, flags);

		MTK_DEBUG_LOG(TAG,
			"txq:%d, skb:0x%p/0x%llx (0x%x, 0x%x, 0x%x, 0x%x)\n",
			qno, skb, tx_req->data_buffer_ptr_saved,
			*(unsigned int *)(skb->data),
			*(unsigned int *)(skb->data+4),
			*(unsigned int *)(skb->data+8),
			*(unsigned int *)(skb->data+12));
		MTK_DEBUG_LOG(TAG,
			"tx_xmit:0x%llx, tr_done:0x%llx, budget:%d\n",
			queue->tx_xmit->gpd_addr,
			queue->tr_done->gpd_addr, queue->budget);
		mtk_pci_l_resource_wait_complete(
			hw_ctrl->mtk_dev, L_RES_USER_CTRL);
		spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
		md_ctrl->tx_busy_warn_cnt = 0;
#ifdef ENABLE_CCCI_DRI_UT
		cldma_ut_lp_func(queue);
#else
		cldma_hw_start_send(md_id, hif_id, qno);
#endif
		spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	} else {
		spin_unlock_irqrestore(&queue->ring_lock, flags);
		mtk_pci_l_resource_wait_complete(
			hw_ctrl->mtk_dev, L_RES_USER_CTRL);
		MTK_INFO_LIMITED_LOG(TAG,
			"txbusy: budget=%d, skb=%p, tx_xmit=0x%p\n",
			queue->budget, tx_req->skb, queue->tx_xmit);

		if (likely(ccci_md_get_cap_by_id(md_ctrl->md_id) &
			MODEM_CAP_TXBUSY_STOP))
			cldma_queue_broadcast_state(md_ctrl,
			TX_FULL, MTK_OUT, queue->index);
		/* check CLDMA status */
		if (cldma_hw_queue_isactive(hw_ctrl, qno, 0)) {
			MTK_DEBUG_LOG(TAG, "qno=%d free slot 0\n", qno);
			queue->busy_count++;
			md_ctrl->tx_busy_warn_cnt = 0;
		} else {
			if (cldma_hw_queue_ismask(hw_ctrl, qno, 0))
				MTK_DEBUG_LOG(TAG,
					"qno=%d free slot 0\n", qno);
			if (++md_ctrl->tx_busy_warn_cnt == 1000) {
				MTK_NOTICE_LOG(TAG,
					"tx busy: dump CLDMA and GPD status\n");
				md_ctrl->ops->dump_status(md_ctrl->md_id,
					hif_id, DUMP_FLAG_HIF,
					NULL, qno);
			}
			/* resume channel */
			spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
			cldma_hw_resume_queue(hw_ctrl, qno, 0);
			spin_unlock_irqrestore(
				&md_ctrl->cldma_timeout_lock, flags);
		}

#if defined(CLDMA_NO_TX_IRQ)
		queue->tr_ring->handle_tx_done(queue, 0, 0);
#endif
		if (blocking) {
			ret = wait_event_interruptible_exclusive(
				queue->req_wq, (queue->budget > 0));
			if (ret == -ERESTARTSYS) {
				ret = -EINTR;
				goto __EXIT_FUN;
			}
#ifdef CLDMA_TRACE
			trace_cldma_error(qno, ret, __LINE__);
#endif
			goto retry;
		} else {
			ret = -EBUSY;
			goto __EXIT_FUN;
		}
	}

 __EXIT_FUN:
#ifdef CCCI_CTL_TRACE
	trace_md_cldma_send_skb(queue->tx_xmit->gpd, queue->budget);
#endif /* CCCI_CTL_TRACE */
#ifdef CLDMA_TRACE
	if (unlikely(ret)) {
		MTK_DEBUG_LOG(TAG, "txq_active=%d, qno=%d is 0,ret=%d\n",
				 md_ctrl->txq_active, qno, ret);
		trace_cldma_error(qno, ret, __LINE__);
	} else {
		last_leave_time[qno] = sched_clock();
		total_time = last_leave_time[qno] - total_time;
		sample_time[queue->index] += (total_time + tx_interal);
		sample_bytes[queue->index] += tx_bytes;
		trace_cldma_tx(qno, md_ctrl->txq[qno].budget,
			tx_interal, total_time, tx_bytes, 0, 0);
		if (sample_time[queue->index] >= trace_sample_time) {
			trace_cldma_tx(qno, 0, 0, 0, 0,
				sample_time[queue->index],
				sample_bytes[queue->index]);
			sample_time[queue->index] = 0;
			sample_bytes[queue->index] = 0;
		}
	}
#endif
	mtk_pci_l_resource_unlock(hw_ctrl->mtk_dev, L_RES_USER_CTRL);
	mtk_pm_runtime_put_sync(hw_ctrl->mtk_dev);
	return ret;
}

static inline void ccci_cldma_adjust_config(unsigned char md_id,
	unsigned char cfg_id)
{
	int qno = 0;

	if (cfg_id > HIF_CFG_MAX) {
		MTK_ERR_LOG(TAG, "invalid input\n");
		return;
	}
	/*set back to default set, Because RXQ NUM= TXQ NUM*/
	for (qno = 0; qno < CLDMA_RXQ_NUM; qno++) {
		normal_rx_queue_buffer_size[qno] = SKB_4K;
		normal_tx_queue_buffer_size[qno] = SKB_4K;
		normal_rx_queue_type[qno] = SHARED_Q;
		normal_tx_queue_type[qno] = SHARED_Q;
	}

	switch (cfg_id) {
	case HIF_CFG_DEF:
		break;
	case HIF_CFG1:
		normal_rx_queue_buffer_size[7] = SKB_64K;
		break;
	case HIF_CFG2:
		/*Download Port Configuration*/
		normal_rx_queue_type[0] = DEDICATED_Q;
		normal_tx_queue_type[0] = DEDICATED_Q;
		normal_rx_queue_buffer_size[0] = SKB_2K;
		normal_tx_queue_buffer_size[0] = SKB_2K;
		/*Postdump Port Configuration*/
		normal_rx_queue_type[1] = DEDICATED_Q;
		normal_tx_queue_type[1] = DEDICATED_Q;
		normal_rx_queue_buffer_size[1] = SKB_2K;
		normal_tx_queue_buffer_size[1] = SKB_2K;
		break;
	default:
		break;
	}
}
/* we put initializations which takes too much time here */
int ccci_cldma_late_init(unsigned char md_id, unsigned char hif_id)
{
	int i;
	unsigned long flags;
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	char dma_pool_name[32];
	if (md_ctrl->is_late_init == 1) {
		MTK_ERR_LOG(TAG, "cldma late init has been done\n");
		return -1;
	}
	atomic_set(&md_ctrl->wakeup_src, 0);
	hif_traffic_init(&md_ctrl->traffic_info);
	mutex_lock(&ctl_cfg_mutex);
	ccci_cldma_adjust_config(md_id, md_ctrl->cfg_id);
	/* init ring buffers */
	sprintf(dma_pool_name, "cldma_requeset_DMA_hif%u", hif_id);
	md_ctrl->gpd_dmapool = dma_pool_create(dma_pool_name,
		hw_ctrl->dma_dev, sizeof(struct cldma_tgpd), 16, 0);
	if (md_ctrl->gpd_dmapool == NULL) {
		MTK_ERR_LOG(TAG, "dmapool alloc fail\n");
		return -1;
	};
	for (i = 0; i < NORMAL_TXQ_NUM; i++) {
		INIT_LIST_HEAD(&md_ctrl->normal_tx_ring[i].gpd_ring);
		md_ctrl->normal_tx_ring[i].length =
			normal_tx_queue_buffer_number[normal_tx_ring2queue[i]];
		md_ctrl->normal_tx_ring[i].type = RING_GPD;
		md_ctrl->normal_tx_ring[i].handle_tx_request =
			&cldma_gpd_handle_tx_request;
		md_ctrl->normal_tx_ring[i].handle_tx_done =
			&cldma_gpd_tx_collect;
		cldma_tx_ring_init(md_ctrl, &md_ctrl->normal_tx_ring[i]);
	}
	for (i = 0; i < NORMAL_RXQ_NUM; i++) {
		INIT_LIST_HEAD(&md_ctrl->normal_rx_ring[i].gpd_ring);
		md_ctrl->normal_rx_ring[i].length =
			normal_rx_queue_buffer_number[normal_rx_ring2queue[i]];
		md_ctrl->normal_rx_ring[i].pkt_size =
			normal_rx_queue_buffer_size[normal_rx_ring2queue[i]];
		md_ctrl->normal_rx_ring[i].type = RING_GPD;
		md_ctrl->normal_rx_ring[i].handle_rx_done =
			&cldma_gpd_rx_collect;
		cldma_rx_ring_init(md_ctrl, &md_ctrl->normal_rx_ring[i]);
	}
	/* init queue */
	for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++)
		cldma_tx_queue_init(&md_ctrl->txq[i]);

	for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++)
		cldma_rx_queue_init(&md_ctrl->rxq[i]);
	mutex_unlock(&ctl_cfg_mutex);
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	md_ctrl->is_late_init = 1;	
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	MTK_INFO_LOG(TAG, "md_ctl %p is_late_init = %d\n",md_ctrl, md_ctrl->is_late_init);
	return 0;
}

void *ccci_cldma_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *mtk_dev)
{
	struct cldma_hw_info *hw_info = NULL;
	struct md_cd_ctrl *md_ctrl = NULL;
	struct ccci_hw_ctrl *hw_ctrl = NULL;


	md_ctrl = kzalloc(sizeof(struct md_cd_ctrl), GFP_KERNEL);
	ccci_hif[md_id][hif_id] = (void *)md_ctrl;

	hw_ctrl = kzalloc(sizeof(struct ccci_hw_ctrl), GFP_KERNEL);
	ccci_hw_ctrl_info[md_id][hif_id] = hw_ctrl;

	if (NULL != hw_ctrl && NULL != md_ctrl) {
		hw_ctrl->hif_id = hif_id;
		hw_ctrl->mtk_dev = mtk_dev;
		spin_lock_init(&hw_ctrl->spinlock);
		hw_info = cldma_driver_init(hw_ctrl);
		md_ctrl->hif_hw_info = (void *)hw_info;
	} else {
		MTK_ERR_LOG(TAG, "Malloc Fail, hif_id:%d\n", hif_id);
		return NULL;
	}
	if (hw_info != NULL)
		ccci_cldma_get_dev_info(hw_ctrl);

	return hw_info;
}

static int md_cldma_dump_status(unsigned char md_id, unsigned char hif_id,
	enum modem_dump_flag flag, void *data, int length)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	MTK_DEBUG_LOG(TAG, "is_late_init is set to %d\n",
		md_ctrl->is_late_init);
	if (md_ctrl->is_late_init && (flag & DUMP_FLAG_HIF)) {
		mtk_pci_l_resource_lock(hw_ctrl->mtk_dev, L_RES_USER_CTRL);
		mtk_pci_l_resource_wait_complete(hw_ctrl->mtk_dev, L_RES_USER_CTRL);
		cldma_hw_dump(hw_ctrl);
		mtk_pci_l_resource_unlock(hw_ctrl->mtk_dev, L_RES_USER_CTRL);
		if (length == -1) {
			cldma_dump_packet_history(md_ctrl);
			cldma_dump_all_gpd(md_ctrl);
		}
		if (length >= 0 && length < CLDMA_TXQ_NUM) {
			cldma_dump_queue_history(md_ctrl, length);
			cldma_dump_gpd_queue(md_ctrl, length);
		}
	}
	return 0;
}

int ccci_cldma_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	struct ccci_hw_ctrl *hw_ctrl = 
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	switch (stage) {
	case HIF_EX_INIT:
		/*dump cldma flag*/
		md_cldma_dump_status(md_id, hif_id,
			DUMP_FLAG_HIF, NULL, 0);
		/*disable CLDMA Tx queues*/
		md_cldma_stop_queue(md_id, hif_id, 0xFF, MTK_OUT);
		/*Clear Tx queue*/
		md_cldma_clear_all_queue(md_id, hif_id, MTK_OUT);
		break;
	case HIF_EX_ACK:
		break;
	case HIF_EX_INIT_DONE:
		break;
	case HIF_EX_CLEARQ_DONE:
		/* stop CLDMA, we don't want to get CLDMA IRQ when MD is
		 * resetting CLDMA after it got cleaq_ack
		 */
		md_cldma_stop_queue(md_id, hif_id, 0xFF, MTK_IN);
		/* flush all (TX&RX) workqueue */
		md_cldma_stop(md_id, hif_id);
		md_cldma_reset(md_id, hif_id, 1);
		/*clear the RX queue*/
		md_cldma_clear_all_queue(md_id, hif_id, MTK_IN);
		MTK_NOTICE_LOG(TAG, "send clearq_ack to MD\n");
		break;
	case HIF_EX_CLEARQ_ACK:
		break;
	case HIF_EX_ALLQ_RESET:
		cldma_hw_init(hw_ctrl);
		md_cldma_start(md_id, hif_id);
		break;
	}
	return 0;
}


static struct ccci_hif_ops ccci_hif_cldma_ops = {
	.send_skb = &md_cldma_send_skb,
	.give_more = &md_cldma_give_more,
	.write_room = &md_cldma_write_room,
	.stop_queue = &md_cldma_stop_queue,
	.start_queue = &md_cldma_start_queue,
	.dump_status = &md_cldma_dump_status,
	.hif_start = &md_cldma_start,
	.hif_stop = &md_cldma_stop,
	.hif_stop_for_ee = &md_cldma_stop_for_ee,
	.hif_clear = &md_cldma_clear_hif,
	.hif_reset = &md_cldma_reset,
	.hif_clear_all_queue = &md_cldma_clear_all_queue,
	.hif_allQreset_work = &md_cldma_allQreset_work,
};


int cldma_resume_early(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	int ret = 0, qno_t = 0;
	struct md_cd_ctrl *md_ctrl = (struct md_cd_ctrl *)entity_param;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	unsigned long flags;

	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	cldma_hw_reg_restore(hw_ctrl);
	for (qno_t = 0; qno_t < CLDMA_TXQ_NUM; qno_t++) {
		cldma_hw_set_start_address(hw_ctrl,
			qno_t, md_ctrl->txq[qno_t].tx_xmit->gpd_addr, 0);
		cldma_hw_set_start_address(hw_ctrl,
			qno_t, md_ctrl->rxq[qno_t].tr_done->gpd_addr, 1);
	}
	cldma_enable_irq(md_ctrl, hw_ctrl);
	cldma_hw_start_queue(hw_ctrl, 0xFF, 1);
	md_ctrl->rxq_active |= TXRX_STATUS_BITMASK;
	cldma_hw_dismask_eqirq(hw_ctrl, 0xFF, 1);
	cldma_hw_dismask_txrxirq(hw_ctrl, 0xFF, 1);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	MTK_INFO_LOG(TAG, "cldma hif id: %d, isactive: %x\n",
		hw_ctrl->hif_id, cldma_hw_queue_isactive(hw_ctrl, 0xFF, 1));
	return ret;
}



int cldma_resume(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	int ret = 0;
	struct md_cd_ctrl *md_ctrl = (struct md_cd_ctrl *)entity_param;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	unsigned long flags;

	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
//	if (!md_ctrl->txq_started) {
//		cldma_hw_start_queue(hw_ctrl, 0xFF, 0);
//		md_ctrl->txq_started = 1;
//	} else {
//		cldma_hw_resume_queue(hw_ctrl, 0xFF, 0);
//	}
	md_ctrl->txq_active |= TXRX_STATUS_BITMASK;
	cldma_hw_dismask_txrxirq(hw_ctrl, 0xFF, 0);
	cldma_hw_dismask_eqirq(hw_ctrl, 0xFF, 0);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
        if (hw_ctrl->hif_id == HIF_ID_CLDMA_PCIE)
            mhccif_mask_clr(mtk_dev, (1<<MHCCIF_D2H_INT_except_init)|
                (1<<MHCCIF_D2H_INT_except_init_done)|
                (1<<MHCCIF_D2H_INT_except_clearQ_done)|
                (1<<MHCCIF_D2H_INT_except_allQ_reset)|
                (1<<MHCCIF_BOOT_FLOW_SYNC)|
                (1<<MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_SAP)|
                (1<<MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_MD)
            );

	MTK_INFO_LOG(TAG, "cldma hif id: %d, isactive: %x\n",
		hw_ctrl->hif_id, cldma_hw_queue_isactive(hw_ctrl, 0xFF, 0));
	return ret;
}


int cldma_suspend_late(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	int ret = 0;
	struct md_cd_ctrl *md_ctrl = (struct md_cd_ctrl *)entity_param;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	unsigned long flags;

	MTK_NOTICE_LOG(TAG, "cldma hif id: %d, isactive: %x\n",
		hw_ctrl->hif_id, cldma_hw_queue_isactive(hw_ctrl, 0xFF, 1));
	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	cldma_hw_mask_eqirq(hw_ctrl, 0xFF, 1);
	cldma_hw_mask_txrxirq(hw_ctrl, 0xFF, 1);
	md_ctrl->rxq_active &= ~TXRX_STATUS_BITMASK;
	cldma_hw_stop_queue(hw_ctrl, 0xFF, 1);
	cldma_hw_reg_backup(hw_ctrl);
	clear_ip_busy(hw_ctrl);
	cldma_disable_irq(md_ctrl, hw_ctrl);
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	return ret;
}

int cldma_suspend(struct mtk_pci_dev *mtk_dev, void *entity_param)
{
	int ret = 0;
	struct md_cd_ctrl *md_ctrl = (struct md_cd_ctrl *)entity_param;
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	unsigned long flags;

	MTK_NOTICE_LOG(TAG, "cldma hif id: %d, isactive: %x\n",
		hw_ctrl->hif_id, cldma_hw_queue_isactive(hw_ctrl, 0xFF, 0));

        if (hw_ctrl->hif_id == HIF_ID_CLDMA_PCIE)
            mhccif_mask_set(mtk_dev, (1<<MHCCIF_D2H_INT_except_init)|
                (1<<MHCCIF_D2H_INT_except_init_done)|
                (1<<MHCCIF_D2H_INT_except_clearQ_done)|
                (1<<MHCCIF_D2H_INT_except_allQ_reset)|
                (1<<MHCCIF_BOOT_FLOW_SYNC)|
                (1<<MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_SAP)|
                (1<<MHCCIF_D2H_INT_ASYNC_HS_NOTIFY_MD)
            );

	spin_lock_irqsave(&md_ctrl->cldma_timeout_lock, flags);
	cldma_hw_mask_eqirq(hw_ctrl, 0xFF, 0);
	cldma_hw_mask_txrxirq(hw_ctrl, 0xFF, 0);
	md_ctrl->txq_active &= ~TXRX_STATUS_BITMASK;
	cldma_hw_stop_queue(hw_ctrl, 0xFF, 0);
	md_ctrl->txq_started = 0;
	spin_unlock_irqrestore(&md_ctrl->cldma_timeout_lock, flags);
	return ret;
}



int cldma_pm_init(struct md_cd_ctrl *md_ctrl)
{
	int ret = 0;

	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	md_ctrl->pm_entity = (struct md_pm_entity *)
		kzalloc(sizeof(struct md_pm_entity), GFP_KERNEL);
	if (md_ctrl->pm_entity != NULL) {
		md_ctrl->pm_entity->entity_param = (void *)(md_ctrl);
		if (hw_ctrl->hif_id == HIF_ID_CLDMA0_PCIE) {
			md_ctrl->pm_entity->key = PM_ENTITY_KEY_CTRL2;
		} else if (hw_ctrl->hif_id == HIF_ID_CLDMA_PCIE) {
			md_ctrl->pm_entity->key = PM_ENTITY_KEY_CTRL;
		}
		md_ctrl->pm_entity->suspend = cldma_suspend;
		md_ctrl->pm_entity->suspend_late = cldma_suspend_late;
		md_ctrl->pm_entity->resume = cldma_resume;
		md_ctrl->pm_entity->resume_early = cldma_resume_early;
		ret = mtk_pci_pm_entity_register(
			hw_ctrl->mtk_dev, md_ctrl->pm_entity);
	} else {
		MTK_ERR_LOG(TAG,
			"failed to alloc memory for cldma pm entity\n");
		ret = -1;
	}
	return ret;
}

int ccci_cldma_hif_hw_init(unsigned char md_id, unsigned char hif_id)
{

	struct ccci_hw_ctrl *hw_ctrl;

	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);

	/*mask cldma interrupt*/
	cldma_hw_stop(hw_ctrl, 0);
	cldma_hw_stop(hw_ctrl, 1);

	/*clear cldma interrupt*/
	cldma_hw_rx_done(hw_ctrl, EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK);
	cldma_hw_tx_done(hw_ctrl, EMPTY_STATUS_BITMASK|TXRX_STATUS_BITMASK);

	/*initialize CLDMA hardware*/
	cldma_hw_init(hw_ctrl);

	return 0;
}


int ccci_cldma_hif_init(unsigned char md_id, unsigned char hif_id)
{
	int i;
	struct md_cd_ctrl *md_ctrl;
	struct ccci_hw_ctrl *hw_ctrl;
	struct ccci_modem *md;

	md = (struct ccci_modem *)ccci_md_get_modem_by_id(md_id);
	/*CLDMA HIF SW initialization*/
	md_ctrl = (struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	if (md_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "invalid input: md_ctrl is NULL\n");
		return -1;
	}
	md_ctrl->md_id = md_id;
	md_ctrl->hif_id = hif_id;
	md_ctrl->ops = &ccci_hif_cldma_ops;
	md_ctrl->txq_active = 0;
	md_ctrl->rxq_active = 0;
	md_ctrl->is_late_init = 0;
	md_ctrl->cfg_id = -1;
	md_ctrl->tx_busy_warn_cnt = 0;
	hw_ctrl = (struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(md_id, hif_id);
	cldma_pm_init(md_ctrl);
	spin_lock_init(&md_ctrl->cldma_timeout_lock);
	/*initialize HIF queue structure*/
	for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
		md_cd_queue_struct_init(&md_ctrl->txq[i],
			md_ctrl->hif_id, MTK_OUT, i);
		md_ctrl->txq[i].modem = ccci_md_get_modem_by_id(md_id);
		md_ctrl->txq[i].worker =
			alloc_workqueue("md%d_hif%d_tx%d_worker",
			WQ_UNBOUND | WQ_MEM_RECLAIM | (i == 0 ? WQ_HIGHPRI : 0),
			1, md_ctrl->md_id + 1, hif_id, i);
		INIT_DELAYED_WORK(&(md_ctrl->txq[i].cldma_tx_work),
			cldma_tx_done);
#ifdef ENABLE_CCCI_DRI_UT
		md_ctrl->txq[i].lp_worker =
			alloc_workqueue("md%d_hif%d_tx%d_worker",
			WQ_UNBOUND | WQ_MEM_RECLAIM,
			1, md_ctrl->md_id + 1, hif_id, i);
		INIT_WORK(&(md_ctrl->txq[i].lp_qwork), cldma_ut_lp_work);

#endif//ENABLE_CCCI_DRI_UT

	}
	for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
		md_cd_queue_struct_init(&md_ctrl->rxq[i],
			md_ctrl->hif_id, MTK_IN, i);
		md_ctrl->rxq[i].modem = ccci_md_get_modem_by_id(md_id);
		INIT_WORK(&(md_ctrl->rxq[i].cldma_rx_work), cldma_rx_done);
		md_ctrl->rxq[i].worker = alloc_workqueue(
			"md%d_hif%d_rx%d_worker",
			WQ_UNBOUND | WQ_MEM_RECLAIM, 1,
			md_ctrl->md_id + 1, hif_id, i);
	}
	/*initialize virtual runtime data sram layout*/
	md_ctrl->cldma_sram_layout =
		kzalloc(sizeof(struct cldma_sram_layout),
		GFP_KERNEL);

	if (md->mem_layout.ccci_rt_smem_base == NULL) {
		md->mem_layout.ccci_rt_smem_size = CCCI_SMEM_SIZE_RUNTIME_AP;
		md->mem_layout.ccci_rt_smem_base =
			kzalloc(md->mem_layout.ccci_rt_smem_size, GFP_KERNEL);
	}

	if (md->mem_layout.ccci_rt_smem_base == NULL) {
		MTK_ERR_LOG(TAG, "failed to kmalloc runtime data, size=%d\n",
			md->mem_layout.ccci_rt_smem_size);
		return -1;
	}

	hw_ctrl->irqops.disable_irq(hw_ctrl);
	atomic_set(&md_ctrl->cldma_irq_enabled, 0);

	/* registers CLDMA callback isr with PCIE driver */
	hw_ctrl->irqops.register_isr(hw_ctrl,
		cldma_irq_work_cb, (void *)md_ctrl);

	md_ctrl->tx_busy_warn_cnt = 0;
	/*initialize CLDMA hardware*/
	//cldma_hw_init(hw_ctrl);
	return 0;
}

void switch_cldma_cfg(unsigned char md_id,
	unsigned char hif_id, unsigned char cfg_id)
{
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl != NULL) {
		if (md_ctrl->cfg_id != cfg_id) {
			md_ctrl->cfg_id = cfg_id;
			ccci_cldma_late_uninit(md_ctrl);
			ccci_cldma_late_init(md_id, hif_id);
		}
	}
}

int cldma_pm_uninit(struct md_cd_ctrl *md_ctrl)
{
	int ret = 0;

	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)ccci_hw_ctrl_get_by_id(
		md_ctrl->md_id, md_ctrl->hif_id);
	if (md_ctrl->pm_entity != NULL) {
		ret = mtk_pci_pm_entity_unregister(hw_ctrl->mtk_dev,
			md_ctrl->pm_entity);
		md_ctrl->pm_entity->entity_param = NULL;
		md_ctrl->pm_entity->suspend = NULL;
		md_ctrl->pm_entity->suspend_late = NULL;
		md_ctrl->pm_entity->resume = NULL;
		md_ctrl->pm_entity->resume_early = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(md_ctrl->pm_entity);
#else		
		kzfree(md_ctrl->pm_entity);
#endif		
	} else {
		ret = -1;
		MTK_ERR_LOG(TAG, "pm_entity isn't allocated successfully\n");
	}
	return ret;
}

void cldma_hif_exit(unsigned char md_id, unsigned char hif_id)
{
	int i = 0;
	struct md_cd_ctrl *md_ctrl =
		(struct md_cd_ctrl *)ccci_hif_get_by_id(md_id, hif_id);
	struct ccci_modem *md =
		(struct ccci_modem *)ccci_md_get_modem_by_id(md_id);

	MTK_INFO_LOG(TAG, "HIF will free CLDMA%d resource\n", hif_id);
	if (md_ctrl) {
		/*stop cldma work*/
		md_cldma_stop(md_id, hif_id);
		ccci_cldma_late_uninit(md_ctrl);

		/*free cldma_sram_layout*/
		if (md_ctrl->cldma_sram_layout) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
			kfree_sensitive(md_ctrl->cldma_sram_layout);
#else			
			kzfree(md_ctrl->cldma_sram_layout);
#endif			
			md_ctrl->cldma_sram_layout = NULL;
		}
		for (i = 0; i < QUEUE_LEN(md_ctrl->txq); i++) {
			if (md_ctrl->txq[i].worker) {
				flush_workqueue(md_ctrl->txq[i].worker);
				destroy_workqueue(md_ctrl->txq[i].worker);
				md_ctrl->txq[i].worker = NULL;
			}
		}
		for (i = 0; i < QUEUE_LEN(md_ctrl->rxq); i++) {
			if (md_ctrl->rxq[i].worker) {
				flush_workqueue(md_ctrl->rxq[i].worker);
				destroy_workqueue(md_ctrl->rxq[i].worker);
				md_ctrl->rxq[i].worker = NULL;
			}
		}
		cldma_pm_uninit(md_ctrl);
		/*free md_cd_ctrl*/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)		
		kfree_sensitive(md_ctrl);
#else		
		kzfree(md_ctrl);
#endif		
		ccci_hif[md_id][hif_id] = NULL;
	}

	/*free ccci_rt_smem_base*/
	if (md && md->mem_layout.ccci_rt_smem_base) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(md->mem_layout.ccci_rt_smem_base);
#else		
		kzfree(md->mem_layout.ccci_rt_smem_base);
#endif		
		md->mem_layout.ccci_rt_smem_base = NULL;
		MTK_INFO_LOG(TAG, "free ccci_rt_smem_base successfully\n");
	}

	/*free hw_ctrl*/
	ccci_driver_uninit(md_id, hif_id);
}

int exception_flow_test(int argc, char **argv)
{
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_INIT);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_INIT);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_ACK);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_ACK);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_INIT_DONE);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_INIT_DONE);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_CLEARQ_DONE);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_CLEARQ_DONE);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_CLEARQ_ACK);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_CLEARQ_ACK);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA0_PCIE, HIF_EX_ALLQ_RESET);
	ccci_cldma_exception(MD_SYS1, HIF_ID_CLDMA_PCIE, HIF_EX_ALLQ_RESET);
	return 0;
}

int cldma_low_power_test(int argc, char **argv)
{
	struct md_cd_ctrl *md_ctrl_1, *md_ctrl_2;

	md_ctrl_1 = (struct md_cd_ctrl *)ccci_hif_get_by_id(
		MD_SYS1, HIF_ID_CLDMA0_PCIE);
	cldma_suspend(NULL, (void *)md_ctrl_1);
	cldma_suspend_late(NULL, (void *)md_ctrl_1);
	cldma_resume_early(NULL, (void *)md_ctrl_1);
	cldma_resume(NULL, (void *)md_ctrl_1);
	md_ctrl_2 = (struct md_cd_ctrl *)ccci_hif_get_by_id(MD_SYS1,
		HIF_ID_CLDMA_PCIE);
	cldma_suspend(NULL, (void *)md_ctrl_2);
	cldma_suspend_late(NULL, (void *)md_ctrl_2);
	cldma_resume_early(NULL, (void *)md_ctrl_2);
	cldma_resume(NULL, (void *)md_ctrl_2);
	return 0;
}


