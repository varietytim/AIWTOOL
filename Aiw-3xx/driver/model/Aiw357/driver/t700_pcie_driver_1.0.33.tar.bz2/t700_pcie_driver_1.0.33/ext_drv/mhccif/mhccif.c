// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/types.h>        /* size_t */

#include "common.h"
#include "mtk-pcie-dbg.h"
#include "mhccif_reg.h"
#include "mtk-pci.h"
#include "mtk-pci-ext.h"
#include "mtk-pcie.h"
#include "mtk-isr.h"
#include "PCIE_MAC_IREG_c_header.h"
#include "mhccif.h"
#define MHCCIF_SPARE_REG_SET    8

#ifdef TAG
#undef TAG
#endif

#define TAG		"MHCCIF"

bool mhccif_spare_reg_ep_get(struct mtk_pci_dev *mtk_dev,u32 set, u32 *data)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return FALSE;
	}

	if (set >= MHCCIF_SPARE_REG_SET || mtk_dev->mhccif_init_done != TRUE)
		return FALSE;

	*data = REG_IO_READ32(REG_PCIE_SPARE_EP_n_REG(
		mtk_dev->base_addr.mhccif_rc_base, set));

	return TRUE;
}

bool mhccif_spare_reg_rc_get(struct mtk_pci_dev *mtk_dev,u32 set, u32 *data)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return FALSE;
	}

	if (set >= MHCCIF_SPARE_REG_SET || mtk_dev->mhccif_init_done != TRUE)
		return FALSE;

	*data = REG_IO_READ32(REG_PCIE_SPARE_RC_n_REG(
		mtk_dev->base_addr.mhccif_rc_base, set));

	return TRUE;
}

bool mhccif_spare_reg_rc_set(struct mtk_pci_dev *mtk_dev,u32 set, u32 data)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return FALSE;
	}

	if (set >= MHCCIF_SPARE_REG_SET || mtk_dev->mhccif_init_done != TRUE)
		return FALSE;

	REG_IO_WRITE32(REG_PCIE_SPARE_RC_n_REG(
		mtk_dev->base_addr.mhccif_rc_base, set), data);

	return TRUE;
}

bool mhccif_ep2rc_reg_read(struct mtk_pci_dev *mtk_dev,u32 *reg)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev!\n");
		return FALSE;
	}

	if (mtk_dev->mhccif_init_done != TRUE){
		MTK_ERR_LOG(TAG,
			"Fatal error:MHCCIF not initialized, read status fail!\n");
		return FALSE;
		}

	*reg = REG_IO_READ32(REG_EP2RC_SW_INT_STS(
		mtk_dev->base_addr.mhccif_rc_base));

	if((mtk_dev->pdev->current_state == PCI_D3hot ||
	    mtk_dev->pdev->current_state == PCI_D3cold)&&
	    (*reg == 0xFFFFFFFF)){
		MTK_ERR_LOG(TAG,
			"Warning: PCI STATE D3() with D2H reg all F! Discard!\n");
		return FALSE;
	}

	return TRUE;
}
EXPORT_SYMBOL(mhccif_ep2rc_reg_read);

void mhccif_mask_set(struct mtk_pci_dev *mtk_dev, u32 val)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG, "input NULL pointer mtk_dev\n");
		return;
	}

	MTK_DEBUG_LOG(TAG, "MHCCIF D2H mask set 0x%x.\n",val);
	REG_IO_WRITE32(REG_EP2RC_SW_INT_EAP_MASK_SET(
		mtk_dev->base_addr.mhccif_rc_base), val);
}

void mhccif_mask_clr(struct mtk_pci_dev *mtk_dev, u32 val)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG, "input NULL pointer mtk_dev\n");
		return;
	}
	MTK_DEBUG_LOG(TAG, "MHCCIF D2H mask clear 0x%x.\n",val);
	REG_IO_WRITE32(REG_EP2RC_SW_INT_EAP_MASK_CLR(
		mtk_dev->base_addr.mhccif_rc_base), val);
}

u32 mhccif_mask_get(struct mtk_pci_dev *mtk_dev)
{
	return REG_IO_READ32(REG_EP2RC_SW_INT_EAP_MASK(
		mtk_dev->base_addr.mhccif_rc_base));
}

void mhccif_update_reg_trsl_addr(struct mtk_pci_dev *mtk_dev)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return;
	}

	mtk_dev->base_addr.mhccif_rc_base =
		mtk_dev->base_addr.pcie_ext_reg_base +
		MHCCIF_RC_DEV_BASE - mtk_dev->base_addr.pcie_dev_reg_trsl_addr;
	mtk_dev->base_addr.mhccif_ep_base =
		mtk_dev->base_addr.pcie_ext_reg_base +
		MHCCIF_EP_DEV_BASE - mtk_dev->base_addr.pcie_dev_reg_trsl_addr;

	MTK_DEBUG_LOG(TAG, "MHCCIF_RC_BASE 0x%llx(0x%llx + 0x%llx -0x%llx)\n",
		mtk_dev->base_addr.mhccif_rc_base,
		mtk_dev->base_addr.pcie_ext_reg_base, (u64)MHCCIF_RC_DEV_BASE,
		mtk_dev->base_addr.pcie_dev_reg_trsl_addr);
}

int mhccif_int_callback(void *param)
{
	struct mtk_pci_dev *mtk_dev = param;

	MTK_DEBUG_LOG(TAG, "MHCCIF AT interrupt callback\n");

	set_bit(__PCIE_EP2RC_SW_INT, mtk_dev->state);

	mtk_pcie_isr_service_event_schedule(mtk_dev);

	return 0;
}

int mhccif_init(void *param)
{
	struct mtk_pci_dev *mtk_dev;

	mtk_dev = (struct mtk_pci_dev *)param;
	MTK_DEBUG_LOG(TAG, "MHCCIF init .\n");

	mhccif_update_reg_trsl_addr(mtk_dev);

	/* Register MHCCHIF int handler to handle */
	mtk_dev->intr_callback[MHCCIF_INT] = mhccif_int_callback;
	mtk_dev->callback_param[MHCCIF_INT] = mtk_dev;

	/* Enable MHCCIF interrupt*/
	//mhccif_mask_clr(mtk_dev, 0xffffffff);

	mtk_dev->mhccif_init_done = TRUE;

	return 0;
}

int mhccif_deinit(void *param)
{
	struct mtk_pci_dev *mtk_dev;

	MTK_DEBUG_LOG(TAG, "MHCCIF deinit callback\n");

	mtk_dev = (struct mtk_pci_dev *)param;

	mtk_dev->mhccif_init_done = FALSE;

	return 0;
}

void mtk_pcie_clear_mhccif_int(struct mtk_pci_dev *mtk_dev, u32 reg)
{
	u64 temp_mhccif_rc_base;
	u32 temp_reg = 0;
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return;
	}
	temp_mhccif_rc_base = mtk_dev->base_addr.mhccif_rc_base;

	MTK_DEBUG_LOG(TAG, "MHCCIF ack for  %x .\n", reg);

	/* Clear 2 level interrupt */
	REG_IO_WRITE32(REG_EP2RC_SW_INT_ACK(temp_mhccif_rc_base), reg);
	/*clear level 2 and read back level 2, to ensure it is written done*/
	if(!mhccif_ep2rc_reg_read(mtk_dev,&temp_reg)){
		MTK_ERR_LOG(TAG,
			"ERROR: mhccif cannot read register!\n");
	}
	if(temp_reg!=0){
		MTK_DEBUG_LOG(TAG, "Aware that read back MHCCIF reg=0x%x , confirm if it's new MHCCIF interrupt.\n", temp_reg);
	}
	else{
		MTK_DEBUG_LOG(TAG, "MHCCIF Successfully  ack for  0x%x .\n", reg);
	}
	/* Clear 1 level interrupt */
	if(mtk_dev->pdev->msix_enabled){
		mtk_pcie_ext_int_status_clear_msix(mtk_dev->base_addr.pcie_mac_ireg_base,MHCCIF_INT);
	}else{
		ISTATUS_HOST_SET_MHCCIF_INT(MTK_ISTATUS_HOST(
			mtk_dev->base_addr.pcie_mac_ireg_base), 0x1);
	}



}

void __mhccif_print_ep_reg_status(struct mtk_pci_dev *mtk_dev)
{
		u64 temp_mhccif_ep_base;
		if(mtk_dev == NULL){
			MTK_ERR_LOG(TAG,
				"Fatal error:input NULL pointer mtk_dev\n");
			return;
		}

		temp_mhccif_ep_base = mtk_dev->base_addr.mhccif_ep_base;

		MTK_INFO_LOG(TAG,
			"MHCCIF STS = %x, MASK= %x, EAP_MASK = %x, 0x24=%x\n",
			REG_IO_READ32(temp_mhccif_ep_base+0x10),
			REG_IO_READ32(temp_mhccif_ep_base+0x28),
			REG_IO_READ32(temp_mhccif_ep_base+0x20),
			REG_IO_READ32(temp_mhccif_ep_base+0x24));

		return;
}

void __mhccif_rc2ep_swint_trigger(struct mtk_pci_dev *mtk_dev, u32 channel)
{
	u64 temp_mhccif_rc_base;
	u32 mask;

	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return;
	}

	temp_mhccif_rc_base = mtk_dev->base_addr.mhccif_rc_base;

	MTK_INFO_LOG(TAG, "MHCCIF send sw int channel %d .\n", channel);
	REG_IO_WRITE32(REG_RC2EP_SW_BSY(temp_mhccif_rc_base),
		REG_FLD_MASK(H2D_INT_CCCI_EXP_ACK(channel)));
	REG_IO_WRITE32(REG_RC2EP_SW_TCHNUM(temp_mhccif_rc_base), channel);
	/*ADD log for ack issue*/
	mask = mhccif_mask_get(mtk_dev);
	MTK_INFO_LOG(TAG, "After MHCCIF send sw int channel %d , the D2H mask is %x.\n", channel,mask);
}

void mhccif_rc2ep_swint_trigger(struct mtk_pci_dev *mtk_dev,u32 channel)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Fatal error:input NULL pointer mtk_dev\n");
		return;
	}

	__mhccif_rc2ep_swint_trigger(mtk_dev, channel);
}

