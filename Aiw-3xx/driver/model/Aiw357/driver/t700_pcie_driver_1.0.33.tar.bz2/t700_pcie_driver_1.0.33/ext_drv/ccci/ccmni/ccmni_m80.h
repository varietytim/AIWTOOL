/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_CCMNI_H__
#define __CCCI_CCMNI_H__
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/skbuff.h>
#include <linux/bitops.h>
#include <linux/spinlock.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/dma-mapping.h>
#include <linux/timer.h>
#include <linux/if_ether.h>
#include <linux/bitops.h>
#include <linux/dma-mapping.h>

#include "dpmaif_hif_platform_m80.h"
#include "ccci_fsm.h"


#define RXQ_NUM MAIFQ_MAX_DLQ_NUM
#define NIC_DEV_MAX		(21)  //current for host driver
#define NIC_DEV_DEFAULT (8)
#define NIC_NAPI_POLL_BUDGET    (128)

/* should less than DPMAIF_HW_MTU_SIZE (3*1024 + 8) */
#define CCMNI_MTU_MAX			(3000)
#define	CCMNI_MTU				(1500)

#define	CCMNI_TX_QUEUE			1000
#define	CCMNI_NETDEV_WDT_TO		(1*HZ)

#define	IPV4_VERSION			0x40
#define	IPV6_VERSION			0x60

/* stop/start tx queue */
#define	SIOCSTXQSTATE	(SIOCDEVPRIVATE + 0)

/* enable/disable ul queue priority */
#define	SIOCTXQPRIO	(SIOCDEVPRIVATE + 4)

#define	CCMNI_TX_PRINT_F		(0x1 << 0)

#define	CCMNI_UL_PRIONUM		 (16)

/*priority bits: bit12 ~ bit15*/
#define CCMNI_GET_SKB_PRIO(mark)  (((mark) >> 12) & 0x0F)

/*This should be align with Data Path HW queues configuration*/
enum {
	HIF_MIN_TXQ = 0,
	HIF_TXQ0 = HIF_MIN_TXQ,
	HIF_NORMAL_QUEUE = HIF_TXQ0,
	HIF_TXQ1 = 1,
	HIF_ACK_QUEUE = HIF_TXQ1,
	HIF_H_PRIO_QUEUE = HIF_ACK_QUEUE,
	HIF_TXQ2 = 2,
	HIF_TXQ3 = 3,
	HIF_TXQ4 = 4,
	HIF_MAX_TXQ = HIF_TXQ4,
};

/* HIF_TXQ0, HIF_TXQ1*/
#define HIF_TXQ_IN_USE		(2)

/* netdev TX queue,  */
enum {
	CCMNI_TXQ_NORMAL   = 0,
	CCMNI_TXQ_FAST	   = 1,
	CCMNI_TXQ_NUM,
	CCMNI_TXQ_END	  = CCMNI_TXQ_NUM
};

struct ccmni_instance {
	unsigned int	index;
	int				   md_id;
	int				   net_if_off;


	/*0:disable priority; none zero: enable priority*/
	int					prio_en;

	atomic_t		   usage;
	unsigned int 		queue_status;

	/* use pointer to keep these items unique,
	 * while switching between CCMNI instances
	 */
	struct net_device  *dev;
	unsigned int	   rx_seq_num;
	unsigned int	   tx_seq_num[2];
	unsigned int	   flags[2];
	spinlock_t	   *spinlock;
	struct ccmni_ctl_block	*ctlb;
	unsigned long	   tx_busy_cnt[2];
	unsigned long	   tx_full_tick[2];
	unsigned long	   tx_irq_tick[2];
	unsigned int	   tx_full_cnt[2];
	unsigned int	   tx_irq_cnt[2];
	unsigned int	   rx_gro_cnt;
	void			   *priv_data;
};


struct ccmni_ctl_block {
	unsigned int md_id;
	struct mtk_pci_dev *mtk_dev;
	struct md_dpmaif_ctrl *hif_ctrl;
	struct ccmni_instance	*ccmni_inst[NIC_DEV_MAX];
	unsigned int nic_dev_num;
#ifdef MODEM_MANAGER_SUPPORT
	bool nic_dev_created;
#endif
	unsigned int		md_sta;
	unsigned int capability;

	struct net_device dummy_dev;
	unsigned int napi_poll_weigh;
	int (*napi_poll)(struct napi_struct *napi, int weight);
	struct napi_struct *napi[RXQ_NUM];
	atomic_t napi_usr_refcnt;
	atomic_t napi_enable;

	struct fsm_notifier_block md_status_notify;
	unsigned long long net_rx_delay[4];
#ifdef CCCI_SKB_TRACE
	unsigned long long netif_rx_profile[8];
#endif

	unsigned char 	*prio_mapping;
};

enum {
	CCMNI_ERR_TX_OK = 0,	/* ccci send pkt success */
	CCMNI_ERR_TX_BUSY = -1,	/* ccci tx packet buffer full and tx fail */
	CCMNI_ERR_MD_NO_READY = -2,/* modem not ready and tx fail */
	CCMNI_ERR_TX_INVAL = -3,		/* ccmni parameter error */
};

#define NIC_CAP_TXBUSY_STOP 	(1 << 0)
#define NIC_CAP_SGIO 			(1 << 1)
#define NIC_CAP_DATA_ACK_DVD 	(1 << 2)
#define NIC_CAP_CCMNI_MQ 		(1 << 3)
#define NIC_CAP_NAPI 			(1 << 4)

int ccmni_init(int md_id, struct mtk_pci_dev *mtk_dev);
void ccmni_exit(int md_id, struct mtk_pci_dev *mtk_dev);
int ccmni_rx_callback(struct ccmni_ctl_block *ctlb,
	int ccmni_idx, struct sk_buff *skb, void *priv_data);

void ccmni_queue_state_notify(struct ccmni_ctl_block *ctlb,
	enum HIF_STATE state, int qno);
int ccmni_get_nic_cap(struct ccmni_ctl_block *ctlb);

void dump_skb_info(struct sk_buff *skb, const char *func, int line);


#endif /* __CCCI_CCMNI_H__ */
