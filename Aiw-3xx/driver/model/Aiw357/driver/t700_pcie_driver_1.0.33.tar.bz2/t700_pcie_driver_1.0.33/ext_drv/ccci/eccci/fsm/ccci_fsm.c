// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_fsm_internal.h"
#include "port_t.h"
#include "ccci_hif_cldma.h"
#include <linux/kernel.h>
#include "ccci_fsm.h"
#include "modem_sys_1.h"
#include "../../../../PCIE/core/mtk-pci.h"
#include "mtk-pci-rescan.h"
#include "mhccif.h"
#include "mtk-isr.h"

#include "mtk-pcie-mac.h"


//XSQUARE
#include <linux/version.h>


#define HOST_EVENT_OFFSET 28
bool da_down_stage_flag = false;

enum host_event_e {
	HOST_EVENT_INIT = 0,
	BROM_REBOOT_ACK = 0x1,
	BROM_DLPT_NOTY = 0x2,
};

enum brom_event_id_e {
	BROM_EVENT_NORMAL = 0,
	BROM_EVENT_JUMP_BL = 1,
	BROM_EVENT_TIME_OUT = 2,
	BROM_EVENT_JUMP_DA = 3,
	BROM_EVENT_CREATE_DL_PORT = 4,
	BROM_EVENT_RESET = 7,
};
enum lk_event_id_e {
	LK_EVENT_NORMAL = 0,
	LK_EVENT_CREATE_PD_PORT = 1,
	LK_EVENT_RESET = 7,
};
enum linux_event_id_e {
	LINUX_EVENT_NORMAL = 0,
	LINUX_EVENT_PCIE = 1,
	LINUX_EVENT_DUAL = 2,
	LINUX_EVENT_RESET = 0xf,
};

enum device_stage {
	INIT_STAGE = 0,
	BROM_STAGE_PRE = 1,
	BROM_STAGE_POST = 2,
	LK_STAGE = 3,
	LINUX_STAGE = 4,
};

u32 hs_timeout; //adjust handshake timeout dynamically
struct ccci_fsm_ctl *ccci_fsm_entries[MAX_MD_NUM];
static int count;
unsigned short brom_dl_flag;

static void fsm_finish_command(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd, int result);
static void fsm_finish_event(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_event *event);

int port_enumeration_test(int argc, char **argv)
{
	unsigned int tmp_val = 0;

	if (argc > 1) {
		if(!kstrtou32(argv[1], 16, &tmp_val))
			mod_param_val = tmp_val;
	}
	return 0;
}

int fsm_state_test(int argc, char **argv)
{
	struct ccci_fsm_ctl *ctl;

	ctl = fsm_get_entity_by_md_id(0);

	MTK_NOTICE_LOG(FSM, "fsm_state_test: %s %s", argv[0], (argc > 1 ? argv[1]:NULL));

	if (argc > 1) {
		if (!strcmp(argv[1], "PreStart")) {
			MTK_NOTICE_LOG(FSM, "Append Pre-Start command\n");
			fsm_append_command(ctl, CCCI_COMMAND_PRE_START, 0);
		}
		if (!strcmp(argv[1], "Starting")) {
			MTK_NOTICE_LOG(FSM, "Append Start command\n");
			fsm_append_command(ctl, CCCI_COMMAND_START, 0);
		}
		if (!strcmp(argv[1], "Ready")) {
			MTK_NOTICE_LOG(FSM, "Append Ready command\n");
			fsm_append_command(ctl, CCCI_COMMAND_READY, 0);
		}
		if (!strcmp(argv[1], "Exception")) {
			MTK_NOTICE_LOG(FSM, "Append Exception command\n");
			fsm_append_command(ctl, CCCI_COMMAND_EXCEPTION, 0);
		}
		if (!strcmp(argv[1], "Stopping")) {
			MTK_NOTICE_LOG(FSM, "Append Stopping command\n");
			fsm_append_command(ctl, CCCI_COMMAND_PRE_STOP, 0);
		}
		if (!strcmp(argv[1], "Stopped")) {
			MTK_NOTICE_LOG(FSM, "Append Stopped command\n");
			fsm_append_command(ctl, CCCI_COMMAND_STOP, 0);
		}
	}

	return 0;
}

static inline int send_brom_cmd(
	struct port_t *dl_port, u8 cmd_byte)
{
	int ret = 0;
	struct sk_buff *skb = NULL;

	skb = ccci_alloc_skb(sizeof(u8), 1, 1);
	if (skb == NULL)
		return -1;

	skb_put(skb, sizeof(u8));
	*(skb->data) = cmd_byte;
	ret = port_send_skb_to_md(dl_port, skb, 1);
	if (ret) {
		ccci_free_skb(skb);
		return -1;
	}
	return 0;
}

inline static void brom_jump_bl(struct port_t *dl_port)
{
	if (dl_port != NULL) {
		/*enter start cmd*/
		send_brom_cmd(dl_port, 0xa0);
		send_brom_cmd(dl_port, 0x0a);
		send_brom_cmd(dl_port, 0x50);
		send_brom_cmd(dl_port, 0x05);
		/*jump bl cmd*/
		send_brom_cmd(dl_port, 0xD6);
	}
}

int brom_jp_bl_cmd_test(int argc, char **argv)
{
	int ret = 0;
	struct port_t *dl_port = NULL;
	dl_port = port_get_by_name(0, "brom_download");
	brom_jump_bl(dl_port);
	return ret;
}

int fsm_notifier_register(int md_id, struct fsm_notifier_block *notifier)
{
	struct ccci_fsm_ctl *ctl;
	unsigned long flags;

	if(unlikely(md_id < 0 || md_id >= MAX_MD_NUM || notifier == NULL)) {
		MTK_ERR_LOG(FSM, "Invalid Arguments");
		return -EINVAL;
	}

	ctl = fsm_get_entity_by_md_id(md_id);
	spin_lock_irqsave(&ctl->notifier_lock, flags);
	list_add_tail(&notifier->entry, &ctl->notifier_list);
	spin_unlock_irqrestore(&ctl->notifier_lock, flags);

	return 0;
}

int fsm_notifier_unregister(int md_id, struct fsm_notifier_block *notifier)
{
	struct ccci_fsm_ctl *ctl;
	unsigned long flags;
	struct fsm_notifier_block *notifier_cur, *notifier_next;

	if(unlikely(md_id < 0 || md_id >= MAX_MD_NUM || notifier == NULL)) {
		MTK_ERR_LOG(FSM, "Invalid Arguments");
		return -EINVAL;
	}

	ctl = fsm_get_entity_by_md_id(md_id);

	spin_lock_irqsave(&ctl->notifier_lock, flags);
	list_for_each_entry_safe(notifier_cur, notifier_next, &ctl->notifier_list, entry) {
		if (notifier_cur == notifier)
			list_del(&notifier->entry);
	}
	spin_unlock_irqrestore(&ctl->notifier_lock, flags);

	return 0;
}

static int fsm_state_notify(int md_id, enum MD_STATE state)
{
	struct ccci_fsm_ctl *ctl;
	unsigned long flags;
	struct fsm_notifier_block *notifier;

	if(unlikely(md_id < 0 || md_id >= MAX_MD_NUM || state >= MD_STATE_MAX)) {
		MTK_ERR_LOG(FSM, "Invalid Arguments");
		return -EINVAL;
	}

	ctl = fsm_get_entity_by_md_id(md_id);
    spin_lock_irqsave(&ctl->notifier_lock, flags);
	list_for_each_entry(notifier, &ctl->notifier_list, entry) {
		spin_unlock_irqrestore(&ctl->notifier_lock, flags);
		if (notifier->notifier_fn)
			notifier->notifier_fn(state, notifier->data);
		spin_lock_irqsave(&ctl->notifier_lock, flags);
	}
	spin_unlock_irqrestore(&ctl->notifier_lock, flags);

	return 0;
}


int fsm_broadcast_state(struct ccci_fsm_ctl *ctl,
	enum MD_STATE state)
{
	if (unlikely(ctl->md_state != BOOT_WAITING_FOR_HS2 && state == READY)) {
		MTK_INFO_LOG(FSM,
			"ignore HS2 when md_state=%d\n", ctl->md_state);
		return 0;
	}
	MTK_INFO_LOG(FSM,
		"md_state change from %d to %d\n", ctl->md_state, state);
	ctl->md_state = state;

	/* update to port first, otherwise send message on HS2 may fail */
	ccci_port_md_status_notify(ctl->md_id, state);
#ifdef M7X
	ccci_hif_state_notification(ctl->md_id, state);
#endif
	fsm_state_notify(ctl->md_id, state);
	return 0;
}

static void fsm_routine_zombie(struct ccci_fsm_ctl *ctl)
{
	struct ccci_fsm_event *event, *evt_next;
	struct ccci_fsm_command *cmd, *cmd_next;
	unsigned long flags;

	spin_lock_irqsave(&ctl->command_lock, flags);
	list_for_each_entry_safe(cmd, cmd_next, &ctl->command_queue, entry) {
		MTK_ERR_LOG(FSM, "unhandled command %d\n", cmd->cmd_id);
		list_del(&cmd->entry);
		fsm_finish_command(ctl, cmd, -1);
	}
	spin_unlock_irqrestore(&ctl->command_lock, flags);
	spin_lock_irqsave(&ctl->event_lock, flags);
	list_for_each_entry_safe(event, evt_next, &ctl->event_queue, entry) {
		MTK_ERR_LOG(FSM, "unhandled event %d\n", event->event_id);
		fsm_finish_event(ctl, event);
	}
	spin_unlock_irqrestore(&ctl->event_lock, flags);
}

/* cmd is not NULL only when reason is ordinary EE */
static void fsm_routine_exception(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd, CCCI_EE_REASON reason)
{
	int count = 0, ex_got = 0, rec_ok_got = 0, pass_got = 0;
	struct ccci_fsm_event *event;
	unsigned long flags;
	int timeout = 0;
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);
	struct port_t *log_port, *meta_port;

	MTK_INFO_LOG(FSM, "exception %d, from %ps\n",
		reason, __builtin_return_address(0));
	fsm_monitor_send_message(ctl->md_id, CCCI_MD_MSG_EXCEPTION, 0);
	/* 1. state sanity check */
	if ((ctl->curr_state != CCCI_FSM_READY) && (ctl->curr_state != CCCI_FSM_STARTING)) {
		if (cmd)
			fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_EXCEPTION;
	if (reason == EXCEPTION_WDT || reason == EXCEPTION_HS_TIMEOUT)
		mdee_set_ex_start_str(&ctl->ee_ctl, 0, NULL);

	/* 2. check EE reason */
	switch (reason) {
	case EXCEPTION_HS_TIMEOUT:
		MTK_ERR_LOG(FSM, "BOOT_HS_FAIL!\n");
		ccci_hif_dump_status(ctl->md_id,
			HIF_FLAG_CTRL|HIF_FLAG_CTRL_1,
			DUMP_FLAG_HIF, NULL, 0);
		break;
	case EXCEPTION_WDT:
		fsm_broadcast_state(ctl, EXCEPTION);
		MTK_ERR_LOG(FSM, "MD_WDT!\n");
		fsm_md_wdt_handler(&ctl->ee_ctl);
		break;
	case EXCEPTION_EE:
		fsm_broadcast_state(ctl, EXCEPTION);
		mtk_pci_pm_exp_detected(md->mtk_dev);
		ccci_md_exception_handshake(ctl->md_id, MD_EX_CCIF_TIMEOUT);
		count = 0;
		MTK_NOTICE_LOG(FSM,
			"CCCI exception handshake1... [timeout=%ds]\n",
			MD_EX_REC_OK_TIMEOUT/1000);
		while (count < MD_EX_REC_OK_TIMEOUT/EVENT_POLL_INTEVAL) {
			if(kthread_should_stop()) {
				MTK_NOTICE_LOG(FSM, "Fsm thread was stopped\n");
				return;
			}
			spin_lock_irqsave(&ctl->event_lock, flags);
			if (!list_empty(&ctl->event_queue)) {
				event = list_first_entry(&ctl->event_queue,
					struct ccci_fsm_event, entry);
				if (event->event_id == CCCI_EVENT_MD_EX) {
					MTK_NOTICE_LOG(FSM,
						"sAP receive CCCI_EVENT_MD_EX.\n");
					ex_got = 1;
					fsm_finish_event(ctl, event);
				} else if (event->event_id ==
					CCCI_EVENT_MD_EX_REC_OK) {
					MTK_NOTICE_LOG(FSM,
						"sAP receive CCCI_EVENT_MD_EX_REC_OK.\n");
					rec_ok_got = 1;
					fsm_finish_event(ctl, event);
				}
			}
			spin_unlock_irqrestore(&ctl->event_lock, flags);
			if (rec_ok_got) {
				MTK_NOTICE_LOG(FSM,
					"CCCI exception handshake1 pass.\n");
				timeout = 1;
				break;
			}
			count++;
			msleep(EVENT_POLL_INTEVAL);
		}
		if (timeout != 1)
			MTK_NOTICE_LOG(FSM,
				"CCCI exception handshake1 timeout.\n");

		fsm_md_exception_stage(&ctl->ee_ctl, 1);

		count = 0;
		MTK_NOTICE_LOG(FSM,
			"CCCI exception handshake2... [timeout=%ds]\n",
			MD_EX_PASS_TIMEOUT/1000);
		while (count < MD_EX_PASS_TIMEOUT/EVENT_POLL_INTEVAL) {
			if(kthread_should_stop()) {
				MTK_NOTICE_LOG(FSM, "Fsm thread was stopped\n");
				return;
			}
			spin_lock_irqsave(&ctl->event_lock, flags);
			if (!list_empty(&ctl->event_queue)) {
				event = list_first_entry(&ctl->event_queue,
					struct ccci_fsm_event, entry);
				if (event->event_id == CCCI_EVENT_MD_EX_PASS) {
					MTK_NOTICE_LOG(FSM,
						"sAP receive CCCI_EVENT_MD_EX_PASS.\n");
					pass_got = 1;
					fsm_finish_event(ctl, event);
				}
			}
			spin_unlock_irqrestore(&ctl->event_lock, flags);
			if (pass_got) {
				MTK_NOTICE_LOG(FSM,
					"CCCI exception handshake2 pass.\n");
				timeout = 2;
				log_port = port_get_by_name(ctl->md_id, "ttyCMdLog");
				if (log_port != NULL)
					log_port->ops->enable_chl(log_port);
				else
					MTK_ERR_LOG(FSM, "can't found logging port/n");
				meta_port = port_get_by_name(ctl->md_id, "ttyCMdMeta");
				if (meta_port != NULL)
					meta_port->ops->enable_chl(meta_port);
				else
					MTK_ERR_LOG(FSM, "can't found meta port/n");
				break;

			}
			count++;
			msleep(EVENT_POLL_INTEVAL);

			if (count%500 == 0)
				MTK_NOTICE_LOG(FSM,
					"wait for the CCCI_EVENT_MD_EX_PASS...\n");
		}
		if (timeout != 2)
			MTK_NOTICE_LOG(FSM,
				"CCCI exception handshake2 timeout.\n");

		fsm_md_exception_stage(&ctl->ee_ctl, 2);

		/* wait until modem memory dump done */
		fsm_check_ee_done(&ctl->ee_ctl, EE_DONE_TIMEOUT);

		break;
	default:
		break;
	}

	/* 3. always end in exception state */
	if (cmd)
		fsm_finish_command(ctl, cmd, 1);
}


void brom_event_monitor(struct timer_list *timer)
{
	struct ccci_modem *md;
	unsigned int dummy_reg = 0;
	struct coprocessor_ctl *temp_cocore_ctl = container_of(timer,
		struct coprocessor_ctl, event_check_timer);
	struct ccci_fsm_ctl *fsm_ctl = container_of(temp_cocore_ctl,
		struct ccci_fsm_ctl, sap_state_ctl);

	md = ccci_md_get_modem_by_id(fsm_ctl->md_id);

	/*store dummy register*/
	dummy_reg = ccci_dummy_register_val_get(md, 0)&~HOST_EVENT_MASK;
	if (dummy_reg != temp_cocore_ctl->last_dummy_reg)
		fsm_append_command(fsm_ctl, CCCI_COMMAND_PRE_START, 0);
	mod_timer(timer, jiffies + HZ/20);

}
static inline void start_brom_event_start_timer(struct ccci_fsm_ctl *ctl)
{
	if (!ctl->sap_state_ctl.event_check_timer.function) {
		timer_setup(&(ctl->sap_state_ctl.event_check_timer),
			brom_event_monitor, 0);
		ctl->sap_state_ctl.event_check_timer.expires =
			jiffies + (HZ/20); // 50ms
		add_timer(&(ctl->sap_state_ctl.event_check_timer));
	} else {
		mod_timer(&(ctl->sap_state_ctl.event_check_timer),
			jiffies + HZ/20);
	}
}

static inline void stop_brom_event_start_timer(struct ccci_fsm_ctl *ctl)
{
	if (ctl->sap_state_ctl.event_check_timer.function) {
		del_timer(&(ctl->sap_state_ctl.event_check_timer));
		ctl->sap_state_ctl.event_check_timer.expires = 0;
		ctl->sap_state_ctl.event_check_timer.function = NULL;
	}
}

static inline void host_event_notify(
	struct ccci_modem *md, enum host_event_e event_id) {
	u32 dummy_reg_val_temp = 0;
	dummy_reg_val_temp = ccci_dummy_register_val_get(md, 0);
	dummy_reg_val_temp &= ~HOST_EVENT_MASK;
	dummy_reg_val_temp |= event_id << HOST_EVENT_OFFSET;
	ccci_dummy_register_val_write(md, dummy_reg_val_temp);
	MTK_DEBUG_LOG(FSM, "host event id:%x, dummy reg:%x(%x)\n",
		event_id, ccci_dummy_register_val_get(md, 0), dummy_reg_val_temp);
}

static inline void brom_stage_event_handling(struct ccci_fsm_ctl *ctl,
	unsigned int dummy_reg)
{
	unsigned char brom_event;
	struct port_t *dl_port = NULL;
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);

	/*get brom event id*/
	brom_event = (dummy_reg & BROM_EVENT_MASK)>>4;
	MTK_DEBUG_LOG(FSM, "device event: %x\n", brom_event);
	switch (brom_event) {
	case BROM_EVENT_NORMAL:
		//MTK_NOTICE_LOG(FSM, "Non Download Mode\n");
	case BROM_EVENT_JUMP_BL:
	case BROM_EVENT_TIME_OUT:
		if(brom_event == BROM_EVENT_NORMAL){
			MTK_NOTICE_LOG(FSM, "Non Download Mode\n");
		}
		MTK_NOTICE_LOG(FSM, "jump next stage\n");
		dl_port = port_get_by_name(ctl->md_id, "brom_download");
		if (dl_port != NULL)
			dl_port->ops->disable_chl(dl_port);
		else
			MTK_ERR_LOG(FSM, "can't found DL port\n");
		/* some race condition: In SMPU test, host driver hangs in BROM stage when B2 is read, but B4 is not read before. */
		start_brom_event_start_timer(ctl);
		MTK_NOTICE_LOG(FSM,
			"Device enter next stage from Brom stage\n");
		break;
	case BROM_EVENT_JUMP_DA:
		MTK_NOTICE_LOG(FSM, "jump DA and wait reset signal\n");
		da_down_stage_flag = false;
		host_event_notify(md, BROM_DLPT_NOTY);
		start_brom_event_start_timer(ctl);
		MTK_NOTICE_LOG(FSM, "Device enter DA from Brom stage\n");
		break;
	case BROM_EVENT_CREATE_DL_PORT:
		MTK_NOTICE_LOG(FSM, "create DL port,brom_dl_flag:%d\n",brom_dl_flag);
		da_down_stage_flag = true;
		ccci_hif_hw_init(ctl->md_id, HIF_FLAG_CTRL_1);
		ccci_hif_stop(ctl->md_id, HIF_FLAG_CTRL_1);
		ccci_switch_hif_cfg(ctl->md_id, HIF_PATH_CTRL_1, HIF_CFG2);
		switch_port_cfg(ctl->md_id, PORT_CFG1);
		dl_port = port_get_by_name(ctl->md_id, "brom_download");
		if (dl_port != NULL){
			if (brom_dl_flag){
				dl_port->ops->enable_chl(dl_port);
				ccci_hif_start(ctl->md_id, HIF_FLAG_CTRL_1);
			} else {
				ccci_hif_start(ctl->md_id, HIF_FLAG_CTRL_1);
				brom_jump_bl(dl_port);
			}
		}else
			MTK_ERR_LOG(FSM, "can't found DL port/n");
		/*start brom event check thread */
		start_brom_event_start_timer(ctl);
		break;
	case BROM_EVENT_RESET:
		host_event_notify(md, BROM_REBOOT_ACK);
		mtk_queue_rescan_work(md->mtk_dev->pdev);
		break;
	default:
		MTK_ERR_LOG(FSM,
			"Brom Event region content error\n");
		break;
	}
}

static int dump_status_before_mrdump(struct mtk_pci_dev *mtk_dev)
{
	int cldma_irq_sta;
	int rgu_irq_sta;

	cldma_irq_sta = mtk_pcie_msix_irq_raw_status(mtk_dev->base_addr.pcie_mac_ireg_base,
						CLDMA0_INT + PCIE_EXT_INT_OFFSET);

	rgu_irq_sta = mtk_pcie_msix_irq_raw_status(mtk_dev->base_addr.pcie_mac_ireg_base,
						SAP_RGU_INT + PCIE_EXT_INT_OFFSET);

	MTK_NOTICE_LOG(FSM, "CLDMA0 IRQ:0X%X, RGU IRQ:0X%X\n", cldma_irq_sta, rgu_irq_sta);

	return 0;
}
static inline void lk_stage_event_handling(struct ccci_fsm_ctl *ctl,
	unsigned int dummy_reg)
{
	unsigned char lk_event;
	struct port_t *pd_port;
	struct ccci_modem *md;

	/*get lk event id*/
	lk_event = (dummy_reg & LK_EVENT_MASK)>>8;
	switch (lk_event) {
	case LK_EVENT_NORMAL:
		MTK_NOTICE_LOG(FSM, "Device enter next stage from LK stage/n");
		break;
	case LK_EVENT_CREATE_PD_PORT:
		md = ccci_md_get_modem_by_id(ctl->md_id);
		dump_status_before_mrdump(md->mtk_dev);
		ccci_hif_hw_init(ctl->md_id, HIF_FLAG_CTRL_1);
		ccci_hif_stop(ctl->md_id, HIF_FLAG_CTRL_1);
		ccci_switch_hif_cfg(ctl->md_id,
			HIF_PATH_CTRL_1, HIF_CFG2);
		switch_port_cfg(ctl->md_id, PORT_CFG1);
		pd_port = port_get_by_name(ctl->md_id, "ttyDUMP");
		if (pd_port != NULL)
			pd_port->ops->enable_chl(pd_port);
		else
			MTK_ERR_LOG(FSM, "can't found PD port/n");
		ccci_hif_start(ctl->md_id, HIF_FLAG_CTRL_1);
		break;
	case LK_EVENT_RESET:
		/*send r&r event to r&r thread*/
		break;
	default:
		MTK_ERR_LOG(FSM, "Brom Event region content error\n");
		break;
	}
}
static inline void linux_stage_event_handling(struct ccci_fsm_ctl *ctl,
	unsigned int dummy_reg)
{
	unsigned char linux_event;
	/*get linux event id*/
	linux_event = (dummy_reg & LINUX_EVENT_MASK)>>12;
	switch (linux_event) {
	case LINUX_EVENT_NORMAL:
		break;
	case LINUX_EVENT_PCIE:
		break;
	case LINUX_EVENT_DUAL:
		break;
	case LINUX_EVENT_RESET:
		/*send r&r event to r&r thread*/
		break;
	default:
		MTK_ERR_LOG(FSM, "Brom Event region content error\n");
		break;
	}
	fsm_append_command(ctl, CCCI_COMMAND_START, 0);
}


static void fsm_stopped_handler(struct ccci_fsm_ctl *ctl, struct mtk_pci_dev *mtk_dev)
{
	if (unlikely(ctl == NULL || mtk_dev == NULL)) {
		MTK_ERR_LOG(FSM, "Invalid arguments\n");
		return;
	}
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_STOPPED;

	fsm_broadcast_state(ctl, STOPPED);
	ccci_modem_reset(mtk_dev);
}


static void fsm_routine_stopped(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);

	/* 1. state sanity check */
	if (ctl->curr_state == CCCI_FSM_STOPPED) {
		fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}

	fsm_stopped_handler(ctl, md->mtk_dev);
	fsm_finish_command(ctl, cmd, 1);
}


static void fsm_routine_stopping(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd)
{
	int err;

	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);

	/*remove timer to avoid pre start again*/
	stop_brom_event_start_timer(ctl);

	/* 1. state sanity check */
	if (ctl->curr_state == CCCI_FSM_STOPPED || ctl->curr_state == CCCI_FSM_STOPPING) {
		fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_STOPPING;

	fsm_broadcast_state(ctl, WAITING_TO_STOP);
	//stop hw
	ccci_hif_stop(ctl->md_id, HIF_FLAG_CTRL);
	ccci_hif_stop(ctl->md_id, HIF_FLAG_CTRL_1);

	//TODO: reset device if not RGU interrupt occurs
	if (atomic_read(&md->rgu_irq_assered) == 0) {
		MTK_INFO_LOG(FSM, "Ignore Hotplug and Reset Device\n");
		pci_ignore_hotplug(md->mtk_dev->pdev);
		/* To disable DRM before FLDR */;
		__mhccif_rc2ep_swint_trigger(md->mtk_dev, MHCCIF_H2D_INT_DRM_DISABLE_AP);
		msleep(200);
		/*try fldr firstly*/
		err = mtk_acpi_fldr_func(md->mtk_dev);
		if (err)
			__mhccif_rc2ep_swint_trigger(md->mtk_dev,
						MHCCIF_H2D_INT_DEVICE_RESET);
	}

	//auto jump to stopped state handler
	fsm_stopped_handler(ctl, md->mtk_dev);

	fsm_finish_command(ctl, cmd, 1);
}


static void fsm_routine_pre_start(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd)
{
	unsigned int current_dummy_reg = 0;
	unsigned char device_stage = 0;
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);
	/*read dummy register*/
	current_dummy_reg = ccci_dummy_register_val_get(md, 0)&~HOST_EVENT_MASK;
	MTK_INFO_LOG(FSM,
		"dummy register initialization val-- dummy_reg: %x %x\n",
		current_dummy_reg, ctl->sap_state_ctl.last_dummy_reg);
	if (current_dummy_reg == (0xFFFFFFFF&~HOST_EVENT_MASK)) {
		MTK_ERR_LOG(FSM, "invaild PCIe register value\n");
		fsm_finish_command(ctl, cmd, -1);
		ctl->sap_state_ctl.last_dummy_reg = current_dummy_reg;
		return;
	}
	/* state sanity check */
	if (ctl->curr_state != CCCI_FSM_INIT &&
		ctl->curr_state != CCCI_FSM_PRE_STARTING &&
		ctl->curr_state != CCCI_FSM_STOPPED) {
		fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_PRE_STARTING;
	md->ops->md_event_notify(md, FSM_PRE_START);
	switch_port_cfg(ctl->md_id, PORT_CFG1);


	if (current_dummy_reg != ctl->sap_state_ctl.last_dummy_reg) {
		device_stage = current_dummy_reg & DEV_STAGE_MASK;
		switch (device_stage) {
		case INIT_STAGE:
			fsm_append_command(ctl,
				CCCI_COMMAND_PRE_START, 0);
			break;
		case BROM_STAGE_PRE:
		case BROM_STAGE_POST:
			brom_stage_event_handling(ctl,
				current_dummy_reg);
			break;
		case LK_STAGE:
			da_down_stage_flag = false;
			stop_brom_event_start_timer(ctl);
			lk_stage_event_handling(ctl, current_dummy_reg);
			break;
		case LINUX_STAGE:
			da_down_stage_flag = false;
			stop_brom_event_start_timer(ctl);
			ccci_hif_hw_init(ctl->md_id, HIF_FLAG_CTRL_DATA);
			ccci_hif_hw_init(ctl->md_id, HIF_FLAG_EX);
			linux_stage_event_handling(ctl, current_dummy_reg);
			break;
		default:
			MTK_ERR_LOG(FSM, "PCIe register content error\n");
			break;
		}
		/* store dummy_register*/
		ctl->sap_state_ctl.last_dummy_reg = current_dummy_reg;
		count = 0;
	} else {
		if (current_dummy_reg == 0) {
			if (count++ >= 200) {
				MTK_NOTICE_LOG(FSM, "CCCI_COMMAND_PRE_START 200 times\n");
				count = 0;
			} else {
				msleep(100);
				fsm_append_command(ctl, CCCI_COMMAND_PRE_START, 0);
			}
		} else {
			count = 0;
		}
	}
	fsm_finish_command(ctl, cmd, 1);
}

void async_hk_timer_handle(struct timer_list *timer) {
	struct ccci_fsm_ctl *fsm_ctl =
		container_of(timer, struct ccci_fsm_ctl, async_hk_timer);
	MTK_INFO_LOG(FSM, "handshake monitor timer handling function enter\n");
	atomic_set(&fsm_ctl->async_hk_timeout, 1);
	wake_up(&fsm_ctl->async_hk_wq);
}

static void fsm_routine_ready(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);

	/* 1. state sanity check */
	if (ctl->curr_state != CCCI_FSM_STARTING) {
		fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_READY;
	fsm_broadcast_state(ctl, READY);
	md->ops->md_event_notify(md, FSM_READY);
	fsm_finish_command(ctl, cmd, 1);
}

static inline void start_hk_timer(struct ccci_fsm_ctl *ctl)
{
	timer_setup(&ctl->async_hk_timer, async_hk_timer_handle, 0);
	ctl->async_hk_timer.expires = jiffies + (HZ*60); //60s
	add_timer(&ctl->async_hk_timer);
}

static void fsm_routine_starting(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(ctl->md_id);
	int ret = 0;

	/* 1. state sanity check */
	if (ctl->curr_state != CCCI_FSM_PRE_STARTING) {
		fsm_finish_command(ctl, cmd, -1);
		//fsm_routine_zombie(ctl);
		return;
	}
    switch_port_cfg(ctl->md_id, PORT_CFG0);
	ctl->last_state = ctl->curr_state;
	ctl->curr_state = CCCI_FSM_STARTING;

	ret = ccci_md_start(ctl->md_id);
	if (ret) {
		MTK_ERR_LOG(FSM, "fail to start MD.\n");
		fsm_finish_command(ctl, cmd, -1);
		return;
	}
	fsm_broadcast_state(ctl, BOOT_WAITING_FOR_HS1);
	md->ops->md_event_notify(md, FSM_START);
	start_hk_timer(ctl);
	MTK_INFO_LOG(FSM, "start handshake flow\n");
	do {
		ret = wait_event_interruptible(ctl->async_hk_wq,
			(atomic_read(&(md->core_md.ready)) && atomic_read(&(md->core_sap.ready)))
			|| atomic_read(&ctl->async_hk_timeout) || atomic_read(&ctl->exp_flg));
	} while(ret); // ret == -ERESTARTSYS
	del_timer(&ctl->async_hk_timer);
	if (atomic_read(&ctl->async_hk_timeout)) {
		if (atomic_read(&(md->core_md.ready)) == 0) {
			MTK_ERR_LOG(FSM, "MD handshake timeout\n");
			if (atomic_read(&(md->core_md.handshake_ongoing)) == 1)
				fsm_append_event(ctl, CCCI_EVENT_MD_HS2_EXIT, NULL, 0);
		}
		if (atomic_read(&(md->core_sap.ready)) == 0) {
			MTK_ERR_LOG(FSM, "AP handshake timeout\n");
			if (atomic_read(&(md->core_sap.handshake_ongoing)) == 1)
				fsm_append_event(ctl, CCCI_EVENT_AP_HS2_EXIT, NULL, 0);
		}
		fsm_routine_exception(ctl, NULL, EXCEPTION_HS_TIMEOUT);
		fsm_finish_command(ctl, cmd, -1);
	} else if (atomic_read(&ctl->exp_flg)) {
		MTK_ERR_LOG(FSM,"md exception is captured during handshake\n");
		if (atomic_read(&(md->core_md.ready)) == 0 && atomic_read(&(md->core_md.handshake_ongoing)) == 1)
			fsm_append_event(ctl, CCCI_EVENT_MD_HS2_EXIT, NULL, 0);
		if (atomic_read(&(md->core_sap.ready)) == 0 && atomic_read(&(md->core_sap.handshake_ongoing)) == 1)
			fsm_append_event(ctl, CCCI_EVENT_AP_HS2_EXIT, NULL, 0);

		ccci_switch_hif_cfg(md->index, HIF_PATH_CTRL, HIF_CFG1);
		ccci_switch_hif_cfg(md->index, HIF_PATH_CTRL_1, HIF_CFG_DEF);
		fsm_finish_command(ctl, cmd, -1);
	} else {
		MTK_NOTICE_LOG(FSM, "ccci boot handshake done, md status:%d, sAP status:%d\n",\
					atomic_read(&(md->core_md.ready)), atomic_read(&(md->core_sap.ready)));
		mtk_pci_pm_init_late(md->mtk_dev);
		fsm_append_command(ctl, CCCI_COMMAND_READY, 0);
		fsm_finish_command(ctl, cmd, 1);
	}
}

static int fsm_main_thread(void *data)
{
	struct ccci_fsm_ctl *ctl = (struct ccci_fsm_ctl *)data;
	struct ccci_fsm_command *cmd = NULL;
	unsigned long flags;
	int reason;
	int ret = 0;

	while (1) {
		ret = wait_event_interruptible(ctl->command_wq,
			(!list_empty(&ctl->command_queue) ||
			kthread_should_stop()));
			if (ret == -ERESTARTSYS)
				continue;	/* FIXME */
		if (kthread_should_stop())
			break;

		spin_lock_irqsave(&ctl->command_lock, flags);
		cmd = list_first_entry(&ctl->command_queue,
			struct ccci_fsm_command, entry);
		// delete first, otherwise hard to peek
		//next command in routines
		list_del(&cmd->entry);
		spin_unlock_irqrestore(&ctl->command_lock, flags);

		MTK_INFO_LOG(FSM, "command %d process\n", cmd->cmd_id);
		switch (cmd->cmd_id) {
		case CCCI_COMMAND_PRE_START:
			fsm_routine_pre_start(ctl, cmd);
			break;
		case CCCI_COMMAND_START:
			fsm_routine_starting(ctl, cmd);
			break;
		case CCCI_COMMAND_READY:
			fsm_routine_ready(ctl, cmd);
			break;
		case CCCI_COMMAND_EXCEPTION:
			reason = ((cmd->flag)>>16)& 0xFF;
			fsm_routine_exception(ctl, cmd, reason);
			break;
		case CCCI_COMMAND_PRE_STOP:
			fsm_routine_stopping(ctl, cmd);
			break;
		case CCCI_COMMAND_STOP:
			fsm_routine_stopped(ctl, cmd);
			break;
		default:
			MTK_ERR_LOG(FSM, "Invalid command %d \n", cmd->cmd_id);
			fsm_finish_command(ctl, cmd, -1);
			fsm_routine_zombie(ctl);
			break;
		};

	}
	return 0;
}


int fsm_append_ex_cmd(struct ccci_fsm_ctl *ctl,
	CCCI_FSM_COMMAND cmd_id, unsigned int flag, unsigned int reason)
{
	int result = 0;
	unsigned int cmd_flag;

	cmd_flag = (((reason & 0xFF)<<16)|(flag & 0xFF));
	result = fsm_append_command(ctl, cmd_id, cmd_flag);

	return result;
}


int fsm_append_command(struct ccci_fsm_ctl *ctl,
	CCCI_FSM_COMMAND cmd_id, unsigned int flag)
{
	struct ccci_fsm_command *cmd = NULL;
	int result = 0;
	unsigned long flags;

	if (cmd_id <= CCCI_COMMAND_INVALID || cmd_id >= CCCI_COMMAND_MAX) {
		MTK_ERR_LOG(FSM, "invalid command %d\n", cmd_id);
		return -CCCI_ERR_INVALID_PARAM;
	}
	cmd = kmalloc(sizeof(struct ccci_fsm_command),
		(in_irq() || in_softirq() ||
		irqs_disabled()) ? GFP_ATOMIC : GFP_KERNEL);
	if (!cmd) {
		MTK_ERR_LOG(FSM,
			"fail to alloc memory for command %d\n", cmd_id);
		return -CCCI_ERR_GET_MEM_FAIL;
	}
	INIT_LIST_HEAD(&cmd->entry);
	init_waitqueue_head(&cmd->complete_wq);
	cmd->cmd_id = cmd_id;
	cmd->complete = 0;
	if (in_irq() || irqs_disabled())
		flag &= ~FSM_CMD_FLAG_WAIT_FOR_COMPLETE;
	cmd->flag = flag;

	spin_lock_irqsave(&ctl->command_lock, flags);
	list_add_tail(&cmd->entry, &ctl->command_queue);
	spin_unlock_irqrestore(&ctl->command_lock, flags);
	MTK_INFO_LOG(FSM, "command %d is appended %x from %ps\n",
		cmd->cmd_id, cmd->flag, __builtin_return_address(0));
	/* after this line, only dereference cmd when "wait-for-complete" */
	wake_up(&ctl->command_wq);
	if (flag & FSM_CMD_FLAG_WAIT_FOR_COMPLETE) {
		if (in_irq() || in_softirq())
			MTK_ERR_LOG(FSM, "Not to block in atomic context!\n");
		wait_event(cmd->complete_wq, cmd->complete != 0);
		if (cmd->complete != 1)
			result = -1;
		spin_lock_irqsave(&ctl->cmd_complete_lock, flags);
		kfree(cmd);
		spin_unlock_irqrestore(&ctl->cmd_complete_lock, flags);
	}
	return result;
}

static void fsm_finish_command(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_command *cmd, int result)
{
	unsigned long flags;

	MTK_INFO_LOG(FSM,
		"command %d is completed %d by %ps\n", cmd->cmd_id, result,
		__builtin_return_address(0));
	if (cmd->flag & FSM_CMD_FLAG_WAIT_FOR_COMPLETE) {
		spin_lock_irqsave(&ctl->cmd_complete_lock, flags);
		cmd->complete = result;
		/* do not dereference cmd after this line */
		wake_up_all(&cmd->complete_wq);
		// after cmd in list, processing thread may see
		//it without being waked up, so spinlock is needed
		spin_unlock_irqrestore(&ctl->cmd_complete_lock, flags);
	} else {
		/* no one is waiting for this cmd, free to free */
		kfree(cmd);
	}
}

int fsm_append_event(struct ccci_fsm_ctl *ctl, CCCI_FSM_EVENT event_id,
	unsigned char *data, unsigned int length)
{
	struct ccci_fsm_event *event = NULL;
	unsigned long flags;

	if (event_id <= CCCI_EVENT_INVALID || event_id >= CCCI_EVENT_MAX) {
		MTK_ERR_LOG(FSM, "invalid event %d\n", event_id);
		return -CCCI_ERR_INVALID_PARAM;
	}
	event = kmalloc(sizeof(struct ccci_fsm_event) + length,
		in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);
	if (!event) {
		MTK_ERR_LOG(FSM, "fail to alloc event%d\n", event_id);
		return -CCCI_ERR_GET_MEM_FAIL;
	}
	INIT_LIST_HEAD(&event->entry);
	event->event_id = event_id;
	event->length = length;
	if (data && length)
		memcpy(event->data, data, length);

	spin_lock_irqsave(&ctl->event_lock, flags);
	list_add_tail(&event->entry, &ctl->event_queue);
	spin_unlock_irqrestore(&ctl->event_lock, flags);
	wake_up_all(&ctl->event_wq);
	/* do not derefence event after here */
	MTK_INFO_LOG(FSM, "event %d is appended from %ps\n", event_id,
		__builtin_return_address(0));
	return 0;
}

/* must be called within protection of event_lock */
static void fsm_finish_event(struct ccci_fsm_ctl *ctl,
	struct ccci_fsm_event *event)
{
	list_del(&event->entry);
	MTK_INFO_LOG(FSM, "event %d is completed by %ps\n", event->event_id,
			__builtin_return_address(0));
	kfree(event);
}

void fsm_clear_event(struct ccci_fsm_ctl *ctl, CCCI_FSM_EVENT event_id)
{
	struct ccci_fsm_event *event, *evt_next;
	unsigned long flags;

	spin_lock_irqsave(&ctl->event_lock, flags);
	list_for_each_entry_safe(event, evt_next, &ctl->event_queue, entry) {
		MTK_ERR_LOG(FSM, "unhandled event %d\n", event->event_id);
		if (event->event_id == event_id)
			fsm_finish_event(ctl, event);
	}
	spin_unlock_irqrestore(&ctl->event_lock, flags);
}

struct ccci_fsm_ctl *fsm_get_entity_by_device_number(dev_t dev_n)
{
	int i;

	for (i = 0; i < ARRAY_SIZE(ccci_fsm_entries); i++) {
		if (ccci_fsm_entries[i] &&
			ccci_fsm_entries[i]->monitor_ctl.dev_n == dev_n)
			return ccci_fsm_entries[i];
	}
	return NULL;
}

struct ccci_fsm_ctl *fsm_get_entity_by_md_id(int md_id)
{
	int i;

	for (i = 0; i < ARRAY_SIZE(ccci_fsm_entries); i++) {
		if (ccci_fsm_entries[i] && ccci_fsm_entries[i]->md_id == md_id)
			return ccci_fsm_entries[i];
	}
	return NULL;
}

enum MD_STATE ccci_fsm_get_md_state(int md_id)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	if (ctl)
		return ctl->md_state;
	else
		return INVALID;
}

unsigned int ccci_fsm_get_current_state(int md_id)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	if (ctl)
		return ctl->curr_state;
	else
		return CCCI_FSM_STOPPED;
}
enum MD_STATE_FOR_USER ccci_fsm_get_md_state_for_user(int md_id)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	if (!ctl)
		return MD_STATE_INVALID;
	switch (ctl->md_state) {
	case INVALID:
	case WAITING_TO_STOP:
		return MD_STATE_INVALID;
	case RESET:
	case BOOT_WAITING_FOR_HS1:
	case BOOT_WAITING_FOR_HS2:
		return MD_STATE_BOOTING;
	case READY:
		return MD_STATE_READY;
	case EXCEPTION:
		return MD_STATE_EXCEPTION;
	default:
		MTK_ERR_LOG(FSM, "Invalid md_state %d\n", ctl->md_state);
		return MD_STATE_INVALID;
	}
}

int ccci_fsm_recv_md_interrupt(int md_id, MD_IRQ_TYPE type)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	if (!ctl)
		return -CCCI_ERR_INVALID_PARAM;

	if (type == MD_IRQ_PORT_ENUM) {
		fsm_append_command(ctl, CCCI_COMMAND_PRE_START, 0);
	} else if (type == MD_IRQ_CCIF_EX) {
		/*interrupt handshake flow*/
		atomic_set(&ctl->exp_flg, 1);
		wake_up(&ctl->async_hk_wq);
		fsm_md_exception_stage(&ctl->ee_ctl, 0);
		fsm_append_ex_cmd(ctl, CCCI_COMMAND_EXCEPTION, 0, EXCEPTION_EE);
	}
	return 0;
}

int ccci_fsm_recv_control_packet(int md_id, unsigned int ctrl_msg_id, struct sk_buff *skb)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);
	int ret = 0, free_skb = 1;

	if (!ctl)
		return -CCCI_ERR_INVALID_PARAM;

	switch (ctrl_msg_id) {
	/*exception handshake message*/
	case CTL_ID_MD_EX:
	case CTL_ID_MD_EX_REC_OK:
	case CTL_ID_MD_EX_PASS:
	case CCCI_DRV_VER_ERROR:
		fsm_ee_message_handler(&ctl->ee_ctl, skb);
		break;
	default:
		MTK_ERR_LOG(FSM,
			"unknown control message to fsm %x\n", ctrl_msg_id);
		break;
	}
	if (free_skb)
		ccci_free_skb(skb);
	return ret;
}

void fsm_set_state(struct ccci_fsm_ctl *ctl, int last_state, int cur_state)
{
	ctl->last_state = last_state;
	ctl->curr_state = cur_state;
	return;
}

int ccci_fsm_reset(int md_id)
{
	struct ccci_fsm_ctl *ctl;

	ctl = ccci_fsm_entries[md_id];

	if (ctl == NULL) {
		MTK_ERR_LOG(FSM, "Invlid value for ccci_fsm_ctl \n");
		return -EINVAL;
	}

	//Clear the event queue and command queue
	fsm_routine_zombie(ctl);

	ctl->md_id = md_id;
	ctl->last_state = CCCI_FSM_INIT;
	ctl->curr_state = CCCI_FSM_STOPPED;
	atomic_set(&ctl->fs_ongoing, 0);
	atomic_set(&ctl->async_hk_timeout, 0);
	atomic_set(&ctl->exp_flg, 0);
	ctl->sap_state_ctl.last_dummy_reg = 0;

	fsm_ee_reset(&ctl->ee_ctl);
	fsm_monitor_reset(&ctl->monitor_ctl);
	return 0;
}

int ccci_fsm_init(int md_id)
{
	struct ccci_fsm_ctl *ctl;

	if (md_id < 0 || md_id >= ARRAY_SIZE(ccci_fsm_entries))
		return -CCCI_ERR_INVALID_PARAM;

	ctl = kzalloc(sizeof(struct ccci_fsm_ctl), GFP_KERNEL);
	ccci_fsm_entries[md_id] = ctl;
	ctl->md_id = md_id;
	ctl->last_state = CCCI_FSM_INIT;
	ctl->curr_state = CCCI_FSM_INIT;
	atomic_set(&ctl->fs_ongoing, 0);
	ctl->sap_state_ctl.last_dummy_reg = 0;
	INIT_LIST_HEAD(&ctl->command_queue);
	INIT_LIST_HEAD(&ctl->event_queue);
	init_waitqueue_head(&ctl->async_hk_wq);
	init_waitqueue_head(&ctl->event_wq);
	INIT_LIST_HEAD(&ctl->notifier_list);
	init_waitqueue_head(&ctl->command_wq);
	spin_lock_init(&ctl->event_lock);
	spin_lock_init(&ctl->command_lock);
	spin_lock_init(&ctl->cmd_complete_lock);
	atomic_set(&ctl->fs_ongoing, 0);
	atomic_set(&ctl->async_hk_timeout, 0);
	atomic_set(&ctl->exp_flg, 0);
	spin_lock_init(&ctl->notifier_lock);

	ctl->fsm_thread =
		kthread_run(fsm_main_thread, ctl, "ccci_fsm%d", md_id + 1);
	fsm_ee_init(&ctl->ee_ctl);
	fsm_monitor_init(&ctl->monitor_ctl);

	return 0;
}

int ccci_fsm_uninit(int md_id)
{
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	if (ctl) {
		if (ctl->fsm_thread) {
			MTK_INFO_LOG(FSM, "Before stop fsm thread.\n");
			stop_brom_event_start_timer(ctl);
			kthread_stop(ctl->fsm_thread);
			MTK_INFO_LOG(FSM, "Stop fsm thread\n");
		}
		MTK_INFO_LOG(FSM, "fsm monitor exit.\n");
		fsm_monitor_uninit(&ctl->monitor_ctl);
		MTK_INFO_LOG(FSM, "fsm ee exit.\n");
		fsm_ee_uninit(&ctl->ee_ctl);
		fsm_routine_zombie(ctl);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(ctl);
#else		
		kzfree(ctl);
#endif		
		ccci_fsm_entries[md_id] = NULL;
	}
	return 0;
}


