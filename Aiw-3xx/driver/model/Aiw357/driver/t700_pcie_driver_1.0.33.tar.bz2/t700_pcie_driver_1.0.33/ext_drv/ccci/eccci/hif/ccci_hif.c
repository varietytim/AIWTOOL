// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/types.h>
#include <linux/ktime.h>

#include "ccci_debug.h"
#include "ccci_core.h"
#include "ccci_hif_cldma.h"
#include "ccci_hif_mhccif.h"

#ifdef M7X
#include "ccci_hif_dpmaif.h"
#endif
#include "ccci_event.h"
#define TAG "hif"

hif_id_type ccci_hif_path[MAX_MD_NUM][HIF_PATH_MAX];

void *ccci_hif[MAX_MD_NUM][HIF_ID_MAX]={0};

int ccci_hif_get_queue_mtu(unsigned char md_id,
	unsigned int path_id, unsigned char qno)
{
	unsigned int mtu = CCCI_MTU;
	unsigned char hif_id = ccci_hif_path[md_id][path_id];

	switch (hif_id) {
	case HIF_ID_CLDMA_PCIE:
	case HIF_ID_CLDMA0_PCIE:
		mtu = normal_tx_queue_buffer_size[qno];
		break;
	}
	return mtu;
}

void ccci_switch_hif_cfg(unsigned char md_id,
	hif_path_type path_id, unsigned int cfg_id)
{
	unsigned char hif_id = -1;

	if (path_id > HIF_PATH_MAX) {
		MTK_ERR_LOG(TAG, "invalid input:path id is error\n");
		return;
	}
	hif_id = ccci_hif_path[md_id][path_id];
	switch (hif_id) {
	case HIF_ID_CLDMA_PCIE:
	case HIF_ID_CLDMA0_PCIE:
		switch_cldma_cfg(md_id, hif_id, cfg_id);
		break;
	default:
		break;
	}
}

int ccci_hif_init(unsigned char md_id, unsigned int path_flag)
{
	unsigned char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;
#ifdef CCCI_CTL_TRACE
	unsigned char trace_log[TRACE_LOG_LEN] = {0};

	snprintf(trace_log, TRACE_LOG_LEN,
		"md_id:%d, path_flag:%d", md_id, path_flag);
	trace_ccci_hif_init(trace_log);
#endif /* CCCI_CTL_TRACE */
	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_hif_init(md_id, hif_id);
			break;
#ifdef M7X
		case HIF_ID_DPMAIF_PCIE:
			ret = ccci_dpmaif_hif_init(md_id, hif_id);
			break;
#endif
		case HIF_ID_PCIE:
			ret = ccci_mhccif_hif_init(md_id, hif_id);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to init hif, hif_id = %d\n", hif_id);
			break;
		}

		pflag++;
	}
#ifdef CCCI_CTL_TRACE
	memset(trace_log, 0, TRACE_LOG_LEN);
	snprintf(trace_log, TRACE_LOG_LEN, "hif_id:%d, ret:%d", hif_id, ret);
	trace_ccci_hif_init(trace_log);
#endif /* CCCI_CTL_TRACE */
	return ret;
}


int ccci_hif_hw_init(unsigned char md_id, unsigned int path_flag)
{
	unsigned char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;
#ifdef CCCI_CTL_TRACE
	unsigned char trace_log[TRACE_LOG_LEN] = {0};

	snprintf(trace_log, TRACE_LOG_LEN,
		"md_id:%d, path_flag:%d", md_id, path_flag);
	trace_ccci_hif_init(trace_log);
#endif /* CCCI_CTL_TRACE */
	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_hif_hw_init(md_id, hif_id);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to init hif, hif_id = %d\n", hif_id);
			break;
		}

		pflag++;
	}
	return ret;
}


int ccci_hif_late_init(unsigned char md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_late_init(md_id, hif_id);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to init hif, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}

	return ret;
}

int ccci_hif_send_skb(unsigned char md_id, unsigned int path_flag,
	unsigned char tx_qno,
	struct sk_buff *skb, unsigned char from_pool, unsigned char blocking)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
#ifdef M7X
		case HIF_ID_DPMAIF_PCIE:
			ret = ccci_dpma_hif_send_skb(md_id,
				hif_id, tx_qno, skb, from_pool, blocking);
			break;
#endif
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_hif_send_skb(md_id, hif_id,
				tx_qno, skb, from_pool, blocking);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to send packet, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}
	return ret;

}

int ccci_hif_write_room(unsigned char md_id, unsigned char path_id,
	unsigned char qno)
{
	int ret = 0;
	unsigned char hif_id = ccci_hif_path[md_id][path_id];
	switch (hif_id) {
	case HIF_ID_CLDMA_PCIE:
	case HIF_ID_CLDMA0_PCIE:
		ret = ccci_cldma_write_room(md_id, hif_id, qno);
		break;
	default:
		break;
	}
	return ret;
}

int ccci_hif_ask_more_request(unsigned char md_id,
	unsigned int path_flag, unsigned char rx_qno)
{
	char hif_id = -1;

	int ret = 0;

	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to ask more request, hif_id = %d\n",
				hif_id);
			break;
		}
		pflag++;
	}

	return ret;
}

int ccci_hif_dump_status(unsigned char md_id, unsigned int path_flag,
	enum modem_dump_flag dump_flag, void *data, int length)
{
	char hif_id = -1;

	int ret = 0;

	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_hif_dump_status(md_id,
				hif_id, dump_flag, data, length);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to dump status, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}

	return ret;
}

int ccci_hif_set_wakeup_src(unsigned char md_id,
	unsigned int path_flag, int value)
{

	char hif_id = -1;

	int ret = 0;

	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to wakeup src, hif_id = %d", hif_id);
			break;
		}

		pflag++;
	}

	return ret;

}

int ccci_hif_start(unsigned char md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_hif_start(md_id, hif_id);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to start hif, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}

	return ret;

}

int ccci_hif_stop(unsigned char md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ccci_cldma_hif_stop(md_id, hif_id);
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to stop hif, hif_id = %d\n", hif_id);
			break;
		}

		pflag++;
	}

	return ret;
}
int ccci_hif_start_queue(unsigned char md_id, unsigned int path_flag,
	unsigned char qno, enum direction dir)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to start queue, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}

	return ret;


}
int ccci_hif_stop_queue(unsigned char md_id, unsigned int path_flag,
	unsigned char qno, enum direction dir)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to stop queue, hif_id = %d\n", hif_id);
			break;
		}

		pflag++;
	}
	return ret;
}

int ccci_hif_stop_for_ee(unsigned char md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to stop hif for excepton, hif_id = %d\n",
				hif_id);
			break;
		}

		pflag++;
	}
	return ret;
}

int ccci_hif_clear(unsigned int md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to clear hif, hif_id = %d\n", hif_id);
			break;
		}

		pflag++;
	}
	return ret;
}

void ccci_hif_reset(u8 md_id, unsigned int path_flag, char is_hw)
{
	char hif_id = -1;

	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ccci_cldma_hif_reset(md_id, hif_id, is_hw);
			break;
		default:
			break;
		}
		pflag++;
	}
}

int ccci_hif_clear_all_queue(u8 md_id, unsigned int path_flag, enum direction dir)
{
		unsigned char hif_id = -1;
		int ret = 0;
		hif_path_type pflag = HIF_PATH_CTRL;

		while (pflag < HIF_PATH_MAX) {
			if ((1 << pflag) & path_flag)
				hif_id = ccci_hif_path[md_id][pflag];
			else
				hif_id = -1;

			switch (hif_id) {
			case HIF_ID_CLDMA_PCIE:
			case HIF_ID_CLDMA0_PCIE:
				ret = ccci_cldma_clear_all_queue(
					md_id, hif_id, dir);
				break;
			default:
				break;
			}
			if (ret != 0) {
				MTK_ERR_LOG(TAG,
					"failed to clear all queue, hif_id = %d\n",
					hif_id);
				break;
			}
			pflag++;
		}

		return ret;
}

int ccci_hif_allQreset_work(unsigned int md_id, unsigned int path_flag)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id =  ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to reset work, hif_id = %d\n", hif_id);
			break;
		}
		pflag++;
	}
	return ret;
}


int ccci_hif_exception(unsigned char md_id,
	unsigned int path_flag, HIF_EX_STAGE stage)
{
	char hif_id = -1;
	int ret = 0;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_exception(md_id, hif_id, stage);
			break;
		default:
			break;
		}
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to process hif exception, hif_id = %d\n",
				hif_id);
			break;
		}
		pflag++;
	}

	return ret;
}

int ccci_hif_ex_handshake(unsigned char md_id, unsigned int hif_id,
	HIF_EX_STAGE stage)
{
	int ret = 0;

	switch (hif_id) {
	case HIF_ID_PCIE:
		ret = ccci_mhccif_ex_handshake(md_id, hif_id, stage);
		break;
	default:
		break;
	}
	return ret;
}

int ccci_hif_get_hw_info(unsigned char md_id, unsigned int path_flag,
	struct mtk_pci_dev *dev_ptr)
{
	char hif_id = -1;
	void *ret = NULL;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;
		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			ret = ccci_cldma_get_hw_info(
				md_id, hif_id, dev_ptr);
			break;
#ifdef M7X
		case HIF_ID_DPMAIF_PCIE:
			ret = ccci_dpmaif_get_hw_info(
				md_id, hif_id, dev_ptr);
			break;
#endif
		case HIF_ID_PCIE:
			ret = ccci_mhccif_get_hw_info(
				md_id, hif_id, dev_ptr);
			break;
		default:
			break;
		}
		if (!ret) {
			MTK_ERR_LOG(TAG,
				"failed to get hw info, hif_id = %d\n", hif_id);
			return -1;
		}
		pflag++;
	}

	return 0;
}

void *get_rt_header(unsigned char md_id, unsigned int path_flag, int tx_ch,
	int packet_size, unsigned int txqno, int skb_from_pool)
{
	char hif_id = -1;
	void *ret = NULL;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
			ret = cldma_hif_fill_rt_header(md_id,
				hif_id, packet_size, tx_ch, txqno);
			break;
		default:
			break;
		}
		if (ret == NULL) {
			MTK_WARN_LOG(TAG,
				"warning: get runtime header, hif_id = %d\n",
				hif_id);
			break;
		}
		pflag++;
	}

	return ret;
}


unsigned long ccci_hif_get_event_id(unsigned char md_id, unsigned int hif_id)
{
	unsigned long ret = 0;

	switch (hif_id) {
	case HIF_ID_CLDMA_PCIE:
		break;
	case HIF_ID_PCIE:
		ret = ccci_mhccif_get_int_id(md_id, hif_id);
		break;
	default:
		break;
	}
	return ret;
}

//=========== newly added ====================
#ifdef M7X
int ccci_hif_state_notification(unsigned char md_id, unsigned char state)
{
	int ret = 0;

	switch (state) {
	case BOOT_WAITING_FOR_HS1:
		if (ccci_hif_get_by_id(md_id, HIF_ID_DPMAIF_PCIE) != NULL)
			ret = dpmaif_start(md_id, HIF_ID_DPMAIF_PCIE);
		break;
	case READY:
		break;
	case EXCEPTION:
		/* maybe we can move here */
		if (ccci_hif_get_by_id(md_id, HIF_ID_DPMAIF_PCIE) != NULL) {
			ccci_hif_dump_status(md_id,
				HIF_FLAG_DATA, DUMP_FLAG_REG, NULL, 0);
			/* dpmaif_stop_hw(md_id, hif_id); */
			dpmaif_pos_stop_hw(md_id, HIF_ID_DPMAIF_PCIE);
		}
		break;
	case RESET:
	case WAITING_TO_STOP:
		if (ccci_hif_get_by_id(md_id, HIF_ID_DPMAIF_PCIE) != NULL)
			dpmaif_stop_hw(md_id, HIF_ID_DPMAIF_PCIE);
		break;

	case STOPPED:
		if (ccci_hif_get_by_id(md_id, HIF_ID_DPMAIF_PCIE) != NULL)
			ret = dpmaif_stop(md_id, HIF_ID_DPMAIF_PCIE);
		break;
	default:
		break;
	}
	return ret;
}
#endif

void ccci_hif_uninit(unsigned char md_id, unsigned int path_flag)
{
	char hif_id = -1;
	hif_path_type pflag = HIF_PATH_CTRL;

	while (pflag < HIF_PATH_MAX) {
		if ((1 << pflag) & path_flag)
			hif_id = ccci_hif_path[md_id][pflag];
		else
			hif_id = -1;

		switch (hif_id) {
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			cldma_hif_exit(md_id, hif_id);
			break;
#ifdef M7X
		case HIF_ID_DPMAIF_PCIE:
			ccci_dpmaif_hif_exit(md_id, hif_id);
			break;
#endif
		case HIF_ID_PCIE:
			ccci_mhccif_hif_exit(md_id, hif_id);
			break;
		default:
			break;
		}
		pflag++;
	}
}

