/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_HIF_INTERNAL_H__
#define __CCCI_HIF_INTERNAL_H__

#include "ccci_core.h"
#include "ccci_port.h"
#include "ccci_fsm.h"
#include "ccci_hif.h"
#include "ccci_modem.h"

#define MAX_TXQ_NUM (16)
#define MAX_RXQ_NUM (16)
#define PACKET_HISTORY_DEPTH 16	/* must be power of 2 */

struct ccci_log {
	struct ccci_header msg;
	u64 tv;
	int droped;
};

struct ccci_hif_traffic {
#if PACKET_HISTORY_DEPTH
	struct ccci_log tx_history[MAX_TXQ_NUM][PACKET_HISTORY_DEPTH];
	struct ccci_log rx_history[MAX_RXQ_NUM][PACKET_HISTORY_DEPTH];
	int tx_history_ptr[MAX_TXQ_NUM];
	int rx_history_ptr[MAX_RXQ_NUM];
#endif
	unsigned long logic_ch_pkt_cnt[CCCI_MAX_CH_NUM];
	unsigned long logic_ch_pkt_pre_cnt[CCCI_MAX_CH_NUM];
	short seq_nums[2][CCCI_MAX_CH_NUM];

	unsigned long long latest_isr_time;
	unsigned long long latest_q_rx_isr_time[MAX_RXQ_NUM];
	unsigned long long latest_q_rx_time[MAX_RXQ_NUM];

	/* interrupt statistics */
	unsigned long long isr_cnt;
	unsigned long long rx_done_isr_cnt[MAX_RXQ_NUM];
	unsigned long long tx_done_isr_cnt[MAX_TXQ_NUM];
	unsigned long long rx_isr_bat_len_err_cnt[MAX_RXQ_NUM];
	unsigned long long rx_isr_pit_len_err_cnt[MAX_RXQ_NUM];

	/* others */
	unsigned long long poll_pit_empty[MAX_RXQ_NUM];
	unsigned long long rx_tasket_cnt;
	unsigned long long isr_time_bak;
	unsigned long long rx_full_cnt;
	unsigned long long rx_other_isr_cnt[MAX_RXQ_NUM];
	unsigned long long tx_other_isr_cnt[MAX_RXQ_NUM];
};

struct ccci_hif_ops {
	/* must-have */
	int (*send_skb)(unsigned char md_id, unsigned char hif_id,
		int qno, struct sk_buff *skb, int skb_from_pool, int blocking);
	int (*give_more)(unsigned char md_id,
		unsigned char hif_id, unsigned char qno);
	int (*write_room)(unsigned char md_id,
		unsigned char hif_id, unsigned char qno);
	int (*start_queue)(unsigned char md_id,
		unsigned char hif_id, unsigned char qno, enum direction dir);
	int (*stop_queue)(unsigned char md_id,
		unsigned char hif_id, unsigned char qno, enum direction dir);
//	int (*broadcast_state)(unsigned char hif_id, enum MD_STATE state);
	int (*dump_status)(unsigned char md_id, unsigned char hif_id,
		enum modem_dump_flag dump_flag, void *data, int length);
	int (*set_wakeup_src)(unsigned char md_id,
		unsigned char hif_id, int value);
	int (*hif_start)(unsigned char md_id, unsigned char hif_id);
	int (*hif_stop)(unsigned char md_id, unsigned char hif_id);
	int (*hif_stop_for_ee)(unsigned char md_id, unsigned char hif_id);
	int (*hif_clear)(unsigned char md_id, unsigned char hif_id);
	int (*hif_reset)(unsigned char md_id,
		unsigned char hif_id, unsigned char is_hw);
	int (*hif_clear_all_queue)(unsigned char md_id,
		unsigned char hif_id, enum direction dir);
	int (*hif_allQreset_work)(unsigned char md_id, unsigned char hif_id);
};

enum RX_COLLECT_RESULT {
	ONCE_MORE,
	ALL_CLEAR,
	LOW_MEMORY,
	ERROR_STOP,
};

static void ccci_md_dump_log_rec(unsigned char md_id, struct ccci_log *log)
{
	u64 ts_nsec = log->tv;
	unsigned long rem_nsec;

	if (ts_nsec == 0)
		return;
	rem_nsec = do_div(ts_nsec, 1000000000);
	if (!log->droped) {
		MTK_DEBUG_LOG(CORE,
			"%08X %08X %08X %08X  %5lu.%06lu\n",
			log->msg.data[0], log->msg.data[1],
			*(((u32 *)&log->msg) + 2), log->msg.reserved,
			(unsigned long)ts_nsec, rem_nsec / 1000);
	} else {
		MTK_DEBUG_LOG(CORE,
			"%08X %08X %08X %08X  %5lu.%06lu -\n",
			log->msg.data[0], log->msg.data[1],
			*(((u32 *)&log->msg) + 2), log->msg.reserved,
			(unsigned long)ts_nsec, rem_nsec / 1000);
	}
}

static inline void ccci_md_add_log_history(struct ccci_hif_traffic *tinfo,
	enum direction dir, int queue_index, struct ccci_header *msg, int is_droped)
{
#ifdef PACKET_HISTORY_DEPTH
	if (dir == MTK_OUT) {
		memcpy(&tinfo->tx_history[queue_index][tinfo->tx_history_ptr[queue_index]].msg,
			msg, sizeof(struct ccci_header));
		tinfo->tx_history[queue_index][tinfo->tx_history_ptr[queue_index]].tv
			= local_clock();
		tinfo->tx_history[queue_index][tinfo->tx_history_ptr[queue_index]].droped
			= is_droped;
		tinfo->tx_history_ptr[queue_index]++;
		tinfo->tx_history_ptr[queue_index] &=
			(PACKET_HISTORY_DEPTH - 1);
	}
	if (dir == MTK_IN) {
		memcpy(&tinfo->rx_history[queue_index][tinfo->rx_history_ptr[queue_index]].msg,
			msg, sizeof(struct ccci_header));
		tinfo->rx_history[queue_index][tinfo->rx_history_ptr[queue_index]].tv
			= local_clock();
		tinfo->rx_history[queue_index][tinfo->rx_history_ptr[queue_index]].droped
			= is_droped;
		tinfo->rx_history_ptr[queue_index]++;
		tinfo->rx_history_ptr[queue_index] &=
			(PACKET_HISTORY_DEPTH - 1);
	}
#endif
}

static inline void ccci_md_dump_log_history(
	unsigned char md_id, struct ccci_hif_traffic *tinfo,
	int dump_multi_rec, int tx_queue_num, int rx_queue_num)
{
#ifdef PACKET_HISTORY_DEPTH
	int i, j;
	int tx_num = 0;
	int rx_num = 0;

	if (dump_multi_rec) {
		for (i = 0; i < ((tx_queue_num <= MAX_TXQ_NUM) ?
			tx_queue_num : MAX_TXQ_NUM); i++) {
			MTK_DEBUG_LOG(CORE,
				"dump txq%d packet history, ptr=%d\n",
				i, tinfo->tx_history_ptr[i]);
			for (j = 0; j < PACKET_HISTORY_DEPTH; j++)
				ccci_md_dump_log_rec(md_id,
				&tinfo->tx_history[i][j]);
		}
		for (i = 0; i < ((rx_queue_num <= MAX_RXQ_NUM) ?
			rx_queue_num : MAX_RXQ_NUM); i++) {
			MTK_DEBUG_LOG(CORE,
				"dump rxq%d packet history, ptr=%d\n",
				i, tinfo->rx_history_ptr[i]);
			for (j = 0; j < PACKET_HISTORY_DEPTH; j++)
				ccci_md_dump_log_rec(md_id,
				&tinfo->rx_history[i][j]);
		}
	} else {
		tx_num = (tx_queue_num <= MAX_TXQ_NUM) ?
			tx_queue_num : MAX_TXQ_NUM;
		rx_num = (rx_queue_num <= MAX_RXQ_NUM) ?
			rx_queue_num : MAX_RXQ_NUM;

		if (tx_num >= 0) {
			MTK_DEBUG_LOG(CORE,
				"dump txq%d packet history, ptr=%d\n",
				tx_num, tinfo->tx_history_ptr[tx_num]);
			for (j = 0; j < PACKET_HISTORY_DEPTH; j++)
				ccci_md_dump_log_rec(md_id,
					&tinfo->tx_history[tx_num][j]);
		}

		if (rx_num >= 0) {
			MTK_DEBUG_LOG(CORE,
				"dump rxq%d packet history, ptr=%d\n",
				rx_num, tinfo->rx_history_ptr[rx_num]);
			for (j = 0; j < PACKET_HISTORY_DEPTH; j++)
				ccci_md_dump_log_rec(md_id,
					&tinfo->rx_history[rx_num][j]);
		}
	}
#endif
}


static inline void *ccci_hif_get_by_id(unsigned char md_id,
	unsigned char hif_id)
{
	if (md_id >= MAX_MD_NUM || hif_id >= HIF_ID_MAX) {
		MTK_ERR_LOG(CORE,
			"ccci_hif_get_by_id md_id = %u, hif_id = %u\n",
			md_id, hif_id);
		return NULL;
	} else
		return ccci_hif[md_id][hif_id];
}

static inline void ccci_hif_queue_status_notify(int md_id,
	int hif_id, int qno, int dir, int state)
{
	return ccci_port_queue_status_notify(md_id, hif_id, qno, dir, state);
}


static inline void ccci_reset_seq_num(struct ccci_hif_traffic *traffic_info)
{
	/* it's redundant to use 2 arrays,
	 * but this makes sequence checking easy
	 */
	memset(traffic_info->seq_nums[MTK_OUT], 0,
		sizeof(traffic_info->seq_nums[MTK_OUT]));
	memset(traffic_info->seq_nums[MTK_IN], -1,
		sizeof(traffic_info->seq_nums[MTK_IN]));
}

/*
 * as one channel can only use one hardware queue,
 * so it's safe we call this function in hardware queue's lock protection
 */
static inline void ccci_md_inc_tx_seq_num(unsigned char md_id,
	struct ccci_hif_traffic *traffic_info, struct ccci_header *ccci_h)
{
	if (ccci_h->channel >= ARRAY_SIZE(traffic_info->seq_nums[MTK_OUT])
		|| ccci_h->channel < 0) {
		MTK_ERR_LOG(CORE,
			"ignore seq inc on channel %x\n",
			*(((u32 *) ccci_h) + 2));
		return;		/* for force assert channel, etc. */
	}
	ccci_h->seq_num = traffic_info->seq_nums[MTK_OUT][ccci_h->channel]++;
	ccci_h->assert_bit = 1;
	// for rpx channel, can only set assert_bit
	//when md is in single-task phase.
	// when md is in multi-task phase, assert bit
	//should be 0, since ipc task are preemptible
	if ((ccci_h->channel == CCCI_RPC_TX || ccci_h->channel == CCCI_FS_TX) &&
		ccci_fsm_get_md_state(md_id) != BOOT_WAITING_FOR_HS2)
		ccci_h->assert_bit = 0;
}

static inline void ccci_md_check_rx_seq_num(unsigned char md_id,
	struct ccci_hif_traffic *traffic_info,
	struct ccci_header *ccci_h, int qno)
{
	u16 channel, seq_num, assert_bit;
	unsigned int param[3] = {0};

	channel = ccci_h->channel;
	seq_num = ccci_h->seq_num;
	assert_bit = ccci_h->assert_bit;

	if (assert_bit && traffic_info->seq_nums[MTK_IN][channel] != 0 &&
		((seq_num - traffic_info->seq_nums[MTK_IN][channel])
		& 0x7FFF) != 1) {
		MTK_ERR_LOG(CORE,
			"channel %d seq number out-of-order %d->%d (data: %X, %X)\n",
			channel, seq_num,
			traffic_info->seq_nums[MTK_IN][channel],
			ccci_h->data[0], ccci_h->data[1]);
		ccci_md_dump_info(md_id, DUMP_FLAG_DATA_HIF, NULL, qno);
		param[0] = channel;
		param[1] = traffic_info->seq_nums[MTK_IN][channel];
		param[2] = seq_num;
		ccci_md_force_assert(md_id, MD_FORCE_ASSERT_BY_MD_SEQ_ERROR,
			(char *)param, sizeof(param));
	} else {
		traffic_info->seq_nums[MTK_IN][channel] = seq_num;
	}
}

static inline void ccci_channel_update_packet_counter(
	unsigned long *logic_ch_pkt_cnt, struct ccci_header *ccci_h)
{
	if ((ccci_h->channel & 0xFFFF) < CCCI_MAX_CH_NUM)
		logic_ch_pkt_cnt[ccci_h->channel]++;
}

static inline void ccci_channel_dump_packet_counter(unsigned char md_id,
	struct ccci_hif_traffic *traffic_info)
{
	MTK_DEBUG_LOG(CORE,
		"traffic(ch): tx:[%d]%ld, [%d]%ld rx:[%d]%ld, [%d]%ld\n",
		CCCI_CONTROL_TX,
		traffic_info->logic_ch_pkt_cnt[CCCI_CONTROL_TX],
		CCCI_FS_TX, traffic_info->logic_ch_pkt_cnt[CCCI_FS_TX],
		CCCI_CONTROL_RX,
		traffic_info->logic_ch_pkt_cnt[CCCI_CONTROL_RX],
		CCCI_FS_RX, traffic_info->logic_ch_pkt_cnt[CCCI_FS_RX]);
}

static inline unsigned int ccci_md_get_seq_num(
	struct ccci_hif_traffic *traffic_info, enum direction dir, enum ccci_ch ch)
{
	return traffic_info->seq_nums[dir][ch];
}

static inline void hif_traffic_init(struct ccci_hif_traffic *tinfo)
{
	int qno_index = 0;
	int chn_index = 0;

	if (tinfo == NULL) {
		MTK_ERR_LOG("hif", "%s parameter error\n", __func__);
		return;
	}
	tinfo->latest_isr_time = 0;
	tinfo->isr_cnt = 0;
	for (qno_index = 0; qno_index < MAX_RXQ_NUM; qno_index++) {
		tinfo->latest_q_rx_isr_time[qno_index] = 0;
		tinfo->latest_q_rx_time[qno_index] = 0;
		tinfo->rx_done_isr_cnt[qno_index] = 0;
#if PACKET_HISTORY_DEPTH
		tinfo->rx_history_ptr[qno_index] = 0;
#endif
	}
	for (qno_index = 0; qno_index < MAX_TXQ_NUM; qno_index++) {
		tinfo->tx_done_isr_cnt[qno_index] = 0;
#if PACKET_HISTORY_DEPTH
		tinfo->tx_history_ptr[qno_index] = 0;
#endif
	}
	for (chn_index = 0; chn_index < CCCI_MAX_CH_NUM; chn_index++) {
		tinfo->logic_ch_pkt_cnt[chn_index] = 0;
		tinfo->logic_ch_pkt_pre_cnt[chn_index] = 0;
	}
}

#endif
