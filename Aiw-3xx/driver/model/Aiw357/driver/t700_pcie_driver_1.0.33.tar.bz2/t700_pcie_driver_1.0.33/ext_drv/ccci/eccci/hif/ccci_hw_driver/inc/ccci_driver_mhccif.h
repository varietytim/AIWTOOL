/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __MODEM_MHCCIFHW_H__
#define __MODEM_MHCCIFHW_H__

#include "ccci_driver.h"

struct mhccif_hw_info {
	void __iomem *ap_mhccif_base;
	void __iomem *md_mhccif_base;
	/* HW info - Interrutpt ID */
	u32 irq_id;
	atomic_t irq_enable;
};

//static struct mhccif_hw_info hw_info;

void mhccif_driver_init(struct ccci_hw_ctrl *hw_ctrl);


extern bool mhccif_ep2rc_reg_read(struct mtk_pci_dev *mtk_dev,u32 *reg);
extern void mtk_pcie_clear_ccif_int(u32 reg);
extern void mhccif_rc2ep_swint_trigger(struct mtk_pci_dev *mtk_dev,u32 channel);



#endif

