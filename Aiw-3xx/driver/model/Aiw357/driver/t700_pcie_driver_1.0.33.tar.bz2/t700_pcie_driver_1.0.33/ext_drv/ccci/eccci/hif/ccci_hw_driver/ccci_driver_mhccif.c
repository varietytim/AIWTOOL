// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_driver_mhccif.h"
#include "ccci_debug.h"

#define TAG			"mhccif"

#define CCCI_INF_MSG(idx, tag, fmt, args...)\
	CCCI_NORMAL_LOG(idx, tag, fmt, ##args)


static void mhccif_hw_init(struct ccci_hw_ctrl *hw_ctrl)
{
	struct mhccif_hw_info *hw_info;

	hw_info = (struct mhccif_hw_info *)hw_ctrl->private;
}

static void mhccif_hw_send(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno)
{
	struct mhccif_hw_info *hw_info;
	
	if(unlikely(hw_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid arguments");
		return;
	}
	
	hw_info = (struct mhccif_hw_info *)hw_ctrl->private;

	//call mhccif driver API to write register
	MTK_DEBUG_LOG(TAG, "qno-%d\n", qno);
	mhccif_rc2ep_swint_trigger(hw_ctrl->mtk_dev, qno);
}

static void mhccif_hw_reset(struct ccci_hw_ctrl *hw_ctrl)
{
	struct mhccif_hw_info *hw_info;

	hw_info = (struct mhccif_hw_info *)hw_ctrl->private;
}

static unsigned int mhccif_hw_rx_done(
	struct ccci_hw_ctrl *hw_ctrl, unsigned int bitmask)
{
	unsigned int ch_id = 0;

	if (true == mhccif_ep2rc_reg_read(hw_ctrl->mtk_dev, &ch_id)) {
		ch_id = ch_id & bitmask;
	//mtk_pcie_clear_ccif_int(ch_id); //pcie mhccif driver will ack irq
	} else {
		MTK_ERR_LOG(TAG, "mhccif ep2rc reg error.");
	}
	MTK_DEBUG_LOG(TAG, "ch_id=%08x\n", ch_id);
	return ch_id;
}

static unsigned int mhccif_hw_tx_done(
	struct ccci_hw_ctrl *hw_ctrl, unsigned int bitmask)
{
	return 0;
}

static void mhccif_hw_dump(struct ccci_hw_ctrl *hw_ctrl)
{
	struct mhccif_hw_info *hw_info;

	hw_info = (struct mhccif_hw_info *)hw_ctrl->private;
}

#ifdef CONFIG_MTK_ECCCI_SIMULATOR_UT
static struct ccci_hw_ops ccci_hw_mhccif_ops = {
	.ccci_hw_init = NULL,
	.ccci_hw_reset = NULL,
	.ccci_hw_dump = NULL,
	.ccci_hw_clear = NULL,
	.ccci_hw_send = NULL,
	.ccci_hw_start = NULL,
	.ccci_hw_stop = NULL,
	.ccci_hw_start_queue = NULL,
	.ccci_hw_stop_queue = NULL,
	.ccci_hw_resume_queue = NULL,
	.ccci_hw_rx_done = NULL,
	.ccci_hw_tx_done = NULL,
};
#else
static struct ccci_hw_ops ccci_hw_mhccif_ops = {
	.ccci_hw_init = &mhccif_hw_init,
	.ccci_hw_reset = &mhccif_hw_reset,
	.ccci_hw_dump = &mhccif_hw_dump,
	.ccci_hw_clear = NULL,
	.ccci_hw_send = &mhccif_hw_send,
	.ccci_hw_start = NULL,
	.ccci_hw_stop = NULL,
	.ccci_hw_start_queue = NULL,
	.ccci_hw_stop_queue = NULL,
	.ccci_hw_resume_queue = NULL,
	.ccci_hw_rx_done = &mhccif_hw_rx_done,
	.ccci_hw_tx_done = &mhccif_hw_tx_done,

};
#endif

void mhccif_driver_init(struct ccci_hw_ctrl *hw_ctrl)
{
	hw_ctrl->opts = &ccci_hw_mhccif_ops;
}


