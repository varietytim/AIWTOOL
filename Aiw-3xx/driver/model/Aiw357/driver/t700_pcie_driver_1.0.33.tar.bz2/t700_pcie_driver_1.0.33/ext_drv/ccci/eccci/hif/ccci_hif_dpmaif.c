// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/ip.h>
#include <linux/random.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/syscore_ops.h>
#include <linux/version.h>
#include "ccci_config.h"
#include "ccci_core.h"
#include "modem_sys.h"
#include "ccci_bm.h"
#include "ccci_platform.h"
#include "ccci_hif_dpmaif.h"
#include "md_sys1_platform.h"
#include "modem_reg_base.h"
#include "ccci_fsm.h"
#include "ccci_port.h"
#include "dpmaif_hif_platform.h"
#include "mtk-pci-ext.h"        // for PCIE driver interfaces
#include "ccci_hif_dpmaif_ut.h"


#if defined(CCCI_SKB_TRACE)
#undef TRACE_SYSTEM
#define TRACE_SYSTEM ccci

#include <linux/tracepoint.h>
#endif

#define DP_UNUSED(x)   ((x) = (x))

#define TAG "DATA"

#define DPMF_QUERY_PCIE_INFO_CNT_MAX    (1500)
#define DPMF_POLL_SAME_PIT_CNT_MAX        (50)


#ifdef DPMA_FTRACE_DEBUG
static u64 g_total_isr;
static u64 g_pkt_cnt_per_isr;
#endif

/* operates HW info lock */
#define LOCK_DPMF_RESOURCE(lock, flags) spin_lock_irqsave(&(lock), flags)
#define UNLOCK_DPMF_RESOURCE(lock, flags) \
	spin_unlock_irqrestore(&(lock), flags)

/* DPMAIF throughput statistics */
#ifdef DATA_PATH_DL_TP_CALC
static struct dpmaif_tp_statistics g_dpmf_tp_stat;
#endif

/* CPU information */
#define DPMF_GET_CUR_CPU(cpu) {\
	*(cpu) = get_cpu(); \
	put_cpu(); \
}

#define DPMF_CUR_CPU_INVALID    (-1)

/* CPU CACHE LINE */
unsigned long g_DPMAIF_CACHE_LINE_SIZE;


/* =======================================================
 *
 * Descriptions: Debug part
 *
 * ========================================================
 */

#if defined(CCCI_SKB_TRACE)
TRACE_EVENT(ccci_skb_rx,
	TP_PROTO(unsigned long long *dl_delay),
	TP_ARGS(dl_delay),
	TP_STRUCT__entry(
		__array(unsigned long long, dl_delay, 8)
	),

	TP_fast_assign(
		memcpy(__entry->dl_delay, dl_delay,
			8*sizeof(unsigned long long));
	),

	TP_printk(
	"    %llu    %llu    %llu    %llu    %llu    %llu    %llu    %llu",
		__entry->dl_delay[0], __entry->dl_delay[1],
		__entry->dl_delay[2], __entry->dl_delay[3],
		__entry->dl_delay[4], __entry->dl_delay[5],
		__entry->dl_delay[6], __entry->dl_delay[7])
);
#endif

static void dpmaif_dump_register(struct md_dpmaif_ctrl *hif_ctrl,
	int buf_type)
{
	/* TBD */
	/* FIX ME!!! */
}

void dpmaif_dump_reg(unsigned int md_id, unsigned char hif_id)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL)
		return;
   // dpmaif_dump_register(dpmaif_ctrl, CCCI_DUMP_REGISTER);
}
EXPORT_SYMBOL(dpmaif_dump_reg);

static void dpmaif_dump_rxq_history(struct md_dpmaif_ctrl *hif_ctrl,
	unsigned int qno, int dump_multi)
{
	unsigned char md_id = hif_ctrl->md_id;

	if (qno > DPMAIF_RXQ_NUM) {
		MTK_ERR_LOG(TAG, "Invalid rxq%d\n", qno);
		return;
	}
	ccci_md_dump_log_history(md_id, &hif_ctrl->traffic_info,
			dump_multi, -1, qno);
}

static void dpmaif_dump_txq_history(struct md_dpmaif_ctrl *hif_ctrl,
	unsigned int qno, int dump_multi)
{
	unsigned char md_id = hif_ctrl->md_id;

	if (qno > DPMAIF_TXQ_NUM) {
		MTK_ERR_LOG(TAG, "Invalid txq%d\n", qno);
		return;
	}
	ccci_md_dump_log_history(md_id, &hif_ctrl->traffic_info,
			dump_multi, qno, -1);
}

static void dpmaif_dump_rxq_remain(struct md_dpmaif_ctrl *hif_ctrl,
	unsigned int qno, int dump_multi)
{
	int i, rx_qno;
	unsigned char md_id = hif_ctrl->md_id;
	struct dpmaif_rx_queue *rxq;

	if (!dump_multi && (qno > DPMAIF_RXQ_NUM)) {
		MTK_ERR_LOG(TAG, "Invalid rxq%d\n", qno);
		return;
	}

	if (dump_multi) {
		rx_qno = ((qno <= MAX_RXQ_NUM) ? qno : MAX_RXQ_NUM);
		i = 0;
	} else {
		i = qno;
		rx_qno = qno + 1;
	}
	for (; i < rx_qno; i++) {
		rxq = &hif_ctrl->rxq[i];
		/* rxq struct dump */
		MTK_DEBUG_LOG(TAG, "dump rxq(%d): 0x%p\n",
			i, rxq);
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP, (void *)rxq,
			(int)sizeof(struct dpmaif_rx_queue));
		/* PIT mem dump */
		MTK_DEBUG_LOG(TAG,
			"pit request base: 0x%p(%d*%d)\n",
			rxq->pit_base,
			(int)sizeof(struct dpmaifq_normal_pit),
			rxq->pit_size_cnt);
		MTK_DEBUG_LOG(TAG,
			"Current rxq%d pit pos: w/r/rel=%x, %x, %x\n", i,
			rxq->pit_wr_idx,
			rxq->pit_rd_idx,
			rxq->pit_rel_rd_idx);
		ccci_util_mem_dump(-1, CCCI_DUMP_MEM_DUMP, rxq->pit_base,
			(rxq->pit_size_cnt *
			sizeof(struct dpmaifq_normal_pit)));
		/* BAT mem dump */
		MTK_DEBUG_LOG(TAG,
			"bat request base: 0x%p(%d*%d)\n",
			rxq->bat_req.bat_base,
			(int)sizeof(struct dpmaif_bat_t),
			rxq->bat_req.bat_size_cnt);
		MTK_DEBUG_LOG(TAG,
			"Current rxq%d bat pos: w/r/rel=%x, %x, %x\n", i,
			rxq->bat_req.bat_wr_idx, rxq->bat_req.bat_rd_idx,
			rxq->bat_req.bat_rel_rd_idx);
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP,
			rxq->bat_req.bat_base,
			(rxq->bat_req.bat_size_cnt *
			sizeof(struct dpmaif_bat_t)));
		/* BAT SKB mem dump */
		MTK_DEBUG_LOG(TAG, "bat skb base: 0x%p(%d*%d)\n",
			rxq->bat_req.bat_skb_ptr,
			(int)sizeof(struct dpmaif_bat_skb_t),
			rxq->bat_req.bat_size_cnt);
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP,
			rxq->bat_req.bat_skb_ptr,
			(rxq->bat_req.skb_pkt_cnt *
			sizeof(struct dpmaif_bat_skb_t)));

	}
}

static void dpmaif_dump_txq_remain(struct md_dpmaif_ctrl *hif_ctrl,
	unsigned int qno, int dump_multi)
{
	struct dpmaif_tx_queue *txq;
	int i, j;
	struct dpmaif_drb_skb *drb_skb = NULL;
	unsigned int count, size;
	char line_data[500] = {0};
	char tmp_data[10] = {0};
	unsigned char *data = NULL;

	txq = &hif_ctrl->txq[qno];
	count = txq->drb_size_cnt;
	size = sizeof(struct dpmaif_drb_msg);
	data = txq->drb_base;

	MTK_INFO_LOG(TAG, "============ DUMP TXQ%d BEGIN ============\n", qno);
	/* dump index */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	MTK_INFO_LOG(TAG,
		"write_index(%u), read_index(%u), rel_index(%u), drb_cnt(%u), drb_msg_size(%u), drb_skb_base(0x%p), drb_base(0x%p), budget(%d), busy_cnt(%u)\n",
		txq->drb_wr_idx, txq->drb_rd_idx, txq->drb_wr_idx,
		count, size, txq->drb_skb_base, txq->drb_base,
		txq->tx_budget, atomic_read(&(txq->busy_count)));
#else
	MTK_INFO_LOG(TAG,
		"write_index(%u), read_index(%u), rel_index(%u), drb_cnt(%u), drb_msg_size(%u), drb_skb_base(0x%p), drb_base(0x%p), budget(%d)\n",
		txq->drb_wr_idx, txq->drb_rd_idx, txq->drb_wr_idx,
		count, size, txq->drb_skb_base, txq->drb_base,
		atomic_read(&(txq->tx_budget)));
#endif

	/* dump drb skb */
	MTK_INFO_LOG(TAG, "DRB SKB INFO:%u\n", qno);
	for (i = 0; i < count; i++) {
		drb_skb = (struct dpmaif_drb_skb *)txq->drb_skb_base + i;
		MTK_INFO_LOG(TAG,
			"drb_idx(%u), clone_buffer(0x%p), skb(0x%p), phy_addr(0x%llx), data_len(%u), is_frg(%u), is_last_one(%u), is_msg(%u)\n",
			drb_skb->drb_idx, drb_skb->clone_buffer, drb_skb->skb,
			drb_skb->phy_addr, drb_skb->data_len, drb_skb->is_frag,
			drb_skb->is_last_one, drb_skb->is_msg);
	}

	/* dump drb buffer */
	MTK_INFO_LOG(TAG, "DRB INFO:%u\n", qno);
	for (i = 0; i < count; i++) {
		memset(line_data, 0, sizeof(line_data));

		for (j = 0; j < size; j++) {
			snprintf(tmp_data, 4, "%02X ",
				(unsigned char)data[i*size + j]);
			strncat(line_data, tmp_data, 3);
		}
		MTK_INFO_LOG(TAG,
			"0x%04X~0x%04X:  %s\n",
			i*size, (i+1)*size, line_data);
	}

	MTK_INFO_LOG(TAG, "============ DUMP TXQ%u END =============\n", qno);
}

/*actrually, length is dump flag's private argument*/
static int dpmaif_dump_status(unsigned char md_id, unsigned char hif_id,
	enum modem_dump_flag dump_flag, void *data, int length)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	int i, q_bitmap = 0;
	unsigned int dir = 1 << MTK_OUT | 1 << MTK_IN;

	if (dump_flag & DUMP_FLAG_REG) {
		dpmaif_dump_register(hif_ctrl, CCCI_DUMP_MEM_DUMP);
		q_bitmap = length;
	}
	if (dump_flag & DUMP_FLAG_QUEUE_0)
		q_bitmap = 0x1;
	if (dump_flag & DUMP_FLAG_QUEUE_0_1) {
		q_bitmap = 0x3;
		if (length != 0)
			dir = length;
	}
	MTK_DEBUG_LOG(TAG, "q_bitmap = %d\n", q_bitmap);

	if (q_bitmap == -1) {
		dpmaif_dump_rxq_history(hif_ctrl, DPMAIF_RXQ_NUM, 1);
		dpmaif_dump_rxq_remain(hif_ctrl, DPMAIF_RXQ_NUM, 1);
		dpmaif_dump_txq_history(hif_ctrl, DPMAIF_TXQ_NUM, 1);
		dpmaif_dump_txq_remain(hif_ctrl, DPMAIF_TXQ_NUM, 1);
	} else {
		for (i = 0; q_bitmap && i < DPMAIF_TXQ_NUM; i++) {
			dpmaif_dump_rxq_history(hif_ctrl, i, 0);
			dpmaif_dump_rxq_remain(hif_ctrl, i, 0);
			dpmaif_dump_txq_history(hif_ctrl, i, 0);
			dpmaif_dump_txq_remain(hif_ctrl, i, 0);
			q_bitmap &= ~(1 << i);
		}
	}

	return 0;
}

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
static void dpmaif_clear_traffic_data(
	unsigned char md_id, unsigned char hif_id)
{
	struct md_dpmaif_ctrl *hif_ctrl =
		(struct md_dpmaif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	memset(hif_ctrl->tx_traffic_monitor, 0,
		sizeof(hif_ctrl->tx_traffic_monitor));
	memset(hif_ctrl->rx_traffic_monitor, 0,
		sizeof(hif_ctrl->rx_traffic_monitor));
	memset(hif_ctrl->tx_pre_traffic_monitor, 0,
		sizeof(hif_ctrl->tx_pre_traffic_monitor));
	memset(hif_ctrl->tx_payload_monitor, 0,
		sizeof(hif_ctrl->tx_payload_monitor));
	memset(hif_ctrl->tx_done_last_count, 0,
		sizeof(hif_ctrl->tx_done_last_count));
	memset(hif_ctrl->tx_done_last_start_time, 0,
		sizeof(hif_ctrl->tx_done_last_start_time));

	hif_ctrl->traffic_info.isr_time_bak = 0;
	hif_ctrl->traffic_info.isr_cnt = 0;
	hif_ctrl->traffic_info.rx_full_cnt = 0;

	hif_ctrl->traffic_info.rx_done_isr_cnt[0] = 0;
	hif_ctrl->traffic_info.rx_other_isr_cnt[0] = 0;
	hif_ctrl->traffic_info.rx_tasket_cnt = 0;

	hif_ctrl->traffic_info.tx_done_isr_cnt[0] = 0;
	hif_ctrl->traffic_info.tx_done_isr_cnt[1] = 0;
	hif_ctrl->traffic_info.tx_done_isr_cnt[2] = 0;
	hif_ctrl->traffic_info.tx_done_isr_cnt[3] = 0;

	hif_ctrl->traffic_info.tx_other_isr_cnt[0] = 0;
	hif_ctrl->traffic_info.tx_other_isr_cnt[1] = 0;
	hif_ctrl->traffic_info.tx_other_isr_cnt[2] = 0;
	hif_ctrl->traffic_info.tx_other_isr_cnt[3] = 0;
}

static inline unsigned int dpmaif_align_buf_avail_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index);
static inline unsigned int dpmaif_skb_avail_cnt
	(struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index);


static void dpmaif_traffic_monitor_func(struct timer_list *t)
{
	struct md_dpmaif_ctrl *hif_ctrl = from_timer(
		hif_ctrl, t, traffic_monitor);
	struct ccci_hif_traffic *tinfo = &hif_ctrl->traffic_info;
	unsigned long q_rx_rem_nsec[DPMAIF_RXQ_NUM] = {0};
	unsigned long isr_rem_nsec;
	int i, q_state = 0;
	unsigned long long total_tx_cnt = 0;
	unsigned long long total_pre_tx_cnt = 0;
	unsigned long long total_tx_payload_cnt = 0;
	unsigned long long total_rx_cnt = 0;
	unsigned int ul_vail_cnt = 0;
	unsigned int dl_vail_cnt = 0;
	u64 dl_bytes_cnt, dl_rec_start_tm, dl_tm_now, dl_tm_del;

#ifdef DATA_PATH_DL_TP_CALC
	unsigned int dl_tp_calc = ccci_dp_dl_tp_calc;
#endif

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		if (hif_ctrl->txq[i].busy_count != 0) {
			MTK_DEBUG_LOG(TAG,
				"Txq%d(%d) busy count %d\n",
				i, hif_ctrl->txq[i].que_started,
				hif_ctrl->txq[i].busy_count);
			hif_ctrl->txq[i].busy_count = 0;
		}
		q_state |= (hif_ctrl->txq[i].que_started << i);
		MTK_DEBUG_LOG(TAG,
			"Current txq%d pos: w/r/rel=%d, %d, %d\n", i,
			hif_ctrl->txq[i].drb_wr_idx,
			hif_ctrl->txq[i].drb_rd_idx,
			hif_ctrl->txq[i].drb_rel_rd_idx);
	}

	/* calculates total tx packets count */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		total_tx_cnt += hif_ctrl->tx_traffic_monitor[i];
		total_pre_tx_cnt += hif_ctrl->tx_pre_traffic_monitor[i];
		total_tx_payload_cnt += hif_ctrl->tx_payload_monitor[i];
	}

	if (3 < DPMAIF_TXQ_NUM)
		MTK_DEBUG_LOG(TAG,
			"net Txq0-3(status=0x%x):%d-%d-%d, %d-%d-%d, %d-%d-%d, %d-%d-%d\n",
			q_state, atomic_read(&hif_ctrl->txq[0].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[0],
			hif_ctrl->tx_traffic_monitor[0],
			atomic_read(&hif_ctrl->txq[1].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[1],
			hif_ctrl->tx_traffic_monitor[1],
			atomic_read(&hif_ctrl->txq[2].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[2],
			hif_ctrl->tx_traffic_monitor[2],
			atomic_read(&hif_ctrl->txq[3].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[3],
			hif_ctrl->tx_traffic_monitor[3]);

	isr_rem_nsec = (tinfo->latest_isr_time == 0 ?
		0 : do_div(tinfo->latest_isr_time, NSEC_PER_SEC));
	MTK_DEBUG_LOG(TAG,
		"net Rx ISR %lu.%06lu, active %d\n",
		(unsigned long)tinfo->latest_isr_time, isr_rem_nsec / 1000,
		hif_ctrl->rxq[0].que_started);
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		/* calculates total rx packets count */
		total_rx_cnt += hif_ctrl->rx_traffic_monitor[i];

		q_rx_rem_nsec[i] = (tinfo->latest_q_rx_isr_time[i] == 0 ?
			0 : do_div(tinfo->latest_q_rx_isr_time[i],
			NSEC_PER_SEC));
		MTK_DEBUG_LOG(TAG, "net RX:%lu.%06lu, %d\n",
			(unsigned long)tinfo->latest_q_rx_isr_time[i],
			q_rx_rem_nsec[i] / 1000,
			hif_ctrl->rx_traffic_monitor[i]);

		q_rx_rem_nsec[i] = (tinfo->latest_q_rx_time[i] == 0 ?
			0 : do_div(tinfo->latest_q_rx_time[i], NSEC_PER_SEC));
		MTK_DEBUG_LOG(TAG, "net RXq%d:%lu.%06lu\n",
			i, (unsigned long)tinfo->latest_q_rx_time[i],
			q_rx_rem_nsec[i] / 1000);
	}

	/* DL throughput */
#ifdef DATA_PATH_DL_TP_CALC
	if (dl_tp_calc) {
		if (true == g_dpmf_tp_stat.rx_rec_enable) {
			/* total DL bytes count */
			dl_bytes_cnt = g_dpmf_tp_stat.rx_num;

			dl_tm_now = DPMA_UT_TIME_NOW();
			dl_rec_start_tm = g_dpmf_tp_stat.rx_rec_start_tm;
			g_dpmf_tp_stat.rx_rec_enable = false;

			/* total time */
			dl_tm_del = dl_tm_now - dl_rec_start_tm;
		}

		MTK_INFO_LOG(TAG,
			"#[HIF-DPMAIF-THROUGHPUT], [DL], (total bytes, total time): #%llu#%llu\n",
			dl_bytes_cnt, dl_tm_del);

		if (false == g_dpmf_tp_stat.rx_rec_enable) {
			g_dpmf_tp_stat.rx_num = 0;
			g_dpmf_tp_stat.rx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_rx_pkt = true;

			/* this setting should be last */
			g_dpmf_tp_stat.rx_rec_enable = true;
		}
	} else {
		if (true == g_dpmf_tp_stat.rx_rec_enable) {
			g_dpmf_tp_stat.rx_rec_enable = false;
			g_dpmf_tp_stat.rx_num = 0;
			g_dpmf_tp_stat.rx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_rx_pkt = true;
		}
	}
#endif

	/* debug log for total tx, rx packets count */
	MTK_DEBUG_LOG(TAG,
		"TX_RX info: tx_count = %llu, tx_done_count = %llu, tx_payload_count = %llu, rx_count = %llu\n",
		total_pre_tx_cnt, total_tx_cnt,
		total_tx_payload_cnt, total_rx_cnt);

	/* interrupt count */
	MTK_DEBUG_LOG(TAG,
		"INTERRUPT info: total(%llu), tx_0(%llu), tx_1(%llu), tx_2(%llu), tx_3(%llu), rx0(%llu)\n",
		tinfo->isr_cnt,
		tinfo->tx_done_isr_cnt[0],
		tinfo->tx_done_isr_cnt[1],
		tinfo->tx_done_isr_cnt[2],
		tinfo->tx_done_isr_cnt[3],
		tinfo->rx_done_isr_cnt[0]);
	/* error interrupt count */
	MTK_DEBUG_LOG(TAG,
		"ERROR INTERRUPT: bat_len_err(%llu), pit_len_err(%llu)\n",
		tinfo->rx_isr_bat_len_err_cnt[0],
		tinfo->rx_isr_pit_len_err_cnt[0]);

	/* poll pit empty count */
	MTK_DEBUG_LOG(TAG,
		"POLL EMPTY PIT %llu time(s)\n", tinfo->poll_pit_empty[0]);

	/* available UL align buffer count */
	for (i = 0; i < DPMA_ALIGN_QUEUE_CNT; i++) {
		ul_vail_cnt = dpmaif_align_buf_avail_cnt(hif_ctrl, i);
		MTK_DEBUG_LOG(TAG,
			"UL align queue%d avail_cnt(%u)\n", i, ul_vail_cnt);
	}

	/* available DL skb count */
	for (i = 0; i < DPMA_SKB_QUEUE_CNT; i++) {
		dl_vail_cnt = dpmaif_skb_avail_cnt(hif_ctrl, i);
		MTK_DEBUG_LOG(TAG,
			"DL skb queue%d avail_cnt(%u)\n", i, dl_vail_cnt);
	}

	mod_timer(&hif_ctrl->traffic_monitor,
			jiffies + DPMAIF_TRAFFIC_MONITOR_INTERVAL * HZ);
}


#endif

/* =======================================================
 *
 * Descriptions: common part
 *
 * ========================================================
 */

static int dpmaif_queue_broadcast_state(struct md_dpmaif_ctrl *hif_ctrl,
	enum HIF_STATE state, enum direction dir, unsigned char index)
{
	MTK_DEBUG_LOG(TAG,
		"%s sta(q%d) %d\n", ((dir == MTK_IN) ? "RX":"TX"), (int)index,
		(int)state);

	ccci_port_queue_status_notify(hif_ctrl->md_id, hif_ctrl->hif_id,
		(int)index, dir, state);
	return 0;
}

static int dpmaif_give_more(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL)
		return 0;

#ifndef DATA_PATH_NET_NAPI_MODE
	tasklet_hi_schedule(&dpmaif_ctrl->rxq[0].dpmaif_rxq0_task);
#endif
	return 0;
}

static int dpmaif_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_dpmaif_ctrl *hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	if (qno >= DPMAIF_TXQ_NUM)
		return -CCCI_ERR_INVALID_QUEUE_INDEX;
	return atomic_read(&hif_ctrl->txq[qno].tx_budget);
}

static unsigned int     ring_buf_get_next_wrdx(unsigned int  buf_len,
	unsigned int buf_idx)
{
	buf_idx++;
	if (buf_idx >= buf_len)
		buf_idx -= buf_len;
	return buf_idx;
}

static unsigned int ring_buf_readable(unsigned int    total_cnt,
	unsigned int rd_idx, unsigned int  wrt_idx)
{
	unsigned int pkt_cnt = 0;

	if (wrt_idx >= rd_idx)
		pkt_cnt = wrt_idx - rd_idx;
	else
		pkt_cnt = total_cnt + wrt_idx - rd_idx;

	return pkt_cnt;
}

static unsigned int ring_buf_writeable(unsigned int     total_cnt,
	unsigned int rel_idx, unsigned int    wrt_idx)
{
	unsigned int pkt_cnt = 0;

	if (wrt_idx < rel_idx)
		pkt_cnt = rel_idx - wrt_idx - 1;
	else
		pkt_cnt = total_cnt + rel_idx - wrt_idx - 1;

	return pkt_cnt;
}

static unsigned int ring_buf_releasable(unsigned int  total_cnt,
	unsigned int rel_idx, unsigned int    rd_idx)
{
	unsigned int pkt_cnt = 0;

	if (rel_idx <= rd_idx)
		pkt_cnt = rd_idx - rel_idx;
	else
		pkt_cnt = total_cnt + rd_idx - rel_idx;

	return pkt_cnt;
}

static inline unsigned int dpmaif_get_ul_read_index(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char qno)
{
	return dpmaif_hw_get_drb_rd_idx(qno);
}

static inline unsigned int dpmaif_get_dl_pit_write_index(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char qno)
{
	return dpmaif_hw_get_pit_wr_idx(qno);
}

static inline unsigned int dpmaif_get_dl_pit_read_index(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char qno)
{
	return dpmaif_hw_get_pit_rd_idx(qno);
}

static inline unsigned int dpmaif_get_dl_pkt_bat_read_index(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char qno)
{
	return dpmaif_hw_get_pkt_bat_rd_idx(qno);
}

static inline unsigned int dpmaif_get_dl_pkt_bat_write_index(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char qno)
{
	return dpmaif_hw_get_pkt_bat_wr_idx(qno);
}

static inline int dpmaif_add_pkt_bat_cnt(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char qno, unsigned int count)
{
	return dpmaif_hw_dl_add_pkt_bat_cnt(qno, count);
}

static inline int dpmaif_send_data(unsigned char qno, unsigned int drb_cnt)
{
	return dpmaif_hw_ul_add_wcnt(qno, drb_cnt);
}


static inline int dpmaif_add_pit_remain_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char qno, unsigned int count)
{
	return dpmaif_hw_dl_add_pit_remain_cnt(qno, count);
}

static inline struct device *dpmaif_get_hw_device(
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	return ((dpmaif_pcie_hw_info_ptr_t)dpmaif_ctrl->hif_hw_info)->pcie_dev;
}

/* =======================================================
 *
 * Descriptions: RX part start
 *
 * ========================================================
 */
extern int ccmni_rx_callback(
	int md_id, int ccmni_idx, struct sk_buff *skb, void *priv_data);

#if !defined(DATA_PATH_NET_NAPI_MODE) || defined(DATA_PATH_UT_LOOPBACK)
static inline int dpmaif_set_cpu_affinity(unsigned int cpu)
{
	return set_cpus_allowed_ptr(current, cpumask_of(cpu));
}

static inline bool dpmaif_rx_push_need_reschedule(
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	return (dpmaif_ctrl->rxq[0].cur_rx_thrd_cpu == DPMF_CUR_CPU_INVALID ||
		dpmaif_ctrl->rxq[0].cur_rx_thrd_cpu ==
		dpmaif_ctrl->rxq[0].cur_irq_cpu);
}

static inline int dpmaif_find_rx_push_cpu(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int cpu;
	bool found = false;

	for_each_online_cpu(cpu) {
		if (cpu != dpmaif_ctrl->rxq[0].cur_irq_cpu) {
			found = true;
			break;
		}
	}
	if (false == found)
		DPMF_GET_CUR_CPU(&cpu);


	MTK_DEBUG_LOG(TAG, "Rx_push_cpu(%d), cur_irq_cpu(%d)\n",
					cpu, dpmaif_ctrl->rxq[0].cur_irq_cpu);
	return cpu;
}

static inline void dpmaif_rx_push_thrd_reschedule(
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int cpu = -1;

	cpu = dpmaif_find_rx_push_cpu(dpmaif_ctrl);
	if (likely(!dpmaif_set_cpu_affinity(cpu))) {
		dpmaif_ctrl->rxq[0].cur_rx_thrd_cpu = cpu;
		MTK_DEBUG_LOG(TAG,
			"Schedule rx push thread(pid = %d) to cpu(%d)\n",
			current->pid, cpu);
	} else {
		MTK_ERR_LOG(TAG,
			"Try to schedule rx push thread(pid = %d) to cpu(%d) failed!\n",
			current->pid, cpu);
	}
}

static int dpmaif_net_rx_push_thread(void *arg)
{
	struct sk_buff *skb = NULL;
	struct dpmaif_rx_queue *queue = (struct dpmaif_rx_queue *)arg;
	struct md_dpmaif_ctrl *hif_ctrl = queue->dpmaif_ctrl;
#ifdef CCCI_SKB_TRACE
	struct ccci_per_md *per_md_data = ccci_get_per_md_data(hif_ctrl->md_id);
#endif
	int count = 0;
	int ret;
	int netif_id = 0;

	while (1) {
		if (skb_queue_empty(&queue->skb_list.skb_list)) {
			count = 0;
			ret = wait_event_interruptible(queue->rx_wq,
				(!skb_queue_empty(&queue->skb_list.skb_list) ||
				kthread_should_stop()));
			if (ret == -ERESTARTSYS)
				continue;    /* FIXME */
		}
		if (kthread_should_stop())
			break;

		if (dpmaif_rx_push_need_reschedule(hif_ctrl))
			dpmaif_rx_push_thrd_reschedule(hif_ctrl);


		skb = ccci_skb_dequeue(&queue->skb_list);
		if (!skb)
			continue;

#ifdef CCCI_SKB_TRACE
		per_md_data->netif_rx_profile[6] = sched_clock();
		if (count > 0)
			skb->tstamp = sched_clock();


#endif
		netif_id = ((struct lhif_header *)skb->data)->netif;
		skb_pull(skb, sizeof(struct lhif_header));

		ccmni_rx_callback(hif_ctrl->md_id, netif_id, skb, NULL);
		count++;

#ifdef CCCI_SKB_TRACE
		per_md_data->netif_rx_profile[6] = sched_clock() -
			per_md_data->netif_rx_profile[6];
		per_md_data->netif_rx_profile[5] = count;
		trace_ccci_skb_rx(per_md_data->netif_rx_profile);
#endif
	}
	return 0;
}
#endif

/* SW write, Update write index of ring buffer to HW */
static int dpmaifq_set_rx_bat(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned int bat_cnt)
{
	struct dpmaif_rx_queue *rxq = &dpmaif_ctrl->rxq[q_num];
	struct dpmaif_bat_request *bat_req = &rxq->bat_req;
	int ret = 0;
	unsigned short old_sw_rl_idx = 0, new_sw_wr_idx = 0, old_sw_wr_idx = 0;

	if ((rxq->que_started != true) ||
		(bat_cnt >= bat_req->bat_size_cnt)) {
		MTK_ERR_LOG(TAG, "que_started:%d, bat_cnt:%d\n",
			rxq->que_started, bat_cnt);
		return ret;
	}

	old_sw_rl_idx = bat_req->bat_rel_rd_idx;
	old_sw_wr_idx = bat_req->bat_wr_idx;
	new_sw_wr_idx = old_sw_wr_idx + bat_cnt;

	if (old_sw_rl_idx > old_sw_wr_idx) {
		if (new_sw_wr_idx >= old_sw_rl_idx) {
			MTK_ERR_LOG(TAG,
				"Rx bat flow check fail: new_sw_wr_idx >= old_sw_rl_idx\n");
			ret = FLOW_CHECK_ERR;
		}
	} else {
		if (new_sw_wr_idx >= bat_req->bat_size_cnt) {
			new_sw_wr_idx = new_sw_wr_idx - bat_req->bat_size_cnt;
			if (new_sw_wr_idx >= old_sw_rl_idx) {
				MTK_ERR_LOG(TAG,
					"Rx bat flow check fail: new_sw_wr_idx >= old_sw_rl_idx\n");
				ret = FLOW_CHECK_ERR;
			}
		}
	}
	if (ret < 0)
		goto exit;

	bat_req->bat_wr_idx = new_sw_wr_idx;

exit:
	MTK_DEBUG_LOG(TAG, "bat_cnt: %d ret: %d\n", bat_cnt, ret);
	return ret;
}

struct dpmaif_skb_info *dpmaif_skb_dequeue(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index);

#define GET_SKB_BY_ENTRY(skb_entry)  \
	list_entry(skb_entry, struct dpmaif_skb_info, entry)

static struct dpmaif_skb_info *dpmaif_skb_dma_map(
	struct md_dpmaif_ctrl *dpmaif_ctrl, struct sk_buff *skb)
{
	struct dpmaif_skb_info *skb_info = NULL;
	unsigned long long data_phy_addr;
	size_t data_len = 0;

	if (unlikely(skb == NULL))
		goto error;


	skb_info = kmalloc(sizeof(struct dpmaif_skb_info), GFP_KERNEL);
	if (unlikely(skb_info == NULL))
		goto error;


	/* DMA mapping */
	data_len = skb_data_size(skb);
	data_phy_addr = dma_map_single(
		dpmaif_get_hw_device(dpmaif_ctrl),
		skb->data,
		data_len,
		DMA_FROM_DEVICE);
	if (unlikely(dma_mapping_error(
		dpmaif_get_hw_device(dpmaif_ctrl), data_phy_addr))) {
		MTK_ERR_LOG(TAG, "Dma mapping fail\n");
		kfree(skb_info);
		skb_info = NULL;
		goto error;
	}

	skb_info->skb = skb;
	skb_info->data_len = data_len;
	skb_info->data_phy_addr = data_phy_addr;

#ifdef DPMAIF_DEBUG_DUMP
	MTK_DEBUG_LOG(TAG,
		"dma_map: Skb_info(%p), skb(%p), data_len(%zu), data_phy_addr(%llx)\n",
		skb_info, skb, data_len, data_phy_addr);
#endif

	return skb_info;
error:
	return NULL;
}

static void *dpmaif_alloc_skb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int size, int blocking)
{
	struct sk_buff *skb = NULL;
	unsigned int index = 0;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_info *skb_info = NULL;

	if (unlikely(size > DPMA_SKB_SIZE_MAX))
		goto from_kernel;


	for (index = 0; index < dpmaif_ctrl->skb_pool.queue_cnt; index++) {
		queue = &dpmaif_ctrl->skb_pool.queue[DPMA_SKB_QUEUE_CNT - 1 - index];
		if (size <= queue->size) {
			skb_info = dpmaif_skb_dequeue(
				dpmaif_ctrl,
				DPMA_SKB_QUEUE_CNT -
				1 - index);
			if (unlikely(skb_info == NULL ||
				skb_info->skb == NULL)) {
				MTK_DEBUG_LOG(TAG,
					"Dequeue from skb(%u) queue fail, try alloc form kernel\n",
					size);
				if (skb_info != NULL) {
					kfree(skb_info);
					skb_info = NULL;
				}
				goto from_kernel;
			}

			break;
		}
	}

	return skb_info;

from_kernel:
	skb = ccci_alloc_skb(size, 0, blocking);
	if (likely(skb)) {
		skb_info = dpmaif_skb_dma_map(dpmaif_ctrl, skb);
		if (unlikely(skb_info == NULL)) {
			MTK_INFO_LOG(TAG, "skb dma mapping fail\n");
			ccci_free_skb(skb);
			skb = NULL;
		}
	}
	return skb_info;
}

static int dpmaif_alloc_rx_buf(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req, unsigned char q_num,
	unsigned int buf_cnt, int blocking, bool first_time)
{
	struct sk_buff *new_skb = NULL;
	struct dpmaif_bat_t *cur_bat;
	struct dpmaif_bat_skb_t *cur_skb;
	struct dpmaif_skb_info *skb_info = NULL;
	int ret = 0, ret_hw = 0;
	unsigned int alloc_cnt, i;
	unsigned int bat_cnt, bat_max_cnt;
	unsigned short bat_star_idx, cur_bat_idx;
	unsigned long long data_base_addr;
	size_t data_len = 0;

	alloc_cnt = buf_cnt;
	if (alloc_cnt == 0 || alloc_cnt > bat_req->bat_size_cnt) {
		MTK_ERR_LOG(TAG, "Alloc_cnt is invalid !\n");
		return 0;
	}

	/*check bat buffer space*/
	bat_max_cnt = bat_req->bat_size_cnt;
	bat_cnt = ring_buf_writeable(bat_max_cnt, bat_req->bat_rel_rd_idx,
					bat_req->bat_wr_idx);

	MTK_DEBUG_LOG(TAG,
		"Alloc_cnt:%d, bat_size_cnt:%d, writeable bat_cnt: %d\n",
		alloc_cnt, bat_req->bat_size_cnt, bat_cnt);

	if (alloc_cnt > bat_cnt) {
		MTK_ERR_LOG(TAG, "Alloc bat buf not enough(%d>%d)\n",
			alloc_cnt, bat_cnt);
		return FLOW_CHECK_ERR;
	}

	bat_star_idx = bat_req->bat_wr_idx;

	/*Set buffer to be used*/
	for (i = 0 ; i < alloc_cnt ; i++) {
		cur_bat_idx = bat_star_idx + i;
		if (cur_bat_idx >= bat_max_cnt)
			cur_bat_idx = cur_bat_idx - bat_max_cnt;

		/* re-init check  */
		cur_skb = ((struct dpmaif_bat_skb_t *)bat_req->bat_skb_ptr +
			cur_bat_idx);
		if (cur_skb->skb == NULL) {
			skb_info = dpmaif_alloc_skb(
				dpmaif_ctrl, bat_req->pkt_buf_sz, blocking);
			if (likely(skb_info)) {
				new_skb = skb_info->skb;
				data_base_addr = skb_info->data_phy_addr;
				data_len = skb_info->data_len;
				/* we won't use skb_info any more, so free it */
				kfree(skb_info);
				skb_info = NULL;
			} else {
				MTK_ERR_LOG(TAG, "Dpmaif alloc skb fail\n");
				break;
			}

			if (unlikely(!new_skb)) {
				MTK_ERR_LOG(TAG, "Alloc skb(%d) fail on q%d!(%d/%d)\n",
					bat_req->pkt_buf_sz, q_num, cur_bat_idx,
					blocking);
				ret = LOW_MEMORY_SKB;
				break;
			}

			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);

			cur_bat->buffer_addr_ext = (data_base_addr >> 32) & 0xFFFFFFFF;
			cur_bat->p_buffer_addr = data_base_addr & 0xFFFFFFFF;

			cur_skb->skb = new_skb;
			cur_skb->data_phy_addr = data_base_addr;
			cur_skb->data_len = data_len;
		} else {
			data_base_addr = cur_skb->data_phy_addr;
			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);
			cur_bat->buffer_addr_ext = (data_base_addr >> 32) & 0xFFFFFFFF;
			cur_bat->p_buffer_addr = data_base_addr & 0xFFFFFFFF;
		}
	}
	wmb(); /* flush data before notify HW. */

	ret = dpmaifq_set_rx_bat(dpmaif_ctrl, q_num, i);
	if (unlikely(ret < 0))
		return ret;

	if (false == first_time)
		ret_hw = dpmaif_add_pkt_bat_cnt(dpmaif_ctrl, q_num, i);

	return ret_hw < 0 ? ret_hw : ret;
}

static int dpmaifq_rel_rx_pit_entry(struct dpmaif_rx_queue *rxq,
			unsigned short rel_entry_num)
{
	unsigned short old_sw_rel_idx = 0, new_sw_rel_idx = 0,
		old_hw_wr_idx = 0;
	int ret = 0;
	unsigned int i, cur_pit, pit_cnt;
	struct dpmaifq_normal_pit *pkt_inf_t = NULL;

	if (rxq->que_started != true)
		return 0;

	if (rel_entry_num >= rxq->pit_size_cnt) {
		MTK_ERR_LOG(TAG, "Release pit entry check fail\n");
		return -1;
	}

	MTK_DEBUG_LOG(TAG,
		"old: rel%d, w%d, r%d, to rel_count%d\n",
		rxq->pit_rel_rd_idx, rxq->pit_wr_idx,
		rxq->pit_rd_idx, rel_entry_num);

	old_sw_rel_idx = rxq->pit_rel_rd_idx;
	new_sw_rel_idx = old_sw_rel_idx +
		rel_entry_num + rxq->pit_not_rel_entrynum;

	MTK_DEBUG_LOG(TAG, "new: rel%d, pit_not_rel_entry_num: %d\n",
		new_sw_rel_idx, rxq->pit_not_rel_entrynum);

	if (old_sw_rel_idx % DPMAIF_PIT_REL_BATCH_NUM != 0) {
		MTK_ERR_LOG(TAG,
			"old_sw_rel_idx not cache line size aligned\n");
		DPMAIF_ASSERT();
		return -1;
	}

	/* Only release cache aligned size of PIT entries */
	if (new_sw_rel_idx % DPMAIF_PIT_REL_BATCH_NUM != 0) {
		rxq->pit_not_rel_entrynum =
			new_sw_rel_idx % DPMAIF_PIT_REL_BATCH_NUM;
		new_sw_rel_idx -= rxq->pit_not_rel_entrynum;
		MTK_DEBUG_LOG(TAG,
			"new(after align check): rel%d, pit_not_rel_entrynum: %d\n",
			new_sw_rel_idx, rxq->pit_not_rel_entrynum);
	} else {
		rxq->pit_not_rel_entrynum = 0;
	}

	cur_pit = old_sw_rel_idx;
	pit_cnt = new_sw_rel_idx - old_sw_rel_idx;

	/* Write PIT SEQ magic and flush cache*/
	for (i = 0; i < pit_cnt; i++) {
		pkt_inf_t = (struct dpmaifq_normal_pit *)
			rxq->pit_base + cur_pit;
		pkt_inf_t->pit_seq = DPMAIF_PIT_SEQ_MAGIC;

		cur_pit++;

		if (cur_pit >= rxq->pit_size_cnt)
			cur_pit = 0;

	}

	old_hw_wr_idx = rxq->pit_wr_idx;

	/*queue had empty and no need to release*/
	if (old_hw_wr_idx == old_sw_rel_idx) {
		MTK_DEBUG_LOG(TAG,
			"(old_hw_wr_idx == old_sw_rel_idx)\n");
	}

	if (old_hw_wr_idx > old_sw_rel_idx) {
		if (new_sw_rel_idx > old_hw_wr_idx) {
			MTK_DEBUG_LOG(TAG,
				"(new_rel_idx > old_hw_wr_idx)\n");
		}
	} else if (old_hw_wr_idx < old_sw_rel_idx) {
		if (new_sw_rel_idx >= rxq->pit_size_cnt) {
			new_sw_rel_idx = new_sw_rel_idx - rxq->pit_size_cnt;
			if (new_sw_rel_idx > old_hw_wr_idx) {
				MTK_DEBUG_LOG(TAG,
					"(new_rel_idx > old_wr_idx)\n");
			}
		}
	}

	ret = dpmaif_add_pit_remain_cnt(rxq->dpmaif_ctrl, rxq->index, pit_cnt);
	if (likely(ret == 0)) {
		rxq->pit_rel_rd_idx = new_sw_rel_idx;
	} else {
		MTK_ERR_LOG(TAG,
			"release pit fail(rel%d, w%d, r%d, rel_entry_num = %d), ret = %d\n",
			rxq->pit_rel_rd_idx, rxq->pit_wr_idx,
			rxq->pit_rd_idx, rel_entry_num, ret);
	}

	return ret;
}

static int BAT_cur_bid_check(struct dpmaif_rx_queue *rxq,
	unsigned int cur_pit, unsigned int cur_bid)
{
	int ret = 0;
	struct dpmaif_bat_request *bat_req = &rxq->bat_req;
	struct sk_buff *skb =
		((struct dpmaif_bat_skb_t *)bat_req->bat_skb_ptr +
			cur_bid)->skb;

	DP_UNUSED(cur_pit);
	if (unlikely((skb == NULL) ||
		(cur_bid >= DPMAIF_DL_BAT_ENTRY_SIZE))) {
		rxq->check_bid_fail_cnt++;
		ret = DATA_CHECK_FAIL;
	}

	return ret;
}

#if defined(DATA_PATH_NET_NAPI_MODE) && !defined(DATA_PATH_UT_LOOPBACK)
#define NOTIFY_RX_PUSH(rxq)     {}
#else
#define NOTIFY_RX_PUSH(rxq)     wake_up_all(&rxq->rx_wq)
#endif


#define DPMF_SET_SKB_CS_TYPE(cs_result, skb) {\
	if (cs_result == DPMF_CS_RESULT_PASS) \
		skb->ip_summed = CHECKSUM_UNNECESSARY; \
	else \
		skb->ip_summed = CHECKSUM_NONE; \
}

static inline void dpmaif_handle_tx_done_if_need(
	struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
	int i;
	unsigned int intr_ul_que_done;

	if (likely(que_mask)) {
		dpmaif_hw_ul_mask_multiple_tx_done_intr(que_mask);

		MTK_DEBUG_LOG(TAG, "UL done que_mask(0x%x)\n", que_mask);
		for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
			intr_ul_que_done = que_mask & (1 << i);
			if (intr_ul_que_done) {
				queue_delayed_work(dpmaif_ctrl->txq[i].worker,
					&dpmaif_ctrl->txq[i].dpmaif_tx_work,
					msecs_to_jiffies(1));
			}
		}
	}
}

#define DPMF_HDL_UL_DONE_INTR_IF_NEED(dpmaif_ctrl, que_mask) {\
	if (que_mask) \
		dpmaif_handle_tx_done_if_need(dpmaif_ctrl, que_mask); \
}

#define DPMF_PIT_SEQ_MAX    (rxq->pit_size_cnt - 2)

static int dpmaif_check_pit_seq(struct dpmaif_rx_queue *rxq,
	struct dpmaifq_normal_pit *pit)
{
	unsigned int count = 0;

	/* checks inputs */
	if (unlikely(pit == NULL)) {
		DPMAIF_ASSERT();
		goto error;
	}

	while (count <= DPMF_POLL_SAME_PIT_CNT_MAX) {
		if (pit->pit_seq != DPMAIF_PIT_SEQ_MAGIC)
			return 0;
		count++;
	}

error:
	return -1;
}

static inline void dpmaif_set_pkt_bat_mask(struct dpmaif_rx_queue *rxq,
	unsigned int bat_idx)
{
	if (likely((rxq->bat_req.bat_mask[bat_idx]) == 0))
		rxq->bat_req.bat_mask[bat_idx] = 1;
	else {
		MTK_ERR_LOG(TAG,
			"Try to set a bat mask value which already has been set!\n");
		DPMAIF_ASSERT();
	}
}

static unsigned int dpmaif_chk_avail_pkt_bat_cnt(struct dpmaif_rx_queue *rxq)
{
	unsigned int count = 0;
	unsigned int i = 0;
	unsigned int index = 0;

	for (i = 0; i < rxq->bat_req.bat_size_cnt; i++) {
		index = rxq->bat_req.bat_rel_rd_idx + i;
		if (index >= rxq->bat_req.bat_size_cnt)
			index -= rxq->bat_req.bat_size_cnt;


		if (rxq->bat_req.bat_mask[index] == 1)
			count++;
		else
			break;
	}

	if (unlikely(count > rxq->bat_req.bat_size_cnt)) {
		MTK_ERR_LOG(TAG,
			"Got available PKT_BAT count(%u) > total PKT_BAT count(%u)\n",
			count, rxq->bat_req.bat_size_cnt);
		DPMAIF_ASSERT();
		return 0;
	}

	MTK_DEBUG_LOG(TAG,
		"bat_rel_rd_idx = %u, bat_size_cnt = %u, release bat count: %u\n",
		rxq->bat_req.bat_rel_rd_idx, rxq->bat_req.bat_size_cnt, count);

	return count;
}

static int dpmaif_rel_dl_bat_entry(struct dpmaif_rx_queue *rxq,
	unsigned int rel_entry_num)
{
	unsigned char q_num = 0;
	unsigned short old_sw_rel_idx = 0, new_sw_rel_idx = 0, hw_rd_idx = 0;
	unsigned int i = 0;
	unsigned int index = 0;

	q_num = rxq->index;

	if (unlikely(false == rxq->que_started))
		goto error;


	if (unlikely(rel_entry_num >= rxq->bat_req.bat_size_cnt ||
		rel_entry_num == 0)) {
		DPMAIF_ASSERT();
		goto error;
	}

	old_sw_rel_idx = rxq->bat_req.bat_rel_rd_idx;
	new_sw_rel_idx = old_sw_rel_idx + rel_entry_num;

	hw_rd_idx = dpmaif_get_dl_pkt_bat_read_index(rxq->dpmaif_ctrl, q_num);
	rxq->bat_req.bat_rd_idx = hw_rd_idx;
	MTK_DEBUG_LOG(TAG,
		"bat: r%u, old_rel%u, new_rel%u, bat_size_cnt = %u\n",
		rxq->bat_req.bat_rd_idx, old_sw_rel_idx,
		new_sw_rel_idx, rxq->bat_req.bat_size_cnt);

	/*queue had empty and no need to release*/
	if (rxq->bat_req.bat_wr_idx == old_sw_rel_idx) {
		DPMAIF_ASSERT();
		goto error;
	}

	if (hw_rd_idx > old_sw_rel_idx) {

		if (new_sw_rel_idx > hw_rd_idx) {
			DPMAIF_ASSERT();
			goto error;
		}

	} else if (hw_rd_idx < old_sw_rel_idx) {

		if (new_sw_rel_idx >= rxq->bat_req.bat_size_cnt) {
			new_sw_rel_idx = new_sw_rel_idx -
				rxq->bat_req.bat_size_cnt;

			if (new_sw_rel_idx > hw_rd_idx) {
				DPMAIF_ASSERT();
				goto error;
			}
		}
	}

	/* reset bat mask value */
	for (i = 0; i < rel_entry_num; i++) {
		index = rxq->bat_req.bat_rel_rd_idx + i;
		if (index >= rxq->bat_req.bat_size_cnt)
			index -= rxq->bat_req.bat_size_cnt;


		rxq->bat_req.bat_mask[index] = 0;
	}

	rxq->bat_req.bat_rel_rd_idx = new_sw_rel_idx;

	return rel_entry_num;

error:
	return -1;
}

static int dpmaif_dl_pit_rel_and_add(struct dpmaif_rx_queue *rxq)
{
	int ret = 0;

	if (likely(rxq->pit_remain_rel_cnt)) {
		if (rxq->pit_remain_rel_cnt >= DPMF_PIT_CNT_UPDATE_THRESHOLD) {
			ret = dpmaifq_rel_rx_pit_entry(
				rxq, rxq->pit_remain_rel_cnt);
			if (likely(ret == 0))
				rxq->pit_remain_rel_cnt = 0;
			else
				MTK_ERR_LOG(TAG,
					"Release and add pit fail, ret:%d\n",
					ret);


			return ret;
		}
	}
	return ret;
}

static inline void dpmaif_dl_pit_add_remain_rel_cnt(
	struct dpmaif_rx_queue *rxq)
{
	rxq->pit_remain_rel_cnt++;
}

static int dpmaif_dl_pkt_bat_rel_and_add(struct dpmaif_rx_queue *rxq,
	int blocking)
{
	int ret = 0;
	unsigned int bid_cnt = 0;

	bid_cnt = dpmaif_chk_avail_pkt_bat_cnt(rxq);
	if (bid_cnt == 0)
		goto exit;


	if (bid_cnt < DPMF_BAT_CNT_UPDATE_THRESHOLD)
		goto exit;


	ret = dpmaif_rel_dl_bat_entry(rxq, bid_cnt);
	if (unlikely(ret <= 0)) {
		MTK_ERR_LOG(TAG, "Release bat fail\n");
		goto exit;
	}

	ret = dpmaif_alloc_rx_buf(rxq->dpmaif_ctrl, &rxq->bat_req, rxq->index,
		bid_cnt, blocking, false);
	if (unlikely(ret < 0)) {
		MTK_ERR_LOG(TAG, "Allocate new RX buffer fail, ret:%d\n", ret);
		goto exit;
	}

exit:
	return ret;
}

static int dpmaif_dl_pkt_bat_handle(
	struct dpmaif_rx_queue *rxq, unsigned int cur_bid,
	struct dpmaifq_normal_pit *pkt_inf_t, int blocking)
{
	int ret = 0;

	if (unlikely(pkt_inf_t == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid input, pkt_inf_t is NULL\n");
		goto exit;
	}

	dpmaif_set_pkt_bat_mask(rxq, cur_bid);

exit:
	return ret;
}

#ifdef DPMAIF_DEBUG_DUMP
static void dpmaif_dump_msg_pit_entry(unsigned char md_id,
	struct dpmaifq_msg_pit *msg_pit)
{
	if (msg_pit == NULL)
		goto exit;

	MTK_DEBUG_LOG(TAG, "======== DUMP MSG PIT START ========\n");
	MTK_DEBUG_LOG(TAG,
		"packet_type = %u, c_bit = %u, check_sum = %u, error_bit = %u, src_qid = %u\n",
		msg_pit->packet_type, msg_pit->c_bit,
		msg_pit->check_sum, msg_pit->error_bit, msg_pit->src_qid);
	MTK_DEBUG_LOG(TAG,
		"channel_id = %u, network_type = %u, dp = %u, count_l = %u, flow = %u\n",
		msg_pit->channel_id, msg_pit->network_type,
		msg_pit->dp, msg_pit->count_l, msg_pit->flow);
	MTK_DEBUG_LOG(TAG,
		"cmd = %u, vbid = %u, pit_seq = %u, ulq_done = %u, dlq_done = %u\n",
		msg_pit->cmd, msg_pit->vbid, msg_pit->pit_seq,
		msg_pit->ulq_done, msg_pit->dlq_done);
	MTK_DEBUG_LOG(TAG, "========  DUMP MSG PIT END    ========\n");

exit:
	return;
}

static void dpmaif_dump_nor_pit_entry(
	unsigned char md_id, struct dpmaifq_normal_pit *nor_pit)
{
	if (nor_pit == NULL)
		goto exit;

	MTK_DEBUG_LOG(TAG, "======== DUMP NORMAL PIT START ========\n");
	MTK_DEBUG_LOG(TAG,
		"packet_type = %u, c_bit = %u, buffer_type = %u, buffer_id = %u, data_len = %u\n",
		nor_pit->packet_type, nor_pit->c_bit,
		nor_pit->buffer_type, nor_pit->buffer_id, nor_pit->data_len);
	MTK_DEBUG_LOG(TAG,
		"p_data_addr = %x, data_addr_ext = %x, pit_seq = %u, ulq_done = %u, dlq_done = %u\n",
		nor_pit->p_data_addr, nor_pit->data_addr_ext,
		nor_pit->pit_seq, nor_pit->ulq_done, nor_pit->dlq_done);
	MTK_DEBUG_LOG(TAG,
		"========  DUMP NORMAL PIT END  ========\n");

exit:
	return;
}
#endif

#define DPMF_CHECK_PIT_SEQ_NUM(rxq, pit)    dpmaif_check_pit_seq(rxq, pit)

#ifndef DATA_PATH_NET_NAPI_MODE
static int dpmaif_rx_start(struct dpmaif_rx_queue *rxq, unsigned short pit_cnt,
		int blocking, unsigned long time_limit)
{
	struct dpmaifq_normal_pit *pkt_inf_t = NULL;
	struct dpmaifq_msg_pit *msg_pit = NULL;
	struct dpmaif_bat_request *bat_req = &rxq->bat_req;
	struct dpmaif_bat_t *buf_addr_t = NULL;
	struct dpmaif_bat_skb_t *cur_skb = NULL;
	struct sk_buff *new_skb = NULL;
	struct ccci_header ccci_h; /* for collect debug info. */
	struct lhif_header *lhif_h = NULL; /* for uplayer: port */
	unsigned short rx_cnt;
	unsigned int pit_len = rxq->pit_size_cnt;
	unsigned int cur_bid, cur_pit;
	unsigned int data_len;
	unsigned short ret_hw_pit_cnt = 0;
	int ret = 0, ret_hw = 0;
	unsigned long long data_phy_addr, data_base_addr;
	int data_offset;
	unsigned int *temp_u32;
#ifdef DATA_PATH_LATENCY
	unsigned long long time_a, time_b;
#endif
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	unsigned char cs_result;
	bool begin_drop;
#ifdef DATA_PATH_DL_TP_CALC
	unsigned int dl_tp_stat_enable = ccci_dp_dl_tp_calc;
#endif
#ifdef DPMA_FTRACE_DEBUG
	unsigned int pkt_read = 0;
#endif

	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "Rxq, dpmaif_ctrl pointer check fail\n");
		goto error;
	}

	cs_result = rxq->cs_result;
	begin_drop = rxq->begin_drop;

	dpmaif_ctrl = rxq->dpmaif_ctrl;
	cur_pit = rxq->pit_rd_idx;

	for (rx_cnt = 0; rx_cnt < pit_cnt; rx_cnt++) {
		if (!blocking && time_after_eq(jiffies, time_limit)) {
			MTK_DEBUG_LOG(TAG, "RX timeout, pit_info: %d/%d\n",
				rx_cnt, pit_cnt);
			break;
		}
		/*GET_PKT_INFO_PTR(rxq, cur_pit); pit item */
		pkt_inf_t = (struct dpmaifq_normal_pit *)
			rxq->pit_base + cur_pit;

#ifdef DPMAIF_DEBUG_DUMP
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			dpmaif_dump_nor_pit_entry(
				dpmaif_ctrl->md_id, pkt_inf_t);
		} else {
			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			dpmaif_dump_msg_pit_entry(dpmaif_ctrl->md_id, msg_pit);
		}
#endif

		/* checks PIT SEQ firstly */
		if (unlikely(DPMF_CHECK_PIT_SEQ_NUM(rxq, pkt_inf_t) != 0)) {
			MTK_ERR_LOG(TAG, "pit seq check fail\n");
			goto error;
		}

		/* tries to handle UL done interrupt earlier */
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			cur_bid = pkt_inf_t->buffer_id; /*cur BID in pit info*/
			/* check bid */
			ret = BAT_cur_bid_check(rxq, cur_pit, cur_bid);
			if (ret < 0) {
				MTK_ERR_LOG(TAG,
					"bid:%d check fail, ret: %d\n",
					cur_bid, ret);
				break;
			}

			/* handle DL bat:
			 * record the received packet
			 * update BAT and reallocate buffer if needed
			 */
			ret = dpmaif_dl_pkt_bat_handle(
				rxq, cur_bid, pkt_inf_t, blocking);
			if (ret < 0) {
				MTK_ERR_LOG(TAG,
					"Handle DL PKT_BAT fail! ret = %d\n",
					ret);
				break;
			}

			/* memory(alloc skb) OK, get cur bid-> skb */
			cur_skb = ((struct dpmaif_bat_skb_t *)
				bat_req->bat_skb_ptr + cur_bid);
			new_skb = cur_skb->skb;

			/* rx current skb data unmapping */
			dma_unmap_single(
				dpmaif_get_hw_device(dpmaif_ctrl),
				cur_skb->data_phy_addr,
				cur_skb->data_len,
				DMA_FROM_DEVICE);

			/* throughput statistics */
#ifdef DATA_PATH_DL_TP_CALC
			if (dl_tp_stat_enable) {
				if (g_dpmf_tp_stat.rx_rec_enable) {
					if (unlikely(g_dpmf_tp_stat.first_rx_pkt)) {
						g_dpmf_tp_stat.first_rx_pkt
							= false;
						g_dpmf_tp_stat.rx_rec_start_tm =
							DPMA_UT_TIME_NOW();
					}

					g_dpmf_tp_stat.rx_num +=
						pkt_inf_t->data_len;
				}
			}
#endif
			/* Checks whether need drop packet */
			if (true == begin_drop) {
				MTK_DEBUG_LOG(TAG,
					"Skips and free this packet to drop it, pit_seq:%d\n",
					pkt_inf_t->pit_seq);
				kfree_skb(new_skb);
				new_skb = NULL;
			} else {
				/* calculate data address && data len. */
				/* cur pkt data len */
				data_len = pkt_inf_t->data_len;
				/* cur pkt physical address(in a buffer bid pointed) */
				data_phy_addr = pkt_inf_t->data_addr_ext;
				data_phy_addr = (data_phy_addr<<32) +
					pkt_inf_t->p_data_addr;
				/* get cur pkt buffer base address */
				/* GET_BUF_ADDR_PTR(bat_req, cur_bid); */
				buf_addr_t =
					((struct dpmaif_bat_t *)
						bat_req->bat_base + cur_bid);
				data_base_addr = buf_addr_t->buffer_addr_ext;
				data_base_addr = (data_base_addr<<32) +
					buf_addr_t->p_buffer_addr;

				data_offset = (int)(data_phy_addr -
					data_base_addr);
				/* record to skb for user: wapper, enqueue */
				 /* get skb which data contained pkt data */
				new_skb->len = 0;
				skb_reset_tail_pointer(new_skb);
				/*set data len, data pointer*/
				skb_reserve(new_skb, data_offset);
				/* for debug: */
				if (unlikely((new_skb->tail + data_len) >
					new_skb->end)) {
					/*dump*/
					MTK_INFO_LOG(TAG,
						"pkt(%d/%d): len = 0x%x, offset=0x%llx-0x%llx, skb(%p, %p, 0x%x, 0x%x)\n",
						cur_pit, cur_bid, data_len,
						data_phy_addr, data_base_addr,
						new_skb->head, new_skb->data,
						(unsigned int)new_skb->tail,
						(unsigned int)new_skb->end);

					if (cur_pit > 2) {
						temp_u32 = (unsigned int *)
							((struct dpmaifq_normal_pit *)
							rxq->pit_base +
							cur_pit - 2);
						MTK_INFO_LOG(TAG,
							"pit(%d):data(%x, %x, %x, %x, %x, %x, %x, %x, %x)\n",
							cur_pit - 2,
							temp_u32[0],
							temp_u32[1],
							temp_u32[2],
							temp_u32[3],
							temp_u32[4],
							temp_u32[5],
							temp_u32[6],
							temp_u32[7],
							temp_u32[8]);
					}

					//dpmaif_dump_rxq_remain(dpmaif_ctrl, DPMAIF_RXQ_NUM, 1);

					/* move on pit index to skip error data */
					cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
					rxq->pit_rd_idx = cur_pit;
					ret_hw_pit_cnt++;
					dpmaif_dl_pit_add_remain_rel_cnt(rxq);
					DPMAIF_ASSERT();

					ret = DATA_CHECK_FAIL;
					break;
				}
				skb_put(new_skb, data_len);
				DPMF_SET_SKB_CS_TYPE(
					cs_result, new_skb);

#ifdef DATA_PATH_UT_HW_LOOPBACK
				dpmaif_ut_loopback_pkt(new_skb);
#endif
				MTK_DEBUG_LOG(TAG,
					"cur_bid: %u, checksum type:%d, netif_id:%d\n",
					cur_bid, new_skb->ip_summed,
					rxq->cur_chn_idx);

				/* md put the ccmni_index to the msg pkt,
				 * so we need push it by self. maybe no need
				 */
				lhif_h = (struct lhif_header *)(
					skb_push(new_skb,
						sizeof(struct lhif_header)));
				lhif_h->netif = rxq->cur_chn_idx;

				ccci_h = *(struct ccci_header *)new_skb->data;
				/* Add data to rx thread SKB list */
				ccci_skb_enqueue(&rxq->skb_list, new_skb);

				cur_skb->skb = NULL;

#ifdef DPMA_FTRACE_DEBUG
				pkt_read++;
#endif
			}

			/* collect debug information */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->rx_traffic_monitor[rxq->index]++;
#endif
		} else {
			/* === message PIT === */
			if (true == begin_drop)
				begin_drop = false;

			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			MTK_DEBUG_LOG(TAG,
				"pit_base = %p, msg_pit = %p",
				rxq->pit_base, msg_pit);

			/* Checks whether need drop this packet */
			if (msg_pit->dp != 0) {
				MTK_INFO_LOG(TAG,
					"Drop bit is set in message PIT");
				begin_drop = true;
			}

			rxq->cur_chn_idx = msg_pit->channel_id;

			/* records current PIT entry's CS check result value */
			cs_result = msg_pit->check_sum;

			/* backup the pit information */
			rxq->cs_result = cs_result;
			rxq->begin_drop = begin_drop;
		}

		/* get next pointer to get pkt data */
		cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
		rxq->pit_rd_idx = cur_pit;
		ret_hw_pit_cnt++;
		/*notify_hw_pit_cnt++;*/
		dpmaif_dl_pit_add_remain_rel_cnt(rxq);
		if ((rx_cnt & DPMF_RX_PUSH_THRESHOLD_MASK) == 0) {
			NOTIFY_RX_PUSH(rxq);
			ret_hw_pit_cnt = 0;
		}
		if (rx_cnt > 0 && rx_cnt % DPMF_NOTIFY_RELEASE_COUNT == 0) {
#ifdef DATA_PATH_LATENCY
			time_a = local_clock();
#endif
			ret = dpmaif_dl_pkt_bat_rel_and_add(rxq, blocking);
			if (ret < 0) {
				MTK_ERR_LOG(TAG, "Update bat fail(128)\n");
				break;
			}

			ret = dpmaif_dl_pit_rel_and_add(rxq);
			if (ret < 0) {
				MTK_ERR_LOG(TAG, "Update pit fail(128)\n");
				break;
			}
#ifdef DATA_PATH_LATENCY
			time_b = local_clock();
			MTK_DEBUG_LOG(TAG, "dpmaif_rx_update time:%llu\n",
				(time_b-time_a));
#endif
		}

	}

	if (ret_hw_pit_cnt)
		NOTIFY_RX_PUSH(rxq);

#ifdef DATA_PATH_LATENCY
	time_a = local_clock();
#endif

	/* update to HW */
	ret_hw = ret;
	if (likely(ret_hw != HW_REG_CHK_FAIL)) {
		ret_hw = dpmaif_dl_pkt_bat_rel_and_add(rxq, blocking);
		if (ret_hw < 0)
			MTK_ERR_LOG(TAG, "Update bat fail\n");

	}

	if (likely(ret_hw != HW_REG_CHK_FAIL)) {
		ret_hw = dpmaif_dl_pit_rel_and_add(rxq);
		if (ret_hw < 0)
			MTK_ERR_LOG(TAG, "Update pit fail\n");

	}
	if (ret_hw < 0 && ret == 0)
		ret = ret_hw;

#ifdef DATA_PATH_LATENCY
	time_b = local_clock();
	MTK_DEBUG_LOG(TAG, "dpmaif_rx_update time1:0x%llx\n",
		(time_b-time_a));
#endif

	MTK_DEBUG_LOG(TAG, "pit: w%d, r%d, rel%d\n",
			rxq->pit_wr_idx, rxq->pit_rd_idx,
			rxq->pit_rel_rd_idx);
	MTK_DEBUG_LOG(TAG, "bat: w%d, r%d rel%d\n",
			bat_req->bat_wr_idx, bat_req->bat_rd_idx,
			bat_req->bat_rel_rd_idx);


#ifdef DPMA_FTRACE_DEBUG
	g_pkt_cnt_per_isr += pkt_read;
#endif
	return ret < 0 ? ret : rx_cnt;

error:
#ifdef DPMA_FTRACE_DEBUG
	g_pkt_cnt_per_isr += pkt_read;
#endif
	return ONCE_MORE;
}
#endif

static unsigned int dpmaifq_poll_rx_pit(struct dpmaif_rx_queue *rxq)
{
	unsigned int pit_cnt = 0;
	unsigned short sw_rd_idx = 0, hw_wr_idx = 0;

	if (rxq->que_started == false)
		return pit_cnt;
	sw_rd_idx = rxq->pit_rd_idx;
	hw_wr_idx = dpmaif_get_dl_pit_write_index(rxq->dpmaif_ctrl, rxq->index);

	pit_cnt = ring_buf_readable(rxq->pit_size_cnt, sw_rd_idx, hw_wr_idx);

	rxq->pit_wr_idx = hw_wr_idx;

	return pit_cnt;
}

#ifdef DATA_PATH_NET_NAPI_MODE

static struct napi_struct *g_net_napi;
static struct md_dpmaif_ctrl *g_hif_ctrl;
#define DPMF_NAPI_RX_SCHE() {\
	if (likely(g_net_napi)) {\
		if (likely(napi_schedule_prep(g_net_napi))) {\
			__napi_schedule(g_net_napi);\
		} \
	} \
}

#define DPMF_NAPI_COMP() {\
	if (likely(g_net_napi)) {\
		napi_complete(g_net_napi);\
	} \
}

void dpmaif_init_napi_mode(void *para)
{
	if (g_net_napi == NULL) {    /* TEMP SOLUTION: FIX ME!!! */
		if (likely(para)) {
			g_net_napi = (struct napi_struct *)para;
			MTK_DEBUG_LOG(TAG, "g_net_napi = %p\n", g_net_napi);
		}
	}
}

static int dpmaif_napi_rx_start(
	struct dpmaif_rx_queue *rxq, unsigned short pit_cnt,
	int blocking, unsigned int budget)
{
	struct dpmaifq_normal_pit *pkt_inf_t = NULL;
	struct dpmaifq_msg_pit *msg_pit = NULL;
	struct dpmaif_bat_request *bat_req = &rxq->bat_req;
	struct dpmaif_bat_t *buf_addr_t = NULL;
	struct dpmaif_bat_skb_t *cur_skb = NULL;
	struct sk_buff *new_skb = NULL;
	unsigned short rx_cnt;
	unsigned int pit_len = rxq->pit_size_cnt;
	unsigned int cur_bid, cur_pit;
	unsigned int data_len;
	unsigned short ret_hw_pit_cnt = 0;
	int ret = 0, ret_hw = 0;
	unsigned long long data_phy_addr, data_base_addr;
	int data_offset;
	unsigned int *temp_u32;
#ifdef DATA_PATH_LATENCY
	unsigned long long time_a, time_b;
#endif
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	unsigned char cs_result;
	bool begin_drop;
#ifdef DATA_PATH_DL_TP_CALC
	unsigned int dl_tp_stat_enable = ccci_dp_dl_tp_calc;
#endif
	unsigned int packets_cnt = 0;

	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "Rxq, dpmaif_ctrl pointer check fail\n");
			goto error;
	}

	cs_result = rxq->cs_result;
	begin_drop = rxq->begin_drop;

	dpmaif_ctrl = rxq->dpmaif_ctrl;
	cur_pit = rxq->pit_rd_idx;

	for (rx_cnt = 0; rx_cnt < pit_cnt; rx_cnt++) {
		if (packets_cnt >= budget) {
			/* reach budget */
			break;
		}

		/*GET_PKT_INFO_PTR(rxq, cur_pit); pit item */
		pkt_inf_t = (struct dpmaifq_normal_pit *)
			rxq->pit_base + cur_pit;

		/* Handles UL done interrupt if need */
#ifdef DPMAIF_DEBUG_DUMP
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			dpmaif_dump_nor_pit_entry(
				dpmaif_ctrl->md_id, pkt_inf_t);
		} else {
			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			dpmaif_dump_msg_pit_entry(dpmaif_ctrl->md_id, msg_pit);
		}
#endif
		/* checks PIT SEQ firstly */
		if (unlikely(DPMF_CHECK_PIT_SEQ_NUM(rxq, pkt_inf_t) != 0)) {
			MTK_ERR_LOG(TAG, "pit seq check fail\n");
			goto error;
		}

		/* tries to handle UL done interrupt earlier */
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			cur_bid = pkt_inf_t->buffer_id; /*cur BID in pit info*/
			/* check bid */
			ret = BAT_cur_bid_check(rxq, cur_pit, cur_bid);
			if (ret < 0) {
				MTK_DEBUG_LOG(TAG,
					"bid:%d check fail, ret: %d\n",
					cur_bid, ret);
				break;
			}
			/* handle DL bat:
			 * record the received packet
			 * update BAT and reallocate buffer if needed
			 */
			ret = dpmaif_dl_pkt_bat_handle(
				rxq, cur_bid, pkt_inf_t, blocking);
			if (ret < 0) {
				MTK_ERR_LOG(TAG,
					"Handle DL PKT_BAT fail! ret = %d\n",
					ret);
				break;
			}

			/* received a new packet */
			packets_cnt++;

			/* get cur bid-> skb */
			cur_skb = ((struct dpmaif_bat_skb_t *)
				bat_req->bat_skb_ptr + cur_bid);
			new_skb = cur_skb->skb;

			/* rx current skb data unmapping */
			dma_unmap_single(
				dpmaif_get_hw_device(dpmaif_ctrl),
				cur_skb->data_phy_addr,
				cur_skb->data_len,
				DMA_FROM_DEVICE);

			/* throughput statistics */
#ifdef DATA_PATH_DL_TP_CALC
			if (dl_tp_stat_enable) {
				if (g_dpmf_tp_stat.rx_rec_enable) {
					if (unlikely(g_dpmf_tp_stat.first_rx_pkt)) {
						g_dpmf_tp_stat.first_rx_pkt
							= false;
						g_dpmf_tp_stat.rx_rec_start_tm =
							DPMA_UT_TIME_NOW();
					}

					g_dpmf_tp_stat.rx_num +=
						pkt_inf_t->data_len;
				}
			}
#endif
			/* Checks whether need drop packet */
			if (true == begin_drop) {
				MTK_DEBUG_LOG(TAG,
					"Skips and free this packet to drop it(SEQ=%u)\n",
					pkt_inf_t->pit_seq);
				kfree_skb(new_skb);
				new_skb = NULL;
			} else {

				/* 2. calculate data address && data len. */
				/* cur pkt data len */
				data_len = pkt_inf_t->data_len;
				/* cur pkt physical address
				 *(in a buffer bid pointed)
				 */
				data_phy_addr = pkt_inf_t->data_addr_ext;
				data_phy_addr = (data_phy_addr<<32) +
					pkt_inf_t->p_data_addr;
				/* get cur pkt buffer base address */
				/* GET_BUF_ADDR_PTR(bat_req, cur_bid); */
				buf_addr_t =
					((struct dpmaif_bat_t *)
					bat_req->bat_base +
					cur_bid);
				data_base_addr = buf_addr_t->buffer_addr_ext;
				data_base_addr = (data_base_addr<<32) +
					buf_addr_t->p_buffer_addr;

				data_offset = (int)(data_phy_addr -
					data_base_addr);
				/* 3. record to skb for user: wapper, enqueue */
				 /* get skb which data contained pkt data */
				new_skb->len = 0;
				skb_reset_tail_pointer(new_skb);
				/*set data len, data pointer*/
				skb_reserve(new_skb, data_offset);
				/* for debug: */
				if (unlikely((new_skb->tail + data_len) >
					new_skb->end)) {
					/*dump*/
					MTK_DEBUG_LOG(TAG,
						"pkt(%u/%u): len = 0x%x, offset=0x%llx-0x%llx, skb(%p, %p, 0x%x, 0x%x)\n",
						cur_pit, cur_bid, data_len,
						data_phy_addr, data_base_addr,
						new_skb->head, new_skb->data,
						(unsigned int)new_skb->tail,
						(unsigned int)new_skb->end);

					if (cur_pit > 2) {
						temp_u32 = (unsigned int *)
							((struct dpmaifq_normal_pit *)
							rxq->pit_base
							+ cur_pit - 2);
						MTK_DEBUG_LOG(TAG,
							"pit(%d):data(%x, %x, %x, %x, %x, %x, %x, %x, %x)\n",
							cur_pit - 2,
							temp_u32[0],
							temp_u32[1],
							temp_u32[2],
							temp_u32[3],
							temp_u32[4],
							temp_u32[5],
							temp_u32[6],
							temp_u32[7],
							temp_u32[8]);
					}

					//dpmaif_dump_rxq_remain(dpmaif_ctrl, DPMAIF_RXQ_NUM, 1);

					/* move on pit index to skip error data */
					cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
					rxq->pit_rd_idx = cur_pit;
					ret_hw_pit_cnt++;
					dpmaif_dl_pit_add_remain_rel_cnt(rxq);
					DPMAIF_ASSERT();

					ret = DATA_CHECK_FAIL;
					break;
				}
				skb_put(new_skb, data_len);
				DPMF_SET_SKB_CS_TYPE(cs_result, new_skb);

#ifdef DATA_PATH_UT_HW_LOOPBACK
				dpmaif_ut_loopback_pkt(new_skb);
#endif
				MTK_DEBUG_LOG(TAG,
				"cur_bid: %u, checksum type:%d, netif_id:%d\n",
				cur_bid, new_skb->ip_summed, rxq->cur_chn_idx);

				MTK_DEBUG_LOG(TAG,
					"#%s#ip.id#%d\n",__func__,
					dpmaif_ut_get_packet_id(
					(struct iphdr *)new_skb->data));
				/* directly push to kernel stack */
				ccmni_rx_callback(
					dpmaif_ctrl->md_id,
					rxq->cur_chn_idx,
					new_skb, NULL);
				cur_skb->skb = NULL;
			}

			/* collect debug information */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->rx_traffic_monitor[rxq->index]++;
#endif
		} else {
			/* === message PIT === */
			if (true == begin_drop)
				begin_drop = false;


			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			MTK_DEBUG_LOG(TAG,
				"pit_base = %p, msg_pit = %p\n",
				rxq->pit_base, msg_pit);

			/* Checks whether need drop this packet */
			if (msg_pit->dp != 0) {
				MTK_DEBUG_LOG(TAG,
					"Drop bit is set in message PIT\n");
				begin_drop = true;
			}

			rxq->cur_chn_idx = msg_pit->channel_id;

			/* records current PIT entry's CS check result value */
			cs_result = msg_pit->check_sum;

			/* backup the pit information */
			rxq->cs_result = cs_result;
			rxq->begin_drop = begin_drop;
		}

		/* get next pointer to get pkt data */
		cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
		rxq->pit_rd_idx = cur_pit;
		ret_hw_pit_cnt++;

		dpmaif_dl_pit_add_remain_rel_cnt(rxq);

		if ((rx_cnt > 0) &&
			(rx_cnt & DPMF_RX_PUSH_THRESHOLD_MASK) == 0) {
			NOTIFY_RX_PUSH(rxq);
			ret_hw_pit_cnt = 0;
		}
		if (rx_cnt > 0 && rx_cnt % DPMF_NOTIFY_RELEASE_COUNT == 0) {
#ifdef DATA_PATH_LATENCY
			time_a = local_clock();
#endif
			ret = dpmaif_dl_pkt_bat_rel_and_add(rxq, blocking);
			if (ret < 0) {
				MTK_DEBUG_LOG(TAG,
					"Update bat fail(128), ret(%d)\n", ret);
				break;
			}
			ret = dpmaif_dl_pit_rel_and_add(rxq);

			if (ret < 0) {
				MTK_DEBUG_LOG(TAG,
					"Update pit fail(128), ret(%d)\n", ret);
				break;
			}

#ifdef DATA_PATH_LATENCY
			time_b = local_clock();
			MTK_DEBUG_LOG(TAG, "dpmaif_rx_update time:%llu\n",
				(time_b-time_a));
#endif
		}

	}

	if (ret_hw_pit_cnt)
		NOTIFY_RX_PUSH(rxq);

#ifdef DATA_PATH_LATENCY
	time_a = local_clock();
#endif

	/* update to HW */
	ret_hw = ret;

	ret_hw = dpmaif_dl_pkt_bat_rel_and_add(rxq, blocking);
	if (ret_hw < 0)
		MTK_DEBUG_LOG(TAG, "Update bat fail, ret_hw(%d)\n", ret_hw);

	if (ret_hw != HW_REG_CHK_FAIL) {
		ret_hw = dpmaif_dl_pit_rel_and_add(rxq);
		if (ret_hw < 0)
			MTK_DEBUG_LOG(TAG, "Update pit fail(%d)\n", ret_hw);
	}

	if (ret_hw < 0 && ret == 0)
		ret = ret_hw;

#ifdef DATA_PATH_LATENCY
	time_b = local_clock();
	MTK_DEBUG_LOG(TAG, "dpmaif_rx_update time1:0x%llx\n",
		(time_b-time_a));
#endif

	MTK_DEBUG_LOG(TAG, "pit: %d, %d, %d\n",
			rxq->pit_wr_idx, rxq->pit_rd_idx,
			rxq->pit_rel_rd_idx);
	MTK_DEBUG_LOG(TAG, "bat: %d, %d, %d\n",
			bat_req->bat_wr_idx, bat_req->bat_rd_idx,
			bat_req->bat_rel_rd_idx);

	if (ret)
		MTK_ERR_LOG(TAG, "NAPI rx start fail, ret:%d\n", ret);


	return ret < 0 ? ret : packets_cnt;

error:
	return ONCE_MORE;
}

static int dpmaif_napi_rx_data_collect(struct md_dpmaif_ctrl *hif_ctrl,
		unsigned char q_num, int budget)
{
	struct dpmaif_rx_queue *rxq = &hif_ctrl->rxq[q_num];
	unsigned int cnt = 0;
	int ret = 0, real_cnt = 0;

	cnt = dpmaifq_poll_rx_pit(rxq);
	MTK_DEBUG_LOG(TAG,
		"Poll rx pit return %d, budget = %d, blocking = %d\n",
		cnt, budget, false);

	if (cnt) {
		DPMA_FT_LOG(
			"start poll: pit_cnt(%u), packet_budget(%u)",
			cnt, budget);
		real_cnt = dpmaif_napi_rx_start(rxq, cnt, false, budget);
		DPMA_FT_LOG("end poll: packet_read(%d)", real_cnt);

		MTK_DEBUG_LOG(TAG,
			"dpmaif_napi_rx_start return %d\n",
			real_cnt);

		if (unlikely(real_cnt < 0)) {
			ret = -1;
			if (real_cnt < LOW_MEMORY_TYPE_MAX)
				MTK_ERR_LOG(TAG, "rx low mem: %d\n", real_cnt);
			else if (real_cnt <= ERROR_STOP_MAX)
				MTK_ERR_LOG(TAG, "rx ERR_STOP: %d\n", real_cnt);
			else
				MTK_ERR_LOG(TAG, "rx ERROR: %d\n", real_cnt);

		} else {
			ret = real_cnt;
		}
	} else {
		ret = 0;
	}

	return ret;
}


int dpmaif_napi_rx_poll(struct napi_struct *napi, int budget)
{
	int work_done = 0;
	int rx_cnt = 0;
	int each_budget = 0;

	BUG_ON(g_hif_ctrl == NULL);

	/* RPM lock */
	mtk_pm_runtime_get(g_hif_ctrl->mtk_dev);

	if (likely(true == g_hif_ctrl->rxq[0].que_started)) {
		do {
			each_budget = budget - work_done;
			if (each_budget) {
				rx_cnt = dpmaif_napi_rx_data_collect(
					g_hif_ctrl, 0, each_budget);
				if (rx_cnt > 0) {
					work_done += rx_cnt;
				} else {
					if (work_done == 0) {
						/* empty interrupt */
						g_hif_ctrl->traffic_info.poll_pit_empty[0]++;
					}
					break;
				}
			}
		} while (work_done <= budget && each_budget > 0 && rx_cnt > 0);

#ifdef DPMA_FTRACE_DEBUG
		g_pkt_cnt_per_isr += work_done;
#endif

		if (work_done < budget) {
#ifdef DPMA_FTRACE_DEBUG
			g_total_isr++;
			DPMA_FT_LOG(
				"NAPI_STATISTICS: intr_index(%llu), packet_cnt(%llu) --- #%llu#%llu#",
				g_total_isr, g_pkt_cnt_per_isr,
				g_total_isr, g_pkt_cnt_per_isr);
			g_pkt_cnt_per_isr = 0;
#endif
			DPMF_NAPI_COMP();

			dpmaif_hw_clear_ip_busy();
			dpmaif_hw_dl_unmask_rx_done_intr();

			MTK_DEBUG_LOG(TAG,
				"Complete napi: work_done(%d) < budget(%d)\n",
				work_done, budget);
		}
	}


	/* RPM unlock */
	mtk_pm_runtime_put(g_hif_ctrl->mtk_dev);

	return work_done;
}

#endif


/*
 * may be called from workqueue or NAPI or tasklet context,
 * NAPI and tasklet with blocking=false
 */
#ifndef DATA_PATH_NET_NAPI_MODE
static int dpmaif_rx_data_collect(struct md_dpmaif_ctrl *hif_ctrl,
		unsigned char q_num, int budget, int blocking)
{
	struct dpmaif_rx_queue *rxq = &hif_ctrl->rxq[q_num];
	unsigned int cnt, rd_cnt = 0, max_cnt = budget;
	int ret = ALL_CLEAR, real_cnt = 0;
	unsigned long time_limit = jiffies + 2;

poll_again:
	cnt = dpmaifq_poll_rx_pit(rxq);
	MTK_DEBUG_LOG(TAG,
		"poll rx pit return %d, budget = %d, blocking = %d\n",
		cnt, budget, blocking);

	if (cnt) {
		max_cnt = cnt;
		rd_cnt = (cnt > budget && !blocking) ? budget:cnt;

		DPMA_FT_LOG("start poll: pit_cnt(%u), pit_budget(%u)",
			cnt, budget);
		real_cnt = dpmaif_rx_start(rxq, rd_cnt, blocking, time_limit);
		DPMA_FT_LOG("end poll: pit_read(%d)", real_cnt);

		MTK_DEBUG_LOG(TAG, "dpmaif_rx_start return %d\n", real_cnt);

		if (real_cnt < LOW_MEMORY_TYPE_MAX) {
			ret = LOW_MEMORY;
			MTK_NOTICE_LOG(TAG, "rx low mem: %d\n", real_cnt);
		} else if (real_cnt <= ERROR_STOP_MAX) {
			ret = ERROR_STOP;
			MTK_NOTICE_LOG(TAG, "rx ERR_STOP: %d\n", real_cnt);
		} else if (real_cnt < 0) {
			ret = LOW_MEMORY;
			MTK_NOTICE_LOG(TAG, "rx ERROR: %d\n", real_cnt);
		} else if (real_cnt < max_cnt)
			ret = ONCE_MORE;
		else
			ret = ALL_CLEAR;
	} else {
		ret = ALL_CLEAR;
		hif_ctrl->traffic_info.poll_pit_empty[0]++;
	}

	if (cnt && ALL_CLEAR == ret) {
		MTK_DEBUG_LOG(TAG, "last cnt(%d), try poll again\n", cnt);
		goto poll_again;
	} else if (ret == ONCE_MORE) {
		/* hw ack. */
		dpmaif_hw_clr_dl_intr_sts_dl_done(0);
	}
#ifdef DPMA_FTRACE_DEBUG
	if (ret == ALL_CLEAR) {
		g_total_isr++;
		DPMA_FT_LOG(
			"NONE_NAPI_STATISTICS: intr_index(%llu), packet_cnt(%llu) --- #%llu#%llu#",
			g_total_isr, g_pkt_cnt_per_isr,
			g_total_isr, g_pkt_cnt_per_isr);
		g_pkt_cnt_per_isr = 0;
	}
#endif
	return ret;
}

static void dpmaif_rxq0_work(struct work_struct *work)
{
	struct dpmaif_rx_queue *rxq =
		container_of(work, struct dpmaif_rx_queue, dpmaif_rxq0_work);
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	int ret;

	atomic_set(&rxq->rx_processing, 1);
	smp_mb(); /* for cpu exec. */
	if (rxq->que_started != true) {
		ret = ALL_CLEAR;
		atomic_set(&rxq->rx_processing, 0);
		return;
	}

	/* RPM lock */
	mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);

	dpmaif_ctrl->traffic_info.latest_q_rx_time[rxq->index] = local_clock();
	ret = dpmaif_rx_data_collect(dpmaif_ctrl, rxq->index, rxq->budget, 1);

	if (ret == ONCE_MORE) {
		tasklet_hi_schedule(&dpmaif_ctrl->rxq[0].dpmaif_rxq0_task);
	} else if (unlikely(ret == LOW_MEMORY)) {
		/*Rx done and empty interrupt will be enabled in workqueue*/
		queue_work(rxq->worker,
			&rxq->dpmaif_rxq0_work);
	} else if (unlikely(ret == ERROR_STOP)) {
		ret = ccci_md_force_assert(dpmaif_ctrl->md_id,
			MD_FORCE_ASSERT_BY_AP_Q0_BLOCKED,
			NULL, 0);
	} else {
		dpmaif_hw_clear_ip_busy();
		dpmaif_hw_dl_unmask_rx_done_intr();
	}

	/* RPM unlock */
	mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

	atomic_set(&rxq->rx_processing, 0);


}

static void dpmaif_rxq0_tasklet(unsigned long data)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)data;
	struct dpmaif_rx_queue *rxq = &dpmaif_ctrl->rxq[0];
	int ret;

	atomic_set(&rxq->rx_processing, 1);
	dpmaif_ctrl->traffic_info.rx_tasket_cnt++;
	smp_mb(); /* for cpu exec. */
	if (rxq->que_started != true) {
		ret = ALL_CLEAR;
		atomic_set(&rxq->rx_processing, 0);
		return;
	}

	/* RPM lock */
	mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);

	dpmaif_ctrl->traffic_info.latest_q_rx_time[rxq->index] = local_clock();
	ret = dpmaif_rx_data_collect(dpmaif_ctrl, rxq->index, rxq->budget, 0);
	MTK_DEBUG_LOG(TAG, "dpmaif_rx_data_collect return %d\n", ret);

	if (ret == ONCE_MORE) {
		tasklet_hi_schedule(&rxq->dpmaif_rxq0_task);
	} else if (unlikely(ret == LOW_MEMORY)) {
		/*Rx done and empty interrupt will be enabled in workqueue*/
		queue_work(rxq->worker,
			&rxq->dpmaif_rxq0_work);
	} else if (unlikely(ret == ERROR_STOP)) {
		ret = ccci_md_force_assert(dpmaif_ctrl->md_id,
			MD_FORCE_ASSERT_BY_AP_Q0_BLOCKED,
			NULL, 0);
	} else {
		dpmaif_hw_clear_ip_busy();
		dpmaif_hw_dl_unmask_rx_done_intr();
	}

	/* RPM unlock */
	mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

	atomic_set(&rxq->rx_processing, 0);

	MTK_DEBUG_LOG(TAG, "rxq0 tasklet result %d\n", ret);


}
#endif
/* =======================================================
 *
 * Descriptions:  TX part start
 *
 * ========================================================
 */

static unsigned int dpmaifq_poll_tx_drb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num)
{
	struct dpmaif_tx_queue *txq;
	unsigned int drb_cnt = 0;
	unsigned short old_sw_rd_idx = 0, new_hw_rd_idx = 0;
	unsigned int hw_read_idx = 0;

	txq = &dpmaif_ctrl->txq[q_num];

	if (txq->que_started == false)
		return drb_cnt;

	old_sw_rd_idx = txq->drb_rd_idx;

	smp_mb(); /* for cpu exec. */

	hw_read_idx = dpmaif_get_ul_read_index(dpmaif_ctrl, q_num);

	new_hw_rd_idx = hw_read_idx / DPMAIF_UL_DRB_ENTRY_WORD;
	MTK_DEBUG_LOG(TAG,
		"txq%d UL read index = %d, new_hw_rd_idx = %d, old_sw_rd_idx = %d\n",
		q_num, hw_read_idx, new_hw_rd_idx, old_sw_rd_idx);

	if (new_hw_rd_idx >= DPMAIF_UL_DRB_ENTRY_SIZE)
		new_hw_rd_idx = 0;


	smp_mb(); /* for cpu exec. */

	if (old_sw_rd_idx <= new_hw_rd_idx)
		drb_cnt = new_hw_rd_idx - old_sw_rd_idx;
	else
		drb_cnt = txq->drb_size_cnt - old_sw_rd_idx + new_hw_rd_idx;

	smp_mb(); /* for cpu exec. */

	txq->drb_rd_idx = new_hw_rd_idx;
	MTK_DEBUG_LOG(TAG,
		"After update: txq%d new_hw_rd_idx = %d, old_sw_rd_idx = %d, txq->drb_rd_idx = %d, drb_cnt = %d, drb_rel_rd_idx = %d\n",
		q_num, new_hw_rd_idx, old_sw_rd_idx,
		txq->drb_rd_idx, drb_cnt, txq->drb_rel_rd_idx);

	return drb_cnt;
}

static void dpmaif_align_buf_enqueue(
	struct dpmaif_align_buf_pool *pool,
	unsigned int index, struct dpmaif_align_buffer **align_buf,
	unsigned int count);

static unsigned short dpmaif_relase_tx_buffer(
	struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned int release_cnt)
{
	unsigned int drb_entry_num, idx;
	unsigned short cur_idx;
	struct dpmaif_drb_pd *cur_drb, *drb_base =
		(struct dpmaif_drb_pd *)(dpmaif_ctrl->txq[q_num].drb_base);
	struct sk_buff *skb_free = NULL;
	struct dpmaif_tx_queue *txq = &dpmaif_ctrl->txq[q_num];
	struct dpmaif_drb_skb *cur_drb_skb = NULL;
	unsigned long flags;
	struct dpmaif_align_buffer *align_buffer = NULL;
	struct dpmaif_align_buf_queue *align_queue = NULL;

	if (release_cnt <= 0)
		return 0;

	LOCK_DPMF_RESOURCE(txq->tx_lock, flags);
	drb_entry_num = txq->drb_size_cnt;
	cur_idx = txq->drb_rel_rd_idx;
	UNLOCK_DPMF_RESOURCE(txq->tx_lock, flags);
	MTK_DEBUG_LOG(TAG,
		"Current drb idx = %d, release count = %d\n",
		cur_idx, release_cnt);

	for (idx = 0 ; idx < release_cnt ; idx++) {
		cur_drb = drb_base + cur_idx;
		if (cur_drb->dtyp == DES_DTYP_PD) {
			MTK_DEBUG_LOG(TAG,
				"txq%d release tx drb%d\n",
				q_num, cur_idx);
			cur_drb_skb =
				((struct dpmaif_drb_skb *)txq->drb_skb_base +
				cur_idx);

			dma_unmap_single(
				dpmaif_get_hw_device(dpmaif_ctrl),
				cur_drb_skb->phy_addr, cur_drb_skb->data_len,
				DMA_TO_DEVICE);

			/* do ul address align */
			if (cur_drb_skb->clone_buffer != NULL) {
				MTK_DEBUG_LOG(TAG,
					"cur_drb_skb->clone_buffer = %p\n",
					cur_drb_skb->clone_buffer);

				align_buffer = cur_drb_skb->clone_buffer;

				if (likely(true == align_buffer->from_pool)) {
					/* from pool */
					align_queue = align_buffer->queue;
					if (likely(align_queue)) {
						dpmaif_align_buf_enqueue(
							&dpmaif_ctrl->align_buf_pool,
							align_queue->q_index,
							&align_buffer, 1);
					}
				} else {
					/* from kernel */
					if (likely(align_buffer->buffer)) {
						kfree(align_buffer->buffer);
						align_buffer->buffer = NULL;
					}
					kfree(align_buffer);
					align_buffer = NULL;
				}

				cur_drb_skb->clone_buffer = NULL;
			}

			if (cur_drb->c_bit == 0) {
				skb_free = cur_drb_skb->skb;
				MTK_DEBUG_LOG(TAG,
					"txq(%u): drb_skb = 0x%p, cur_idx = %u, skb = 0x%p\n",
					q_num, cur_drb_skb,
					cur_idx, skb_free);
				if (skb_free == NULL) {
					MTK_INFO_LOG(TAG,
						"txq (%u)pkt(%u): drb check fail, (w/r/rel=%d, %d, %d), release_cnt = %u, this time index = %u\n",
						q_num, cur_idx,
						txq->drb_wr_idx,
						txq->drb_rd_idx,
						txq->drb_rel_rd_idx,
						release_cnt,
						idx);

					dpmaif_hw_dump(NULL);
					dpmaif_dump_txq_remain(dpmaif_ctrl,
						txq->index, 0);

					/* sleep 5ms */
					usleep_range(5000, 6000);
					DPMAIF_ASSERT();
					return DATA_CHECK_FAIL;
				}

			/* release buffer */
			if (skb_free)
				ccci_free_skb(skb_free);
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
				dpmaif_ctrl->tx_traffic_monitor[txq->index]++;
#endif
			}

			cur_drb_skb->skb = NULL;
		} else {
			txq->last_ch_id =
				((struct dpmaif_drb_msg *)cur_drb)->channel_id;
		}

		LOCK_DPMF_RESOURCE(txq->tx_lock, flags);
		cur_idx = ring_buf_get_next_wrdx(drb_entry_num, cur_idx);
		txq->drb_rel_rd_idx = cur_idx;
		atomic_inc(&txq->tx_budget);
		UNLOCK_DPMF_RESOURCE(txq->tx_lock, flags);

		if (ccci_md_get_cap_by_id(dpmaif_ctrl->md_id)
			& MODEM_CAP_TXBUSY_STOP) {
			if (atomic_read(&txq->tx_budget) >
				txq->drb_size_cnt / 8)
				dpmaif_queue_broadcast_state(dpmaif_ctrl,
					TX_IRQ, MTK_OUT, txq->index);
		}
	}
	if (cur_drb->c_bit != 0)
		MTK_DEBUG_LOG(TAG,
			"txq%d_done: last one: c_bit != 0 ???\n", q_num);

	return idx;
}

static int dpmaif_tx_release(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short budget)
{
	unsigned int rel_cnt, hw_rd_cnt, real_rel_cnt;
	struct dpmaif_tx_queue *txq = &dpmaif_ctrl->txq[q_num];
	unsigned long flags;

	/* update rd idx: from HW */
	LOCK_DPMF_RESOURCE(txq->tx_lock, flags);
	hw_rd_cnt = dpmaifq_poll_tx_drb(dpmaif_ctrl, q_num);
	rel_cnt = ring_buf_releasable(txq->drb_size_cnt,
				txq->drb_rel_rd_idx, txq->drb_rd_idx);
	UNLOCK_DPMF_RESOURCE(txq->tx_lock, flags);

	if (budget != 0 && rel_cnt > budget)
		real_rel_cnt = budget;
	else
		real_rel_cnt = rel_cnt;

	MTK_DEBUG_LOG(TAG,
		"txq%d %s hw cnt = 0x%x, 0x%x, 0x%x\n",
		q_num, __func__, hw_rd_cnt, rel_cnt, real_rel_cnt);

	if (real_rel_cnt) {
		/* release data buff */
		real_rel_cnt = dpmaif_relase_tx_buffer(dpmaif_ctrl,
			q_num, real_rel_cnt);
	}
	/* not need to know release idx hw, hw just update rd, and read wrt */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_done_last_count[q_num] = real_rel_cnt;
#endif

	if (real_rel_cnt < 0 || txq->que_started == false)
		return ERROR_STOP;
	else
		return ((real_rel_cnt < rel_cnt)?ONCE_MORE : ALL_CLEAR);
}

static inline unsigned int dpmaif_tx_queue_has_interrupt(unsigned int qno)
{
	return (dpmaif_hw_get_ul_done_status() & (0x01 << qno));
}

/*=== tx done =====*/
static void dpmaif_tx_done(struct work_struct *work)
{
	struct delayed_work *dwork = to_delayed_work(work);
	struct dpmaif_tx_queue *txq =
		container_of(dwork, struct dpmaif_tx_queue, dpmaif_tx_work);
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	int ret;

	dpmaif_ctrl = txq->dpmaif_ctrl;
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "hif_ctrl is a NULL pointer!\n");
		goto exit;
	}

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_done_last_start_time[txq->index] = local_clock();
#endif

	ret = dpmaif_tx_release(dpmaif_ctrl, txq->index, txq->drb_size_cnt);

	if (unlikely(ret == ERROR_STOP)) {

	} else if (ret == ONCE_MORE ||
		dpmaif_tx_queue_has_interrupt(txq->index)) {
		ret = queue_delayed_work(dpmaif_ctrl->txq[txq->index].worker,
				&dpmaif_ctrl->txq[txq->index].dpmaif_tx_work,
				msecs_to_jiffies(4));
	} else {
		dpmaif_hw_clear_ip_busy();
		dpmaif_hw_ul_unmask_tx_done_intr(txq->index);
	}

exit:
	return;
}

static void set_drb_msg(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char q_num,
	unsigned short cur_idx, unsigned int pkt_len, unsigned short count_l,
	unsigned char channel_id, unsigned short network_type)
{
	struct dpmaif_drb_msg *drb =
		((struct dpmaif_drb_msg *)dpmaif_ctrl->txq[q_num].drb_base +
		cur_idx);
	unsigned int *temp;


	drb->dtyp = DES_DTYP_MSG;
	drb->c_bit = 1;
	drb->packet_len = pkt_len;
	drb->count_l = count_l;
	drb->channel_id = channel_id;
	switch (network_type) {
	/*case htons(ETH_P_IP):
	 * drb->network_type = 4;
	 * break;
	 *
	 * case htons(ETH_P_IPV6):
	 * drb->network_type = 6;
	 * break;
	 */
	default:
		drb->network_type = 0;
		break;
	}

	temp = (unsigned int *)drb;
	MTK_DEBUG_LOG(TAG, "txq%d 0x%p: drb message(%d): 0x%x, 0x%x\n",
		q_num, drb, cur_idx, temp[0], temp[1]);

}

static void set_drb_payload(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short cur_idx,
	unsigned long long data_addr, unsigned int pkt_size, char last_one)
{
	struct dpmaif_drb_pd *drb =
		((struct dpmaif_drb_pd *)dpmaif_ctrl->txq[q_num].drb_base +
		cur_idx);
	unsigned int *temp;

	drb->dtyp = DES_DTYP_PD;
	if (last_one)
		drb->c_bit = 0;
	else
		drb->c_bit = 1;
	drb->data_len = pkt_size;
	drb->p_data_addr = data_addr & 0xFFFFFFFF;
	drb->data_addr_ext = (data_addr >> 32) & 0xFFFFFFFF;
	temp = (unsigned int *)drb;
	MTK_DEBUG_LOG(TAG,
		"txq%d 0x%p: drb payload(%d): 0x%x, 0x%x, 0x%x, 0x%x\n",
		q_num, drb, cur_idx, temp[0], temp[1], temp[2], temp[3]);
}

static void record_drb_skb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short cur_idx,
	struct sk_buff *skb, unsigned short is_msg, unsigned short is_frag,
	unsigned short is_last_one, dma_addr_t phy_addr, unsigned int data_len,
	void *align_buffer)
{
	struct dpmaif_drb_skb *drb_skb =
		((struct dpmaif_drb_skb *)dpmaif_ctrl->txq[q_num].drb_skb_base +
		cur_idx);
	unsigned int *temp;

	drb_skb->skb = skb;
	drb_skb->phy_addr = phy_addr;
	drb_skb->data_len = data_len;
	drb_skb->drb_idx = cur_idx;
	drb_skb->is_msg = is_msg;
	drb_skb->is_frag = is_frag;
	drb_skb->is_last_one = is_last_one;

	drb_skb->clone_buffer = align_buffer;

	temp = (unsigned int *)drb_skb;
	MTK_DEBUG_LOG(TAG,
		"txq(%d)0x%p: drb skb(%d): 0x%x, 0x%x, 0x%x, 0x%x\n",
		q_num, drb_skb, cur_idx, temp[0], temp[1], temp[2], temp[3]);
}


#ifdef DATA_PATH_UT_LOOPBACK
void dpmaif_ut_loopback_rx_skb(
	struct dpmaif_rx_queue *rxq, struct sk_buff *skb)
{
	struct ccci_header ccci_h;
	struct lhif_header *lhif_h;

	/* remove the ccci header */
	ccci_h = *(struct ccci_header *)skb->data;
	skb_pull(skb, sizeof(struct ccci_header));
	MTK_DEBUG_LOG(TAG, "TX interface ID = %d\n", ccci_h.data[0]);

	/* UT loopback */
	dpmaif_ut_loopback_pkt(skb);

	/* add lhif header for upper layer */
	lhif_h = (struct lhif_header *)(skb_push(skb,
		sizeof(struct lhif_header)));
	lhif_h->netif = ccci_h.data[0];
	ccci_skb_enqueue(&rxq->skb_list, skb);
	NOTIFY_RX_PUSH(rxq);
}
#endif

#ifdef DPMAIF_DEBUG_DUMP
static u64 g_dump_tx_cnt_main;    /* count of dump IP packets */
static u32 g_dump_tx_idx_frag;    /* frag index of dump IP packets */

/* this funciton just fot debug */
static void dpmaif_dump_ip_packet_data(unsigned short is_frag,
	char *data, unsigned int length)
{
	const unsigned int LINE_LEN = 0x10;
	unsigned int i = 0;
	unsigned int j = 0;
	char line_data[500] = {0};
	char tmp_data[10] = {0};

	if (is_frag == 0) {
		g_dump_tx_cnt_main++;
		g_dump_tx_idx_frag = 0;
	} else {
		g_dump_tx_idx_frag++;
	}

	MTK_DEBUG_LOG(TAG,
		"=== DUMP IP PACKET(No.%llu - %u) TO DPMAIF HW BEGIN ===\n",
		g_dump_tx_cnt_main, g_dump_tx_idx_frag);

	for (i = 0; i < length/LINE_LEN; i++) {
		memset(line_data, 0, sizeof(line_data));
		for (j = 0; j < LINE_LEN; j++) {
			snprintf(tmp_data, 4, "%02X ",
				(unsigned char)data[i*LINE_LEN + j]);
			strncat(line_data, tmp_data, 3);
		}
		MTK_DEBUG_LOG(TAG, "0x%04X~0x%04X:    %s\n",
			i*0x10, (i+1)*0x10, line_data);
	}

	if (length % LINE_LEN > 0) {
		memset(line_data, 0, sizeof(line_data));
		for (j = 0; j < length%LINE_LEN; j++) {
			snprintf(tmp_data, 4, "%02X ",
				(unsigned char)data[i*LINE_LEN + j]);
			strncat(line_data, tmp_data, 3);
		}
		MTK_DEBUG_LOG(TAG, "0x%04X~0x%04X:    %s\n",
			i*0x10, (i+1)*0x10, line_data);
	}

	MTK_DEBUG_LOG(TAG,
		"====== DUMP IP PACKET(No.%llu - %u) TO DPMAIF HW END ====\n",
		g_dump_tx_cnt_main, g_dump_tx_idx_frag);
}
#endif

void *dpmaif_align_buf_dequeue(struct dpmaif_align_buf_pool *pool,
	unsigned int index);
static void *dpmaif_alloc_aligned_buffer(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int size, unsigned char alignment, gfp_t flag)
{
	unsigned int align_size = 0;
	void *buffer = NULL;

	int index = 0;
	int q_index = 0;
	struct dpmaif_align_buf_pool *pool = NULL;
	struct dpmaif_align_buffer *align_buf = NULL;

	align_size = SIZE_ALIGN(size, alignment);

	pool = &dpmaif_ctrl->align_buf_pool;
	if (unlikely(align_size > DPMA_ALIGN_BUF_SIZE_MAX))
		goto from_kernel;


	for (index = 0; index < DPMA_ALIGN_QUEUE_CNT; index++) {
		q_index = DPMA_ALIGN_QUEUE_CNT - 1 - index;
		if (align_size <= pool->queue[q_index].size) {
			align_buf = (struct dpmaif_align_buffer *)
				dpmaif_align_buf_dequeue(pool, q_index);
			if (align_buf)
				break;
		}
	}

	if (likely(align_buf))
		goto succ;


from_kernel:
	align_buf = kzalloc(sizeof(struct dpmaif_align_buffer), flag);
	if (likely(align_buf)) {
		buffer = kmalloc(align_size, flag);
		if (likely(buffer)) {
			align_buf->buffer = buffer;
			align_buf->from_pool = false;
		} else {
			kfree(align_buf);
			align_buf = NULL;
		}
	}

	MTK_DEBUG_LOG(TAG,
		"size = %u, aligned size = %u, alignment = %u, buffer = %p, from_pool = %d\n",
		size, align_size, alignment, align_buf, align_buf->from_pool);
succ:
	return (void *)align_buf;
}

/* if we won't allocate new buffer, *vir_addr should be NULL */
static int dpmaif_tx_buffer_addr_align(struct md_dpmaif_ctrl *dpmaif_ctrl,
	dpmaif_ul_pkt_info_t *pkt_info, unsigned int index,
	dma_addr_t *phy_addr, void **aligned_addr, unsigned int *len)
{
	unsigned char *new_buffer = NULL;
	unsigned int copy_len = 0;
	unsigned char *vir_addr = NULL;
	struct dpmaif_align_buffer *tmp_buffer = NULL;

	if (unlikely(dpmaif_ctrl == NULL || pkt_info == NULL ||
		phy_addr == NULL || aligned_addr == NULL ||  len == NULL)) {
		MTK_DEBUG_LOG(TAG,
			"Invalid parameter: dpmaif_ctrl = %p, pkt_info = %p, phy_addr = %p, vir_addr = %p, len = %p\n",
			dpmaif_ctrl, pkt_info,
			phy_addr, aligned_addr, len);
		goto error;
	}

	*phy_addr = 0;
	*aligned_addr = NULL;
	*len = 0;

	MTK_DEBUG_LOG(TAG,
		"index = %u, remain_len = %u, remain_data_addr = %p, data_len = %u, data_addr = %p\n",
		index, pkt_info->remain_len,
		pkt_info->remain_data_addr,
		pkt_info->data_len[index],
		pkt_info->data_addr[index]);

	/* firstly, decide if need to allocate new buffer */
	if (!ADDR_ALIGN(pkt_info->data_addr[index],
		UL_ALIGNMENT) || pkt_info->remain_len) {
		if (pkt_info->remain_len &&
			pkt_info->remain_data_addr == NULL) {
			MTK_DEBUG_LOG(TAG,
				"remain_data_addr is NULL while remain_len is not 0\n");
			//DPMAIF_ASSERT();
			goto error;
		}

		tmp_buffer = dpmaif_alloc_aligned_buffer(dpmaif_ctrl,
			pkt_info->data_len[index] + pkt_info->remain_len,
			UL_ALIGNMENT,
			in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);

		if (unlikely(tmp_buffer == NULL)) {
			MTK_DEBUG_LOG(TAG, "allocate new buffer failed!\n");
			goto error;
		}

		new_buffer = (unsigned char *)tmp_buffer->buffer;

		if (pkt_info->remain_len != 0) {
			memcpy(new_buffer, pkt_info->remain_data_addr,
				pkt_info->remain_len);
		}

		/* checks if it is the last packet */
		if (index == pkt_info->pkt_cnt - 1) {
			*len = pkt_info->data_len[index] + pkt_info->remain_len;
		} else {
			*len = SIZE_ALIGN_DOWN(pkt_info->data_len[index]
				+ pkt_info->remain_len,
					UL_ALIGNMENT);
		}

		copy_len = *len - pkt_info->remain_len;
		memcpy((void *)((unsigned char *)new_buffer +
			pkt_info->remain_len),
			pkt_info->data_addr[index], copy_len);
		pkt_info->remain_len = pkt_info->data_len[index] - copy_len;

		if (pkt_info->remain_len != 0) {
			pkt_info->remain_data_addr = (void *)(
				(unsigned char *)
				pkt_info->data_addr[index] + copy_len);
		} else {
			pkt_info->remain_data_addr = NULL;
		}

		MTK_DEBUG_LOG(TAG, "len = %u, copy_len = %u, remain_len = %u\n",
			*len, copy_len,
			pkt_info->remain_len);
		vir_addr = new_buffer;
		*aligned_addr = tmp_buffer;
	} else {
		*len = pkt_info->data_len[index];
		vir_addr = pkt_info->data_addr[index];
		*aligned_addr = NULL;
	}

	/* tx mapping */
	*phy_addr = dma_map_single(
			dpmaif_get_hw_device(dpmaif_ctrl),
				vir_addr, *len, DMA_TO_DEVICE);
	if (dma_mapping_error(
		dpmaif_get_hw_device(dpmaif_ctrl), *phy_addr)) {
		MTK_ERR_LOG(TAG, "DMA mapping fail\n");
		goto error;
	}

	if (!ADDR_ALIGN(*phy_addr, UL_ALIGNMENT)) {
		MTK_ERR_LOG(TAG,
				"Data buffer address align 8 bytes failed!\n");
			goto error;
	}

	MTK_DEBUG_LOG(TAG,
		"vir_addr = %p, phy_addr = %llx, len = %u, aligned_addr = %p\n",
		vir_addr, *phy_addr, *len, *aligned_addr);

#ifdef DPMAIF_DEBUG_DUMP
	/* dump IP data for debugging */
	dpmaif_dump_ip_packet_data((index == 0) ? 0 : 1, vir_addr, *len);
#endif

	return 0;

error:
	return -1;
}

static int dpmaif_alloc_ul_pkt_info_res(struct md_dpmaif_ctrl *dpmaif_ctrl,
	dpmaif_ul_pkt_info_t *info, unsigned int cnt)
{
	if (unlikely(info == NULL)) {
		MTK_ERR_LOG(TAG, "NULL input pointer!\n");
		goto error;
	}

	info->data_len = kmalloc(sizeof(unsigned int) * cnt,
		in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);
	if (unlikely(info->data_len == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc memory for info->data_len failed!\n");
		goto error;
	}

	info->data_addr = kmalloc(sizeof(void *) * cnt,
		in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);
	if (unlikely(info->data_addr == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc memory for info->data_addr failed!\n");
		kfree(info->data_len);
		info->data_len = NULL;
		goto error;
	}

	memset(info->data_len, 0, sizeof(unsigned int) * cnt);
	memset(info->data_addr, 0, sizeof(void *) * cnt);

	return 0;

error:
	return -1;
}

static void dpmaif_rel_ul_pkt_info_res(struct md_dpmaif_ctrl *dpmaif_ctrl,
	dpmaif_ul_pkt_info_t *info)
{
	if (unlikely(info == NULL)) {
		MTK_ERR_LOG(TAG, "NULL input pointer!\n");
		goto exit;
	}

	if (info->data_len != NULL) {
		kfree(info->data_len);
		info->data_len = NULL;
	}

	if (info->data_addr != NULL) {
		kfree(info->data_addr);
		info->data_addr = NULL;
	}

exit:
	return;
}

static bool check_tx_queue_drb_available(struct dpmaif_tx_queue *txq,
	struct sk_buff *skb)
{
	bool ret = true;
	unsigned long flags;

	/*  msg drb + normal drb (skb linear data + frags data)*/
	int send_num_drb = skb_shinfo(skb)->nr_frags + 1 + 1;
	int drb_remain_cnt;

	spin_lock_irqsave(&txq->tx_lock, flags);
	drb_remain_cnt = ring_buf_writeable(txq->drb_size_cnt,
			txq->drb_rel_rd_idx, txq->drb_wr_idx);
	spin_unlock_irqrestore(&txq->tx_lock, flags);

	MTK_DEBUG_LOG(TAG, "Writeable drb count:%d\n", drb_remain_cnt);

	/* Check tx buffer full */
	if (unlikely(drb_remain_cnt < send_num_drb)) {
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
		txq->busy_count++;
#endif
		ret = false;
	}
	
	return ret;
}


static int dpmaif_tx_send_skb_on_tx_thread(
	unsigned char md_id, unsigned char hif_id, int qno,
	struct sk_buff *skb, int skb_from_pool, int blocking, bool first_time)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct dpmaif_tx_queue *txq;
	struct skb_shared_info *info = NULL;
	void *data_addr;
	unsigned int data_len;
	int ret = 0;
	unsigned short cur_idx, is_frag, is_last_one;
	struct ccci_header ccci_h;
	/* struct iphdr *iph = NULL;  add at port net layer? */
	unsigned int wt_cnt = 0, drb_remain_cnt = 0, send_cnt = 0, payload_cnt = 0;
	dma_addr_t phy_addr;
	unsigned long flags;
	bool skb_pulled = false;

	dpmaif_ul_pkt_info_t pkt_info;
	void *align_buffer = NULL;
	unsigned int align_len = 0;
	int align_ret = 0;
	int drb_wr_idx_backup = -1;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);

	/* 1. parameters check*/
	if (!skb)
		return 0;

	txq = &dpmaif_ctrl->txq[qno];

	MTK_DEBUG_LOG(TAG, "hif_id%d, ulq%d, drb: %d, w(%d), r(%d), rel(%d)\n",
		hif_id, qno, txq->drb_size_cnt, txq->drb_wr_idx,
		txq->drb_rd_idx, txq->drb_rel_rd_idx);

	atomic_set(&txq->tx_processing, 1);

	/* for cpu exec */
	smp_mb();

	if (txq->que_started != true) {
		ret = -CCCI_ERR_HIF_NOT_POWER_ON;
		goto exit;
	}

	if (dpmaif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON) {
		ret = -CCCI_ERR_HIF_NOT_POWER_ON;
		goto exit;
	}

#ifdef DATA_PATH_UT_LOOPBACK
	dpmaif_ut_loopback_rx_skb(&dpmaif_ctrl->rxq[0], skb);
	return 0;
#endif

	info = skb_shinfo(skb);
	if (info->frag_list != NULL)
		MTK_NOTICE_LOG(TAG,
			"Attention:ulq%d skb frag_list not supported!\n", qno);

	payload_cnt = info->nr_frags + 1;
	/* nr_frags: frag cnt, 1: skb->data, 1: msg drb */
	send_cnt = payload_cnt + 1;

	MTK_DEBUG_LOG(TAG,
		"send_cnt = %u, tx_budget = %d, que_started = %d, tx_processing = %d\n",
		send_cnt, (int)atomic_read(&txq->tx_budget),
		(int)txq->que_started, (int)atomic_read(&txq->tx_processing));

	spin_lock_irqsave(&txq->tx_lock, flags);
	drb_remain_cnt = ring_buf_writeable(txq->drb_size_cnt,
			txq->drb_rel_rd_idx, txq->drb_wr_idx);
	spin_unlock_irqrestore(&txq->tx_lock, flags);
	if (drb_remain_cnt < send_cnt) {
		ret = LOW_MEMORY_DRB;
		goto exit;
	}

	ccci_h = *(struct ccci_header *)skb->data;
	skb_pull(skb, sizeof(struct ccci_header));
	skb_pulled = true;

	spin_lock_irqsave(&txq->tx_lock, flags);

	/* update the drb_wr_idx */
	cur_idx = txq->drb_wr_idx;
	drb_wr_idx_backup = cur_idx;
	txq->drb_wr_idx += send_cnt;
	if (txq->drb_wr_idx >= txq->drb_size_cnt)
		txq->drb_wr_idx -= txq->drb_size_cnt;

	/* 3 send data. */
	/* 3.1 a msg drb first, then payload drb. */
	set_drb_msg(dpmaif_ctrl, txq->index, cur_idx, skb->len, 0,
				ccci_h.data[0], skb->protocol);
	record_drb_skb(dpmaif_ctrl, txq->index, cur_idx, skb, 1, 0, 0, 0, 0, 0);

	spin_unlock_irqrestore(&txq->tx_lock, flags);

	/* for debug */
	MTK_DEBUG_LOG(TAG, "#%s#ip.id#%d\n", __func__,
		dpmaif_ut_get_packet_id((struct iphdr *)skb->data));

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	ccci_md_add_log_history(&dpmaif_ctrl->traffic_info, MTK_OUT,
			(int)txq->index, &ccci_h, 0);
#endif
	/* get next index. */
	cur_idx = ring_buf_get_next_wrdx(txq->drb_size_cnt, cur_idx);

	/* 3.2 payload drb: skb->data + frags[] */
	memset(&pkt_info, 0, sizeof(pkt_info));
	if (unlikely(dpmaif_alloc_ul_pkt_info_res(dpmaif_ctrl,
			&pkt_info, payload_cnt) != 0)) {
		MTK_ERR_LOG(TAG, "Alloc UL skb info fail\n");
		ret = DMA_MAPPING_ERR;
		goto exit;
	}

	for (wt_cnt = 0; wt_cnt < payload_cnt; wt_cnt++) {
		/* get data_addr && data_len */
		if (wt_cnt == 0) {
			data_len = skb_headlen(skb);
			data_addr = skb->data;
		} else {
			skb_frag_t *frag = info->frags + wt_cnt - 1;

			data_len = skb_frag_size(frag);
			data_addr = skb_frag_address(frag);
		}

		pkt_info.data_addr[wt_cnt] = data_addr;
		pkt_info.data_len[wt_cnt] = data_len;
	}

	pkt_info.total_len = skb->len;
	pkt_info.pkt_cnt = payload_cnt;
	MTK_DEBUG_LOG(TAG, "pkt total_len = %u, pkt_cnt = %u,\n",
		pkt_info.total_len, pkt_info.pkt_cnt);

	/* copy data to 8 bytes aligned buffer */
	for (wt_cnt = 0; wt_cnt < pkt_info.pkt_cnt; wt_cnt++) {
		align_ret = dpmaif_tx_buffer_addr_align(
			dpmaif_ctrl, &pkt_info, wt_cnt,
			&phy_addr, &align_buffer, &align_len);
		if (align_ret != 0) {
			MTK_ERR_LOG(TAG, "DMA mapping fail\n");
			ret = -1;
			goto exit;
		}

		if (wt_cnt == pkt_info.pkt_cnt - 1)
			is_last_one = 1;
		else
			is_last_one = 0;

		if (wt_cnt == 0)
			is_frag = 0;
		else
			is_frag = 1;

		spin_lock_irqsave(&txq->tx_lock, flags);
		set_drb_payload(dpmaif_ctrl, txq->index,
			cur_idx, phy_addr, align_len,
			is_last_one);
		record_drb_skb(dpmaif_ctrl,
			txq->index, cur_idx, skb, 0, is_frag,
			is_last_one, phy_addr, align_len, align_buffer);
		spin_unlock_irqrestore(&txq->tx_lock, flags);
		
		cur_idx = ring_buf_get_next_wrdx(txq->drb_size_cnt, cur_idx);

		MTK_DEBUG_LOG(TAG,
			"txq(%d) drb: total(%d) w(%d), r(%d), rel(%d)\n",
			qno, txq->drb_size_cnt, txq->drb_wr_idx,
			txq->drb_rd_idx, txq->drb_rel_rd_idx);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
		dpmaif_ctrl->tx_payload_monitor[txq->index]++;
#endif
	}

	/* debug: tx on ccci_channel && HW Q */
	ccci_channel_update_packet_counter(
		dpmaif_ctrl->traffic_info.logic_ch_pkt_pre_cnt, &ccci_h);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_pre_traffic_monitor[txq->index]++;
#endif
	atomic_sub(send_cnt, &txq->tx_budget);

	/* 3.3 submit drb descriptor*/
	wmb();

	/* wait for the pcie resoure locked done */
	if (first_time)
		mtk_pci_l_resource_wait_complete(
			dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

	ret = dpmaif_send_data(qno, send_cnt);

exit:
	dpmaif_rel_ul_pkt_info_res(dpmaif_ctrl, &pkt_info);

	MTK_DEBUG_LOG(TAG,
		"Ret = %d, send_skb(%d) end: drb: %d w(%d), r(%d), rel(%d)\n",
		ret, qno,
		txq->drb_size_cnt, txq->drb_wr_idx,
		txq->drb_rd_idx, txq->drb_rel_rd_idx);

	atomic_set(&txq->tx_processing, 0);

	/* send fail, should recover the skb data. */
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "send fail: drb_wr_idx_backup:%d, ret:%d\n",
			drb_wr_idx_backup, ret);

		if (skb_pulled == true)
			skb_push(skb, sizeof(struct ccci_header));

		if (drb_wr_idx_backup >= 0) {
			spin_lock_irqsave(&txq->tx_lock, flags);
			txq->drb_wr_idx = drb_wr_idx_backup;
			spin_unlock_irqrestore(&txq->tx_lock, flags);
		}

		if (ret == HW_REG_CHK_FAIL) {
			DPMAIF_ASSERT();
		}
	}

	return ret;
}

/* must be called within protection of event_lock */
static inline void dpamif_finish_event(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_tx_event *event)
{
	list_del(&event->entry);
	kfree(event);
}

static int dpmaif_tx_hw_push_thread(void *arg)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)arg;
	struct dpmaif_tx_event *event = NULL;
	unsigned long flags;
	int ret = 0;
	bool first_time = false;
	struct dpmaif_tx_queue *txq;
	int retry_times = DPMAIF_TX_RETRY_TIMES;
	unsigned int tx_packet_weight = DPMAIF_TX_BURST_SEND_COUNT;

	while (1) {
		if (list_empty(&dpmaif_ctrl->tx_event_queue) ||
			(dpmaif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON)) {
			ret = wait_event_interruptible(dpmaif_ctrl->tx_wq,
				((!list_empty(&dpmaif_ctrl->tx_event_queue) && 
				(dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON)) ||
				kthread_should_stop()));

			if (ret == -ERESTARTSYS)
				continue;
		}

		if (kthread_should_stop())
			break;

		/* RPM get*/
		ret = mtk_pm_runtime_get_sync(dpmaif_ctrl->mtk_dev);
		if (ret < 0) {
			MTK_ERR_LOG(TAG, "rpm lock fail, ret:%d\n", ret);
			ret = -1;
			continue;
		}

		/* lock the pcie resource */
		mtk_pci_l_resource_lock(
			dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

		first_time = true;
		retry_times = DPMAIF_TX_RETRY_TIMES;
		tx_packet_weight = DPMAIF_TX_BURST_SEND_COUNT;
		do {
			/* avoid the tx thread soft lockup */
			tx_packet_weight--;
			if (tx_packet_weight <= 0) {
				tx_packet_weight = DPMAIF_TX_BURST_SEND_COUNT;
				usleep_range(1, 2);
			}

			spin_lock_irqsave(&dpmaif_ctrl->tx_event_lock, flags);
			event = list_first_entry(&dpmaif_ctrl->tx_event_queue,
			   struct dpmaif_tx_event, entry);
			spin_unlock_irqrestore(
				&dpmaif_ctrl->tx_event_lock, flags);

			ret = dpmaif_tx_send_skb_on_tx_thread(
				event->md_id, event->hif_id, event->qno,
				event->skb, event->skb_from_pool,
				event->blocking, first_time);

			txq = &dpmaif_ctrl->txq[event->qno];
			if (unlikely(ret == LOW_MEMORY_DRB)) {
				MTK_INFO_LOG(TAG,"NO DRB to use!\n");
				usleep_range(1000, 2000);
			} else if (unlikely(ret < 0)) {
				MTK_INFO_LOG(TAG,
					"send skb fail, ret=%d,retry_times:%d\n",
					ret, retry_times);
				retry_times--;
				if (retry_times < 0) {
					retry_times = DPMAIF_TX_RETRY_TIMES;
					dev_kfree_skb_any(event->skb);
					event->skb = NULL;
					spin_lock_irqsave(&dpmaif_ctrl->tx_event_lock, flags);
					dpamif_finish_event(dpmaif_ctrl, event);
					txq->tx_submit_cnt--;
					spin_unlock_irqrestore(
						&dpmaif_ctrl->tx_event_lock, flags);
				}
			} else {
				retry_times = DPMAIF_TX_RETRY_TIMES;
				spin_lock_irqsave(&dpmaif_ctrl->tx_event_lock, flags);
				dpamif_finish_event(dpmaif_ctrl, event);
				txq->tx_submit_cnt--;
				spin_unlock_irqrestore(
					&dpmaif_ctrl->tx_event_lock, flags);
			}

			first_time = false;
		} while (!list_empty(&dpmaif_ctrl->tx_event_queue) &&
			!kthread_should_stop() && (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON));

		/* unlock the pcie resource */
		mtk_pci_l_resource_unlock(dpmaif_ctrl->mtk_dev,
			dpmaif_ctrl->lock_user);

		/* RPM put*/
		mtk_pm_runtime_put_sync(dpmaif_ctrl->mtk_dev);
	}

	return 0;
}

static int dpamif_tx_thread_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is NULL pointer!\n");
		return -1;
	}

	spin_lock_init(&dpmaif_ctrl->tx_event_lock);
	INIT_LIST_HEAD(&dpmaif_ctrl->tx_event_queue);
	init_waitqueue_head(&dpmaif_ctrl->tx_wq);
	dpmaif_ctrl->tx_thread = kthread_run(dpmaif_tx_hw_push_thread,
				dpmaif_ctrl, "dpmaif_tx_hw_push");

	return 0;
}

static int dpamif_tx_thread_uninit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned long flags;
	struct dpmaif_tx_event *event, *event_next;

	/* stop rx thread */
	if (dpmaif_ctrl->tx_thread)
		kthread_stop(dpmaif_ctrl->tx_thread);

	spin_lock_irqsave(&dpmaif_ctrl->tx_event_lock, flags);
	list_for_each_entry_safe(event, event_next,
		&dpmaif_ctrl->tx_event_queue, entry) {
		MTK_INFO_LOG(TAG,
			"Drop ulq%d hw send event after stop\n", event->qno);
		if (event->skb)
			dev_kfree_skb_any(event->skb);
		dpamif_finish_event(dpmaif_ctrl, event);
	}
	spin_unlock_irqrestore(&dpmaif_ctrl->tx_event_lock, flags);

	return 0;
}

static int dpmaif_tx_send_skb(
	unsigned char md_id, unsigned char hif_id, int qno,
	struct sk_buff *skb, int skb_from_pool, int blocking)
{
	int ret = 0;
	struct dpmaif_tx_event *event = NULL;
	unsigned long flags;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct dpmaif_tx_queue *txq;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "hif_ctrl is a NULL pointer!\n");
		DPMAIF_ASSERT();
		return 0;
	}

	if (qno >= DPMAIF_TXQ_NUM) {
		MTK_ERR_LOG(TAG, "txq(%d) > %d\n", qno, DPMAIF_TXQ_NUM);
		ret = -CCCI_ERR_INVALID_QUEUE_INDEX;
		DPMAIF_ASSERT();
		goto fail;
	}

	event = kmalloc(sizeof(struct dpmaif_tx_event),
		in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);
	if (!event) {
		MTK_ERR_LOG(TAG, "qno%d: fail to alloc event\n", qno);
		ret = -EBUSY;
		goto fail;
	}

	INIT_LIST_HEAD(&event->entry);
	event->md_id = md_id;
	event->hif_id = hif_id;
	event->qno = qno;
	event->skb = skb;
	event->skb_from_pool = skb_from_pool;
	event->blocking = blocking;

	txq = &dpmaif_ctrl->txq[qno];

	/* check tx queue drb full */
	if ((txq->tx_submit_cnt < txq->tx_list_max_len) && 
		check_tx_queue_drb_available(txq, skb)) {
			spin_lock_irqsave(&dpmaif_ctrl->tx_event_lock, flags);
			list_add_tail(&event->entry, &dpmaif_ctrl->tx_event_queue);
			txq->tx_submit_cnt++;
			spin_unlock_irqrestore(&dpmaif_ctrl->tx_event_lock, flags);
	} else {
		/* notify to ccmni layer, ccmni should carry off the net device tx queue. */
		if (likely(ccci_md_get_cap_by_id(dpmaif_ctrl->md_id)
				&MODEM_CAP_TXBUSY_STOP)) {
			dpmaif_queue_broadcast_state(
				dpmaif_ctrl, TX_FULL, MTK_OUT, event->qno);
		}
		kfree(event);
		ret = -EBUSY;
	}

	wake_up(&dpmaif_ctrl->tx_wq);

fail:
	return ret;
}

/* =======================================================
 *
 * Descriptions: ISR part start
 *
 * ========================================================
 */

static void dpmaif_enable_irq(struct md_dpmaif_ctrl *hif_ctrl)
{
	if (atomic_cmpxchg(&hif_ctrl->dpmaif_irq_enabled, 0, 1) == 0) {
		if (mtk_pcie_set_ext_int_mask(hif_ctrl->mtk_dev, DPMAIF_INT, 0) != 0)
			MTK_ERR_LOG(TAG, "Unmask DPMAIF interrupt failed!\n");
	}
}

static void dpmaif_disable_irq(struct md_dpmaif_ctrl *hif_ctrl)
{
	if (atomic_cmpxchg(&hif_ctrl->dpmaif_irq_enabled, 1, 0) == 1) {
		if (mtk_pcie_set_ext_int_mask(hif_ctrl->mtk_dev, DPMAIF_INT, 1) != 0)
			MTK_ERR_LOG(TAG, "Mask DPMAIF interrupt failed!\n");
	}
}

#ifndef DATA_PATH_NET_NAPI_MODE
static void dpmaif_irq_rx_done(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
	/* debug information colloect */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.latest_q_rx_isr_time[0] = local_clock();
#endif
	/* disable RX_DONE    interrupt */
	tasklet_hi_schedule(&dpmaif_ctrl->rxq[0].dpmaif_rxq0_task);

	/* get current CPU */
	DPMF_GET_CUR_CPU(&dpmaif_ctrl->rxq[0].cur_irq_cpu);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.rx_done_isr_cnt[0]++;
#endif
}

#else /* ifndef DATA_PATH_NET_NAPI_MODE */

static void dpmaif_irq_rx_done(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
/* debug information colloect */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.latest_q_rx_isr_time[0] = local_clock();
#endif

	/* schedule RX napi */
	DPMF_NAPI_RX_SCHE();

	/* get current CPU */
	DPMF_GET_CUR_CPU(&dpmaif_ctrl->rxq[0].cur_irq_cpu);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.rx_done_isr_cnt[0]++;
#endif
}

#endif /* ifndef DATA_PATH_NET_NAPI_MODE */

static void dpmaif_irq_tx_done(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
	int i, ret;
	unsigned int intr_ul_que_done;

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		intr_ul_que_done =
			que_mask & (1 << i);
		if (intr_ul_que_done) {
			ret = queue_delayed_work(dpmaif_ctrl->txq[i].worker,
					&dpmaif_ctrl->txq[i].dpmaif_tx_work,
					/* delay time from 1000/Hz to 1 */
					msecs_to_jiffies(1));
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.tx_done_isr_cnt[i]++;
#endif
		}
	}
}

static void dpmaif_irq_cb(struct md_dpmaif_ctrl *hif_ctrl)
{
	dpmaif_hw_intr_st_para_t intr_status;
	int index = 0;
	int hw_ret = 0;

	if (hif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "Hif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	memset(&intr_status, 0, sizeof(dpmaif_hw_intr_st_para_t));

	/* gets HW interrupt types */
	/* in dpmaif_hw_get_interrupt_status,
	 *we have already clear DPMAIF interrupt status
	 */
	hw_ret = dpmaif_hw_get_interrupt_status((void *)&intr_status);
	if (-1 == hw_ret) {
		MTK_ERR_LOG(TAG, "Get HW interrupt status failed!\n");
		goto exit;
	}

	/* Clear level 1 interrupt status */
	/* Clear level 2 DPMAIF interrupt status firstly,
	 *then clear level 1 PCIE interrupt status to avoid empty interrupt
	 */
	mtk_pcie_clr_ext_int_sts(hif_ctrl->mtk_dev, DPMAIF_INT);

	/* handles interrupts */
	for (index = 0; index < intr_status.intr_cnt; index++) {
		switch (intr_status.intr_types[index]) {
		/* UL part */
		case DPF_INTR_UL_DONE:
			MTK_DEBUG_LOG(TAG,
				"UL interrupt: queue(0x%x) UL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_tx_done(hif_ctrl,
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_UL_DRB_EMPTY:
			MTK_DEBUG_LOG(TAG,
				"UL interrupt: queue(0x%x) DRB empty!\n",
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_UL_MD_NOTREADY:
			MTK_INFO_LOG(TAG, "UL interrupt: MD not ready!\n");
			break;

		case DPF_INTR_UL_MD_PWR_NOTREADY:
			MTK_INFO_LOG(TAG,
				"UL interrupt: MD power not ready!\n");
			break;

		case DPF_INTR_UL_LEN_ERR:
			MTK_INFO_LOG(TAG, "UL interrupt: length error!\n");
			DPMAIF_ASSERT();
			break;

		/*DL part*/
		case DPF_INTR_DL_DONE:
			MTK_DEBUG_LOG(TAG,
				"DL interrupt: queue(0x%x) DL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_rx_done(hif_ctrl,
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_DL_SKB_LEN_ERR:
			MTK_INFO_LOG(TAG, "DL interrupt: skb length err!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			hif_ctrl->traffic_info.rx_other_isr_cnt[0]++;
#endif
			DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_BATCNT_LEN_ERR:
			MTK_INFO_LOG(TAG,
				"DL interrupt: packet BAT count length err!\n");
			//dpmaif_dump_rxq_remain(hif_ctrl, 0, 0);
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			hif_ctrl->traffic_info.rx_isr_bat_len_err_cnt[0]++;
#endif
			dpmaif_hw_dl_unmask_rx_bat_cnt_len_err_intr();
			//DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_PITCNT_LEN_ERR:
			MTK_INFO_LOG(TAG,
				"DL interrupt: PIT count length err!\n");
			//dpmaif_dump_rxq_remain(hif_ctrl, 0, 0);
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			hif_ctrl->traffic_info.rx_isr_pit_len_err_cnt[0]++;
#endif
			dpmaif_hw_dl_unmask_rx_pit_cnt_len_err_intr();
			DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_PKT_EMPTY_SET:
			MTK_INFO_LOG(TAG,
				"DL interrupt: packet BAT buffer empty!\n");
			DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_FRG_EMPTY_SET:
			MTK_INFO_LOG(TAG,
				"DL interrupt: fragment BAT buffer empty!\n");
			DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_MTU_ERR:
			MTK_INFO_LOG(TAG, "DL interrupt: MTU size err!\n");
			DPMAIF_ASSERT();
			break;

		case DPF_INTR_DL_FRGCNT_LEN_ERR:
			MTK_INFO_LOG(TAG,
				"DL interrupt: fragment BAT count length err!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			hif_ctrl->traffic_info.rx_full_cnt++;
#endif
			DPMAIF_ASSERT();
			break;

		default:
			MTK_DEBUG_LOG(TAG,
				"DL interrupt: unknown interrupt!\n");
		}
	}

exit:
	return;
}

static int dpmaif_isr(void *data)
{
	struct md_dpmaif_ctrl *hif_ctrl = (struct md_dpmaif_ctrl *)data;

	if (hif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON) {
		MTK_ERR_LOG(TAG, "the unexpected dpmaif isr!");
		goto exit;
	}

	// mask PCIE interrupt first
	mtk_pcie_set_ext_int_mask(hif_ctrl->mtk_dev, DPMAIF_INT, DRV_TRUE);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	hif_ctrl->traffic_info.latest_isr_time = local_clock();
#endif

	dpmaif_irq_cb(hif_ctrl);

	mtk_pcie_set_ext_int_mask(hif_ctrl->mtk_dev, DPMAIF_INT, DRV_FALSE);

exit:
	return IRQ_HANDLED;
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(RX) -- 1.1.2 rx sw init
 *
 * ========================================================
 */

static int dpmaif_bat_init(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req, unsigned char q_num)
{
	bat_req->bat_size_cnt = DPMAIF_DL_BAT_ENTRY_SIZE;
	bat_req->skb_pkt_cnt = bat_req->bat_size_cnt;
	bat_req->pkt_buf_sz = DPMAIF_BUF_PKT_SIZE;
	bat_req->bat_rd_idx = 0;
	bat_req->bat_wr_idx = 0;
	bat_req->bat_rel_rd_idx = 0;
	/* alloc buffer for HW && AP SW */
#if (DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
	 bat_req->bat_base = dma_alloc_coherent(
		dpmaif_get_hw_device(dpmaif_ctrl),
		(bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)),
		&bat_req->bat_phy_addr, GFP_KERNEL);
#else
	bat_req->bat_base = dma_pool_alloc(dpmaif_ctrl->rx_bat_dmapool,
		GFP_KERNEL, &bat_req->bat_phy_addr);
#endif

	MTK_DEBUG_LOG(TAG, "bat_phy_addr = 0x%llx, bat_size_cnt = %u\n",
		bat_req->bat_phy_addr, bat_req->bat_size_cnt);

	/* alloc buffer for AP SW to record skb information */
	bat_req->bat_skb_ptr = kzalloc((bat_req->skb_pkt_cnt *
		sizeof(struct dpmaif_bat_skb_t)),
		GFP_KERNEL);
	if (bat_req->bat_base == NULL || bat_req->bat_skb_ptr == NULL) {
		MTK_ERR_LOG(TAG, "bat request fail\n");
		return LOW_MEMORY_BAT;
	}
	memset(bat_req->bat_base, 0, DPMAIF_DL_BAT_SIZE);

	/* alloc buffer for BAT mask */
	bat_req->bat_mask = kcalloc(
		bat_req->bat_size_cnt, sizeof(unsigned char), GFP_KERNEL);

	return 0;
}

static void dpmaif_bat_rel(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req)
{
	struct dpmaif_bat_skb_t *cur_skb = NULL;
	unsigned int index = 0;

	if (unlikely(bat_req == NULL || dpmaif_ctrl == NULL))
		return;


	kfree(bat_req->bat_mask);
	bat_req->bat_mask = NULL;

	if (bat_req->bat_skb_ptr) {
		for (index = 0; index < bat_req->bat_size_cnt; index++) {
			cur_skb = ((struct dpmaif_bat_skb_t *)
				bat_req->bat_skb_ptr + index);

			if (cur_skb->skb) {
				dma_unmap_single(
					dpmaif_get_hw_device(dpmaif_ctrl),
					cur_skb->data_phy_addr,
					cur_skb->data_len,
					DMA_FROM_DEVICE);

				kfree_skb(cur_skb->skb);
				cur_skb->skb = NULL;
			}
		}

		kfree(bat_req->bat_skb_ptr);
		bat_req->bat_skb_ptr = NULL;
	}

	if (bat_req->bat_base) {
#if (DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(dpmaif_ctrl),
			(bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)),
			bat_req->bat_base,
			bat_req->bat_phy_addr);
#else
		dma_pool_free(dpmaif_ctrl->rx_bat_dmapool, bat_req->bat_base,
			bat_req->bat_phy_addr);
#endif
	}
}

static void dpmaif_rx_pit_seq_init(struct dpmaif_rx_queue *rxq)
{
	int i = 0;
	struct dpmaifq_normal_pit *pit = NULL;

	for (i = 0; i < rxq->pit_size_cnt; i++) {
		pit = (struct dpmaifq_normal_pit *)rxq->pit_base + i;
		pit->pit_seq = DPMAIF_PIT_SEQ_MAGIC;
	}
}

static int dpmaif_rx_buf_init(struct dpmaif_rx_queue *rxq)
{
	int ret = 0;

	/* PIT buffer init */
	rxq->pit_size_cnt = DPMAIF_DL_PIT_ENTRY_SIZE;
	rxq->pit_rd_idx = 0;
	rxq->pit_wr_idx = 0;
	rxq->pit_rel_rd_idx = 0;
	rxq->expect_pit_seq = 0;
	rxq->pit_remain_rel_cnt = 0;
	rxq->pit_not_rel_entrynum = 0;
	rxq->cur_irq_cpu = DPMF_CUR_CPU_INVALID;
	rxq->cur_rx_thrd_cpu = DPMF_CUR_CPU_INVALID;
	rxq->cs_result = 0;
	rxq->begin_drop = false;

	/* alloc buffer for HW && AP SW */
#if (DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
	rxq->pit_base = dma_alloc_coherent(
		dpmaif_get_hw_device(rxq->dpmaif_ctrl),
		(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)),
		&rxq->pit_phy_addr, GFP_KERNEL);
#else
	rxq->pit_base = dma_pool_alloc(rxq->dpmaif_ctrl->rx_pit_dmapool,
		GFP_KERNEL, &rxq->pit_phy_addr);
#endif
	if (rxq->pit_base == NULL) {
		MTK_ERR_LOG(TAG, "pit request fail\n");
		return LOW_MEMORY_PIT;
	}

	MTK_DEBUG_LOG(TAG, "sizeof(normal pit) = %lu, sizeof(msg pit) = %lu\n",
		sizeof(struct dpmaifq_normal_pit),
		sizeof(struct dpmaifq_msg_pit));
	MTK_DEBUG_LOG(TAG,
		"rxq(%u)'s pit_base = %p, pit_phy_addr = 0x%llx, pit_size_cnt = %u\n",
		rxq->index, rxq->pit_base,
		rxq->pit_phy_addr, rxq->pit_size_cnt);

	memset(rxq->pit_base, 0, DPMAIF_DL_PIT_SIZE);
	dpmaif_rx_pit_seq_init(rxq);

	/* BAT table */
	ret = dpmaif_bat_init(rxq->dpmaif_ctrl, &rxq->bat_req, rxq->index);
	if (ret)
		return ret;

#ifdef DPMAIF_DEBUG_DUMP
	dpmaif_dump_rxq_remain(rxq->dpmaif_ctrl, rxq->index, 0);
#endif

	return ret;
}

static void dpmaif_rx_buf_rel(struct dpmaif_rx_queue *rxq)
{
	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL))
		return;

	dpmaif_bat_rel(rxq->dpmaif_ctrl, &rxq->bat_req);

	if (rxq->pit_base) {
#if (DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(rxq->dpmaif_ctrl),
			(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)),
			rxq->pit_base,
			rxq->pit_phy_addr);
#else
		dma_pool_free(rxq->dpmaif_ctrl->rx_pit_dmapool, rxq->pit_base,
			rxq->pit_phy_addr);
#endif
	}
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(RX) -- 1.1.0 rx init
 *
 * =======================================================
 */
static int dpmaif_rxq_init(struct dpmaif_rx_queue *queue)
{
	int ret = -1;

	ret = dpmaif_rx_buf_init(queue);
	if (ret) {
		MTK_ERR_LOG(TAG, "rx buffer init fail %d\n", ret);
		return ret;
	}

#ifndef DATA_PATH_NET_NAPI_MODE
	/* rx tasklet */
	tasklet_init(&queue->dpmaif_rxq0_task, dpmaif_rxq0_tasklet,
			(unsigned long)queue->dpmaif_ctrl);
	/* rx work */
	INIT_WORK(&queue->dpmaif_rxq0_work, dpmaif_rxq0_work);
	queue->worker = alloc_workqueue("ccci_dpmaif_rx0_worker",
				WQ_UNBOUND | WQ_MEM_RECLAIM | WQ_HIGHPRI, 1);

#endif

#if !defined(DATA_PATH_NET_NAPI_MODE) || defined(DATA_PATH_UT_LOOPBACK)
	/* rx push */
	init_waitqueue_head(&queue->rx_wq);
	ccci_skb_queue_init(&queue->skb_list, queue->bat_req.skb_pkt_cnt,
				SKB_RX_LIST_MAX_LEN, 0);

	queue->rx_thread = kthread_run(dpmaif_net_rx_push_thread,
				queue, "dpmaif_rx_push");
#endif
	spin_lock_init(&queue->rx_lock);

	return 0;
}

void ccci_skb_queue_rel(struct ccci_skb_queue *queue)
{
#ifndef DATA_PATH_NET_NAPI_MODE
	struct sk_buff *skb = NULL;
#endif

	if (unlikely(queue == NULL))
		return;

#ifndef DATA_PATH_NET_NAPI_MODE
	while ((skb = skb_dequeue(&queue->skb_list)) != NULL) {
		kfree_skb(skb);
		skb = NULL;
	}
#endif
}

static void dpmaif_rxq_rel(struct dpmaif_rx_queue *queue)
{
	if (unlikely(queue == NULL))
		return;

#if !defined(DATA_PATH_NET_NAPI_MODE) || defined(DATA_PATH_UT_LOOPBACK)
	/* stop rx thread */
	if (queue->rx_thread)
		kthread_stop(queue->rx_thread);
#endif

#ifndef DATA_PATH_NET_NAPI_MODE
	if (queue->worker) {
		flush_workqueue(queue->worker);
		destroy_workqueue(queue->worker);
	}

	tasklet_disable(&queue->dpmaif_rxq0_task);
	tasklet_kill(&queue->dpmaif_rxq0_task);
#endif

#if !defined(DATA_PATH_NET_NAPI_MODE) || defined(DATA_PATH_UT_LOOPBACK)
	ccci_skb_queue_rel(&queue->skb_list);
#endif

	dpmaif_rx_buf_rel(queue);
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(TX) -- 1.2.2 tx sw init
 *
 * ========================================================
 */
static int dpmaif_tx_buf_init(struct dpmaif_tx_queue *txq)
{
	int ret = 0;

	/* DRB buffer init */
	txq->drb_size_cnt = DPMAIF_UL_DRB_ENTRY_SIZE;

	/* alloc buffer for HW && AP SW */
#if (DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
	txq->drb_base = dma_alloc_coherent(
		dpmaif_get_hw_device(txq->dpmaif_ctrl),
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)),
		&txq->drb_phy_addr, GFP_KERNEL);
#else
	txq->drb_base = dma_pool_alloc(txq->dpmaif_ctrl->tx_drb_dmapool,
		GFP_KERNEL, &txq->drb_phy_addr);
#endif

	if (txq->drb_base == NULL) {
		MTK_ERR_LOG(TAG, "drb request fail\n");
		return LOW_MEMORY_DRB;
	}

	MTK_DEBUG_LOG(TAG,
		"txq%d drb_phy_addr = 0x%llx, drb_size_cnt = %u\n",
		txq->index, txq->drb_phy_addr, txq->drb_size_cnt);

	memset(txq->drb_base, 0, DPMAIF_UL_DRB_SIZE);
	/* alloc buffer for AP SW */
	txq->drb_skb_base =
		kzalloc((txq->drb_size_cnt * sizeof(struct dpmaif_drb_skb)),
				GFP_KERNEL);
	if (txq->drb_skb_base == NULL) {
		MTK_ERR_LOG(TAG, "drb skb buffer request fail\n");
		return LOW_MEMORY_DRB;
	}

	return ret;
}

static void dpmaif_tx_buf_rel(struct dpmaif_tx_queue *txq)
{
	unsigned int index = 0;
	struct dpmaif_drb_skb *drb_skb = NULL;

	if (unlikely(txq == NULL || txq->dpmaif_ctrl == NULL))
		return;

	if (txq->drb_base) {
#if (DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(txq->dpmaif_ctrl),
			(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)),
			txq->drb_base,
			txq->drb_phy_addr);
#else
		dma_pool_free(txq->dpmaif_ctrl->tx_drb_dmapool,
			txq->drb_base, txq->drb_phy_addr);
#endif
	}

	if (txq->drb_skb_base) {
		for (index = 0; index < txq->drb_size_cnt; index++) {
			drb_skb = ((struct dpmaif_drb_skb *)
				txq->drb_skb_base + index);
			if (drb_skb->clone_buffer || drb_skb->skb) {
				dma_unmap_single(
						dpmaif_get_hw_device(
						txq->dpmaif_ctrl),
						drb_skb->phy_addr,
						drb_skb->data_len,
						DMA_TO_DEVICE);
				kfree(drb_skb->clone_buffer);
				drb_skb->clone_buffer = NULL;
				if (drb_skb->skb && drb_skb->is_last_one) {
					kfree_skb(drb_skb->skb);
					drb_skb->skb = NULL;
				}
			}
		}

		kfree(txq->drb_skb_base);
		txq->drb_skb_base = NULL;
	}
}


/* =======================================================
 *
 * Descriptions: State part start(1/3): init(TX) -- 1.2.0 tx init
 *
 * ========================================================
 */

static int dpmaif_txq_init(struct dpmaif_tx_queue *txq)
{
	int ret = -1;

	txq->tx_submit_cnt = 0;
	txq->tx_list_max_len = DPMAIF_DL_BAT_ENTRY_SIZE / 2;

	init_waitqueue_head(&txq->req_wq);
	atomic_set(&txq->tx_budget, DPMAIF_UL_DRB_ENTRY_SIZE);
	ret = dpmaif_tx_buf_init(txq);
	if (ret) {
		MTK_ERR_LOG(TAG, "Tx buffer init fail, ret:%d\n", ret);
		return ret;
	}

	txq->worker = alloc_workqueue("md%d_dpmaif_tx%d_worker",
		WQ_UNBOUND | WQ_MEM_RECLAIM |
		(txq->index == 0 ? WQ_HIGHPRI : 0),
		1, txq->dpmaif_ctrl->md_id + 1, txq->index);
	INIT_DELAYED_WORK(&txq->dpmaif_tx_work, dpmaif_tx_done);
	spin_lock_init(&txq->tx_lock);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	txq->busy_count = 0;
#endif

#ifdef DPMAIF_DEBUG_DUMP
	dpmaif_dump_txq_remain(txq->dpmaif_ctrl, txq->index, 0);
#endif

	return 0;
}

static void dpmaif_txq_rel(struct dpmaif_tx_queue *txq)
{
	if (unlikely(txq == NULL))
		return;

	if (txq->worker) {
		flush_workqueue(txq->worker);
		destroy_workqueue(txq->worker);
	}

	dpmaif_tx_buf_rel(txq);
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(ISR) -- 1.3
 *
 * ========================================================
 */

int dpmaif_platform_irq_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;

	mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, DPMAIF_INT, true);
	ret = mtk_pcie_register_ext_int_callback(
		dpmaif_ctrl->mtk_dev, DPMAIF_INT,
		dpmaif_isr, (void *)dpmaif_ctrl);
	mtk_pcie_clr_ext_int_sts(dpmaif_ctrl->mtk_dev, DPMAIF_INT);
	mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, DPMAIF_INT, false);

	return ret;
}

#define DPMF_MAP_SKB_ENQ(entry, skb_list) {\
		list_add_tail(&entry, &skb_list.head); \
		skb_list.qlen++; \
	}
static inline void *dpmaif_map_skb_deq(struct dpmaif_map_skb *skb_list)
{
	struct list_head *entry = NULL;

	entry = skb_list->head.next;
	if (likely(!list_empty(&skb_list->head) && entry)) {
		list_del(entry);
		skb_list->qlen--;
	} else {
		entry = NULL;
	}

	return (void *)entry;
}

#define DPMF_MAP_SKB_QUE_EMPTY(skb_list)    list_empty(&skb_list.head)

static int dpmaif_skb_queue_init_struct(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int index)
{
	int ret = 0;
	struct dpmaif_skb_queue *queue = NULL;
	unsigned int size = 0;
	unsigned int max_cnt = 0;

	queue = &dpmaif_ctrl->skb_pool.queue[index];
	size = DPMA_SKB_SIZE_MAX / (1 << index);
	max_cnt = DPMA_SKB_QUEUE_SIZE / DPMA_SKB_SIZE_TRUE(size);

	if (size < DPMA_SKB_TRUE_SIZE_MIN) {
		ret = 0;
		goto err;
	}

	INIT_LIST_HEAD(&queue->skb_list.head);
	spin_lock_init(&queue->skb_list.lock);
	queue->skb_list.qlen = 0;
	queue->size = size;
	queue->max_len = max_cnt;
	queue->busy_cnt = 0;

err:
	return ret;
}

static void dpmaif_skb_queue_rel(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index)
{
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_info *skb_info = NULL;
	struct list_head *entry = NULL;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_SKB_QUEUE_CNT)) {
		MTK_ERR_LOG(TAG, "Release skb queue input check fail\n");
		goto exit;
	}

	queue = &dpmaif_ctrl->skb_pool.queue[index];
	while (!DPMF_MAP_SKB_QUE_EMPTY(queue->skb_list)) {
		entry = dpmaif_map_skb_deq(&queue->skb_list);
		if (likely(entry)) {
			skb_info = (struct dpmaif_skb_info *)
				GET_SKB_BY_ENTRY(entry);
			if (likely(skb_info)) {
				if (likely(skb_info->skb)) {
					dev_kfree_skb_any(skb_info->skb);
					skb_info->skb = NULL;
				}
				kfree(skb_info);
				skb_info = NULL;
			}
		}
	}

exit:
	return;
}

static inline int dpmaif_find_reload_cpu(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int cpu;
	bool found = false;

	for_each_online_cpu(cpu) {
		if (cpu != dpmaif_ctrl->rxq[0].cur_irq_cpu && cpu !=
			dpmaif_ctrl->rxq[0].cur_rx_thrd_cpu) {
			found = true;
			break;
		}
	}
	if (false == found)
		DPMF_GET_CUR_CPU(&cpu);

	return cpu;
}

struct dpmaif_skb_info *dpmaif_skb_dequeue(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index)
{
	unsigned long flags;
	struct dpmaif_skb_info *result = NULL;
	struct list_head *entry = NULL;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_pool *pool = NULL;
	unsigned int max_len, qlen;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_SKB_QUEUE_CNT))
		goto error;


	pool = &dpmaif_ctrl->skb_pool;
	queue = &pool->queue[index];

	spin_lock_irqsave(&queue->skb_list.lock, flags);

	entry = dpmaif_map_skb_deq(&queue->skb_list);
	max_len = queue->max_len;
	qlen = queue->skb_list.qlen;

	spin_unlock_irqrestore(&queue->skb_list.lock, flags);

	if (unlikely(entry == NULL))
		goto busy;

	result = (struct dpmaif_skb_info *)GET_SKB_BY_ENTRY(entry);
	if (qlen < max_len * DPMA_RELOAD_TH_1 / DPMA_RELOAD_TH_2) {
		queue_work_on(dpmaif_find_reload_cpu(dpmaif_ctrl),
			pool->pool_reload_work_queue, &pool->reload_work);
	}

busy:
	if (result == NULL) {
		queue->busy_cnt++;
		MTK_INFO_LOG(TAG,
			"skb queue(%u, %u, %lu, %u) empty, dequeue fail\n",
			index, queue->size, queue->busy_cnt,
			queue->skb_list.qlen);
	}

	return result;

error:
	return NULL;
}

static void skb_reload_work(struct work_struct *work)
{
	struct sk_buff *skb;
	unsigned int index = 0;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_pool *pool = NULL;
	unsigned int cnt = 0;
	unsigned int size = 0;
	unsigned int max_cnt = 0;
	unsigned long flags;
	unsigned int qlen = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct dpmaif_skb_info *skb_info = NULL;

	pool = (struct dpmaif_skb_pool *)container_of(work,
		struct dpmaif_skb_pool, reload_work);
	if (unlikely(pool == NULL))
		goto error;


	dpmaif_ctrl = (struct md_dpmaif_ctrl *)container_of(pool,
		struct md_dpmaif_ctrl, skb_pool);
	if (unlikely(dpmaif_ctrl == NULL))
		goto error;


	for (index = 0; index < DPMA_SKB_QUEUE_CNT; index++) {
		queue = &pool->queue[index];
		spin_lock_irqsave(&queue->skb_list.lock, flags);
		size = queue->size;
		max_cnt = queue->max_len;
		qlen = queue->skb_list.qlen;
		spin_unlock_irqrestore(&queue->skb_list.lock, flags);
		if (qlen < max_cnt * DPMA_RELOAD_TH_1 / DPMA_RELOAD_TH_2) {
			cnt = max_cnt - qlen;
			while (cnt > 0) {
				skb = __dev_alloc_skb(size, GFP_KERNEL);
				if (skb) {
					skb_info = dpmaif_skb_dma_map(
						dpmaif_ctrl, skb);
					if (skb_info != NULL) {
						spin_lock_irqsave(
							&queue->skb_list.lock,
							flags);

						DPMF_MAP_SKB_ENQ(
							skb_info->entry,
							queue->skb_list);

						spin_unlock_irqrestore(
							&queue->skb_list.lock,
							flags);
					} else {
						dev_kfree_skb_any(skb);
						skb = NULL;
					}
				} else {
					MTK_ERR_LOG(TAG,
						"Fail to alloc a skb for skb_queue(%d)\n",
						index);
				}
				cnt--;
			}

			MTK_DEBUG_LOG(TAG,
				"Reload skb queue(%d) done, now skb len = %d\n",
				index, queue->skb_list.qlen);
		}
	}

error:
	return;
}

static inline unsigned int dpmaif_skb_avail_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index)
{
	struct dpmaif_skb_queue *queue = NULL;
	unsigned long flags;
	unsigned int result = 0;

	if (likely(dpmaif_ctrl)) {
		queue = &dpmaif_ctrl->skb_pool.queue[q_index];

		spin_lock_irqsave(&queue->skb_list.lock, flags);

		result = queue->skb_list.qlen;

		spin_unlock_irqrestore(&queue->skb_list.lock, flags);
	}

	return result;
}

static int dpmaif_skb_pool_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_skb_pool *pool = NULL;
	int index = 0;

	pool = &dpmaif_ctrl->skb_pool;
	pool->queue_cnt = DPMA_SKB_QUEUE_CNT;

	/* init the skb queue structure */
	for (index = 0; index < pool->queue_cnt; index++) {
		if (unlikely(dpmaif_skb_queue_init_struct(dpmaif_ctrl, index))) {
			MTK_ERR_LOG(TAG,
				"Init align buffer queue(%d) fail\n",
				index);
			goto err;
		}
	}

	/* init pool reload work */
	pool->pool_reload_work_queue = alloc_workqueue(
		"dpmaif_skb_pool_reload_work", WQ_MEM_RECLAIM, 1);
	if (!pool->pool_reload_work_queue) {
		MTK_ERR_LOG(TAG, "Creat the pool_reload_work_queue fail\n");
		goto err;
	}
	INIT_WORK(&pool->reload_work, skb_reload_work);

	/* schedule the skb pool reload workqueue */
	queue_work_on(dpmaif_find_reload_cpu(dpmaif_ctrl),
		pool->pool_reload_work_queue, &pool->reload_work);
err:
	return 0;
}

static void dpmaif_skb_pool_rel(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned int index = 0;
	struct dpmaif_skb_pool *pool = NULL;

	if (unlikely(dpmaif_ctrl == NULL))
		goto exit;


	pool = &dpmaif_ctrl->skb_pool;

	flush_work(&pool->reload_work);

	if (pool->pool_reload_work_queue) {
		flush_workqueue(pool->pool_reload_work_queue);
		destroy_workqueue(pool->pool_reload_work_queue);
		pool->pool_reload_work_queue = NULL;
	}

	for (index = 0; index < DPMA_SKB_QUEUE_CNT; index++)
		dpmaif_skb_queue_rel(dpmaif_ctrl, index);


exit:
	return;
}

static int dpmaif_align_buf_queue_init_struct(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int index)
{
	int ret = 0;
	struct dpmaif_align_buf_queue *queue = NULL;
	unsigned int size = 0;
	unsigned int max_cnt = 0;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_ALIGN_QUEUE_CNT)) {
		ret = -1;
		goto err;
	}

	queue = &dpmaif_ctrl->align_buf_pool.queue[index];
	size = DPMA_ALIGN_BUF_SIZE_MAX /
		(1 << (DPMA_ALIGN_BUF_SIZE_DIV_POW * index));
	size = DPMA_ALIGN_BUF_SIZE_TRUE(size);
	max_cnt = DPMA_ALIGN_BUF_CNT;

	INIT_LIST_HEAD(&queue->buf_list);
	queue->avail_cnt = 0;
	spin_lock_init(&queue->lock);
	queue->max_len = max_cnt;
	queue->size = size;
	queue->busy_cnt = 0;
	queue->q_index = index;

err:
	return ret;

}


static int dpmaif_align_buf_queue_init(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int index)
{
	int i = 0;
	struct dpmaif_align_buf_queue *queue = NULL;
	struct dpmaif_align_buffer *align_buffer = NULL;
	unsigned int size = 0;
	unsigned char *buf = NULL;
	struct list_head *entry, *n;
	unsigned long flags;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_ALIGN_QUEUE_CNT))
		goto error;

	queue = &dpmaif_ctrl->align_buf_pool.queue[index];
	size = queue->size;

	for (i = 0; i < queue->max_len; i++) {
		align_buffer = kmalloc(sizeof(struct dpmaif_align_buffer),
			GFP_KERNEL);
		if (align_buffer) {
			buf = kmalloc(size, GFP_KERNEL);
			if (buf) {
				align_buffer->buffer = buf;
				align_buffer->queue = (void *)queue;
				align_buffer->size = size;
				align_buffer->from_pool = true;
				spin_lock_irqsave(&queue->lock, flags);
				list_add_tail(&align_buffer->entry,
					&queue->buf_list);
				queue->avail_cnt++;
				spin_unlock_irqrestore(&queue->lock, flags);
			} else {
				MTK_DEBUG_LOG(TAG,
					"Allocate buffer(size = %d) for queue(index = %d) fail\n",
					size, index);
				goto alloc_fail;
			}
		} else {
			goto alloc_fail;
		}
	}

	MTK_INFO_LOG(TAG,
		"ALIGN QUEUE: index(%u), max_cnt(%u), avail_cnt(%u), size(%u), busy_cnt(%u)\n",
		index, queue->max_len, queue->avail_cnt, size, queue->busy_cnt);

	return 0;
	
alloc_fail:
	kfree(align_buffer);
	align_buffer = NULL;
	entry = NULL;
	n = NULL;
	list_for_each_safe(entry, n, &queue->buf_list) {
		if (entry) {
			align_buffer = DPMA_GET_ALIGN_BUF(entry);
			if (align_buffer) {
				kfree(align_buffer->buffer);
				align_buffer->buffer = NULL;
				kfree(align_buffer);
				align_buffer = NULL;
			}
		}
	}

error:
	return -1;
}

static void dpmaif_align_buf_queue_rel(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int index)
{
	struct dpmaif_align_buf_queue *queue = NULL;
	struct dpmaif_align_buffer *align_buffer = NULL;
	struct list_head *entry, *n;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_ALIGN_QUEUE_CNT))
		goto exit;

	queue = &dpmaif_ctrl->align_buf_pool.queue[index];

	entry = NULL;
	n = NULL;
	list_for_each_safe(entry, n, &queue->buf_list) {
		if (entry) {
			align_buffer = DPMA_GET_ALIGN_BUF(entry);
			if (align_buffer) {
				kfree(align_buffer->buffer);
				align_buffer->buffer = NULL;

				kfree(align_buffer);
				align_buffer = NULL;
			}
		}
	}

exit:
	return;
}

void *dpmaif_align_buf_dequeue(struct dpmaif_align_buf_pool *pool,
	unsigned int index)
{
	unsigned long flags;
	void *result = NULL;
	struct dpmaif_align_buf_queue *queue = NULL;
	struct dpmaif_align_buffer *buffer = NULL;
	struct list_head *entry = NULL;
	unsigned int avail_cnt = 0;
	unsigned int max_len = 0;

	if (unlikely(pool == NULL || index >= DPMA_ALIGN_QUEUE_CNT))
		goto error;

	queue = &pool->queue[index];
	spin_lock_irqsave(&queue->lock, flags);
	avail_cnt = queue->avail_cnt;
	max_len = queue->max_len;
	if (!list_empty(&queue->buf_list)) {
		entry = queue->buf_list.next;
		buffer = DPMA_GET_ALIGN_BUF(entry);
		list_del(entry);

		queue->avail_cnt--;
		avail_cnt = queue->avail_cnt;
	}
	spin_unlock_irqrestore(&queue->lock, flags);

	result = buffer;
	if (result == NULL)
		queue->busy_cnt++;

	return result;

error:
	return NULL;
}

static void dpmaif_align_buf_enqueue(
	struct dpmaif_align_buf_pool *pool, unsigned int index,
	struct dpmaif_align_buffer **align_buf, unsigned int count)
{
	unsigned long flags;
	struct dpmaif_align_buf_queue *queue = NULL;
	int i = 0;

	if (unlikely(align_buf == NULL ||
		pool == NULL || index >= DPMA_ALIGN_QUEUE_CNT))
		goto error;

	queue = &pool->queue[index];

	spin_lock_irqsave(&queue->lock, flags);
	for (i = 0; i < count; i++) {
		if (align_buf[i]) {
			list_add_tail(&align_buf[i]->entry, &queue->buf_list);
			queue->avail_cnt++;
		}
	}
	spin_unlock_irqrestore(&queue->lock, flags);

error:
	return;
}

static int dpmaif_align_buf_pool_load(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_align_buf_pool *pool = NULL;
	int index = 0;

	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "align buf pool init input check fail\n");
		goto error;
	}

	pool = &dpmaif_ctrl->align_buf_pool;
	for (index = 0; index < pool->queue_cnt; index++) {
		if (unlikely(dpmaif_align_buf_queue_init(dpmaif_ctrl, index))) {
			MTK_ERR_LOG(TAG,
				"Init align buffer queue(%d) fail\n",
				index);
			goto error;
		}
	}

	return 0;

error:
	while (index > 0) {
		dpmaif_align_buf_queue_rel(dpmaif_ctrl, index-1);
		index--;
	}

	return -1;
}

static inline unsigned int dpmaif_align_buf_avail_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index)
{
	struct dpmaif_align_buf_queue *queue = NULL;
	unsigned long flags;
	unsigned int result = 0;

	if (likely(dpmaif_ctrl)) {
		queue = &dpmaif_ctrl->align_buf_pool.queue[q_index];
		spin_lock_irqsave(&queue->lock, flags);
		result = queue->avail_cnt;
		spin_unlock_irqrestore(&queue->lock, flags);
	}

	return result;
}


static void align_skb_reload_work(struct work_struct *work)
{
	struct dpmaif_align_buf_pool *pool = NULL;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	pool = (struct dpmaif_align_buf_pool *)container_of(work,
		struct dpmaif_align_buf_pool, reload_work);

	dpmaif_ctrl = (struct md_dpmaif_ctrl *)container_of(pool,
		struct md_dpmaif_ctrl, align_buf_pool);

	if (dpmaif_align_buf_pool_load(dpmaif_ctrl)) {
		MTK_ERR_LOG(TAG, "Init align skb pool fail\n");
	}

	MTK_INFO_LOG(TAG, "Skb align pool init done\n");
}

static int dpmaif_align_buf_pool_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	struct dpmaif_align_buf_pool *pool = NULL;
	int index = 0;

	pool = &dpmaif_ctrl->align_buf_pool;
	pool->queue_cnt = DPMA_ALIGN_QUEUE_CNT;

	for (index = 0; index < pool->queue_cnt; index++) {
		if (unlikely(dpmaif_align_buf_queue_init_struct(dpmaif_ctrl, index))) {
			MTK_ERR_LOG(TAG,
				"Init align buffer queue(%d) fail\n",
				index);
			ret = -1;
			goto err;
		}
	}

	/* init pool reload work */
	INIT_WORK(&pool->reload_work, align_skb_reload_work);
	schedule_work(&pool->reload_work);

err:
	return ret;
}

static void dpmaif_align_buf_pool_rel(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned int index = 0;
	struct dpmaif_align_buf_pool *pool = NULL;

	if (unlikely(dpmaif_ctrl == NULL))
		goto exit;

	pool = &dpmaif_ctrl->align_buf_pool;
	flush_work(&pool->reload_work);

	for (index = 0; index < DPMA_ALIGN_QUEUE_CNT; index++)
		dpmaif_align_buf_queue_rel(dpmaif_ctrl, index);

exit:
	return;
}


/* we put initializations which takes too much time here: SW init only */
int dpmaif_sw_init(unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_rx_queue *rx_q;
	struct dpmaif_tx_queue *tx_q;
	int ret, i;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	/* gets dpmaif_ctrl firstly */
	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is NULL pointer!\n");
		goto error;
	}

	/* registers DPMAIF callback isr with PCIE driver */
	ret = dpmaif_platform_irq_init(dpmaif_ctrl);
	if (ret != 0) {
		MTK_ERR_LOG(TAG,
			"Register DPMAIF callback isr with PCIE driver fail\n");
		goto error;
	}

	atomic_set(&dpmaif_ctrl->dpmaif_irq_enabled, 1);
	dpmaif_disable_irq(dpmaif_ctrl);

	/* RX PIT/BAT DMA pool init */
#if !(DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
	dpmaif_ctrl->rx_pit_dmapool = dma_pool_create("dpmaif_pit_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_DL_PIT_ENTRY_SIZE * sizeof(struct dpmaifq_normal_pit)),
		64, 0);
#endif

#if !(DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
	dpmaif_ctrl->rx_bat_dmapool = dma_pool_create("dpmaif_bat_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_DL_BAT_ENTRY_SIZE *
			sizeof(struct dpmaif_bat_t)), 64, 0);
#endif

	/* Init the RX queue */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rx_q = &dpmaif_ctrl->rxq[i];
		rx_q->index = i;
		rx_q->dpmaif_ctrl = dpmaif_ctrl;
		dpmaif_rxq_init(rx_q);
	}

	/* RX DRB DMA pool init  */
#if !(DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
	dpmaif_ctrl->tx_drb_dmapool = dma_pool_create("dpmaif_drb_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_UL_DRB_ENTRY_SIZE *
			sizeof(struct dpmaif_drb_pd)), 64, 0);
#endif

	/* Init the TX queue */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		tx_q = &dpmaif_ctrl->txq[i];
		tx_q->index = i;
		tx_q->dpmaif_ctrl = dpmaif_ctrl;
		dpmaif_txq_init(tx_q);
	}

	/* TX thread: send skb data to dpmaif HW */
	dpamif_tx_thread_init(dpmaif_ctrl);

	/* skb pool init */
	dpmaif_skb_pool_init(dpmaif_ctrl);
	dpmaif_align_buf_pool_init(dpmaif_ctrl);

	return 0;

error:
	return -1;
}

static void dpmaif_sw_rel(unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_rx_queue *rx_q = NULL;
	struct dpmaif_tx_queue *tx_q = NULL;
	int i = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (unlikely(dpmaif_ctrl == NULL))
		return;

	/*release the tx thread*/
	dpamif_tx_thread_uninit(dpmaif_ctrl);

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		tx_q = &dpmaif_ctrl->txq[i];
		dpmaif_txq_rel(tx_q);
	}

	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rx_q = &dpmaif_ctrl->rxq[i];
		dpmaif_rxq_rel(rx_q);
	}

#if !(DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->rx_pit_dmapool);
#endif

#if !(DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->rx_bat_dmapool);
#endif

#if !(DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->tx_drb_dmapool);

#endif

	dpmaif_skb_pool_rel(dpmaif_ctrl);
	dpmaif_align_buf_pool_rel(dpmaif_ctrl);
}

/* =======================================================
 *
 * Descriptions: State part start(2/3): Start -- 2.
 *
 * ========================================================
 */

int dpmaif_start(unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_rx_queue *rxq;
	struct dpmaif_tx_queue *txq;
	int i, ret = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	dpmaif_hw_init_para_t hw_init_para;
	unsigned int buf_cnt = 0;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_sw_init_done != true) {
		MTK_ERR_LOG(TAG, "dpmaif sw init fail\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON) {
		MTK_INFO_LOG(TAG, "dpmaif in poweron status\n");
		goto err;
	}
	
	MTK_INFO_LOG(TAG,
		"md%d, dpmaif_state: %d, md_capability: 0x%x\n", md_id,
		dpmaif_ctrl->dpmaif_state,
		ccci_md_get_cap_by_id(dpmaif_ctrl->md_id));

	memset(&hw_init_para, 0, sizeof(dpmaif_hw_init_para_t));

	/* rx rx */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rxq = &dpmaif_ctrl->rxq[i];
		rxq->que_started = true;
		rxq->index = i;
		memset(rxq->bat_req.bat_mask, 0,
			rxq->bat_req.bat_size_cnt * sizeof(unsigned char));

		/*re-use tst buffer and submit bat*/
		buf_cnt = rxq->bat_req.bat_size_cnt - 1;

		ret = dpmaif_alloc_rx_buf(dpmaif_ctrl,
			&rxq->bat_req, i, buf_cnt, 1, true);
		if (ret) {
			MTK_ERR_LOG(TAG, "dpmaif_alloc_rx_buf fail\n");
			return LOW_MEMORY;
		}

		rxq->budget = rxq->bat_req.bat_size_cnt - 1;
		rxq->check_bid_fail_cnt = 0;

		/* DPMAIF HW RX queue init parameter */
		hw_init_para.pkt_bat_base_addr[i] = rxq->bat_req.bat_phy_addr;
		hw_init_para.pkt_bat_size_cnt[i] = rxq->bat_req.bat_size_cnt;
		hw_init_para.pit_base_addr[i] = rxq->pit_phy_addr;
		hw_init_para.pit_size_cnt[i] = rxq->pit_size_cnt;

	}

	/* tx tx */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		txq = &dpmaif_ctrl->txq[i];
		txq->que_started = true;

		/* DPMAIF HW TX queue init parameter */
		hw_init_para.drb_base_addr[i] = txq->drb_phy_addr;
		hw_init_para.drb_size_cnt[i] = txq->drb_size_cnt;
	}

	dpmaif_hw_init((void *)&hw_init_para);

	/* notifies DPMAIF HW for available BAT count */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rxq = &dpmaif_ctrl->rxq[i];
		dpmaif_hw_dl_add_pkt_bat_cnt(i, rxq->bat_req.bat_size_cnt - 1);
	}

	dpmaif_hw_clr_ul_all_intr_sts();
	dpmaif_hw_clr_dl_all_intr_sts();

	/* for traffic monitor */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	mod_timer(&dpmaif_ctrl->traffic_monitor,
			jiffies + DPMAIF_TRAFFIC_MONITOR_INTERVAL * HZ);
#endif

	dpmaif_ctrl->dpmaif_state = HIFDPMAIF_STATE_PWRON;
	dpmaif_enable_irq(dpmaif_ctrl);

	/* wake up the dpmaif tx thread */
	wake_up(&dpmaif_ctrl->tx_wq);
	return 0;

err:
	return -1;
}

void dpmaif_pre_start_hw(unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_rx_queue *rxq;
	struct dpmaif_tx_queue *txq;
	unsigned int que_cnt;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "pre start hw\n");

	/* ===Enable UL SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_TXQ_NUM; que_cnt++) {
		txq = &dpmaif_ctrl->txq[que_cnt];
		MTK_DEBUG_LOG(TAG, "ulq%d: 0x%x, 0x%x, 0x%x, (0x%x)\n", que_cnt,
			txq->drb_wr_idx, txq->drb_rd_idx, txq->drb_rel_rd_idx,
			atomic_read(&txq->tx_processing));
		txq->que_started = true;
	}

	/* ===Ensable DL/RX SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_RXQ_NUM; que_cnt++) {
		rxq = &dpmaif_ctrl->rxq[que_cnt];
		MTK_DEBUG_LOG(TAG,
			"dlq%d: 0x%x, 0x%x, 0x%x\n",
			que_cnt, rxq->pit_rd_idx, rxq->pit_wr_idx,
			rxq->pit_rel_rd_idx);

		rxq->que_started = true;
	}

exit:
	return;
}


void dpmaif_start_hw(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG(TAG, "Start tx/rx queue HW\n");
	dpmaif_hw_start_tx_queue();
	dpmaif_hw_start_rx_queue();
}

/* =======================================================
 *
 * Descriptions: State part start(3/3): Stop -- 3.
 *
 * ========================================================
 */
static void dpmaif_suspend_tx_sw_stop(
	unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_tx_queue *txq;
	unsigned int que_cnt;
	int count;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "tx suspend stop SW\n");

	/* ===Disable UL SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_TXQ_NUM; que_cnt++) {
		txq = &dpmaif_ctrl->txq[que_cnt];
		MTK_DEBUG_LOG(TAG, "txq%d: 0x%x, 0x%x, 0x%x, (0x%x)\n", que_cnt,
			txq->drb_wr_idx, txq->drb_rd_idx, txq->drb_rel_rd_idx,
			atomic_read(&txq->tx_processing));

		txq->que_started = false;
		/* for cpu exec*/
		smp_mb();

		/* just confirm sw will not update drb_wcnt reg. */
		count = 0;
		do {
			if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
				MTK_ERR_LOG(TAG, "Pool stop Tx failed\n");
				break;
			}
		} while (atomic_read(&txq->tx_processing) != 0);
	}
	MTK_DEBUG_LOG(TAG, "Stop tx proc cnt: 0x%x\n", count);

exit:
	return;
}

static void dpmaif_suspend_rx_sw_stop(
	unsigned char md_id, unsigned char hif_id)
{
	struct dpmaif_rx_queue *rxq;
	unsigned int que_cnt;
	int count;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "rx suspend stop SW\n");


	/* ===Disable DL/RX SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_RXQ_NUM; que_cnt++) {
		rxq = &dpmaif_ctrl->rxq[que_cnt];
		/* flush work */
#ifndef DATA_PATH_NET_NAPI_MODE
		flush_work(&rxq->dpmaif_rxq0_work);/* tasklet no need */
#endif
		/* for BAT add_cnt register */
		count = 0;
		do {
			/*retry handler*/
			if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
				MTK_ERR_LOG(TAG,
					"Stop Rx sw failed, 0x%x\n", count);
				MTK_DEBUG_LOG(TAG,
					"dpmaif_stop_rxq: 0x%x, 0x%x, 0x%x\n",
					rxq->pit_rd_idx, rxq->pit_wr_idx,
					rxq->pit_rel_rd_idx);
				break;
			}
		} while (atomic_read(&rxq->rx_processing) != 0);

		MTK_DEBUG_LOG(TAG, "Stop rx proc cnt 0x%x\n", count);

		/* for cpu exec */
		smp_mb();
		rxq->que_started = false;
	}



exit:
	return;
}

void dpmaif_pos_stop_hw(unsigned char md_id, unsigned char hif_id)
{
	dpmaif_suspend_tx_sw_stop(md_id, hif_id);
	dpmaif_suspend_rx_sw_stop(md_id, hif_id);
}


void dpmaif_stop_hw(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG(TAG, "Stop tx/rx queue HW\n");
	dpmaif_hw_stop_tx_queue();
	dpmaif_hw_stop_rx_queue();
}


static int dpmaif_stop_txq(struct dpmaif_tx_queue *txq)
{
	int j;

	if (txq->drb_base == NULL)
		return -1;

	txq->que_started = false;
	/* flush work */
	cancel_delayed_work(&txq->dpmaif_tx_work);
	flush_delayed_work(&txq->dpmaif_tx_work);

	/* reset sw */
	MTK_DEBUG_LOG(TAG, "Stop_txq%d: 0x%x, 0x%x, 0x%x\n",
		txq->index, txq->drb_wr_idx,
		txq->drb_rd_idx, txq->drb_rel_rd_idx);

	if (txq->drb_rd_idx != txq->drb_rel_rd_idx) {
		MTK_NOTICE_LOG(TAG,
			"Stop_txq: tx_release maybe not end: rd(0x%x), rel(0x%x)\n",
			txq->drb_rd_idx, txq->drb_rel_rd_idx);
	}
	if (txq->drb_wr_idx != txq->drb_rel_rd_idx) {
		j = ring_buf_releasable(txq->drb_size_cnt,
			txq->drb_rel_rd_idx, txq->drb_wr_idx);
		dpmaif_relase_tx_buffer(txq->dpmaif_ctrl, txq->index, j);
	}

	memset(txq->drb_base, 0,
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)));
	memset(txq->drb_skb_base, 0,
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_skb)));

	txq->drb_rd_idx = 0;
	txq->drb_wr_idx = 0;
	txq->drb_rel_rd_idx = 0;

	return 0;
}

static int dpmaif_stop_rxq(struct dpmaif_rx_queue *rxq)
{
	int j, cnt;

	if (rxq->pit_base == NULL || rxq->bat_req.bat_base == NULL)
		return -1;

	/* flush work */
#ifndef DATA_PATH_NET_NAPI_MODE
	flush_work(&rxq->dpmaif_rxq0_work);/* tasklet no need */
#endif
	/* reset sw */
	rxq->que_started = false;
	j = 0;
	do {
		/*Disable HW arb and check idle*/
		cnt = ring_buf_readable(rxq->pit_size_cnt,
			rxq->pit_rd_idx, rxq->pit_wr_idx);

		/*retry handler*/
		if (++j >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "Stop Rx sw failed, 0x%x\n",
				cnt);
			MTK_DEBUG_LOG(TAG,
				"%s: 0x%x, 0x%x, 0x%x\n",
				__func__,
				rxq->pit_rd_idx, rxq->pit_wr_idx,
				rxq->pit_rel_rd_idx);
			break;
		}
	} while (cnt != 0);

	memset(rxq->pit_base, 0,
		(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)));
	memset(rxq->bat_req.bat_base, 0,
		(rxq->bat_req.bat_size_cnt * sizeof(struct dpmaif_bat_t)));
	memset(rxq->bat_req.bat_mask, 0,
		(rxq->bat_req.bat_size_cnt * sizeof(unsigned char)));

	rxq->cs_result = 0;
	rxq->begin_drop = false;

	dpmaif_rx_pit_seq_init(rxq);

	rxq->pit_rd_idx = 0;
	rxq->pit_wr_idx = 0;
	rxq->pit_rel_rd_idx = 0;

	rxq->expect_pit_seq = 0;
	rxq->pit_remain_rel_cnt = 0;
	rxq->pit_not_rel_entrynum = 0;
	
	rxq->bat_req.bat_rd_idx = 0;
	rxq->bat_req.bat_rel_rd_idx = 0;
	rxq->bat_req.bat_wr_idx = 0;

	return 0;
}

static int dpmaif_stop_rx_sw(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rxq;
	int i;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto error;
	}

	/* rx rx clear */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rxq = &dpmaif_ctrl->rxq[i];
		dpmaif_stop_rxq(rxq);
#ifdef DPMAIF_DEBUG_DUMP
		dpmaif_dump_rxq_remain(dpmaif_ctrl, i, 0);
#endif
	}
	return 0;

error:
	return -1;
}

static int dpmaif_stop_tx_sw(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_tx_queue *txq;
	int i;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto error;
	}

	/*flush and release UL descriptor*/
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		txq = &dpmaif_ctrl->txq[i];
		dpmaif_stop_txq(txq);
	}
	return 0;

error:
	return -1;
}

int dpmaif_stop(unsigned char md_id, unsigned char hif_id)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;

	dpmaif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_sw_init_done != true) {
		MTK_ERR_LOG(TAG, "dpmaif sw init fail\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWROFF) {
		MTK_INFO_LOG(TAG, "dpmaif in poweroff status\n");
		goto err;
	}

	dpmaif_disable_irq(dpmaif_ctrl);

	dpmaif_ctrl->dpmaif_state = HIFDPMAIF_STATE_PWROFF;

	/* 1. stop HW */
	/* To do */
	//dpmaif_stop_hw(md_id, hif_id); 
	dpmaif_pos_stop_hw(md_id, hif_id);

	/* 2. stop sw */
	/* skb pool workqueue stop */
	flush_work(&dpmaif_ctrl->skb_pool.reload_work);
	flush_work(&dpmaif_ctrl->align_buf_pool.reload_work);

	/* tx tx clear */
	dpmaif_stop_tx_sw(dpmaif_ctrl);

	/* rx rx clear */
	dpmaif_stop_rx_sw(dpmaif_ctrl);

	/* stop debug traffic monitor */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	del_timer(&dpmaif_ctrl->traffic_monitor);
#endif

	/* 3. todo: reset IP */
	dpmaif_hw_reset(NULL);

	MTK_INFO_LOG(TAG, "Stop dpmaif done\n");
	return 0;

err:
	return -1;
}

/* =======================================================
 *
 * Descriptions: State part start(4/3): Misc -- 4.
 *
 * ========================================================
 */
static int dpmaif_stop_queue(unsigned char md_id, unsigned char hif_id,
	unsigned char qno, enum direction dir)
{
	return 0;
}

static int dpmaif_start_queue(unsigned char md_id, unsigned char hif_id,
	unsigned char qno, enum direction dir)
{
	return 0;
}

/* =======================================================
 *
 * Descriptions: State part start(5/3): Resume -- 5.
 *
 * ========================================================
 */

static struct ccci_hif_ops ccci_hif_dpmaif_ops = {
	.send_skb = &dpmaif_tx_send_skb,
	.give_more = &dpmaif_give_more,
	.write_room = &dpmaif_write_room,
	.stop_queue = &dpmaif_stop_queue,
	.start_queue = &dpmaif_start_queue,
	.dump_status = &dpmaif_dump_status,
};

/* =======================================================
 *
 * Descriptions: State part start(6/3): PM -- 6.
 *
 * ========================================================
 */
static int dpmaif_suspend(struct mtk_pci_dev *mtk_dev, void *param)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)param;

	MTK_INFO_LOG(TAG, "Dpmaif suspend\n");

	/* stop dpmaif tx*/
	dpmaif_suspend_tx_sw_stop(dpmaif_ctrl->md_id, dpmaif_ctrl->hif_id);
	dpmaif_hw_stop_tx_queue();

	/* stop dpmaif rx*/
	dpmaif_hw_stop_rx_queue();

	/* mask PCIE DPMAIF interrupt */
	mtk_pcie_set_ext_int_mask(mtk_dev, DPMAIF_INT, DRV_TRUE);

	dpmaif_suspend_rx_sw_stop(dpmaif_ctrl->md_id, dpmaif_ctrl->hif_id);

	return 0;
}

static int dpmaif_suspend_late(struct mtk_pci_dev *mtk_dev, void *param)
{
	return 0;
}
static int dpmaif_resume_early(struct mtk_pci_dev *mtk_dev, void *param)
{
	return 0;
}
static int dpmaif_resume(struct mtk_pci_dev *mtk_dev, void *param)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)param;

	MTK_INFO_LOG(TAG, "Dpmaif resume\n");

	/* start dpmaif tx/rx queue SW */
	dpmaif_pre_start_hw(dpmaif_ctrl->md_id, dpmaif_ctrl->hif_id);

	/* unmask PCIE DPMAIF interrupt */
	mtk_pcie_set_ext_int_mask(mtk_dev, DPMAIF_INT, DRV_FALSE);

	/* start dpmaif HW */
	dpmaif_start_hw(dpmaif_ctrl->md_id, dpmaif_ctrl->hif_id);

	/* wake up the dpmaif tx thread */
	wake_up(&dpmaif_ctrl->tx_wq);

	return 0;
}

static int dpmaif_pm_entity_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	struct md_pm_entity *dpmaif_pm_entity = NULL;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		ret = -1;
		goto err;
	}

	dpmaif_pm_entity = &dpmaif_ctrl->dpmaif_pm_entity;

	INIT_LIST_HEAD(&dpmaif_pm_entity->entity);
	dpmaif_pm_entity->suspend = &dpmaif_suspend;
	dpmaif_pm_entity->suspend_late = &dpmaif_suspend_late;
	dpmaif_pm_entity->resume_early = &dpmaif_resume_early;
	dpmaif_pm_entity->resume = &dpmaif_resume;


	dpmaif_pm_entity->key = PM_ENTITY_KEY_DATA;
	dpmaif_pm_entity->entity_param = (void *)dpmaif_ctrl;

	ret = mtk_pci_pm_entity_register(dpmaif_ctrl->mtk_dev,
		dpmaif_pm_entity);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "Dpmaif register pm_entity fail\n");


err:
	return ret;
}

static int dpmaif_pm_entity_uninit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	struct md_pm_entity *dpmaif_pm_entity = NULL;

	if ((dpmaif_ctrl == NULL) || (dpmaif_ctrl->mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		ret = -1;
		goto err;
	}

	dpmaif_pm_entity = &dpmaif_ctrl->dpmaif_pm_entity;
	ret = mtk_pci_pm_entity_unregister(dpmaif_ctrl->mtk_dev,
		dpmaif_pm_entity);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "Dpmaif register pm_entity fail\n");

err:
	return ret;
}


/* =======================================================
 *
 * Descriptions: State Module part End
 *
 * ========================================================
 */

int ccci_dpmaif_hif_init(unsigned char md_id, unsigned char hif_id)
{
	struct md_dpmaif_ctrl *hif_ctrl = NULL;
	int ret = 0;

	/* init local struct pointer */
	MTK_INFO_LOG(TAG, "md_id = %d, hif_id = %d,\n", md_id, hif_id);
	hif_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (hif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "Get dpmaif_ctrl fail, md_id=%d, hif_id=%d\n",
			md_id, hif_id);
		ret = -1;
		goto fail;
	}

#ifdef DATA_PATH_NET_NAPI_MODE
	g_hif_ctrl = hif_ctrl;
#endif

	hif_ctrl->dpmaif_sw_init_done = false;
	hif_ctrl->md_id = md_id;
	hif_ctrl->hif_id = hif_id;
	hif_ctrl->ops = &ccci_hif_dpmaif_ops;

	/* dpmaif PM init */
	ret = dpmaif_pm_entity_init(hif_ctrl);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "dpmaif PM init fail\n");
		goto fail;
	}

	/* HW layer driver init */
	ccci_driver_init(md_id, hif_id, hif_ctrl->hif_hw_info);

	/* Alloc and init the dpmaif tx/rx/irq resource */
	dpmaif_sw_init(md_id, hif_id);
	hif_ctrl->dpmaif_sw_init_done = true;

	/* set debug traffic monitor */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_clear_traffic_data(md_id, hif_id);
	timer_setup(&hif_ctrl->traffic_monitor, dpmaif_traffic_monitor_func, 0);
#endif

	g_DPMAIF_CACHE_LINE_SIZE = (unsigned long)cache_line_size();
	MTK_INFO_LOG(TAG, "cache line size = %lu\n", g_DPMAIF_CACHE_LINE_SIZE);

	/* throughput parameter clear */
#ifdef DATA_PATH_DL_TP_CALC
	memset(&g_dpmf_tp_stat, 0, sizeof(struct dpmaif_tp_statistics));
	g_dpmf_tp_stat.rx_rec_enable = false;
	g_dpmf_tp_stat.tx_rec_enable = false;
#endif

	return 0;

fail:
	return ret;
}

void *ccci_dpmaif_get_hw_info(unsigned char md_id, unsigned char hif_id,
	struct mtk_pci_dev *dev_ptr)
{
	struct dpmaif_pcie_hw_info *hw_info = NULL;
	struct md_dpmaif_ctrl *md_ctrl = NULL;

	// checks inputs firstly
	if (hif_id < 0 || hif_id >= HIF_ID_MAX) {
		MTK_ERR_LOG(TAG, "Invalid hif_id = %d\n", hif_id);
		goto error;
	}

	/* allocates memory for md_dpmaif_ctrl */
	md_ctrl = kzalloc(sizeof(struct md_dpmaif_ctrl), GFP_KERNEL);
	if (md_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "Allocates memory for md_ctrl failed!\n");
		goto error;
	}
	ccci_hif[md_id][hif_id] = (void *)md_ctrl;
	md_ctrl->mtk_dev = dev_ptr;

	/* allocates memory for dpmaif_pcie_hw_info */
	hw_info = kzalloc(sizeof(struct dpmaif_pcie_hw_info), GFP_KERNEL);
	if (hw_info == NULL) {
		MTK_ERR_LOG(TAG, "Allocates memory for md_ctrl failed!\n");
		goto alloc_fail;
	}
	md_ctrl->hif_hw_info = hw_info;
	hw_info->md_id = md_id;

	/* gets PCIE device information from PCIE driver */
	hw_info->hw_base_addr = dev_ptr->base_addr.pcie_dev_reg_trsl_addr;
	hw_info->hw_map_base_addr = dev_ptr->base_addr.pcie_ext_reg_base;
	hw_info->pcie_dev = &(dev_ptr->pdev->dev);

	/* dpmaif PM */
	md_ctrl->lock_user = L_RES_USER_DATA;

	return hw_info;


alloc_fail:
	if (md_ctrl != NULL) {
		kfree(md_ctrl);
		md_ctrl = NULL;
		ccci_hif[md_id][hif_id] = NULL;
	}
error:
	return NULL;
}

void ccci_dpmaif_rel_hw_info(unsigned char md_id, unsigned char hif_id,
	struct mtk_pci_dev *dev_ptr)
{
	struct dpmaif_pcie_hw_info *hw_info = NULL;
	struct md_dpmaif_ctrl *md_ctrl = NULL;

	DP_UNUSED(dev_ptr);

	if (hif_id < 0 || hif_id >= HIF_ID_MAX) {
		MTK_ERR_LOG(TAG, "Invalid hif_id = %d\n", hif_id);
		goto exit;
	}

	md_ctrl = (struct md_dpmaif_ctrl *)ccci_hif[md_id][hif_id];
	if (md_ctrl == NULL)
		goto exit;
	hw_info = (struct dpmaif_pcie_hw_info *)md_ctrl->hif_hw_info;

	if (hw_info != NULL) {
		kfree(hw_info);
		hw_info = NULL;
		md_ctrl->hif_hw_info = NULL;
	}
	if (md_ctrl != NULL) {
		kfree(md_ctrl);
		md_ctrl = NULL;
		ccci_hif[md_id][hif_id] = NULL;
	}

exit:
	return;
}

void ccci_dpmaif_hif_exit(unsigned char md_id, unsigned char hif_id)
{
	struct md_dpmaif_ctrl *md_ctrl = NULL;

	MTK_INFO_LOG(TAG, "Dpmaif hif exit\n");

	md_ctrl = DPMF_GET_HIF_CTRL(md_id, hif_id);
	if (unlikely(md_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid md_ctrl; md_id=%d, hif_id=%d\n",
			md_id, hif_id);
		return;
	}

	if (md_ctrl->dpmaif_sw_init_done) {
		dpmaif_stop(md_id, hif_id);
		dpmaif_sw_rel(md_id, hif_id);
		dpmaif_pm_entity_uninit(md_ctrl);
	}

	ccci_driver_uninit(md_id, hif_id);
	ccci_dpmaif_rel_hw_info(md_id, hif_id, NULL);
}
