// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/uaccess.h>
#include <linux/mm.h>
#include <linux/kfifo.h>

#include <linux/firmware.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <asm/setup.h>
#include <linux/atomic.h>
#include "ccci_util_lib_sys.h"
#include "mtk_ccci_common.h"
#include "ccci_util_lib_main.h"

/**************************************************************/
/* CCCI Feature option parsiong      entry                    */
/**************************************************************/
static unsigned int s_g_md_usage_case;

static void ccci_util_fo_init(void)
{
	s_g_md_usage_case |= (1<<MD_SYS1);
}
static void ccci_util_fo_uninit(void)
{
	s_g_md_usage_case = 0;
}
unsigned int get_modem_is_enabled(int md_id)
{
	return !!(s_g_md_usage_case & (1 << md_id));
}
int ccci_util_init(void)
{
	ccci_log_init();
	ccci_util_fo_init();
	ccci_common_sysfs_init();
	return 0;
}
void ccci_util_exit(void)
{
	ccci_common_sysfs_rel();
	ccci_util_fo_uninit();
	ccci_log_rel();
}

