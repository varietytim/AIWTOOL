// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/kernel.h>
#include <linux/kthread.h>
#include "ccci_config.h"

#include "ccci_core.h"
#include "ccci_fsm.h"
#include "ccci_bm.h"
#include "port_ctlmsg.h"
#include "port_proxy.h"
#include "ccci_fsm_internal.h"

#define MAX_QUEUE_LENGTH 16

extern int ccci_port_status_update(int md_id, void *data);

/*
 * all supported modems should follow these handshake messages as a protocol.
 * but we still can support un-usual modem by providing cutomed kernel_port_ops.
 */
static void control_msg_handler(struct port_t *port, struct sk_buff *skb)
{
	int md_id = port->md_id;
	int ret = 0;
	struct ccci_header *ccci_h = NULL;
	struct ctrl_msg_header *ctrl_msg_h = NULL;
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);

	ccci_h = (struct ccci_header *)skb->data;
	skb_pull(skb, sizeof(struct ccci_header));
	ctrl_msg_h = (struct ctrl_msg_header *)skb->data;
	MTK_INFO_LOG(FSM, "control message 0x%X,0x%X,0x%X\n",
		ctrl_msg_h->ctrl_msg_id, ctrl_msg_h->reserved, ctrl_msg_h->data_length);

	switch (ctrl_msg_h->ctrl_msg_id) {
	case CTL_ID_HS2_MSG:
		skb_pull(skb, sizeof(struct ctrl_msg_header));
		if (port->rx_ch == CCCI_CONTROL_RX)
			fsm_append_event(ctl, CCCI_EVENT_MD_HS2, \
					skb->data, ctrl_msg_h->data_length);
		if (port->rx_ch == CCCI_SAP_CONTROL_RX)	
			fsm_append_event(ctl, CCCI_EVENT_SAP_HS2, \
					skb->data, ctrl_msg_h->data_length);
		ccci_free_skb(skb);
		break;
	case CTL_ID_MD_EX:
	case CTL_ID_MD_EX_REC_OK:
	case CTL_ID_MD_EX_PASS:
	case CCCI_DRV_VER_ERROR:
		ret = ccci_fsm_recv_control_packet(md_id, ctrl_msg_h->ctrl_msg_id, skb);
		break;
	case CTL_ID_PORT_ENUM:
		skb_pull(skb, sizeof(struct ctrl_msg_header));
        ret = ccci_port_status_update(md_id, (void *)skb->data);
		if (ret == 0) {
			ccci_port_send_msg_to_md(md_id, CCCI_CONTROL_TX, CTL_ID_PORT_ENUM, 0, 1);
		} else {
			ccci_port_send_msg_to_md(md_id, CCCI_CONTROL_TX, CTL_ID_PORT_ENUM, PORT_ENUM_VER_DISMATCH, 1);
		}
		break;
	default:
		break;
	}
	if (ret)
		MTK_ERR_LOG(PORT, "%s control msg handle error: %d\n",
			port->name, ret);
}

static int port_ctl_init(struct port_t *port)
{
	MTK_DEBUG_LOG(PORT, "kernel port %s is initializing\n", port->name);
	port->skb_handler = &control_msg_handler;
	port->private_data =
		kthread_run(port_kthread_handler, port, "%s", port->name);
	port->rx_length_th = MAX_QUEUE_LENGTH;
	port->skb_from_pool = 1;
	port->thread = port->private_data;
	return 0;
}

static void port_ctl_uninit(struct port_t *port)
{
	unsigned long flags;
	struct sk_buff *skb = NULL;

	if (port->thread)
		kthread_stop(port->thread);
	spin_lock_irqsave(&port->rx_skb_list.lock, flags);
	while ((skb = __skb_dequeue(&port->rx_skb_list)) != NULL)
		ccci_free_skb(skb);

	spin_unlock_irqrestore(&port->rx_skb_list.lock, flags);
}

struct port_ops ctl_port_ops = {
	.init = &port_ctl_init,
	.recv_skb = &port_recv_skb,
	.uninit = &port_ctl_uninit,
};
