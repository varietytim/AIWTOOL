/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_CFG_H__
#define __PORT_CFG_H__
#include "port_t.h"
#include "ccci_port.h"

/* external: port ops  mapping */
extern struct port_ops char_port_ops;
extern struct port_ops rpc_port_ops;
extern struct port_ops sys_port_ops;
extern struct port_ops poller_port_ops;
extern struct port_ops ctl_port_ops;
extern struct port_ops ipc_port_ops;
extern struct port_ops smem_port_ops;
extern struct port_ops relay_port_ops;
extern struct port_ops tty_port_ops;

#if defined(M7X) && defined(CONFIG_MTK_NET_CCMNI)
extern struct port_ops net_port_ops;
#else
#define net_port_ops char_port_ops
#endif

int port_get_cfg(int md_id, struct port_t **ports,
	PORT_CFG_ENUM port_cfg_id);

#endif /* __PORT_CFG_H__ */
