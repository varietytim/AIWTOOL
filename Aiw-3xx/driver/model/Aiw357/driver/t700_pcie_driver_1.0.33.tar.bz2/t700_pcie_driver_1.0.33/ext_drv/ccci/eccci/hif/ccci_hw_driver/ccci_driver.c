// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_driver.h"
#include "ccci_driver_cldma.h"
#include "ccci_driver_dpmaif.h"
#include "ccci_driver_mhccif.h"
#include "mtk-pci-ext.h"
#define TAG "CCCI_DRIVER"
#include <linux/of_irq.h>

//XSQUARE
#include <linux/version.h>


struct ccci_hw_ctrl *ccci_hw_ctrl_info[MAX_MD_NUM][HIF_ID_MAX];

void ccci_driver_init(unsigned char md_id, unsigned char hif_id, void *hw_info)
{
	struct ccci_hw_ctrl *hw_ctrl =
		kzalloc(sizeof(struct ccci_hw_ctrl), GFP_KERNEL);

	ccci_hw_ctrl_info[md_id][hif_id] = hw_ctrl;
	switch (hif_id) {
#ifdef M7X
	case HIF_ID_DPMAIF_PCIE:
		hw_ctrl->private = hw_info;
		hw_ctrl->hif_id = hif_id;
		dpmaif_driver_init(hw_ctrl);
		MTK_INFO_LOG("ccci driver",
			"dpmaif_driver_init done!\n");
		break;
#endif
	default:
		break;
	}

}

#if defined(CONFIG_MTK_ECCCI_CLDMA)
#define CLDMA_QUERY_PCIE_INFO_CNT_MAX 1000
#define PCIE_ADDR_TRANSFER(addr, addr_trs1, phy_addr)\
	(addr + (phy_addr - addr_trs1))

#if defined(ENABLE_CCCI_DRI_UT)
struct mh_hw_info {
	long mhccif_physic_base_address;
	void __iomem *mhccif_virtual_base_address;
};

//simulate hardware interrupt
static void tasklet_cldma_isr(unsigned long data)
{
	struct ccci_hw_ctrl *hw_ctrl =
		(struct ccci_hw_ctrl *)data;

	hw_ctrl->irqhd.usr_hd(hw_ctrl->irqhd.param);
}
static void register_isr_ut(struct ccci_hw_ctrl *hw_ctrl,
	int (*handlder_func)(void *), void *param)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)(hw_ctrl->private);

	hw_ctrl->irqhd.param = param;
	hw_ctrl->irqhd.usr_hd = handlder_func;
	tasklet_init(&hw_info->cldma_irq_task,
		tasklet_cldma_isr, (unsigned long)hw_ctrl);
}
static void enable_irq_ut(struct ccci_hw_ctrl *hw_ctrl)
{
}
static void disable_irq_ut(struct ccci_hw_ctrl *hw_ctrl)
{
}

int ccci_cldma_get_dev_info_legacy(struct ccci_hw_ctrl *hw_ctrl)
{
	return 0;
}

struct cldma_hw_info *cldma_driver_init(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info = NULL;

	if (hw_ctrl == NULL) {
		MTK_ERR_LOG("CLDMA", "cldma_driver_init:hw_ctrl is NULL\n");
		return NULL;
	}
	MTK_INFO_LOG("CLDMA", "cldma_driver_init\n");
	if (hw_ctrl->hif_id == HIF_ID_CLDMA_PCIE) {
		if(hw_ctrl->private == NULL) {
			hw_info = kzalloc(sizeof(struct cldma_hw_info) + sizeof(struct mh_hw_info), GFP_KERNEL);
		} else {
			hw_info = hw_ctrl->private;
		}
		if (hw_info != NULL) {
			MTK_INFO_LOG("CLDMA", "CLDMA UT Frame Work\n");
			hw_info->hw_id = hw_ctrl->hif_id; // HW_ID == HIF_ID
			if (hw_info->cldma_ap_pdn_base == NULL)
				hw_info->cldma_ap_pdn_base = kzalloc(0x2000, GFP_KERNEL);
			if (hw_info->cldma_ap_ao_base == NULL)
				hw_info->cldma_ap_ao_base = kzalloc(0x2000, GFP_KERNEL);
			if (((struct mh_hw_info *)(hw_info->other_attr))->mhccif_virtual_base_address == NULL)
				((struct mh_hw_info *)(hw_info->other_attr))->mhccif_virtual_base_address = kzalloc(0x1000, GFP_KERNEL);
			hw_info->cldma_irq_id = 0;
			hw_info->cldma_irq_flags = 0;
		} else {
			MTK_ERR_LOG("CLDMA",
				"%s: hw_info alloc error\n", __func__);
		}
		hw_ctrl->irqops.register_isr = register_isr_ut;
		hw_ctrl->irqops.enable_irqs = enable_irq_ut;
		hw_ctrl->irqops.disable_irq = disable_irq_ut;
	}
	if (hw_ctrl->hif_id == HIF_ID_CLDMA0_PCIE) {
		if(hw_ctrl->private == NULL) {
			hw_info = kzalloc(sizeof(struct cldma_hw_info)+sizeof(struct mh_hw_info), GFP_KERNEL);
		} else {
			hw_info = hw_ctrl->private;
		}

		if (hw_info != NULL) {
			MTK_INFO_LOG("CLDMA", "CLDMA UT Frame Work\n");
			hw_info->hw_id = hw_ctrl->hif_id; // HW_ID == HIF_ID
			if (hw_info->cldma_ap_pdn_base == NULL)
				hw_info->cldma_ap_pdn_base = kzalloc(0x1000, GFP_KERNEL);
			if (hw_info->cldma_ap_ao_base == NULL)
				hw_info->cldma_ap_ao_base = kzalloc(0x1000, GFP_KERNEL);
			if (((struct mh_hw_info *)(hw_info->other_attr))->mhccif_virtual_base_address == NULL)
				((struct mh_hw_info *)(hw_info->other_attr))->mhccif_virtual_base_address = kzalloc(0x1000, GFP_KERNEL);
			hw_info->cldma_irq_id = 0;
			hw_info->cldma_irq_flags = 0;
		} else {
			MTK_ERR_LOG("CLDMA",
				"%s: hw_info alloc error\n", __func__);
		}
		hw_ctrl->irqops.register_isr = register_isr_ut;
		hw_ctrl->irqops.enable_irqs = enable_irq_ut;
		hw_ctrl->irqops.disable_irq = disable_irq_ut;
	} else if (hw_ctrl->hif_id == HIF_ID_CLDMA) {
		if(hw_ctrl->private == NULL) {
			hw_info = (struct cldma_hw_info *)kzalloc(sizeof(struct cldma_hw_info), GFP_KERNEL);
		} else {
			hw_info = hw_ctrl->private;
		}

		if (hw_info != NULL) {
			MTK_INFO_LOG("CLDMA", "CLDMA UT Frame Work\n");
			hw_info->hw_id = hw_ctrl->hif_id; // HW_ID == HIF_ID
		} else {
			MTK_ERR_LOG("CLDMA",
				"%s: hw_info alloc error\n", __func__);
		}
		hw_ctrl->irqops.register_isr = register_isr_ut;
		hw_ctrl->irqops.enable_irqs = enable_irq_ut;
		hw_ctrl->irqops.disable_irq = disable_irq_ut;
	}
	hw_ctrl->private = (void *)hw_info;
	return hw_info;
}

int ccci_cldma_get_pcie_dev_info(struct ccci_hw_ctrl *hw_ctrl, struct mtk_pci_dev *mtk_dev)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)(hw_ctrl->private);
	struct pci_dev *pdev;
	unsigned int count = 0;

	// checks inputs firstly
	if (hw_info == NULL || mtk_dev == NULL)
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!");


	pdev = mtk_dev->pdev;
	if (pdev != NULL) {
			MTK_NOTICE_LOG(TAG,"get device info sucessfully\n");
			hw_ctrl->dma_dev = pdev->dev;
	} else {
		MTK_ERR_LOG(TAG, "device info can't be found\n");
		break;
	}
	return 0;
}

#else //ENABLE_CCCI_DRI_UT

static int pcie_irq_cb_handler(void *data)
{
	int ret = 0;
	struct ccci_hw_ctrl *hw_ctrl = (struct ccci_hw_ctrl *)data;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;
	mtk_pcie_set_ext_int_mask(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id, true);
	mtk_pcie_clr_ext_int_sts(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id);
	ret = hw_ctrl->irqhd.usr_hd(hw_ctrl->irqhd.param);
	mtk_pcie_clr_ext_int_sts(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id);
	mtk_pcie_set_ext_int_mask(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id, false);
	return ret;
}
static void register_isr_pcie(struct ccci_hw_ctrl *hw_ctrl,
	int (*handlder_func)(void *), void *param)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	hw_ctrl->irqhd.param = param;
	hw_ctrl->irqhd.usr_hd = handlder_func;
		/* registers CLDMA callback isr with PCIE driver */
	//mtk_pcie_set_ext_int_mask(hw_info->cldma_phy_interrupt_id, true);
	mtk_pcie_register_ext_int_callback(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id,
		pcie_irq_cb_handler, (void *)hw_ctrl);
	mtk_pcie_clr_ext_int_sts(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id);
	//mtk_pcie_set_ext_int_mask(hw_info->cldma_phy_interrupt_id, false);
}

static void enable_irq_pcie(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (mtk_pcie_set_ext_int_mask(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id,
		false) != 0)
		MTK_ERR_LOG(TAG, "demask DPMAIF interrupt failed!");
}
static void disable_irq_pcie(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	if (mtk_pcie_set_ext_int_mask(hw_ctrl->mtk_dev, hw_info->cldma_phy_interrupt_id,
		true) != 0)
		MTK_ERR_LOG(TAG, "mask DPMAIF interrupt failed!");
}

static irqreturn_t cldma_isr(int irq, void *data)
{
	struct ccci_hw_ctrl *hw_ctrl = (struct ccci_hw_ctrl *)data;

	hw_ctrl->irqhd.usr_hd(hw_ctrl->irqhd. param);
	return IRQ_HANDLED;
}

static void register_isr_legacy(struct ccci_hw_ctrl *hw_ctrl,
	int (*handlder_func)(void *), void *param)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	hw_ctrl->irqhd.param = param;
	hw_ctrl->irqhd.usr_hd = handlder_func;
	if (request_irq(hw_info->cldma_irq_id, cldma_isr,
		hw_info->cldma_irq_flags, "CLDMA0_IRQ", (void *)hw_ctrl)){
		MTK_ERR_LOG(TAG, "request_irq fail!\n");
	}

}
static void enable_irq_legacy(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	enable_irq(hw_info->cldma_irq_id);
}
static void disable_irq_legacy(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)hw_ctrl->private;

	disable_irq(hw_info->cldma_irq_id);
}

struct cldma_hw_info *cldma_driver_init(struct ccci_hw_ctrl *hw_ctrl)
{
	struct cldma_hw_info *hw_info = NULL;

	if (hw_ctrl == NULL) {
		MTK_ERR_LOG("CLDMA", "invalid input:NULL pointer!\n");
		return NULL;
	}
	if (hw_ctrl->hif_id == HIF_ID_CLDMA_PCIE) {
		hw_info = kzalloc(sizeof(struct cldma_hw_info), GFP_KERNEL);

		if (hw_info != NULL) {
			hw_info->hw_id = hw_ctrl->hif_id; // HW_ID == HIF_ID
			hw_info->cldma_phy_ao_base = CLDMA1_AO_BASE;
			hw_info->cldma_phy_pd_base = CLDMA1_PD_BASE;

			hw_info->cldma_phy_interrupt_id = CLDMA1_INT;
			hw_info->direction = AP_TO_MD;
			hw_info->hw_mode = MODE_BIT_64;
		} else {
			MTK_ERR_LOG("CLDMA",
				"failed to alloc memory for cldma hw info\n");
		}
		hw_ctrl->irqops.register_isr = register_isr_pcie;
		hw_ctrl->irqops.enable_irqs = enable_irq_pcie;
		hw_ctrl->irqops.disable_irq = disable_irq_pcie;
	} else if (hw_ctrl->hif_id == HIF_ID_CLDMA0_PCIE) {
		hw_info = kzalloc(sizeof(struct cldma_hw_info), GFP_KERNEL);

		if (hw_info != NULL) {
			hw_info->hw_id = hw_ctrl->hif_id; // HW_ID == HIF_ID

			hw_info->cldma_phy_ao_base = CLDMA0_AO_BASE;
			hw_info->cldma_phy_pd_base = CLDMA0_PD_BASE;

			hw_info->cldma_phy_interrupt_id = CLDMA0_INT;
			hw_info->direction = AP_TO_MD;
			hw_info->hw_mode = MODE_BIT_64;
		} else {
			MTK_ERR_LOG("CLDMA",
				"failed to alloc memory for cldma hw info\n");
		}
		hw_ctrl->irqops.register_isr = register_isr_pcie;
		hw_ctrl->irqops.enable_irqs = enable_irq_pcie;
		hw_ctrl->irqops.disable_irq = disable_irq_pcie;
	} else if (hw_ctrl->hif_id == HIF_ID_CLDMA) {
		hw_info = kzalloc(sizeof(struct cldma_hw_info), GFP_KERNEL);

		if (hw_info != NULL) {
			hw_info->hw_id = hw_ctrl->hif_id;
			hw_info->cldma_phy_ao_base = CLDMA_R_AO_BASE;
			hw_info->cldma_phy_pd_base = CLDMA_R_PD_BASE;
			hw_info->cldma_phy_interrupt_id = CLDMA0_R_INT;
			hw_info->direction = sAP_TO_eAP;
			hw_info->hw_mode = MODE_BIT_64;
		} else {
			MTK_ERR_LOG("CLDMA",
				"failed to alloc memory for cldma hw info\n");
		}
		hw_ctrl->irqops.register_isr = register_isr_legacy;
		hw_ctrl->irqops.enable_irqs = enable_irq_legacy;
		hw_ctrl->irqops.disable_irq = disable_irq_legacy;
	}
	hw_ctrl->private = (void *)hw_info;
	return hw_info;
}
int ccci_cldma_get_pcie_dev_info(struct ccci_hw_ctrl *hw_ctrl)
{
	struct pci_dev *pdev;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)(hw_ctrl->private);
	struct mtk_pci_dev *mtk_dev;

	// checks inputs firstly
	if (hw_info == NULL) {
		MTK_ERR_LOG(TAG, "Invalid inputs: NULL pointer!");
		goto error;
	}

	mtk_dev = hw_ctrl->mtk_dev;
	pdev = mtk_dev->pdev;

	if (pdev != NULL) {
		hw_ctrl->dma_dev = &(pdev->dev);
		hw_info->cldma_ap_ao_base =
			(void __iomem *)PCIE_ADDR_TRANSFER(mtk_dev->base_addr.pcie_ext_reg_base,
			mtk_dev->base_addr.pcie_dev_reg_trsl_addr,
			hw_info->cldma_phy_ao_base);
		hw_info->cldma_ap_pdn_base =
			(void __iomem *)PCIE_ADDR_TRANSFER(mtk_dev->base_addr.pcie_ext_reg_base,
			mtk_dev->base_addr.pcie_dev_reg_trsl_addr,
			hw_info->cldma_phy_pd_base);
		MTK_DEBUG_LOG(TAG, "OA_base_addr = %p, PD_base_addr = %p\n",
			hw_info->cldma_ap_ao_base, hw_info->cldma_ap_pdn_base);
	} else {
		MTK_ERR_LOG(TAG, "failed to get PCIe device info!");
		goto error;
	}
	return 0;

error:
	return -1;
}
int ccci_cldma_get_dev_info_legacy(struct ccci_hw_ctrl *hw_ctrl)
{
	int ret = 0;
	struct cldma_hw_info *hw_info =
		(struct cldma_hw_info *)(hw_ctrl->private);

	if (hw_info->cldma_ap_ao_base == NULL)
		hw_info->cldma_ap_ao_base =
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
			ioremap(hw_info->cldma_phy_ao_base, 0x1000);
#else		
			ioremap_nocache(hw_info->cldma_phy_ao_base, 0x1000);
#endif			
	if (hw_info->cldma_ap_pdn_base == NULL)
		hw_info->cldma_ap_pdn_base =
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
			ioremap(hw_info->cldma_phy_pd_base, 0x1000);
#else		
			ioremap_nocache(hw_info->cldma_phy_pd_base, 0x1000);
#endif			
	hw_info->cldma_irq_flags = IRQF_TRIGGER_NONE;
	if (hw_info->cldma_irq_id == 0)
		hw_info->cldma_irq_id =
			irq_of_parse_and_map(hw_ctrl->dma_dev->of_node, 3);
	MTK_INFO_LOG(TAG, "cldma_irq_id = %d,\n", hw_info->cldma_irq_id);
	return ret;
}


#endif //ENABLE_CCCI_DRI_UT

int ccci_cldma_get_dev_info(struct ccci_hw_ctrl *hw_ctrl)//hw_id==hif_id
{
	int ret = 0;

	if (hw_ctrl->hif_id == HIF_ID_CLDMA)
		ret = ccci_cldma_get_dev_info_legacy(hw_ctrl);
	else
		ret = ccci_cldma_get_pcie_dev_info(hw_ctrl);

	return ret;
}
#endif//CONFIG_MTK_ECCCI_CLDMA
void *ccci_hw_ctrl_get_by_id(unsigned char md_id, unsigned char hif_id)
{
	if (md_id >= MAX_MD_NUM || hif_id >= HIF_ID_MAX) {
		MTK_ERR_LOG(CORE,
			"invalid input:md_id = %u, hif_id = %u\n",
			md_id, hif_id);
		return NULL;
	} else
		return ccci_hw_ctrl_info[md_id][hif_id];
}


void ccci_hw_init(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_init != NULL)
		hw_ctrl->opts->ccci_hw_init(hw_ctrl);
}
void ccci_hw_reset(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_reset != NULL)
		hw_ctrl->opts->ccci_hw_reset(hw_ctrl);
}

void ccci_hw_dump(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_dump != NULL)
		hw_ctrl->opts->ccci_hw_dump(hw_ctrl);
}

int ccci_hw_clear(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_clear != NULL)
		return hw_ctrl->opts->ccci_hw_clear(hw_ctrl);
	else
		return -1;
}

void ccci_hw_send(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno)
{
	if (hw_ctrl->opts->ccci_hw_send != NULL)
		hw_ctrl->opts->ccci_hw_send(hw_ctrl, qno);
}

void ccci_hw_start(struct ccci_hw_ctrl *hw_ctrl, unsigned char tx_rx)
{
	if (hw_ctrl->opts->ccci_hw_start != NULL)
		hw_ctrl->opts->ccci_hw_start(hw_ctrl, tx_rx);
}

int ccci_hw_stop(struct ccci_hw_ctrl *hw_ctrl, unsigned char tx_rx,
	unsigned char is_for_ee)
{
	if (hw_ctrl->opts->ccci_hw_stop != NULL)
		return hw_ctrl->opts->ccci_hw_stop(hw_ctrl, tx_rx, is_for_ee);
	else
		return -1;
}

void ccci_hw_start_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char tx_rx)
{
	if (hw_ctrl->opts->ccci_hw_start_queue != NULL)
		hw_ctrl->opts->ccci_hw_start_queue(hw_ctrl, qno, tx_rx);
}

void ccci_hw_stop_queue(struct ccci_hw_ctrl *hw_ctrl,
	u8 qno, unsigned char rx_tx)
{
	if (hw_ctrl->opts->ccci_hw_stop_queue != NULL)
		hw_ctrl->opts->ccci_hw_stop_queue(hw_ctrl, qno, rx_tx);
}

int ccci_hw_resume_queue(struct ccci_hw_ctrl *hw_ctrl,
	unsigned char qno, unsigned char tx_rx)
{
	if (hw_ctrl->opts->ccci_hw_resume_queue != NULL)
		return hw_ctrl->opts->ccci_hw_resume_queue(hw_ctrl, qno, tx_rx);
	else
		return -1;
}

unsigned int ccci_hw_rx_done(struct ccci_hw_ctrl *hw_ctrl, unsigned int bitmask)
{
	if (hw_ctrl->opts->ccci_hw_rx_done != NULL)
		return hw_ctrl->opts->ccci_hw_rx_done(hw_ctrl, bitmask);
	else
		return 0;
}

unsigned int ccci_hw_tx_done(struct ccci_hw_ctrl *hw_ctrl, unsigned int bitmask)
{
	if (hw_ctrl->opts->ccci_hw_tx_done != NULL)
		return hw_ctrl->opts->ccci_hw_tx_done(hw_ctrl, bitmask);
	else
		return 0;
}

int ccci_hw_get_status(struct ccci_hw_ctrl *hw_ctrl, unsigned char qno)
{
	if (hw_ctrl->opts->ccci_hw_get_status != NULL)
		return hw_ctrl->opts->ccci_hw_get_status(hw_ctrl, qno);
	else
		return -1;
}
int ccci_hw_get_interrupt_status(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_get_interrupt_status != NULL)
		return hw_ctrl->opts->ccci_hw_get_interrupt_status(hw_ctrl);
	else
		return -1;
}
int ccci_hw_notify(struct ccci_hw_ctrl *hw_ctrl)
{
	if (hw_ctrl->opts->ccci_hw_notify != NULL)
		return hw_ctrl->opts->ccci_hw_notify(hw_ctrl);
	else
		return -1;
}

void ccci_driver_uninit(unsigned char md_id, unsigned char hif_id)
{
	struct ccci_hw_ctrl *hw_ctrl = ccci_hw_ctrl_get_by_id(md_id, hif_id);

	if (hw_ctrl != NULL) {
		switch (hif_id) {
#if CONFIG_MTK_ECCCI_CLDMA
		case HIF_ID_CLDMA:
		case HIF_ID_CLDMA_PCIE:
		case HIF_ID_CLDMA0_PCIE:
			if (hw_ctrl->private != NULL) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
				kfree_sensitive((struct cldma_hw_info *)
					hw_ctrl->private);
#else				
				kzfree((struct cldma_hw_info *)
					hw_ctrl->private);
#endif					
				hw_ctrl->private = NULL;
			}
			break;
		case HIF_ID_PCIE:
			if (hw_ctrl->private != NULL) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
				kfree_sensitive(hw_ctrl->private);
#else				
				kzfree(hw_ctrl->private);
#endif				
				hw_ctrl->private = NULL;
			}
			break;
#endif
		default:
			break;
		}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
		kfree_sensitive(hw_ctrl);
#else			
		kzfree(hw_ctrl);
#endif		
	}
	ccci_hw_ctrl_info[md_id][hif_id] = NULL;
}


