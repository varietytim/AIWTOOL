// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/ipv6.h>
#include <net/ipv6.h>
#include <linux/skbuff.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/version.h>
#include <linux/sockios.h>
#include <mt-plat/mtk_ccci_common.h>
#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_bm.h"
#include "ccci_modem.h"
#include "port_net.h"

#ifdef PORT_NET_TRACE
#define CREATE_TRACE_POINTS
#include "port_net_events.h"
#endif
#include "ccmni.h"

#define NET_ACK_TXQ_INDEX(p) ((p)->txq_exp_index&0x0F)
#define GET_CCMNI_IDX(p) ((p)->minor - CCCI_NET_MINOR_BASE)

int ccci_get_ccmni_channel(int md_id, int ccmni_idx, struct ccmni_ch *channel)
{
	int ret = 0;

	switch (ccmni_idx) {
	case 0:
		channel->rx = CCCI_CCMNI1_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI1_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI1_DL_ACK;
		channel->multiq = md_id == MD_SYS1 ? 1 : 0;
		break;
	case 1:
		channel->rx = CCCI_CCMNI2_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI2_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI2_DL_ACK;
		channel->multiq = md_id == MD_SYS1 ? 1 : 0;
		break;
	case 2:
		channel->rx = CCCI_CCMNI3_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI3_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI3_TX;
		channel->multiq = 0;
		break;
	case 3:
		channel->rx = CCCI_CCMNI4_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI4_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI4_TX;
		channel->multiq = 0;
		break;
	case 4:
		channel->rx = CCCI_CCMNI5_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI5_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI5_TX;
		channel->multiq = 0;
		break;
	case 5:
		channel->rx = CCCI_CCMNI6_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI6_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI6_TX;
		channel->multiq = 0;
		break;
	case 6:
		channel->rx = CCCI_CCMNI7_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI7_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI7_TX;
		channel->multiq = 0;
		break;
	case 7:
		channel->rx = CCCI_CCMNI8_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI8_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI8_DLACK_RX;
		channel->multiq = md_id == MD_SYS1 ? 1 : 0;
		break;
	case 8:
		channel->rx = CCCI_CCMNI9_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI9_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI9_DLACK_RX;
		channel->multiq = 0;
		break;
	case 9:
		channel->rx = CCCI_CCMNI10_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI10_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI10_TX;
		channel->multiq = 0;
		break;
	case 10:
		channel->rx = CCCI_CCMNI11_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI11_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI11_TX;
		channel->multiq = 0;
		break;
	case 11:
		channel->rx = CCCI_CCMNI12_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI12_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI12_TX;
		channel->multiq = 0;
		break;
	case 12:
		channel->rx = CCCI_CCMNI13_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI13_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI13_TX;
		channel->multiq = 0;
		break;
	case 13:
		channel->rx = CCCI_CCMNI14_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI14_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI14_TX;
		channel->multiq = 0;
		break;
	case 14:
		channel->rx = CCCI_CCMNI15_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI15_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI15_TX;
		channel->multiq = 0;
		break;
	case 15:
		channel->rx = CCCI_CCMNI16_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI16_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI16_TX;
		channel->multiq = 0;
		break;
	case 16:
		channel->rx = CCCI_CCMNI17_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI17_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI17_TX;
		channel->multiq = 0;
		break;
	case 17:
		channel->rx = CCCI_CCMNI18_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI18_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI18_TX;
		channel->multiq = 0;
		break;
	case 18:
		channel->rx = CCCI_CCMNI19_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI19_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI19_TX;
		channel->multiq = 0;
		break;
	case 19:
		channel->rx = CCCI_CCMNI20_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI20_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI20_TX;
		channel->multiq = 0;
		break;
	case 20:
		channel->rx = CCCI_CCMNI21_RX;
		channel->rx_ack = 0xFF;
		channel->tx = CCCI_CCMNI21_TX;
		channel->tx_ack = 0xFF;
		channel->dl_ack = CCCI_CCMNI21_TX;
		channel->multiq = 0;
		break;
	default:
		MTK_ERR_LOG(NET, "Invalid ccmni index=%d\n", ccmni_idx);
		ret = -1;
		break;
	}

	return ret;
}

struct port_t *find_net_port_by_ccmni_idx(int md_id, int ccmni_idx)
{
	return port_get_by_minor(md_id, ccmni_idx + CCCI_NET_MINOR_BASE);
}

#ifdef DATA_PATH_NET_NAPI_MODE
#include "ccci_hif_dpmaif.h"
int ccmni_napi_poll(int md_id, struct napi_struct *napi, int weight)
{
	return dpmaif_napi_rx_poll(napi, weight);
}
#else /* DATA_PATH_NET_NAPI_MODE */
int ccmni_napi_poll(int md_id, struct napi_struct *napi, int weight)
{
	MTK_ERR_LOG(NET, "NAPI is not supported\n");
	return -ENODEV;
}
#endif /* DATA_PATH_NET_NAPI_MODE */

struct ccmni_ccci_ops eccci_ccmni_ops = {
	.ccmni_ver = CCMNI_DRV_V0,
#ifdef DATA_PATH_NET_NAPI_MODE
	.ccmni_num = 1,
#else
	.ccmni_num = 21,
#endif
	.name = "ccmni",
#ifdef DATA_PATH_NET_NAPI_MODE
	.md_ability =
		MODEM_CAP_DATA_ACK_DVD | MODEM_CAP_CCMNI_MQ | MODEM_CAP_NAPI,
#else
	.md_ability = MODEM_CAP_DATA_ACK_DVD | MODEM_CAP_CCMNI_MQ,
#endif
	.napi_poll_weigh = NAPI_POLL_WEIGHT,
	.napi_poll = ccmni_napi_poll,
	.get_ccmni_ch = ccci_get_ccmni_channel,
};
EXPORT_SYMBOL(eccci_ccmni_ops);


static int port_net_init(struct port_t *port)
{
	int md_id = port->md_id;
	struct ccci_per_md *per_md_data = ccci_get_per_md_data(md_id);

	port->minor += CCCI_NET_MINOR_BASE;
	if (port->rx_ch == CCCI_CCMNI1_RX) {
		eccci_ccmni_ops.md_ability |= per_md_data->md_capability;
		ccmni_ops.init(md_id, &eccci_ccmni_ops);
	}
	return 0;
}

static void port_net_uninit(struct port_t *port)
{
	int md_id = 0;

	MTK_DEBUG_LOG(NET, "Port %s uninit\n", port->name);
	if (port) {
		md_id = port->md_id;
		port->minor -= CCCI_NET_MINOR_BASE;
	} else {
		return;
	}

	if (port->rx_ch == CCCI_CCMNI1_RX) {
		if (ccmni_ops.exit)
			ccmni_ops.exit(md_id);
	}
}

static void port_net_queue_state_notify(struct port_t *port, int dir,
	int qno, unsigned int state)
{
	int is_ack = 0;

	if (dir == MTK_OUT && qno == NET_ACK_TXQ_INDEX(port) &&
		port->txq_index != qno)
		is_ack = 1;

	if (((state == TX_IRQ) &&
		((!is_ack && ((port->flags & PORT_F_TX_DATA_FULLED) == 0)) ||
		(is_ack && ((port->flags & PORT_F_TX_ACK_FULLED) == 0)))) ||
		((state == TX_FULL) &&
		((!is_ack && (port->flags & PORT_F_TX_DATA_FULLED)) ||
		(is_ack && (port->flags & PORT_F_TX_ACK_FULLED)))))
		return;

	ccmni_ops.queue_state_callback(port->md_id,
		GET_CCMNI_IDX(port), state, is_ack);

	switch (state) {
	case TX_IRQ:
		port->flags &= ~(is_ack ?
			PORT_F_TX_ACK_FULLED : PORT_F_TX_DATA_FULLED);
		break;
	case TX_FULL:
		port->flags |= (is_ack ?
			PORT_F_TX_ACK_FULLED : PORT_F_TX_DATA_FULLED);
		break;
	default:
		break;
	};
}

static void port_net_md_state_notify(struct port_t *port, unsigned int state)
{
	ccmni_ops.md_state_callback(port->md_id, GET_CCMNI_IDX(port), state);
}

void port_net_md_dump_info(struct port_t *port, unsigned int flag)
{
	if (port == NULL) {
		MTK_ERR_LOG(NET, "%s : port==NULL\n", __func__);
		return;
	}
	if (ccmni_ops.dump == NULL) {
		MTK_ERR_LOG(NET, "%s : ccmni_ops.dump== null\n", __func__);
		return;
	}
	ccmni_ops.dump(port->md_id, GET_CCMNI_IDX(port), 0);
}

struct port_ops net_port_ops = {
	.init = &port_net_init,
	.queue_state_notify = &port_net_queue_state_notify,
	.md_state_notify = &port_net_md_state_notify,
	.dump_info = &port_net_md_dump_info,
	.uninit = &port_net_uninit,
};
