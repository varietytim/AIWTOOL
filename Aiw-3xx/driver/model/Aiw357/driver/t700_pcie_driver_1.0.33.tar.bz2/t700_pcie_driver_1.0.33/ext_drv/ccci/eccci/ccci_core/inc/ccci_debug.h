/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __CCCI_DEBUG_H__
#define __CCCI_DEBUG_H__

#include "mt-plat/mtk_ccci_common.h"
#include "ccci_util_log.h" //deprecated, remove it in future
#include "mtk_util_log.h"

/* log tag defination */
#define CORE "CCCI_CORE"
#define BM "CCCI_BM"
#define FSM "CCCI_FSM"
#define PORT "CCCI_PORT"
#define NET "CCCI_NET"
#define CHAR "PORT_CHAR"
#define IPC "PORT_IPC"
#define RPC "PORT_RPC"
#define SYS "PORT_SYS"
#define SMEM "CCCI_SHM"
#define CCCI_EX "CCCI_EX"
#define TTY "PORT_TTY"


/***********************************************************************
 ** CCCI dump log define end ****************
 ************************************************************************/

/*#define CLDMA_TRACE*/
/* #define PORT_NET_TRACE */
//#define CCCI_SKB_TRACE
/* #define CCCI_BM_TRACE */

#endif				/* __CCCI_DEBUG_H__ */
