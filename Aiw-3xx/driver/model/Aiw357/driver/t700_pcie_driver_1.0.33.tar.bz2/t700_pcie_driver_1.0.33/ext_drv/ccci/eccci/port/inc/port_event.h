/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



/*
 * If TRACE_SYSTEM is defined, that will be the directory created
 * in the ftrace directory under /sys/kernel/debug/tracing/events/<system>
 *
 * The define_trace.h below will also look for a file name of
 * TRACE_SYSTEM.h where TRACE_SYSTEM is what is defined here.
 * In this case, it would look for sample.h
 *
 * If the header name will be different than the system name
 * (as in this case), then you can override the header name that
 * define_trace.h will look up by defining TRACE_INCLUDE_FILE
 *
 * This file is called trace-events-sample.h but we want the system
 * to be called "sample". Therefore we must define the name of this
 * file:
 *
 * #define TRACE_INCLUDE_FILE trace-events-sample
 *
 * As we do an the bottom of this file.
 *
 * Notice that TRACE_SYSTEM should be defined outside of #if
 * protection, just like TRACE_INCLUDE_FILE.
 */
#undef TRACE_SYSTEM
#define TRACE_SYSTEM port_event


#undef TRACE_SYSTEM_VAR
#define TRACE_SYSTEM_VAR port_event_var
/*
 * Notice that this file is not protected like a normal header.
 * We also must allow for rereading of this file. The
 *
 *	|| defined(TRACE_HEADER_MULTI_READ)
 *
 * serves this purpose.
 */
#if !defined(_PORT_EVENT_H) || defined(TRACE_HEADER_MULTI_READ)
#define _PORT_EVENT_H
#define PORT_EVENT
/*
 * All trace headers should include tracepoint.h, until we finally
 * make it into a standard header.
 */
#include <linux/tracepoint.h>
#include "ccci_core.h"
/*
 * The TRACE_EVENT macro is broken up into 5 parts.
 *
 * name: name of the trace point. This is also how to enable the tracepoint.
 *	 A function called trace_foo_bar() will be created.
 *
 * proto: the prototype of the function trace_foo_bar()
 *	 Here it is trace_foo_bar(char *foo, int bar).
 *
 * args:  must match the arguments in the prototype.
 *	  Here it is simply "foo, bar".
 *
 * struct:	This defines the way the data will be stored in the ring buffer.
 *	  There are currently two types of elements. __field and __array.
 *	  a __field is broken up into (type, name). Where type can be any
 *	  type but an array.
 *	  For an array. there are three fields. (type, name, size). The
 *	  type of elements in the array, the name of the field and the size
 *	  of the array.
 *
 *	  __array( char, foo, 10) is the same as saying	  char foo[10].
 *
 * fast_assign: This is a C like function that is used to store the items
 *	  into the ring buffer.
 *
 * printk: This is a way to print out the data in pretty print. This is
 *	  useful if the system crashes and you are logging via a serial line,
 *	  the data can be printed to the console using this "printk" method.
 *
 * Note, that for both the assign and the printk, __entry is the handler
 * to the data structure in the ring buffer, and is defined by the
 * TP_STRUCT__entry.
 */

/* for UL flow */
TRACE_EVENT(port_dev_write,
		TP_PROTO(const char *name, int md_state, void *skb,
			size_t data_size, unsigned char blocking),

		TP_ARGS(name, md_state, skb, data_size, blocking),

		TP_STRUCT__entry(
				 __string(str, name)
				 __field(int, md_state)
				 __field(void *, skb)
				 __field(size_t, data_size)
				 __field(unsigned char, blocking)
		),

		TP_fast_assign(
			__assign_str(str, name);
			__entry->md_state = md_state;
			__entry->skb = skb;
			__entry->data_size = data_size;
			__entry->blocking = blocking;
		),

		TP_printk("%s md_state %d  skb_addr 0x%p  data_size %ld	 blocking %u",
			__get_str(str), __entry->md_state, __entry->skb,
			__entry->data_size, __entry->blocking)
	);

TRACE_EVENT(port_send_skb_to_md,
		TP_PROTO(const char *name, int tx_qno, void *skb,
			unsigned char path_flag),

		TP_ARGS(name, tx_qno, skb, path_flag),

		TP_STRUCT__entry(
				__string(str,	name)
				__field(int, tx_qno)
				__field(void *, skb)
				__field(unsigned char, path_flag)
		),

		TP_fast_assign(
			__assign_str(str, name);
			__entry->tx_qno = tx_qno;
			__entry->skb = skb;
			__entry->path_flag = path_flag;
		),

		TP_printk("%s tx_qno:%d skb_addr:%p path_flag:%u",
			__get_str(str), __entry->tx_qno, __entry->skb,
			__entry->path_flag)
	);

/* for DL flow */
TRACE_EVENT(proxy_dispatch_recv_skb,
		TP_PROTO(int md_state, int ret, char matched, const void *skb,
			const struct ccci_header *ccci_h),

		TP_ARGS(md_state, ret, matched, skb, ccci_h),

		TP_STRUCT__entry(
				__field(int, md_state)
				__field(int, ret)
				__field(char, matched)
				__field(const void *, skb)
				__field(unsigned int, ccci_h1)
				__field(unsigned int, ccci_h2)
				__field(unsigned int, ccci_h3)
				__field(unsigned int, ccci_h4)
		),

		TP_fast_assign(
			__entry->md_state = md_state;
			__entry->ret = ret;
			__entry->matched = matched;
			__entry->skb = skb;
			__entry->ccci_h1 = *((u32 *)ccci_h);
			__entry->ccci_h2 = *((u32 *)ccci_h + 1);
			__entry->ccci_h3 = *((u32 *)ccci_h + 2);
			__entry->ccci_h4 = *((u32 *)ccci_h + 3);
		),

		TP_printk(
			"rx MD_STD:%d ret:%d matched:%d skb_addr:%p ccci_head:0x%x, 0x%x, 0x%x, 0x%x ",
			__entry->md_state, __entry->ret, __entry->matched,
			__entry->skb, __entry->ccci_h1, __entry->ccci_h2,
			__entry->ccci_h3, __entry->ccci_h4)
	);


//line 545: port_name,	skb_addr, port->rx_skb_len, port_flag
TRACE_EVENT(port_recv_skb,
		TP_PROTO(const char *name, const void *skb,
			unsigned int skb_len, unsigned long port_flag),

		TP_ARGS(name, skb, skb_len, port_flag),

		TP_STRUCT__entry(
		__string(str,	name)
		__field(const void *, skb)
		__field(unsigned int, skb_len)
		__field(unsigned long, port_flag)
		),

		TP_fast_assign(
			__assign_str(str, name);
			__entry->skb = skb;
			__entry->skb_len = skb_len;
			__entry->port_flag = port_flag;
		),

		TP_printk("%s skb_addr:%p skb_len:%d port_flag:%ld",
			__get_str(str), __entry->skb, __entry->skb_len,
			__entry->port_flag)
	);

TRACE_EVENT(port_kthread_handler,
		TP_PROTO(const char *name, const void *skb),

		TP_ARGS(name, skb),

		TP_STRUCT__entry(
		__string(str, name)
		__field(const void *, skb)
		),

		TP_fast_assign(
			__assign_str(str, name);
			__entry->skb = skb;
		),

		TP_printk("%s skb_addr:%p", __get_str(str), __entry->skb)
	);

TRACE_EVENT(port_dev_read,
		TP_PROTO(const char *name, size_t count, unsigned int skb_len),

		TP_ARGS(name, count, skb_len),

		TP_STRUCT__entry(
				__string(str,	name)
				__field(size_t, count)
				__field(unsigned int, skb_len)
		),

		TP_fast_assign(
			__assign_str(str, name);
			__entry->count = count;
			__entry->skb_len = skb_len;
		),

		TP_printk("%s count:%ld skb_len:%u", __get_str(str),
			__entry->count, __entry->skb_len)
	);

/* sysmsg port */
TRACE_EVENT(sys_msg_handler,
		TP_PROTO(const void *skb, const struct ccci_header *ccci_h),

		TP_ARGS(skb, ccci_h),

		TP_STRUCT__entry(
				__field(const void *, skb)
				__field(unsigned int, data0)
				__field(unsigned int, data1)
				__field(unsigned short, channel)
				__field(unsigned int, reserved)
		),

		TP_fast_assign(
			__entry->skb = skb;
			__entry->data0 = ccci_h->data[0];
			__entry->data1 = ccci_h->data[1];
			__entry->channel = ccci_h->channel;
			__entry->reserved = ccci_h->reserved;
		),

		TP_printk("%p system message: (%x %x %x %x)", __entry->skb,
			__entry->data0, __entry->data1,
			__entry->channel, __entry->reserved)
	);
#endif
/***** NOTICE! The #if protection ends here. *****/

/*
 * There are several ways I could have done this. If I left out the
 * TRACE_INCLUDE_PATH, then it would default to the kernel source
 * include/trace/events directory.
 *
 * I could specify a path from the define_trace.h file back to this
 * file.
 *
 * #define TRACE_INCLUDE_PATH ../../samples/trace_events
 *
 * But the safest and easiest way to simply make it use the directory
 * that the file is in is to add in the Makefile:
 *
 * CFLAGS_trace-events-sample.o := -I$(src)
 *
 * This will make sure the current path is part of the include
 * structure for our file so that define_trace.h can find it.
 *
 * I could have made only the top level directory the include:
 *
 * CFLAGS_trace-events-sample.o := -I$(PWD)
 *
 * And then let the path to this directory be the TRACE_INCLUDE_PATH:
 *
 * #define TRACE_INCLUDE_PATH samples/trace_events
 *
 * But then if something defines "samples" or "trace_events" as a macro
 * then we could risk that being converted too, and give us an unexpected
 * result.
 */
#undef TRACE_INCLUDE_PATH
#undef TRACE_INCLUDE_FILE
#define TRACE_INCLUDE_PATH .
/*
 * TRACE_INCLUDE_FILE is not needed if the filename and TRACE_SYSTEM are equal
 */
#define TRACE_INCLUDE_FILE port_event
#include <trace/define_trace.h>
