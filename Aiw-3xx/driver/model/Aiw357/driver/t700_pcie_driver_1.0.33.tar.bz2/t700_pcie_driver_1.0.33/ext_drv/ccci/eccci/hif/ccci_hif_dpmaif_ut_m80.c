// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/in.h>
#include <uapi/linux/icmp.h>
#include <net/checksum.h>
#include <linux/udp.h>
#include <uapi/linux/udp.h>
#include <net/udp.h>
#include <linux/netdevice.h>
#include <linux/string.h>
#include <net/net_namespace.h>

#include "ccci_debug.h"
#include "ccci_hif_dpmaif_ut_m80.h"
#include "dpmaif_hif_platform_m80.h"
#include "ccci_hif_dpmaif_m80.h"

#define TAG		"HIF-DPMAIF_UT"

#if defined(DATA_PATH_UT_LOOPBACK) || defined(DATA_PATH_UT_HW_LOOPBACK)

#define DPMA_UT_IP_HD_LEN		(iph->ihl * 4)
/* ICMP(type is echo) packet's data offset from IP header */
#define DPMA_UT_ICMP_OFFSET		DPMA_UT_IP_HD_LEN


enum dpmaif_ut_packet_type dpmaif_ut_get_packet_type(const struct sk_buff *skb)
{
	const struct iphdr *iph = NULL;

	if (unlikely(skb == NULL)) {
		MTK_ERR_LOG(TAG, "skb is a NULL pointer!\n");
		goto err;
	}

	/* checks packet type*/
	iph = (struct iphdr *)(skb->data);
	MTK_DEBUG_LOG(TAG, "skb's protocol is %d\n", iph->protocol);
	switch (iph->protocol) {
	case IPPROTO_ICMP:
		return DPMF_UT_PKT_ICMP;
	case IPPROTO_UDP:
		return DPMF_UT_PKT_UDP;
	case IPPROTO_TCP:
		return DPMF_UT_PKT_TCP;
	default:
		return DPMF_UT_PKT_UNKNOWN;
	}

err:
	return DPMF_UT_PKT_UNKNOWN;
}

#ifndef DATA_PATH_UT_HW_HANDLE
static bool dpmaif_ut_is_icmp_echo_pkt(const struct sk_buff *skb)
{
	const struct iphdr *iph = NULL;
	const struct icmphdr *icmph = NULL;

	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "Skb is a NULL pointer!\n");
		goto err_or_not;
	}

	/* checks if a ICMP packet */
	iph = (struct iphdr *)(skb->data);
	if (iph->protocol != IPPROTO_ICMP) {
		MTK_ERR_LOG(TAG,
			"This packet(prot = %d) is NOT a ICMP packet\n",
			(int)iph->protocol);
		goto err_or_not;
	}

	/* checks if a echo request packet */
	icmph = (const struct icmphdr *)((unsigned char *)skb->data
		+ DPMA_UT_ICMP_OFFSET);
	MTK_DEBUG_LOG(TAG,
		"This packet's IP header length is %d\n", (int)iph->ihl);
	if (icmph->type != ICMP_ECHO) {
		MTK_INFO_LOG(TAG,
			"This ICMP packet's type(%d) is NOT echo request\n",
			(int)(icmph->type));
		goto err_or_not;
	}

	return true;

err_or_not:
	return false;
}
#endif

int dpmaif_ut_reply_icmp_echo_pkt(struct sk_buff *skb)
{
	/*
	 *	we generate ICMP echo reply packets by modifying
	 *	the original echo packets
	 */
	int ret = 0;
	struct iphdr *iph = NULL;
	struct icmphdr *icmph = NULL;
#ifndef DATA_PATH_UT_HW_HANDLE
	__be32 src_addr, dst_addr;
#endif

	if (skb == NULL) {
		MTK_INFO_LOG(TAG,
			"This ICMP packet's type(%d) is NOT echo request\n",
			(int)(icmph->type));
		ret = -1;
		goto error;
	}

#ifndef DATA_PATH_UT_HW_HANDLE
	/* checks packet type */
	if (false == dpmaif_ut_is_icmp_echo_pkt(skb)) {
		ret = -2;
		goto error;
	}
#endif

	iph = (struct iphdr *)(skb->data);

#ifndef DATA_PATH_UT_HW_HANDLE
	/* exchange IP header's src and dst address */
	src_addr = iph->saddr;
	dst_addr = iph->daddr;
	MTK_DEBUG_LOG(TAG,
		"Original IP header's src address is %u.%u.%u.%u\n",
		(u8)(src_addr & 0xFF), (u8)(src_addr >> 8 & 0xFF),
		(u8)(src_addr >> 16 & 0xFF), (u8)(src_addr >> 24 & 0xFF));
	MTK_DEBUG_LOG(TAG,
		"dst address is %u.%u.%u.%u",
		(u8)(dst_addr & 0xFF), (u8)(dst_addr >> 8 & 0xFF),
		(u8)(dst_addr >> 16 & 0xFF), (u8)(dst_addr >> 24 & 0xFF));

	iph->saddr = dst_addr;
	iph->daddr = src_addr;
#endif

	/* modifies ICMP type for echo reply */
	icmph = (struct icmphdr *)(((unsigned char *)iph)
		+ DPMA_UT_IP_HD_LEN);
	icmph->type = ICMP_ECHOREPLY;

	/* recalculate new checksum for ICMP message */
	icmph->checksum = 0;
	icmph->checksum = ip_compute_csum((void *)icmph,
		skb->len - DPMA_UT_IP_HD_LEN);

	/* recalculate new checksum for IP header */
	iph->check = 0;
	iph->check = ip_fast_csum((unsigned char *)iph, iph->ihl);

	MTK_DEBUG_LOG(TAG,
		"ip header checksum = 0x%x, icmp checksum = 0x%x\n",
		iph->check, icmph->checksum);
	return 0;

error:
	return ret;
}


int dpmaif_ut_loopback_udp_pkt(struct sk_buff *skb)
{
	/*
	 *	we reply UDP packets by modifying
	 *	the original UDP packets
	 */
	struct iphdr *iph = NULL;
#ifndef DATA_PATH_UT_HW_HANDLE
	__be32 src_addr, dst_addr;
#endif

	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "skb is a NULL pointer!\n");
		goto error;
	}

	iph = (struct iphdr *)(skb->data);

#ifndef DATA_PATH_UT_HW_HANDLE
	/* exchange IP header's src and dst address */
	src_addr = iph->saddr;
	dst_addr = iph->daddr;
	MTK_DEBUG_LOG(TAG,
		"Original IP header's src address is %u.%u.%u.%u\n",
		(u8)(src_addr & 0xFF), (u8)(src_addr >> 8 & 0xFF),
		(u8)(src_addr >> 16 & 0xFF), (u8)(src_addr >> 24 & 0xFF));
	MTK_DEBUG_LOG(TAG,
		"dst address is %u.%u.%u.%u\n",
		(u8)(dst_addr & 0xFF), (u8)(dst_addr >> 8 & 0xFF),
		(u8)(dst_addr >> 16 & 0xFF), (u8)(dst_addr >> 24 & 0xFF));

	iph->saddr = dst_addr;
	iph->daddr = src_addr;
#endif

	/* recalculate new checksum for IP header */
	iph->check = 0;
	iph->check = ip_fast_csum((unsigned char *)iph, iph->ihl);
	MTK_DEBUG_LOG(TAG, "ip header checksum = 0x%x\n", iph->check);
	return 0;

error:
	return -2;
}

int dpmaif_ut_loopback_pkt(struct sk_buff *skb)
{
	enum dpmaif_ut_packet_type type = DPMF_UT_PKT_UNKNOWN;

	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "skb is a NULL pointer!\n");
		goto error;
	}

	/* checks packet type */
	type = dpmaif_ut_get_packet_type(skb);
	MTK_DEBUG_LOG(TAG, "packet's type is %d\n", type);
	if (type == DPMF_UT_PKT_ICMP)
		dpmaif_ut_reply_icmp_echo_pkt(skb);
	else if (type == DPMF_UT_PKT_UDP)
		dpmaif_ut_loopback_udp_pkt(skb);
	else if (type == DPMF_UT_PKT_TCP)
		dpmaif_ut_loopback_udp_pkt(skb);
	else
		goto type_err;

	return 0;

type_err:
	return -1;
error:
	return -2;
}

void dpmaif_ut_show_packet_checksum(struct sk_buff *skb)
{
	struct udphdr *udph = NULL;
	struct tcphdr *tcph = NULL;
	struct icmphdr *icmph = NULL;
	struct iphdr *iph = NULL;

	enum dpmaif_ut_packet_type type = DPMF_UT_PKT_UNKNOWN;

	if (skb == NULL) {
		MTK_ERR_LOG(TAG, "skb is a NULL pointer!\n");
		goto err;
	}
	iph = (struct iphdr *)(skb->data);

	/* checks packet type */
	type = dpmaif_ut_get_packet_type(skb);
	MTK_DEBUG_LOG(TAG,
		"packet's type: %d, ip checksum: 0x%04x\n", type, iph->check);
	if (type == DPMF_UT_PKT_ICMP) {
		icmph = (struct icmphdr *)((unsigned char *)iph + 4 * iph->ihl);
		MTK_DEBUG_LOG(TAG, "icmp checksum: 0x%04x\n", icmph->checksum);
	} else if (type == DPMF_UT_PKT_UDP) {
		udph = (struct udphdr *)((unsigned char *)iph + 4 * iph->ihl);
		MTK_DEBUG_LOG(TAG, "udp checksum: 0x%04x\n", udph->check);
	} else if (type == DPMF_UT_PKT_TCP) {
		tcph = (struct tcphdr *)((unsigned char *)iph + 4 * iph->ihl);
		MTK_DEBUG_LOG(TAG, "tcp checksum: 0x%04x\n", tcph->check);
	} else
		goto err;

err:
	return;

}


#endif	/* ifdef DATA_PATH_UT_LOOPBACK */


/* ==================================================== */
/* ==================================================== */

unsigned short dpmaif_ut_get_packet_id(struct iphdr *iph)
{
	unsigned char *data = NULL;

	if (unlikely(iph == NULL)) {
		MTK_DEBUG_LOG(TAG, "iph is NULL\n");
		goto error;
	}

	data = (unsigned char *)iph;

	return ((data[4] << 8) + data[5]);

error:
	return 0;
}

#ifdef DATA_PATH_TP_CALC
struct ccci_dp_tput_configure g_tput_config;
EXPORT_SYMBOL(g_tput_config);
#endif


