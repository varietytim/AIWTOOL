/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_POLLER_H__
#define __PORT_POLLER_H__

#include "ccci_core.h"
#include "port_t.h"
#endif	/* __PORT_POLLER_H__ */
