// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


/*****************************************************************************
 *
 * Filename:
 * ---------
 *	 ccmni.c
 *
 * Project:
 * --------
 *
 *
 ****************************************************************************/
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/ipv6.h>
#include <net/ipv6.h>
#include <net/sch_generic.h>
#include <linux/skbuff.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/version.h>
#include <linux/sockios.h>
#include <linux/device.h>
#include <linux/debugfs.h>
#include <linux/preempt.h>
#include <linux/stacktrace.h>
#include "ccmni.h"
#include "mtk_util_log.h"


#include "port_net.h"
#include "ccci_hif.h"
#include "ccci_util_log.h"


#define TAG "DATA"


struct ccmni_ctl_block *ccmni_ctl_blk[MAX_MD_NUM];

__weak const struct header_ops eth_header_ops;

#ifdef DATA_PATH_NET_NAPI_MODE
#include "ccci_hif_dpmaif.h"
#endif


/********************internal function*********************/
static void ccmni_make_etherframe(int md_id,
	struct net_device *dev, void *_eth_hdr,
	unsigned char *mac_addr, unsigned int packet_type)
{
	struct ethhdr *eth_hdr = _eth_hdr;

	memcpy(eth_hdr->h_dest, mac_addr, sizeof(eth_hdr->h_dest));
	memset(eth_hdr->h_source, 0, sizeof(eth_hdr->h_source));

	if (packet_type == 0x60)
		eth_hdr->h_proto = cpu_to_be16(ETH_P_IPV6);
	else
		eth_hdr->h_proto = cpu_to_be16(ETH_P_IP);
}

static inline int is_ack_skb(int md_id, struct sk_buff *skb)
{
	u32 packet_type;
	struct tcphdr *tcph;
	int ret = 0;

	packet_type = skb->data[0] & 0xF0;
	if (packet_type == IPV6_VERSION) {
		struct ipv6hdr *iph = (struct ipv6hdr *)skb->data;
		u32 total_len =
			sizeof(struct ipv6hdr) + ntohs(iph->payload_len);
		u8 nexthdr = iph->nexthdr;
		__be16 frag_off;
		u32 l4_off = ipv6_skip_exthdr(skb, sizeof(struct ipv6hdr),
			&nexthdr, &frag_off);

		tcph = (struct tcphdr *)(skb->data + l4_off);
		if (nexthdr == IPPROTO_TCP && !tcph->syn && !tcph->fin &&
			!tcph->rst &&
			((total_len - l4_off) == (tcph->doff << 2)))
			ret = 1;
	} else if (packet_type == IPV4_VERSION) {
		struct iphdr *iph = (struct iphdr *)skb->data;

		tcph = (struct tcphdr *)(skb->data + (iph->ihl << 2));
		if (iph->protocol == IPPROTO_TCP && !tcph->syn && !tcph->fin &&
			!tcph->rst && (ntohs(iph->tot_len) ==
			(iph->ihl << 2) + (tcph->doff << 2)))
			ret = 1;
	}

	return ret;
}

/********************netdev register function********************/
#if (LINUX_VERSION_CODE < KERNEL_VERSION(0x4,0x13,0)) 
static u16 ccmni_select_queue(struct net_device *dev, struct sk_buff *skb,
	void *accel_priv, select_queue_fallback_t fallback)

{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[ccmni->md_id];

	if (ctlb->ccci_ops->md_ability & MODEM_CAP_DATA_ACK_DVD) {
		if (ccmni->ch.multiq && is_ack_skb(ccmni->md_id, skb))
			return CCMNI_TXQ_FAST;
		else
			return CCMNI_TXQ_NORMAL;
	} else
		return CCMNI_TXQ_NORMAL;
}
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(0x5,0x1,0x15))
static u16 ccmni_select_queue(struct net_device *dev, struct sk_buff *skb,
	struct net_device *sb_dev)

{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[ccmni->md_id];

	if (ctlb->ccci_ops->md_ability & MODEM_CAP_DATA_ACK_DVD) {
		if (ccmni->ch.multiq && is_ack_skb(ccmni->md_id, skb))
			return CCMNI_TXQ_FAST;
		else
			return CCMNI_TXQ_NORMAL;
	} else
		return CCMNI_TXQ_NORMAL;
}
#endif

static int ccmni_open(struct net_device *dev)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ccmni_ctl = ccmni_ctl_blk[ccmni->md_id];
	struct ccmni_instance *ccmni_tmp = NULL;
	int usage_cnt = 0;
	unsigned long flags;

	if (unlikely(ccmni_ctl == NULL)) {
		MTK_ERR_LOG(TAG,
			"%s_Open: MD%d ctlb is NULL\n",
			dev->name, ccmni->md_id);
		return -1;
	}

	spin_lock_irqsave(ccmni->spinlock, flags);

	netif_carrier_on(dev);
	netif_tx_start_all_queues(dev);

#ifdef DATA_PATH_NET_NAPI_MODE
	if (unlikely(ccmni_ctl->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
		napi_enable(ccmni->napi);
		napi_schedule(ccmni->napi);
		MTK_INFO_LOG(TAG, "Enable napi for interface up\n");
	}
#endif

	atomic_inc(&ccmni->usage);
	ccmni_tmp = ccmni_ctl->ccmni_inst[ccmni->index];
	if (ccmni != ccmni_tmp) {
		usage_cnt = atomic_read(&ccmni->usage);
		atomic_set(&ccmni_tmp->usage, usage_cnt);
	}

	MTK_DEBUG_LOG(TAG, "%s_Open: cnt=(%d,%d), md_ab=0x%X\n",
		dev->name, atomic_read(&ccmni->usage),
		atomic_read(&ccmni_tmp->usage),
		ccmni_ctl->ccci_ops->md_ability);

	spin_unlock_irqrestore(ccmni->spinlock, flags);

	return 0;
}

static int ccmni_close(struct net_device *dev)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ccmni_ctl = ccmni_ctl_blk[ccmni->md_id];
	struct ccmni_instance *ccmni_tmp = NULL;
	int usage_cnt = 0;
	unsigned long flags;

	if (unlikely(ccmni_ctl == NULL)) {
		MTK_ERR_LOG(TAG,
			"%s_Close: MD%d ctlb is NULL\n",
			dev->name, ccmni->md_id);
		return -1;
	}

	MTK_DEBUG_LOG(TAG,
		"ccmni%d usage is %d", ccmni->index,
		atomic_read(&ccmni->usage));
	if (atomic_read(&ccmni->usage) <= 0) {
		/* this means this ccmni device has been closed */
		MTK_INFO_LOG(TAG,
			"ccmni%d has already been closed!\n", ccmni->index);
		return 0;
	}

#ifdef DATA_PATH_NET_NAPI_MODE
	if (unlikely(ccmni_ctl->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
		napi_synchronize(ccmni->napi);
		napi_disable(ccmni->napi);
		MTK_DEBUG_LOG(TAG,
			"ccmni%d, disabled napi for interface down\n",
			ccmni->index);
	}
#endif

	spin_lock_irqsave(ccmni->spinlock, flags);
	atomic_dec(&ccmni->usage);
	ccmni_tmp = ccmni_ctl->ccmni_inst[ccmni->index];
	if (ccmni != ccmni_tmp) {
		usage_cnt = atomic_read(&ccmni->usage);
		atomic_set(&ccmni_tmp->usage, usage_cnt);
	}

	netif_carrier_off(dev);
	netif_tx_disable(dev);

	MTK_DEBUG_LOG(TAG, "%s_Close: cnt=(%d, %d)\n",
		dev->name, atomic_read(&ccmni->usage),
		atomic_read(&ccmni_tmp->usage));
	spin_unlock_irqrestore(ccmni->spinlock, flags);

	return 0;
}

static int ccmni_send_packet(int md_id, int ccmni_idx, void *data, int is_ack)
{
	struct port_t *port = NULL;
	struct ccci_header *ccci_h;
	struct sk_buff *skb = (struct sk_buff *)data;
	int ret;
	unsigned char tx_qno = 0;
#ifdef PORT_NET_TRACE
	unsigned long long send_time = 0;
	unsigned long long get_port_time = 0;
	unsigned long long total_time = 0;

	total_time = sched_clock();
#endif

#ifdef PORT_NET_TRACE
	get_port_time = sched_clock();
#endif
	port = find_net_port_by_ccmni_idx(md_id, ccmni_idx);
#ifdef PORT_NET_TRACE
	get_port_time = sched_clock() - get_port_time;
#endif
	if (!port) {
		MTK_ERR_LOG(TAG, "port is NULL for CCMNI%d\n", ccmni_idx);
		return CCMNI_ERR_TX_INVAL;
	}

	ccci_h = (struct ccci_header *)skb_push(skb,
		sizeof(struct ccci_header));
	ccci_h = (struct ccci_header *)skb->data;
	ccci_h->channel = 0;
	ccci_h->data[0] = ccmni_idx;
	/* as skb->len already included ccci_header after skb_push */
	ccci_h->data[1] = skb->len;
	ccci_h->reserved = 0;

	MTK_DEBUG_LOG(TAG, "port %s send: %08X, %08X, %08X, %08X\n", port->name,
			 ccci_h->data[0], ccci_h->data[1], 0, ccci_h->reserved);
#ifdef PORT_NET_TRACE
	send_time = sched_clock();
#endif

	tx_qno = is_ack ? (port->txq_exp_index & 0x0F) : port->txq_index;
	ret = ccci_hif_send_skb(md_id, GET_PATH_FLAG(port->path_id),
		tx_qno, skb, port->skb_from_pool, 0);
#ifdef PORT_NET_TRACE
	send_time = sched_clock() - send_time;
#endif
	if (ret) {
		skb_pull(skb, sizeof(struct ccci_header));
		/* undo header, in next retry, we'll reserve header again */
		ret = CCMNI_ERR_TX_BUSY;
	} else {
		ret = CCMNI_ERR_TX_OK;
	}
#ifdef PORT_NET_TRACE
	if (ret == CCMNI_ERR_TX_OK) {
		total_time = sched_clock() - total_time;
		trace_port_net_tx(md_id, -1, 0, (unsigned int)get_port_time,
			(unsigned int)send_time, (unsigned int)(total_time));
	} else {
		trace_port_net_error(port->md_id, -1, 0,
			port->tx_busy_count, __LINE__);
	}
#endif
	return ret;
}


static int ccmni_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
	int ret;
	int skb_len = skb->len;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[ccmni->md_id];
	unsigned int is_ack = 0;

	/* dev->mtu is changed	if dev->mtu is changed by upper layer */
	if (unlikely(skb->len > dev->mtu)) {
		MTK_ERR_LOG(TAG,
			"CCMNI%d write fail: len(0x%x)>MTU(0x%x, 0x%x)\n",
			ccmni->index, skb->len, CCMNI_MTU, dev->mtu);
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		return NETDEV_TX_OK;
	}

	if (unlikely(skb_headroom(skb) < sizeof(struct ccci_header))) {
		MTK_ERR_LOG(TAG,
			"CCMNI%d write fail: header room(%d) < ccci_header(%d)\n",
			ccmni->index, skb_headroom(skb), dev->hard_header_len);
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		return NETDEV_TX_OK;
	}

	if (ctlb->ccci_ops->md_ability & MODEM_CAP_DATA_ACK_DVD)
		is_ack = is_ack_skb(ccmni->md_id, skb);

	ret = ccmni_send_packet(ccmni->md_id, ccmni->index, skb, is_ack);

	if (ret == CCMNI_ERR_MD_NO_READY || ret == CCMNI_ERR_TX_INVAL) {
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		ccmni->tx_busy_cnt[is_ack] = 0;
		MTK_ERR_LOG(TAG,
			"[TX]CCMNI%d send tx_pkt=%ld(ack=%d) fail: %d\n",
			ccmni->index, (dev->stats.tx_packets + 1), is_ack, ret);
		return NETDEV_TX_OK;
	} else if (ret == CCMNI_ERR_TX_BUSY) {
		goto tx_busy;
	}
	dev->stats.tx_packets++;
	dev->stats.tx_bytes += skb_len;
	if (ccmni->tx_busy_cnt[is_ack] > 10) {
		MTK_NOTICE_LOG(TAG,
			"[TX]CCMNI%d TX busy: tx_pkt=%ld(ack=%d) retry %ld times done\n",
			ccmni->index, dev->stats.tx_packets,
			is_ack, ccmni->tx_busy_cnt[is_ack]);
	}
	ccmni->tx_busy_cnt[is_ack] = 0;

	return NETDEV_TX_OK;

tx_busy:
	if (unlikely(!(ctlb->ccci_ops->md_ability & MODEM_CAP_TXBUSY_STOP))) {
		if ((ccmni->tx_busy_cnt[is_ack]++) % 100 == 0)
			MTK_NOTICE_LOG(TAG,
				"[TX]CCMNI%d TX busy: tx_pkt=%ld(ack=%d) retry_times=%ld\n",
				ccmni->index, dev->stats.tx_packets, is_ack,
				ccmni->tx_busy_cnt[is_ack]);
	} else {
		ccmni->tx_busy_cnt[is_ack]++;
	}

	return NETDEV_TX_BUSY;
}

static int ccmni_change_mtu(struct net_device *dev, int new_mtu)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);

	if (new_mtu > CCMNI_MTU)
		return -EINVAL;

	dev->mtu = new_mtu;
	MTK_DEBUG_LOG(TAG,
		"CCMNI%d change mtu_siz=%d\n", ccmni->index, new_mtu);
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
static void ccmni_tx_timeout(struct net_device *dev, unsigned int txqueue)
#else
static void ccmni_tx_timeout(struct net_device *dev)
#endif
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);

	MTK_DEBUG_LOG(TAG, "ccmni%d_tx_timeout: usage_cnt=%d, timeout=%ds\n",
		ccmni->index, atomic_read(&ccmni->usage),
		(ccmni->dev->watchdog_timeo/HZ));

	dev->stats.tx_errors++;
	if (atomic_read(&ccmni->usage) > 0)
		netif_tx_wake_all_queues(dev);
}

static int ccmni_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
	int	 usage_cnt;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_instance *ccmni_tmp = NULL;
	struct ccmni_ctl_block *ctlb = NULL;
	unsigned int timeout = 0;

	switch (cmd) {
	case SIOCSTXQSTATE:
		/* ifru_ivalue[3~0]:start/stop; ifru_ivalue[7~4]:reserve; */
		/* ifru_ivalue[15~8]:user id, bit8=rild, bit9=thermal */
		/* ifru_ivalue[31~16]: watchdog timeout value */
		ctlb = ccmni_ctl_blk[ccmni->md_id];
		if ((ifr->ifr_ifru.ifru_ivalue & 0xF) == 0) {
			/*ignore txq stop/resume if dev is not running */
			if (atomic_read(&ccmni->usage) > 0 &&
				netif_running(dev)) {
				atomic_dec(&ccmni->usage);

				netif_tx_disable(dev);
				/* stop queue won't stop Tx watchdog
				 * (ndo_tx_timeout)
				 */
				timeout = (ifr->ifr_ifru.ifru_ivalue &
					0xFFFF0000) >> 16;
				if (timeout == 0)
					dev->watchdog_timeo = 60 * HZ;
				else
					dev->watchdog_timeo = timeout*HZ;

				ccmni_tmp = ctlb->ccmni_inst[ccmni->index];
				if (ccmni_tmp != ccmni) { /* iRAT ccmni */
					usage_cnt = atomic_read(&ccmni->usage);
					atomic_set(
						&ccmni_tmp->usage, usage_cnt);
				}
			}
		} else {
			if (atomic_read(&ccmni->usage) <= 0 &&
				netif_running(dev)) {
				netif_tx_wake_all_queues(dev);
				dev->watchdog_timeo = CCMNI_NETDEV_WDT_TO;
				atomic_inc(&ccmni->usage);

				ccmni_tmp = ctlb->ccmni_inst[ccmni->index];
				if (ccmni_tmp != ccmni) { /* iRAT ccmni */
					usage_cnt = atomic_read(&ccmni->usage);
					atomic_set(
						&ccmni_tmp->usage, usage_cnt);
				}
			}
		}

		if (likely(ccmni_tmp != NULL)) {
			MTK_INFO_LOG(TAG,
				"SIOCSTXQSTATE: %s_state=0x%x, cnt=(%d, %d)\n",
				dev->name, ifr->ifr_ifru.ifru_ivalue,
				atomic_read(&ccmni->usage),
				atomic_read(&ccmni_tmp->usage));
		} else {
			MTK_INFO_LOG(TAG,
				"SIOCSTXQSTATE: %s_state=0x%x, cnt=%d\n",
				dev->name, ifr->ifr_ifru.ifru_ivalue,
				atomic_read(&ccmni->usage));
		}
		break;

	default:
		MTK_ERR_LOG(TAG, "%s: unknown ioctl cmd=%x\n", dev->name, cmd);
		break;
	}

	return 0;
}

static const struct net_device_ops ccmni_netdev_ops = {
	.ndo_open		= ccmni_open,
	.ndo_stop		= ccmni_close,
	.ndo_start_xmit = ccmni_start_xmit,
	.ndo_tx_timeout = ccmni_tx_timeout,
	.ndo_do_ioctl	= ccmni_ioctl,
	.ndo_change_mtu = ccmni_change_mtu,
	.ndo_select_queue = ccmni_select_queue,
};

static inline int ccmni_napi_poll(struct napi_struct *napi, int budget)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(napi->dev);
	int md_id = ccmni->md_id;
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];

	if (ctlb->ccci_ops->napi_poll)
		return ctlb->ccci_ops->napi_poll(md_id, napi, budget);
	else
		return 0;
}

/***************ccmni driver register ccci function**************/
static inline int ccmni_inst_init(int md_id,
	struct ccmni_instance *ccmni, struct net_device *dev)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];
	int i = 0;
	int ret = 0;

	ret = ctlb->ccci_ops->get_ccmni_ch(md_id, ccmni->index, &ccmni->ch);
	if (ret) {
		MTK_ERR_LOG(TAG, "Get ccmni%d channel fail\n", ccmni->index);
		return ret;
	}

	ccmni->dev = dev;
	ccmni->ctlb = ctlb;
	ccmni->md_id = md_id;
#ifdef DATA_PATH_NET_NAPI_MODE
	ccmni->napi = kzalloc(sizeof(struct napi_struct), GFP_KERNEL);
#endif
	ccmni->spinlock = kzalloc(sizeof(spinlock_t), GFP_KERNEL);

#ifdef DATA_PATH_NET_NAPI_MODE
	/* register napi device */
	if (dev && (ctlb->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
		MTK_DEBUG_LOG(TAG, "Add napi(%p), poll(%p), weight(%u)\n",
			ccmni->napi, ccmni_napi_poll,
			ctlb->ccci_ops->napi_poll_weigh);
		netif_napi_add(dev, ccmni->napi, ccmni_napi_poll,
			ctlb->ccci_ops->napi_poll_weigh);

		dpmaif_init_napi_mode((void *)ccmni->napi);
	}
#endif

	atomic_set(&ccmni->usage, 0);
	spin_lock_init(ccmni->spinlock);

	for (i = 0; i < 2; i++) {
		ccmni->tx_seq_num[i] = 0;
		ccmni->tx_full_cnt[i] = 0;
		ccmni->tx_irq_cnt[i] = 0;
		ccmni->tx_full_tick[i] = 0;
		ccmni->flags[i] &= ~CCMNI_TX_PRINT_F;
	}
	ccmni->rx_seq_num = 0;
	ccmni->rx_gro_cnt = 0;

	return ret;
}

static void ccmni_inst_rel(struct ccmni_instance *ccmni)
{
	unsigned int md_ability = 0;
#ifdef DATA_PATH_NET_NAPI_MODE
	bool deleted = false;
#endif
	if (unlikely(ccmni == NULL))
		goto end;

	md_ability = ccmni->ctlb->ccci_ops->md_ability;

#ifdef DATA_PATH_NET_NAPI_MODE
	if (ccmni->napi) {
		if (md_ability & MODEM_CAP_NAPI) {
			netif_napi_del(ccmni->napi);
			deleted = true;
		}
		kfree(ccmni->napi);
		ccmni->napi = NULL;
	}
#endif

	kfree(ccmni->spinlock);
	ccmni->spinlock = NULL;

end:
	return;
}

static void ccmni_start(struct ccmni_instance *ccmni)
{
#ifdef DATA_PATH_NET_NAPI_MODE
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;
#endif

	if (!ccmni || !ccmni->dev) {
		MTK_INFO_LOG(TAG, "ccmni is null err.\n");
		return;
	}

	if (atomic_read(&ccmni->usage) > 0) {
		netif_tx_start_all_queues(ccmni->dev);
		netif_carrier_on(ccmni->dev);

#ifdef DATA_PATH_NET_NAPI_MODE
		if (unlikely(ctlb->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
			napi_enable(ccmni->napi);
			napi_schedule(ccmni->napi);
			MTK_INFO_LOG(TAG, "Enable napi for interface up\n");
		}
#endif
	}

}

static void ccmni_stop(struct ccmni_instance *ccmni)
{
#ifdef DATA_PATH_NET_NAPI_MODE
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;
#endif

	if (!ccmni || !ccmni->dev) {
		MTK_INFO_LOG(TAG, "ccmni is null err.\n");
		return;
	}

	if (atomic_read(&ccmni->usage) > 0) {
#ifdef DATA_PATH_NET_NAPI_MODE
		if (unlikely(ctlb->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
			napi_synchronize(ccmni->napi);
			napi_disable(ccmni->napi);
			MTK_INFO_LOG(TAG, "Disable napi for interface up\n");
		}
#endif
		netif_tx_disable(ccmni->dev);
		netif_carrier_off(ccmni->dev);
	}
}

static inline void ccmni_dev_init(int md_id, struct net_device *dev)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];

	dev->header_ops = NULL;
	dev->mtu = CCMNI_MTU;
	dev->tx_queue_len = CCMNI_TX_QUEUE;
	dev->watchdog_timeo = CCMNI_NETDEV_WDT_TO;
	/* ccmni is a pure IP device */
	dev->flags = IFF_NOARP &
			(~IFF_BROADCAST & ~IFF_MULTICAST);
	/* not support VLAN */
	dev->features = NETIF_F_VLAN_CHALLENGED;
	if (ctlb->ccci_ops->md_ability & MODEM_CAP_SGIO) {
		dev->features |= NETIF_F_SG;
		dev->hw_features |= NETIF_F_SG;
	}
	if (ctlb->ccci_ops->md_ability & MODEM_CAP_NAPI) {
        dev->features |= NETIF_F_GRO;
        dev->hw_features |= NETIF_F_GRO;
	} else {
		dev->hard_header_len += sizeof(struct ccci_header);
	}
	dev->addr_len = ETH_ALEN;

	/* use kernel default free_netdev function */
	dev->needs_free_netdev = true;
	/* don't need to free again, because last step has called free_netdev */
	dev->priv_destructor = NULL;

	dev->netdev_ops = &ccmni_netdev_ops;
	random_ether_addr((u8 *) dev->dev_addr);
}

static int ccmni_init(int md_id, struct ccmni_ccci_ops *ccci_info)
{
	int i = 0, j = 0, ret = 0;
	struct ccmni_ctl_block *ctlb = NULL;
	struct ccmni_instance *ccmni = NULL;
	struct net_device *dev = NULL;

	MTK_INFO_LOG(TAG, "Init all ccmni dev\n");

	if (unlikely(ccci_info->md_ability & MODEM_CAP_CCMNI_DISABLE)) {
		MTK_ERR_LOG(TAG,
			"No need init ccmni: md_ability=0x%08X\n",
			ccci_info->md_ability);
		return 0;
	}

	ctlb = kzalloc(sizeof(struct ccmni_ctl_block), GFP_KERNEL);
	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc ccmni ctl struct fail\n");
		return -ENOMEM;
	}

	ctlb->ccci_ops = kzalloc(sizeof(struct ccmni_ccci_ops), GFP_KERNEL);
	if (unlikely(ctlb->ccci_ops == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc ccmni_ccci_ops struct fail\n");
		ret = -ENOMEM;
		goto alloc_mem_fail;
	}

	ccmni_ctl_blk[md_id] = ctlb;

	memcpy(ctlb->ccci_ops, ccci_info, sizeof(struct ccmni_ccci_ops));

	for (i = 0; i < ctlb->ccci_ops->ccmni_num; i++) {
		/* allocate netdev */
		if (ctlb->ccci_ops->md_ability & MODEM_CAP_CCMNI_MQ) {
			/* alloc multiple tx queue, 2 txq and 1 rxq */
			dev = alloc_etherdev_mqs(
				sizeof(struct ccmni_instance), CCMNI_TXQ_NUM, 1);
		} else {
			dev = alloc_etherdev(sizeof(struct ccmni_instance));
		}
		if (unlikely(dev == NULL)) {
			MTK_ERR_LOG(TAG, "Alloc netdev fail\n");
			ret = -ENOMEM;
			goto alloc_netdev_fail;
		}

		/* init net device */
		ccmni_dev_init(md_id, dev);
		dev->type = ARPHRD_PPP;

		sprintf(dev->name, "%s%d", ctlb->ccci_ops->name, i);

		/* init private structure of netdev */
		ccmni = netdev_priv(dev);
		ccmni->index = i;
		ret = ccmni_inst_init(md_id, ccmni, dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "Initial ccmni instance fail\n");
			goto alloc_netdev_fail;
		}
		ctlb->ccmni_inst[i] = ccmni;

		/* register net device */
		ret = register_netdev(dev);
		if (ret)
			goto alloc_netdev_fail;
	}

	return 0;

alloc_netdev_fail:
	if (dev) {
		free_netdev(dev);
		dev = NULL;
		ctlb->ccmni_inst[i] = NULL;
	}

	for (j = i - 1; j >= 0; j--) {
		ccmni = ctlb->ccmni_inst[j];
		unregister_netdev(ccmni->dev);
		/* free_netdev(ccmni->dev); */
		ctlb->ccmni_inst[j] = NULL;
	}

alloc_mem_fail:
	if (ctlb) {
		kfree(ctlb->ccci_ops);
		ctlb->ccci_ops = NULL;

		kfree(ctlb);
		ctlb = NULL;
	}

	ccmni_ctl_blk[md_id] = NULL;
	return ret;
}

static void ccmni_exit(int md_id)
{
	int i = 0;
	struct ccmni_ctl_block *ctlb = NULL;
	struct ccmni_instance *ccmni = NULL;

	MTK_INFO_LOG(TAG, "%s\n", __func__);

	ctlb = ccmni_ctl_blk[md_id];
	if (ctlb) {
		if (ctlb->ccci_ops == NULL)
			goto ccmni_exit_ret;

		for (i = 0; i < ctlb->ccci_ops->ccmni_num; i++) {
			ccmni = ctlb->ccmni_inst[i];
			if (ccmni) {
				if (ccmni->dev) {
					MTK_INFO_LOG(TAG,
						"Unregister %s dev\n",
						ccmni->dev->name);
					ccmni_close(ccmni->dev);
					ccmni_inst_rel(ccmni);
					unregister_netdev(ccmni->dev);
					/*free_netdev(ccmni->dev);	*/
					/* no need free again */
				}

				ctlb->ccmni_inst[i] = NULL;
			}
		}

		if (ctlb->ccci_ops->md_ability & MODEM_CAP_DIRECT_TETHERING) {
			ccmni = ctlb->ccmni_inst[i];
			if (ccmni) {
				if (ccmni->dev) {
					MTK_INFO_LOG(TAG,
						"Unregister %s dev\n",
						ccmni->dev->name);
					ccmni_close(ccmni->dev);
					ccmni_inst_rel(ccmni);
					unregister_netdev(ccmni->dev);
					/*free_netdev(ccmni->dev);	*/
					/* no need free again */
				}

				ctlb->ccmni_inst[i] = NULL;
			}
		}

		kfree(ctlb->ccci_ops);
		ctlb->ccci_ops = NULL;

ccmni_exit_ret:
		kfree(ctlb);
		ccmni_ctl_blk[md_id] = NULL;
	}

	MTK_INFO_LOG(TAG, "%s done\n", __func__);
}

#ifdef DATA_PATH_NET_NAPI_MODE
#define IPV4_VERSION 0x40
#define IPV6_VERSION 0x60

static int is_skb_gro(struct sk_buff *skb)
{
    u32 packet_type;
    packet_type = skb->data[0] & 0xF0;
    if (packet_type == IPV4_VERSION &&
        ip_hdr(skb)->protocol == IPPROTO_TCP)
        return 1;
    else if (packet_type == IPV6_VERSION &&
        ipv6_hdr(skb)->nexthdr == IPPROTO_TCP)
        return 1;
    else
        return 0;
}
#endif

int ccmni_rx_callback(int md_id,
	int ccmni_idx, struct sk_buff *skb, void *priv_data)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];
	/* struct ccci_header *ccci_h = (struct ccci_header*)skb->data; */
	struct ccmni_instance *ccmni = NULL;
	struct net_device *dev = NULL;
	int pkt_type, skb_len;
#if defined(CCCI_SKB_TRACE)
	struct iphdr *iph;
#endif

#ifdef DATA_PATH_NET_NAPI_MODE
	int is_gro = 0;
#endif

	if (unlikely(ctlb == NULL || ctlb->ccci_ops == NULL)) {
		MTK_ERR_LOG(TAG,
			"Invalid CCMNI%d ctrl/ops struct\n", ccmni_idx);
		dev_kfree_skb(skb);
		return -1;
	}

	ccmni = ctlb->ccmni_inst[ccmni_idx];
	dev = ccmni->dev;

	pkt_type = skb->data[0] & 0xF0;
	ccmni_make_etherframe(md_id, dev,
		skb->data - ETH_HLEN, dev->dev_addr, pkt_type);
	skb_set_mac_header(skb, -ETH_HLEN);
	skb_reset_network_header(skb);
	skb->dev = dev;
	if (pkt_type == 0x60)
		skb->protocol  = htons(ETH_P_IPV6);
	else
		skb->protocol  = htons(ETH_P_IP);

	skb_len = skb->len;

#if defined(NETDEV_TRACE) && defined(NETDEV_DL_TRACE)
	skb->dbg_flag = 0x1;
#endif

#if defined(CCCI_SKB_TRACE)
	iph = (struct iphdr *)skb->data;
	ctlb->net_rx_delay[2] = iph->id;
	ctlb->net_rx_delay[0] = dev->stats.rx_bytes + skb_len;
	ctlb->net_rx_delay[1] = dev->stats.tx_bytes;
#endif

#ifdef DATA_PATH_NET_NAPI_MODE
	if (likely(ctlb->ccci_ops->md_ability & MODEM_CAP_NAPI)) {
		is_gro = is_skb_gro(skb);
		if (is_gro)
			napi_gro_receive(ccmni->napi, skb);
		else
			netif_receive_skb(skb);
	}
#else
	if (!in_interrupt())
		netif_rx_ni(skb);
	else
		netif_rx(skb);
#endif

	dev->stats.rx_packets++;
	dev->stats.rx_bytes += skb_len;

	return 0;
}

static void ccmni_queue_state_callback(int md_id,
	int ccmni_idx, enum HIF_STATE state, int is_ack)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];
	struct ccmni_instance *ccmni = NULL;
	struct ccmni_instance *ccmni_tmp = NULL;
	struct net_device *dev = NULL;
	struct netdev_queue *net_queue = NULL;
	unsigned long flags;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG,
			"Invalid ccmni ctrl when ccmni%d_hif_sta=%d\n",
			ccmni_idx, state);
		return;
	}

	ccmni_tmp = ctlb->ccmni_inst[ccmni_idx];
	dev = ccmni_tmp->dev;
	ccmni = (struct ccmni_instance *)netdev_priv(dev);

	switch (state) {
	case RX_IRQ:
#ifdef DATA_PATH_NET_NAPI_MODE
		napi_schedule(ccmni->napi);
#endif
		break;

	case TX_IRQ:
		spin_lock_irqsave(ccmni->spinlock, flags);
		if (netif_running(ccmni->dev) &&
			atomic_read(&ccmni->usage) > 0) {
			if (likely(ctlb->ccci_ops->md_ability &
				MODEM_CAP_CCMNI_MQ)) {
				if (is_ack)
					net_queue = netdev_get_tx_queue(
						ccmni->dev, CCMNI_TXQ_FAST);
				else
					net_queue = netdev_get_tx_queue(
						ccmni->dev, CCMNI_TXQ_NORMAL);
				if (netif_tx_queue_stopped(net_queue))
					netif_tx_wake_queue(net_queue);
			} else {
				is_ack = 0;
				if (netif_queue_stopped(ccmni->dev))
					netif_wake_queue(ccmni->dev);
			}
			ccmni->tx_irq_cnt[is_ack]++;
			if ((ccmni->flags[is_ack] & CCMNI_TX_PRINT_F) ||
				time_after(jiffies,
				ccmni->tx_irq_tick[is_ack] + 2)) {
				ccmni->flags[is_ack] &= ~CCMNI_TX_PRINT_F;
				MTK_DEBUG_LOG(TAG,
					"%s(%d), idx=%d, md_sta=TX_IRQ, ack=%d, cnt(%u, %u), time=%lu\n",
					ccmni->dev->name,
					atomic_read(&ccmni->usage),
					ccmni->index, is_ack,
					ccmni->tx_full_cnt[is_ack],
					ccmni->tx_irq_cnt[is_ack],
					(jiffies - ccmni->tx_irq_tick[is_ack]));
			}
		}
		spin_unlock_irqrestore(ccmni->spinlock, flags);
		break;

	case TX_FULL:
		spin_lock_irqsave(ccmni->spinlock, flags);
		if (atomic_read(&ccmni->usage) > 0) {
			if (ctlb->ccci_ops->md_ability & MODEM_CAP_CCMNI_MQ) {
				if (is_ack)
					net_queue = netdev_get_tx_queue(
						ccmni->dev, CCMNI_TXQ_FAST);
				else
					net_queue = netdev_get_tx_queue(
						ccmni->dev, CCMNI_TXQ_NORMAL);
				netif_tx_stop_queue(net_queue);
			} else {
				is_ack = 0;
				netif_stop_queue(ccmni->dev);
			}
			ccmni->tx_full_cnt[is_ack]++;
			ccmni->tx_irq_tick[is_ack] = jiffies;
			if (time_after(jiffies,
				ccmni->tx_full_tick[is_ack] + 4)) {
				ccmni->tx_full_tick[is_ack] = jiffies;
				ccmni->flags[is_ack] |= CCMNI_TX_PRINT_F;
				MTK_DEBUG_LOG(TAG,
					"%s(%d), idx=%d, hif_sta=TX_FULL, ack=%d, cnt(%u, %u)\n",
					ccmni->dev->name,
					atomic_read(&ccmni->usage),
					ccmni->index, is_ack,
					ccmni->tx_full_cnt[is_ack],
					ccmni->tx_irq_cnt[is_ack]);
			}
		}
		spin_unlock_irqrestore(ccmni->spinlock, flags);
		break;
	default:
		break;
	}
}

static void ccmni_md_state_callback(int md_id,
	int ccmni_idx, enum MD_STATE state)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];
	struct ccmni_instance *ccmni = NULL;
	struct ccmni_instance *ccmni_tmp = NULL;
	struct net_device *dev = NULL;
	unsigned long flags;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG,
			"Invalid ccmni ctrl when ccmni%d_md_sta=%d\n",
			ccmni_idx, state);
		return;
	}
	ccmni_tmp = ctlb->ccmni_inst[ccmni_idx];
	dev = ccmni_tmp->dev;
	ccmni = (struct ccmni_instance *)netdev_priv(dev);

	spin_lock_irqsave(ccmni->spinlock, flags);
	if (atomic_read(&ccmni->usage) > 0)
		MTK_DEBUG_LOG(TAG,
			"md_state_cb: CCMNI%d, md_sta=%d, usage=%d\n",
			ccmni_idx, state, atomic_read(&ccmni->usage));

	switch (state) {
	case READY:
		ccmni_start(ccmni);
		break;
	case EXCEPTION:
	case RESET:
	case WAITING_TO_STOP:
		ccmni_stop(ccmni);
		break;
	default:
		break;
	}
	spin_unlock_irqrestore(ccmni->spinlock, flags);
}

static void ccmni_dump(int md_id, int ccmni_idx, unsigned int flag)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];
	struct ccmni_instance *ccmni = NULL;
	struct ccmni_instance *ccmni_tmp = NULL;
	struct net_device *dev = NULL;
	struct netdev_queue *dev_queue = NULL;
	struct netdev_queue *ack_queue = NULL;
	struct Qdisc *qdisc;
	struct Qdisc *ack_qdisc;

	if (ctlb == NULL)
		return;

	ccmni_tmp = ctlb->ccmni_inst[ccmni_idx];
	if (unlikely(ccmni_tmp == NULL))
		return;

	if ((ccmni_tmp->dev->stats.rx_packets == 0) &&
		(ccmni_tmp->dev->stats.tx_packets == 0))
		return;

	dev = ccmni_tmp->dev;
	/* ccmni diff from ccmni_tmp for MD IRAT */
	ccmni = (struct ccmni_instance *)netdev_priv(dev);
	dev_queue = netdev_get_tx_queue(dev, 0);
	if (ctlb->ccci_ops->md_ability & MODEM_CAP_CCMNI_MQ) {
		ack_queue = netdev_get_tx_queue(dev, CCMNI_TXQ_FAST);
		qdisc = dev_queue->qdisc;
		ack_qdisc = ack_queue->qdisc;
		/* stats.rx_dropped is dropped in ccmni, dev->rx_dropped
		 * is dropped in net device layer stats.tx_packets is count by
		 * ccmni, bstats.packets is count by qdisc in net device layer
		 */
		MTK_INFO_LOG(TAG,
			"%s(%d,%d), irat_MD%d, rx=(%ld,%ld,%d), tx=(%ld,%d,%d)\n",
			dev->name, atomic_read(&ccmni->usage),
			atomic_read(&ccmni_tmp->usage), (ccmni->md_id + 1),
			dev->stats.rx_packets, dev->stats.rx_bytes,
			ccmni->rx_gro_cnt, dev->stats.tx_packets,
			qdisc->bstats.packets, ack_qdisc->bstats.packets);
		MTK_INFO_LOG(TAG,
			"txq_len=(%d,%d), tx_drop=(%ld,%d,%d), rx_drop=(%ld,%ld)\n",
			qdisc->q.qlen, ack_qdisc->q.qlen,
			dev->stats.tx_dropped, qdisc->qstats.drops,
			ack_qdisc->qstats.drops, dev->stats.rx_dropped,
			atomic_long_read(&dev->rx_dropped));
		MTK_INFO_LOG(TAG,
			"tx_busy=(%ld,%ld), sta=(0x%lx,0x%x,0x%lx,0x%lx)\n",
			ccmni->tx_busy_cnt[0], ccmni->tx_busy_cnt[1],
			dev->state, dev->flags, dev_queue->state,
			ack_queue->state);
	} else {
		MTK_DEBUG_LOG(TAG,
			"%s(%d,%d), irat_MD%d, rx=(%ld,%ld,%d), tx=(%ld,%ld)\n",
			dev->name, atomic_read(&ccmni->usage),
			atomic_read(&ccmni_tmp->usage), (ccmni->md_id + 1),
			dev->stats.rx_packets, dev->stats.rx_bytes,
			ccmni->rx_gro_cnt, dev->stats.tx_packets,
			dev->stats.tx_bytes);
		MTK_DEBUG_LOG(TAG,
			"txq_len=%d, tx_drop=(%ld,%d), rx_drop=(%ld,%ld)\n",
			dev->qdisc->q.qlen, dev->stats.tx_dropped,
			dev->qdisc->qstats.drops, dev->stats.rx_dropped,
			atomic_long_read(&dev->rx_dropped));
		MTK_DEBUG_LOG(TAG,
			"tx_busy=(%ld,%ld), sta=(0x%lx,0x%x,0x%lx)\n",
			ccmni->tx_busy_cnt[0], ccmni->tx_busy_cnt[1],
			dev->state, dev->flags, dev_queue->state);
	}
}

static void ccmni_dump_rx_status(int md_id, unsigned long long *status)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];

	status[0] = ctlb->net_rx_delay[0];
	status[1] = ctlb->net_rx_delay[1];
	status[2] = ctlb->net_rx_delay[2];
}

static struct ccmni_ch *ccmni_get_ch(int md_id, int ccmni_idx)
{
	struct ccmni_ctl_block *ctlb = ccmni_ctl_blk[md_id];

	return &ctlb->ccmni_inst[ccmni_idx]->ch;
}

struct ccmni_dev_ops ccmni_ops = {
	.skb_alloc_size = 1600,
	.init = &ccmni_init,
	.rx_callback = &ccmni_rx_callback,
	.md_state_callback = &ccmni_md_state_callback,
	.queue_state_callback = &ccmni_queue_state_callback,
	.exit = ccmni_exit,
	.dump = ccmni_dump,
	.dump_rx_status = ccmni_dump_rx_status,
	.get_ch = ccmni_get_ch,
	.is_ack_skb = is_ack_skb,
};
