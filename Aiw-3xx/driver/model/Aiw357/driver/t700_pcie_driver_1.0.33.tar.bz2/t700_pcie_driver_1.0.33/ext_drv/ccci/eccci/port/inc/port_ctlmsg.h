/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_CTLMSG_H__
#define __PORT_CTLMSG_H__

#include "ccci_core.h"
#include "port_t.h"
/****************************************************************************/
/* External API Region called by port ctl object */
/****************************************************************************/

#endif	/* __PORT_CTLMSG_H__ */
