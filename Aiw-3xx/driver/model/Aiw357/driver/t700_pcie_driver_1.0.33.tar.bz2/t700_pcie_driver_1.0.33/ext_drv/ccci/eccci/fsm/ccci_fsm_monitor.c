// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "ccci_fsm_internal.h"

static char *fsm_monitor_name[MAX_MD_NUM] = {
	"ccci_monitor",
};

static int dev_char_open(struct inode *inode, struct file *file)
{
	struct ccci_fsm_ctl *ctl = NULL;
	struct ccci_fsm_monitor *monitor_ctl = NULL;

	ctl = fsm_get_entity_by_device_number(inode->i_rdev);
	if (!ctl)
		return -EINVAL;
	monitor_ctl = &ctl->monitor_ctl;
	if (atomic_read(&monitor_ctl->usage_cnt))
		return -EBUSY;

	monitor_ctl = &ctl->monitor_ctl;
	MTK_INFO_LOG(FSM, "monitor node open by %s\n", current->comm);
	atomic_inc(&monitor_ctl->usage_cnt);
	file->private_data = monitor_ctl;
	nonseekable_open(inode, file);
	return 0;
}

static int dev_char_close(struct inode *inode, struct file *file)
{
	struct ccci_fsm_monitor *monitor_ctl = file->private_data;
	struct sk_buff *skb = NULL;
	int clear_cnt = 0;

	atomic_dec(&monitor_ctl->usage_cnt);
	while ((skb = ccci_skb_dequeue(&monitor_ctl->rx_skb_list)) != NULL) {
		ccci_free_skb(skb);
		clear_cnt++;
	}
	MTK_INFO_LOG(FSM, "monitor close, clear_cnt=%d\n", clear_cnt);
	return 0;
}

static ssize_t dev_char_read(struct file *file,
	char *buf, size_t count, loff_t *ppos)
{
	struct ccci_fsm_monitor *monitor_ctl = file->private_data;
	struct sk_buff *skb = NULL;
	int ret = 0, read_len = 0;

	if (skb_queue_empty(&monitor_ctl->rx_skb_list.skb_list)) {
		ret = wait_event_interruptible(monitor_ctl->rx_wq,
			!skb_queue_empty(&monitor_ctl->rx_skb_list.skb_list));
		if (ret == -ERESTARTSYS) {
			ret = -EINTR;
			goto exit;
		}
	}
	skb = ccci_skb_dequeue(&monitor_ctl->rx_skb_list);
	if (skb) {
		read_len = skb->len;
		if (read_len > count ||
			copy_to_user(buf, skb->data, read_len)) {
			MTK_ERR_LOG(FSM,
				"read on monitor, copy to user failed, %d/%zu\n",
				read_len, count);
			ret = -EFAULT;
		}
		ccci_free_skb(skb);
	}

 exit:
	return ret ? ret : read_len;
}

static ssize_t dev_char_write(struct file *file,
	const char __user *buf, size_t count, loff_t *ppos)
{
	return -EACCES;
}

static long dev_char_ioctl(struct file *file,
	unsigned int cmd, unsigned long arg)
{
	struct ccci_fsm_monitor *monitor_ctl = file->private_data;

	return ccci_fsm_ioctl(monitor_ctl->md_id, cmd, arg);
}

#ifdef CONFIG_COMPAT
static long dev_char_compat_ioctl(struct file *filp,
	unsigned int cmd, unsigned long arg)
{
	if (!filp->f_op || !filp->f_op->unlocked_ioctl)
		return -ENOTTY;
	return filp->f_op->unlocked_ioctl(filp,
		cmd, (unsigned long)compat_ptr(arg));
}
#endif

static const struct file_operations char_dev_fops = {
	.owner = THIS_MODULE,
	.open = &dev_char_open,
	.read = &dev_char_read,
	.write = &dev_char_write,
	.release = &dev_char_close,
	.unlocked_ioctl = &dev_char_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = &dev_char_compat_ioctl,
#endif
};

int fsm_monitor_send_message(int md_id, CCCI_MD_MSG msg, u32 resv)
{
	struct sk_buff *skb = NULL;
	struct ccci_header *ccci_h;
	struct ccci_fsm_ctl *ctl = fsm_get_entity_by_md_id(md_id);
	struct ccci_fsm_monitor *monitor_ctl = &ctl->monitor_ctl;

	if (!ctl)
		return -CCCI_ERR_INVALID_PARAM;

	if (unlikely(in_interrupt())) {
		MTK_ERR_LOG(FSM, "sending virtual msg from IRQ context %ps\n",
				 __builtin_return_address(0));
		return -CCCI_ERR_ASSERT_ERR;
	}

	skb = ccci_alloc_skb(sizeof(struct ccci_header), 1, 1);
	ccci_h = (struct ccci_header *)skb_put(skb, sizeof(struct ccci_header));
	ccci_h->data[0] = CCCI_MAGIC_NUM;
	ccci_h->data[1] = msg;
	*(((u32 *) ccci_h) + 2) = CCCI_MONITOR_CH_ID;
	ccci_h->reserved = resv;
	ccci_skb_enqueue(&monitor_ctl->rx_skb_list, skb);
	wake_up_all(&monitor_ctl->rx_wq);
	return 0;
}


void fsm_monitor_reset(struct ccci_fsm_monitor *monitor_ctl)
{
	struct ccci_fsm_ctl *ctl =
			container_of(monitor_ctl, struct ccci_fsm_ctl, monitor_ctl);

	monitor_ctl->md_id = ctl->md_id;
	atomic_set(&monitor_ctl->usage_cnt, 0);

	return;
}


int fsm_monitor_init(struct ccci_fsm_monitor *monitor_ctl)
{
	int ret = 0;
	char tmp_buf[20];

	fsm_monitor_reset(monitor_ctl);
	ccci_skb_queue_init(&monitor_ctl->rx_skb_list, 16, 1024, 0);
	init_waitqueue_head(&monitor_ctl->rx_wq);

	monitor_ctl->char_dev = kmalloc(sizeof(struct cdev), GFP_KERNEL);
	cdev_init(monitor_ctl->char_dev, &char_dev_fops);
	monitor_ctl->char_dev->owner = THIS_MODULE;

	snprintf(tmp_buf, 20, FSM_NAME"%d", monitor_ctl->md_id);
	ret = alloc_chrdev_region(&monitor_ctl->dev_n,
		monitor_ctl->md_id, 1, tmp_buf);
	if (ret)
		MTK_ERR_LOG(FSM, "alloc_chrdev_region fail, ret=%d\n", ret);
	ret = cdev_add(monitor_ctl->char_dev, monitor_ctl->dev_n, 1);
	if (ret)
		MTK_ERR_LOG(FSM, "cdev_add fail, ret=%d\n", ret);

	ret = ccci_register_dev_node(fsm_monitor_name[monitor_ctl->md_id],
			MAJOR(monitor_ctl->dev_n), MINOR(monitor_ctl->dev_n));
	if (ret)
		MTK_ERR_LOG(FSM, "device_create fail, ret=%d\n", ret);
	return ret;
}

int fsm_monitor_uninit(struct ccci_fsm_monitor *monitor_ctl)
{
	struct sk_buff *skb = NULL;

	ccci_unregister_dev_node(MAJOR(monitor_ctl->dev_n),
		MINOR(monitor_ctl->dev_n));

	if (monitor_ctl->char_dev) {
		cdev_del(monitor_ctl->char_dev);
		kfree(monitor_ctl->char_dev);
	}

	while ((skb = ccci_skb_dequeue(&monitor_ctl->rx_skb_list)) != NULL)
		ccci_free_skb(skb);

	unregister_chrdev_region(monitor_ctl->dev_n, 1);
	return 0;
}

