/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MODEM_MHCCIF_H__
#define __MODEM_MHCCIF_H__

#include <linux/atomic.h>
#include <mt-plat/mtk_ccci_common.h>
#include "ccci_config.h"
#include "ccci_core.h"
#include "ccci_modem.h"
#include "ccci_hif_internal.h"
#include "ccci_driver.h"
#include "modem_sys_1.h"

struct md_mhccif_ctrl {
	unsigned char md_id;
	unsigned char hif_id;
	atomic_t wakeup_src;
	atomic_t mhccif_irq_enabled;
	struct ccci_hif_ops *ops;
	void *hif_hw_info;
};

struct ccif_sram_layout {
	struct ccci_header dl_header;
	struct md_query_ap_feature md_rt_data;
	struct ccci_header up_header;
	struct ap_query_md_feature ap_rt_data;
};


#ifdef CONFIG_MTK_ECCCI_MHCCIF
#define RINGQ_EXP_BASE (0)
/*AP to MD exception interrupt id*/
#define H2D_EXCEPTION_ACK        (RINGQ_EXP_BASE+1)
#define H2D_EXCEPTION_CLEARQ_ACK (RINGQ_EXP_BASE+2)
/*MD to AP exception interrupt id*/
#define D2H_EXCEPTION_INIT        (RINGQ_EXP_BASE+1)
#define D2H_EXCEPTION_INIT_DONE   (RINGQ_EXP_BASE+2)
#define D2H_EXCEPTION_CLEARQ_DONE (RINGQ_EXP_BASE+3)
#define D2H_EXCEPTION_ALLQ_RESET  (RINGQ_EXP_BASE+4)



/*provide the other kernel module*/
int ccci_mhccif_hif_init(unsigned char md_id, unsigned char hif_id);
int ccci_mhccif_hif_exit(unsigned char md_id, unsigned char hif_id);
int ccci_mhccif_hif_late_init(unsigned char md_id, unsigned char hif_id);
void *ccci_mhccif_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *dev_ptr);
int ccci_mhccif_hif_start(unsigned char md_id, unsigned char hif_id);
int ccci_mhccif_hif_stop(unsigned char md_id, unsigned char hif_id);
int ccci_mhccif_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage);
int ccci_mhccif_ex_handshake(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage);
void ccci_mhccif_reset(u8 md_id, unsigned char hif_id, char is_hw);
unsigned long ccci_mhccif_get_int_id(unsigned char md_id,
	unsigned char hif_id);


/*The inline func*/
static inline int ccci_mhccif_hif_send_skb(unsigned char md_id,
	unsigned char hif_id, int tx_qno, struct sk_buff *skb,
	int from_pool, int blocking)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->send_skb(md_id,
			hif_id, tx_qno, skb, from_pool, blocking);
	else
		return -1;
}

static inline int ccci_mhccif_hif_write_room(unsigned char md_id,
	unsigned char hif_id, unsigned char qno)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->write_room(md_id, hif_id, qno);
	else
		return -1;
}

static inline int ccci_mhccif_hif_give_more(unsigned char md_id,
	unsigned char hif_id, int rx_qno)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->give_more(md_id, hif_id, rx_qno);
	else
		return -1;
}

static inline int ccci_mhccif_hif_dump_status(unsigned int md_id,
	unsigned int hif_id, enum modem_dump_flag dump_flag, void *data, int length)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->dump_status(md_id,
			hif_id, dump_flag, data, length);
	else
		return -1;

}

static inline int ccci_mhccif_hif_start_queue(unsigned char md_id,
	unsigned char hif_id, unsigned char qno, enum direction dir)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->start_queue(md_id, hif_id, qno, dir);
	else
		return -1;
}

static inline int ccci_mhccif_hif_stop_queue(unsigned char md_id,
	unsigned char hif_id, unsigned char qno, enum direction dir)
{
	struct md_mhccif_ctrl *md_ctrl =
		(struct md_mhccif_ctrl *)ccci_hif_get_by_id(md_id, hif_id);

	if (md_ctrl)
		return md_ctrl->ops->stop_queue(md_id, hif_id, qno, dir);
	else
		return -1;
}
#else
int ccci_mhccif_hif_init(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
int ccci_mhccif_hif_exit(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}

int ccci_mhccif_hif_late_init(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
void *ccci_mhccif_get_hw_info(unsigned char md_id,
	unsigned int hif_id, struct mtk_pci_dev *dev_ptr)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return NULL;
}
int ccci_mhccif_hif_start(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
int ccci_mhccif_hif_stop(unsigned char md_id, unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
int ccci_mhccif_exception(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
int ccci_mhccif_ex_handshake(unsigned char md_id,
	unsigned char hif_id, HIF_EX_STAGE stage)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}
void ccci_mhccif_reset(u8 md_id, unsigned char hif_id, char is_hw)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
}
unsigned long ccci_mhccif_get_int_id(unsigned char md_id,
	unsigned char hif_id)
{
	MTK_DEBUG_LOG("CLD_HIF", "please define CONFIG_MTK_ECCCI_MHCCIF\n");
	return -1;
}

#endif

#endif
