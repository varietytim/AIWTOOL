// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include "dpmaif_hif_platform.h"
#include "ccci_driver_dpmaif_reg.h"
#include "dpmaif_drv.h"
#include "ccci_debug.h"
#include "ccci_hif_dpmaif.h"
#include "ccci_driver_dpmaif.h"



#define		TAG			"DATA"

void drv_dpmaif_hw_init(void)
{
	unsigned int value;

	/* dpmaif HW reset */
	drv_dpmaif_hw_reset();

	/*Set DPMAIF AP port mode*/
	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);
	value &= ~(DPMAIF_PORT_MODE_MSK);
	value |= DPMAIF_PORT_MODE_PCIE;
	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);

	/*Set CG en*/
	DPMAIF_WRITE_PD_UL(NRL2_DPMAIF_AP_MISC_CG_EN, 0);
}

/*
 *	Function: drv_dpmaif_extra_config_for_pfm
 *	Description: new DPMAIF HW setting for 5G performance
 */
void drv_dpmaif_extra_config_for_pfm(void)
{
	unsigned int value;

	/* Config the data path over PCIE */
	dpmaif_drv_pcie_dpmaif_sign();

	/* Set PIT burst en */
	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);
	value |= DPMAIF_DL_BURST_PIT_EN;
	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);

	/* Set BAT cache */
	value = DPMAIF_ReadReg32(NRL2_DPMAIF_DL_BAT_INIT_CON1);
	value |= DPMAIF_DL_BAT_CACHE_PRI;
	DPMAIF_WriteReg32(NRL2_DPMAIF_DL_BAT_INIT_CON1, value);

	/*Set WDMA OSTD*/
	value = DPMAIF_ReadReg32(NRL2_DPMAIF_WDMA_WR_CHNL_CMD_CON3);
	value &= ~(DPMAIF_DL_WDMA_CTRL_OSTD_MSK <<
		DPMAIF_DL_WDMA_CTRL_OSTD_OFST);
	value |= (DPMAIF_DL_WDMA_CTRL_OSTD_VALUE <<
		DPMAIF_DL_WDMA_CTRL_OSTD_OFST);
	DPMAIF_WriteReg32(NRL2_DPMAIF_WDMA_WR_CHNL_CMD_CON3, value);

	/*Clear CTRL_INTVAL_AVG/CTRL_INTVAL_MIN*/
	value = DPMAIF_ReadReg32(NRL2_DPMAIF_WDMA_WR_CMD_CON0);
	value &= (0xFFFF0000);
	DPMAIF_WriteReg32(NRL2_DPMAIF_WDMA_WR_CMD_CON0, value);
}
DRV_BOOL drv_dpmaif_config_que_hw(hifdpmaif_property_t *p_property)
{
	unsigned int que_cnt;
	hifmaif_dl_st_t *p_dl_que;
	hifmaif_ul_st_t *p_ul_que;
	hifmaif_dl_hwq_t *p_dl_hw;

	drv_dpmaif_dl_set_pkt_checksum();

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_DLQ_NUM; que_cnt++) {
		p_dl_que = &p_property->dl_que[que_cnt];
		p_dl_hw = &p_property->dl_que_hw[que_cnt];

		if (p_dl_que->que_started == DRV_TRUE) {

			p_dl_hw->bat_remain_size = DPMAIF_HW_BAT_REMAIN;
			drv_dpmaif_dl_set_ao_remain_minsz(
				que_cnt, p_dl_hw->bat_remain_size);

			p_dl_hw->bat_pkt_bufsz = DPMAIF_HW_BAT_PKTBUF;
			drv_dpmaif_dl_set_ao_bat_bufsz(
				que_cnt, p_dl_hw->bat_pkt_bufsz);

			p_dl_hw->bat_rsv_length = DPMAIF_HW_BAT_RSVLEN;
			drv_dpmaif_dl_set_ao_bat_rsv_length(
				que_cnt, p_dl_hw->bat_rsv_length);

			p_dl_hw->pkt_bid_max_cnt = DPMAIF_HW_PKT_BIDCNT;
			drv_dpmaif_dl_set_ao_bid_maxcnt(
				que_cnt, p_dl_hw->pkt_bid_max_cnt);

			p_dl_hw->pkt_alignment = DPMAIF_HW_PKT_ALIGN;
			if (p_dl_hw->pkt_alignment == 64)
				drv_dpmaif_dl_set_pkt_alignment(que_cnt,
					DRV_TRUE, DPMAIF_PKT_ALIGN64_MODE);
			else if (p_dl_hw->pkt_alignment == 128)
				drv_dpmaif_dl_set_pkt_alignment(que_cnt,
					DRV_TRUE, DPMAIF_PKT_ALIGN128_MODE);
			else
				drv_dpmaif_dl_set_pkt_alignment(
					que_cnt, DRV_FALSE, 0);

			p_dl_hw->mtu_size = DPMAIF_HW_MTU_SIZE;
			drv_dpmaif_dl_set_ao_mtu(p_dl_hw->mtu_size);

			p_dl_hw->chk_pit_num = DPMAIF_HW_CHK_PIT_NUM;
			p_dl_hw->chk_bat_num = DPMAIF_HW_CHK_BAT_NUM;
			drv_dpmaif_dl_set_ao_pit_chknum(que_cnt,
				p_dl_hw->chk_pit_num);
			drv_dpmaif_dl_set_ao_bat_check_thres(que_cnt,
				p_dl_hw->chk_bat_num);

			drv_dpmaif_dl_set_bat_base_addr(que_cnt,
				(unsigned long)p_dl_que->bat_base);
			drv_dpmaif_dl_set_pit_base_addr(que_cnt,
				(unsigned long)p_dl_que->pit_base);
			drv_dpmaif_dl_set_bat_size(que_cnt,
				p_dl_que->bat_size_cnt);
			drv_dpmaif_dl_set_pit_size(que_cnt,
				p_dl_que->pit_size_cnt);

			/* extra setting for performance */
			drv_dpmaif_extra_config_for_pfm();

			/*Enable PIT/BAT*/
			drv_dpmaif_dl_pit_en(que_cnt, DRV_TRUE);
			drv_dpmaif_dl_bat_en(que_cnt, DRV_FALSE);

			/*notify HW init/setting done*/
			drv_dpmaif_dl_bat_init_done(que_cnt, DRV_FALSE);
			drv_dpmaif_dl_pit_init_done(que_cnt);

			drv_dpmaif_dl_all_queue_en(DRV_TRUE);
		}
	}

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM ; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];

		if (p_ul_que->que_started == DRV_TRUE) {
			drv_dpmaif_ul_update_drb_size(que_cnt,
				(p_ul_que->drb_size_cnt *
				DPMAIF_UL_DRB_ENTRY_WORD));

			drv_dpmaif_ul_update_drb_base_addr(que_cnt,
				(unsigned long)p_ul_que->drb_base);

			drv_dpmaif_ul_rdy_en(que_cnt, DRV_TRUE);

			drv_dpmaif_ul_arb_en(que_cnt, DRV_TRUE);
		} else {
			drv_dpmaif_ul_arb_en(que_cnt, DRV_FALSE);
		}
	}

	dpmaif_drv_ap_reorder_en();

	return DRV_TRUE;
}

DRV_BOOL drv_dpmaif_config_tx_que_hw(hifdpmaif_property_t *p_property)
{
	unsigned int que_cnt;
	hifmaif_ul_st_t *p_ul_que;

	for (que_cnt = 0; que_cnt < MAIFQ_MAX_ULQ_NUM; que_cnt++) {
		p_ul_que = &p_property->ul_que[que_cnt];

		if (p_ul_que->que_started == DRV_TRUE) {
			drv_dpmaif_ul_update_drb_size(que_cnt,
				(p_ul_que->drb_size_cnt *
				DPMAIF_UL_DRB_ENTRY_WORD));

			drv_dpmaif_ul_update_drb_base_addr(
				que_cnt, (unsigned long)p_ul_que->drb_base);

			drv_dpmaif_ul_rdy_en(que_cnt, DRV_TRUE);

			drv_dpmaif_ul_arb_en(que_cnt, DRV_TRUE);
		} else {
			drv_dpmaif_ul_arb_en(que_cnt, DRV_FALSE);
		}
	}
	return DRV_TRUE;
}


/***********************************************************************
 *	DPMAIF Common HW setting
 *
 ***********************************************************************/
unsigned int drv_dpmaif_ip_code_version(void)
{
	unsigned int ret = 0;

	/* ToDo */

	return ret;
}

/***********************************************************************
 *	DPMAIF UL/DL HW setting
 *
 ***********************************************************************/
void drv_dpmaif_dl_queue_en(unsigned char q_num, DRV_BOOL enable)
{
	int count = 0;
	unsigned int dl_bat_init = 0;

	dl_bat_init |= DPMAIF_DL_BAT_INIT_ONLY_ENABLE_BIT;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	if (enable == DRV_TRUE)
		drv_dpmaif_dl_bat_en(q_num, DRV_TRUE);
	else
		drv_dpmaif_dl_bat_en(q_num, DRV_FALSE);

	/*update DL bat setting to HW*/
	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dl_queue_en check1 fail\n", q_num);
			return;
		}
	}

	/*wait HW updating*/
	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) == DPMAIF_DL_BAT_INIT_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dl_queue_en check2 fail\n", q_num);
			return;
		}
	}

}

void drv_dpmaif_dl_all_queue_en(DRV_BOOL enable)
{
	int count = 0;
	unsigned int dl_bat_init = 0;
	unsigned int value;

	value = DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1);

	if (enable == DRV_TRUE)
		value |= DPMAIF_BAT_EN_MSK;
	else
		value &= ~DPMAIF_BAT_EN_MSK;

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1, value);

	dl_bat_init |= DPMAIF_DL_BAT_INIT_ONLY_ENABLE_BIT;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	/*update DL bat setting to HW*/
	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_dl_all_queue_en check fail\n");
			return;
		}
	}
	/*wait HW updating*/
	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) == DPMAIF_DL_BAT_INIT_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG, "dpmaif_dl_all_queue_en check fail\n");
			return;
		}
	}

}

unsigned int drv_dpmaif_dl_idle_check(void)
{
	unsigned int ret;

	ret = (DPMAIF_READ_PD_DL(DPMAIF_PD_DL_DBG_STA1) & DPMAIF_DL_IDLE_STS);

	/*if total queue idle, UL all idle*/
	if (ret == DPMAIF_DL_IDLE_STS)
		ret = 0; /*idle*/
	else
		ret = 1; /*not idle*/

	return ret;
}

void drv_dpmaif_ul_queue_en(unsigned char q_num, DRV_BOOL enable)
{
	drv_dpmaif_ul_arb_en(q_num, enable);
}

void drv_dpmaif_ul_all_queue_en(DRV_BOOL enable)
{
	unsigned int ul_arb_en;

	ul_arb_en = DPMAIF_READ_PD_UL(DPMAIF_PD_UL_CHNL_ARB0);

	if (enable == DRV_TRUE)
		ul_arb_en |= DPMAIF_UL_ALL_QUE_ARB_EN;
	else
		ul_arb_en &= ~DPMAIF_UL_ALL_QUE_ARB_EN;

	DPMAIF_WRITE_PD_UL(DPMAIF_PD_UL_CHNL_ARB0, ul_arb_en);
}

unsigned int drv_dpmaif_ul_idle_check(unsigned char q_num)
{
	unsigned int ret, ul_dbg_sta;

	ul_dbg_sta = DPMAIF_READ_PD_UL(DPMAIF_PD_UL_DBG_STA2);

	/*if total queue idle, UL all idle*/
	if ((ul_dbg_sta & DPMAIF_UL_IDLE_STS_MSK) == DPMAIF_UL_IDLE_STS) {
		ret = 1;
	} else {
		/*check per queue channel active?*/
		if ((ul_dbg_sta & DPMAIF_UL_CHNL_ACTIVE_MSK) ==
			DPMAIF_UL_CHNL_ACTIVE_n(q_num))
			ret = 0;
		else
			ret = 1;

	}
	return ret;
}

unsigned int drv_dpmaif_ul_all_idle_check(void)
{
	unsigned int ret, ul_dbg_sta;

	ul_dbg_sta = DPMAIF_READ_PD_UL(DPMAIF_PD_UL_DBG_STA2);

	/*if total queue idle, UL all idle*/
	if ((ul_dbg_sta & DPMAIF_UL_IDLE_STS_MSK) == DPMAIF_UL_IDLE_STS)
		ret = 0; //idle
	else
		ret = 1;

	return ret;
}

/***********************************************************************
 *	DPMAIF UL Part HW setting
 *
 ***********************************************************************/
int drv_dpmaif_ul_add_wcnt(unsigned char q_num, unsigned int drb_entry_cnt)
{
	unsigned int ul_update;
	unsigned int count = 0;

	ul_update = (drb_entry_cnt & 0x0000ffff);
	ul_update |= DPMAIF_UL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_UL(DPMAIF_ULQ_ADD_DESC_CH_n(q_num)) &
			DPMAIF_UL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_UL(
				DPMAIF_ULQ_ADD_DESC_CH_n(q_num), ul_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for UL add wcnt(%u) to queue%d failed!\n",
				drb_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_UL(DPMAIF_ULQ_ADD_DESC_CH_n(q_num)) &
		DPMAIF_UL_ADD_NOT_READY) == DPMAIF_UL_ADD_NOT_READY) {
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"UL add wcnt(%u) for queue%d failed!\n",
				drb_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	return 0;
}

unsigned int drv_dpmaif_ul_get_ridx(unsigned char q_num)
{
	unsigned int ridx;

	ridx = DPMAIF_UL_DRB_GET_RIDX(q_num);

	return ridx;
}


void drv_dpmaif_ul_restore(unsigned char q_num, unsigned int restore_ridx)
{
	int count = 0;
	unsigned int ul_restore;

	ul_restore = (((q_num >> 16)+(restore_ridx)) & 0x0003ffff);

	while (1) {
		if ((DPMAIF_READ_PD_UL(DPMAIF_PD_UL_RESTORE_RIDX) &
			DPMAIF_UL_RESTORE_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_UL(
				DPMAIF_PD_UL_RESTORE_RIDX, ul_restore);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"ulq%d: dpmaif_ul_restore check fail\n", q_num);
			return;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_UL(DPMAIF_PD_UL_RESTORE_RIDX) &
		DPMAIF_UL_ADD_NOT_READY) == DPMAIF_UL_RESTORE_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"ulq%d: dpmaif_ul_restore check fail\n", q_num);
			return;
		}
	}

}

void drv_dpmaif_ul_arb_en(unsigned char q_num, DRV_BOOL enable)
{
	unsigned int ul_arb_en;

	ul_arb_en = DPMAIF_READ_PD_UL(DPMAIF_PD_UL_CHNL_ARB0);

	if (enable == DRV_TRUE)
		ul_arb_en |= (1 << (q_num+8));
	else
		ul_arb_en &= ~(1 << (q_num+8));

	DPMAIF_WRITE_PD_UL(DPMAIF_PD_UL_CHNL_ARB0, ul_arb_en);

}

void drv_dpmaif_ul_rdy_en(unsigned char q_num, DRV_BOOL ready)
{
	unsigned int ul_rdy_en;

	ul_rdy_en = DPMAIF_READ_PD_UL(DPMAIF_PD_UL_CHNL_ARB0);

	if (ready == DRV_TRUE)
		ul_rdy_en |= (1 << q_num);
	else
		ul_rdy_en &= ~(1 << q_num);

	DPMAIF_WRITE_PD_UL(DPMAIF_PD_UL_CHNL_ARB0, ul_rdy_en);
}

unsigned int drv_dpmaif_ul_get_drb_size(unsigned int q_num)
{
	unsigned int size;

	size = DPMAIF_READ_PD_UL(DPMAIF_UL_DRBSIZE_ADDRH_n(q_num));

	size &= DPMAIF_DRB_SIZE_MSK;

	return size;
}

void drv_dpmaif_ul_update_drb_size(unsigned char q_num, unsigned int size)
{
	unsigned int old_size;

	old_size = DPMAIF_READ_PD_UL(DPMAIF_UL_DRBSIZE_ADDRH_n(q_num));

	old_size &= ~DPMAIF_DRB_SIZE_MSK;
	old_size |= (size & DPMAIF_DRB_SIZE_MSK);

	DPMAIF_WRITE_PD_UL(DPMAIF_UL_DRBSIZE_ADDRH_n(q_num), old_size);
}

void drv_dpmaif_ul_update_drb_base_addr(unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);

	DPMAIF_WRITE_PD_UL(DPMAIF_ULQSAR_n(q_num), lb_addr);

	DPMAIF_WRITE_PD_UL(DPMAIF_UL_DRB_ADDRH_n(q_num), hb_addr);

}


/***********************************************************************
 *	DPMAIF DL Part HW setting
 *
 ***********************************************************************/
void drv_dpmaif_dl_bat_init_done(unsigned char q_num, DRV_BOOL frg_en)
{
	int count = 0;
	unsigned int dl_bat_init = 0;

	if (frg_en == DRV_TRUE)
		dl_bat_init |= DPMAIF_DL_BAT_FRG_INIT;

	dl_bat_init |= DPMAIF_DL_BAT_INIT_ALLSET;
	dl_bat_init |= DPMAIF_DL_BAT_INIT_EN;

	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
			DPMAIF_DL_BAT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(
				DPMAIF_PD_DL_BAT_INIT, dl_bat_init);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_bat_init_done check fail\n",
				q_num);
			return;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT) &
		DPMAIF_DL_BAT_INIT_NOT_READY) ==
		DPMAIF_DL_BAT_INIT_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_bat_init_done check fail\n",
				q_num);
			return;
		}
	}
}


void drv_dpmaif_dl_pit_init_done(unsigned char q_num)
{
	int count = 0;
	unsigned int dl_pit_init = 0;

	dl_pit_init |= DPMAIF_DL_PIT_INIT_ALLSET;
	dl_pit_init |= DPMAIF_DL_PIT_INIT_EN;

	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_INIT) &
			DPMAIF_DL_PIT_INIT_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(
				DPMAIF_PD_DL_PIT_INIT, dl_pit_init);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_pit_init_done check fail\n",
				q_num);
			return;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_INIT) &
		DPMAIF_DL_PIT_INIT_NOT_READY) == DPMAIF_DL_PIT_INIT_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_pit_init_done check fail\n",
				q_num);
			return;
		}
	}

}


void drv_dpmaif_dl_set_bat_base_addr(unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON0, lb_addr);

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON3, hb_addr);

}

void drv_dpmaif_dl_set_bat_size(unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1);

	value &= ~(DPMAIF_BAT_SIZE_MSK);
	value |= (size & DPMAIF_BAT_SIZE_MSK);

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1, value);
}

void drv_dpmaif_dl_bat_en(unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1);

	if (enable == DRV_TRUE)
		value |= DPMAIF_BAT_EN_MSK;
	else
		value &= ~DPMAIF_BAT_EN_MSK;

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_BAT_INIT_CON1, value);

}

void drv_dpmaif_dl_set_pit_base_addr(unsigned char q_num, unsigned long addr)
{
	unsigned int lb_addr = (unsigned int)(addr & 0xFFFFFFFF);
	unsigned int hb_addr = (unsigned int)(addr >> 32);

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON0, lb_addr);
	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON4, hb_addr);

}

void drv_dpmaif_dl_set_pit_size(unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON1);

	value &= ~(DPMAIF_PIT_SIZE_MSK);
	value |= (size & DPMAIF_PIT_SIZE_MSK);

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON1, value);

}

void drv_dpmaif_dl_pit_en(unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON3);

	if (enable == DRV_TRUE)
		value |= DPMAIF_PIT_EN_MSK;
	else
		value &= ~DPMAIF_PIT_EN_MSK;

	DPMAIF_WRITE_PD_DL(DPMAIF_PD_DL_PIT_INIT_CON3, value);

}

void drv_dpmaif_dl_set_ao_bid_maxcnt(unsigned char q_num, unsigned int cnt)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PKTINFO_CONO);

	value &= ~(DPMAIF_BAT_BID_MAXCNT_MSK);
	value |= ((cnt << 16) & DPMAIF_BAT_BID_MAXCNT_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CONO, value);

}

void drv_dpmaif_dl_set_ao_remain_minsz(unsigned char q_num, unsigned int sz)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PKTINFO_CONO);

	value &= ~(DPMAIF_BAT_REMAIN_MINSZ_MSK);
	value |= (((sz/DPMAIF_BAT_REMAIN_SZ_BASE) << 8) &
		DPMAIF_BAT_REMAIN_MINSZ_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CONO, value);

}

void drv_dpmaif_dl_set_ao_mtu(unsigned int mtu_sz)
{
	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CON1, mtu_sz);
}


void drv_dpmaif_dl_set_ao_pit_chknum(unsigned char q_num, unsigned int number)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2);

	value &= ~(DPMAIF_PIT_CHK_NUM_MSK);
	value |= ((number << 24) & DPMAIF_PIT_CHK_NUM_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2, value);

}

void drv_dpmaif_dl_set_ao_bat_bufsz(unsigned char q_num, unsigned int buf_sz)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2);

	value &= ~(DPMAIF_BAT_BUF_SZ_MSK);
	value |= (((buf_sz/DPMAIF_BAT_BUFFER_SZ_BASE) << 8) &
		DPMAIF_BAT_BUF_SZ_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2, value);

}

void drv_dpmaif_dl_set_ao_bat_rsv_length(
	unsigned char q_num, unsigned int length)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2);

	value &= ~(DPMAIF_BAT_RSV_LEN_MSK);
	value |= (length & DPMAIF_BAT_RSV_LEN_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_PKTINFO_CON2, value);

}

void drv_dpmaif_dl_set_pkt_alignment(
	unsigned char q_num, DRV_BOOL enable, unsigned int mode)
{
	unsigned int value;

	if (mode >= 2)
		ASSERT(0);

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);

	value &= ~(DPMAIF_PKT_ALIGN_MSK);

	if (enable == DRV_TRUE) {

		value |= DPMAIF_PKT_ALIGN_EN;
		value |= ((mode << 22) & DPMAIF_PKT_ALIGN_MSK);
	}

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);

}

void drv_dpmaif_dl_set_pkt_checksum(void)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);

	value |= DPMAIF_DL_PKT_CHECKSUM_EN;

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

void drv_dpmaif_dl_set_ao_frg_check_thres(
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES);

	value &= ~(DPMAIF_FRG_CHECK_THRES_MSK);
	value |= (size & DPMAIF_FRG_CHECK_THRES_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES, value);

}

void drv_dpmaif_dl_set_ao_frg_bufsz(unsigned char q_num, unsigned int buf_sz)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES);

	value &= ~(DPMAIF_FRG_BUF_SZ_MSK);
	value |= (((buf_sz/DPMAIF_FRG_BUFFER_SZ_BASE) << 8) &
		DPMAIF_FRG_BUF_SZ_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES, value);

}

void drv_dpmaif_dl_frg_ao_en(unsigned char q_num, DRV_BOOL enable)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES);

	if (enable == DRV_TRUE)
		value |= DPMAIF_FRG_EN_MSK;
	else
		value &= ~DPMAIF_FRG_EN_MSK;

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_FRG_CHK_THRES, value);

}

void drv_dpmaif_dl_set_ao_bat_check_thres(
	unsigned char q_num, unsigned int size)
{
	unsigned int value;

	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);

	value &= ~(DPMAIF_BAT_CHECK_THRES_MSK);
	value |= ((size << 16) & DPMAIF_BAT_CHECK_THRES_MSK);

	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);

}

int drv_dpmaif_dl_add_pit_remain_cnt(
	unsigned char q_num, unsigned int pit_remain_cnt)
{
	unsigned int dl_update;
	unsigned int count = 0;

	dl_update = (pit_remain_cnt & 0x0000ffff);
	dl_update |= DPMAIF_DL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(
				DPMAIF_PD_DL_PIT_ADD, dl_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"polling ready for adding pit remain count(%u) to queue%d failed\n",
				pit_remain_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_PIT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) == DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"polling ready for adding pit remain count(%u) to queue%d failed\n",
				pit_remain_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	return 0;
}


unsigned int drv_dpmaif_dl_get_wridx(unsigned char q_num)
{
	unsigned int widx;

	widx = (DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PIT_STA2) &
		DPMAIF_DL_PIT_WRIDX_MSK);

	return widx;
}

unsigned int drv_dpmaif_dl_get_pit_ridx(unsigned char q_num)
{
	unsigned int ridx;

	ridx = ((DPMAIF_READ_AO_DL(DPMAIF_AO_DL_PIT_STA2)>>16) &
		DPMAIF_DL_PIT_WRIDX_MSK);

	return ridx;
}

int drv_dpmaif_dl_add_bat_cnt(unsigned char q_num, unsigned int bat_entry_cnt)
{
	unsigned int dl_bat_update;
	unsigned int count = 0;

	dl_bat_update = (bat_entry_cnt & 0xffff);
	dl_bat_update |= DPMAIF_DL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(
				DPMAIF_PD_DL_BAT_ADD, dl_bat_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for DL adding bat cnt(%u) to queue%d failed!\n",
				bat_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) == DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"poll ready for DL adding bat cnt(%u) to queue%d failed!\n",
				bat_entry_cnt, q_num);
			return HW_REG_CHK_FAIL;
		}
	}

	return 0;
}

unsigned int drv_dpmaif_dl_get_bat_ridx(unsigned char q_num)
{
	unsigned int ridx;

	ridx = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_BAT_STA2);
	ridx = ((ridx >> 16) & DPMAIF_DL_BAT_WRIDX_MSK);

	return ridx;
}

unsigned int drv_dpmaif_dl_get_bat_wridx(unsigned char q_num)
{
	unsigned int widx;

	widx = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_BAT_STA2);
	widx = ((widx >> 0) & DPMAIF_DL_BAT_WRIDX_MSK);

	return widx;
}

void drv_dpmaif_dl_add_frg_cnt(unsigned char q_num, unsigned int frg_entry_cnt)
{
	int count = 0;
	unsigned int dl_frg_update;

	dl_frg_update = (frg_entry_cnt & 0xffff);
	dl_frg_update |= DPMAIF_DL_FRG_ADD_UPDATE;
	dl_frg_update |= DPMAIF_DL_ADD_UPDATE;

	while (1) {
		if ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_ADD) &
			DPMAIF_DL_ADD_NOT_READY) == 0) {
			DPMAIF_WRITE_PD_DL(
				DPMAIF_PD_DL_BAT_ADD, dl_frg_update);
			break;
		}

		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_add_frg_cnt check fail\n",
				q_num);
			return;
		}
	}

	count = 0;
	while ((DPMAIF_READ_PD_DL(DPMAIF_PD_DL_BAT_ADD) &
		DPMAIF_DL_ADD_NOT_READY) == DPMAIF_DL_ADD_NOT_READY) {
		/* avoid cpu hang */
		if (++count >= DPMA_CHECK_RGE_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"dlq%d: dpmaif_dl_add_frg_cnt check fail\n",
				q_num);
			return;
		}
	}

}

unsigned int drv_dpmaif_dl_get_frg_ridx(unsigned char q_num)
{
	unsigned int ridx;

	ridx = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_FRG_STA2);
	ridx = ((ridx >> 16) & DPMAIF_DL_FRG_WRIDX_MSK);

	return ridx;
}

DRV_BOOL drv_dpmaif_check_power_down(void)
{
	DRV_BOOL ret;
	unsigned int check_value;

	check_value = DPMAIF_READ_PD_UL(DPMAIF_ULQSAR_n(0));

	if (check_value == 0)
		ret = DRV_TRUE;
	else
		ret = DRV_FALSE;

	return ret;
}

#define DPMAIF_REORDER_EN_MSK		   (0x1F << 8)
#define DP_RO_EN_4GN	(1 << 8)
#define DP_RO_EN_4GH	(1 << 9)
#define DP_RO_EN_5GU	(1 << 10)
#define DP_RO_EN_5GSW	(1 << 11)
#define DP_RO_EN_LFSW	(1 << 12)

#define DP_RO_EN_QUE_SET (DP_RO_EN_5GU|DP_RO_EN_5GSW)

void dpmaif_drv_ap_reorder_en(void)
{
	unsigned int value;

	/*Set HW queue channel for reorder*/
	value = DPMAIF_READ_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES);

	value &= ~(DPMAIF_REORDER_EN_MSK);
	value |= DP_RO_EN_QUE_SET;
	DPMAIF_WRITE_AO_DL(DPMAIF_AO_DL_RDY_CHK_THRES, value);
}

void dpmaif_drv_pcie_dpmaif_sign(void)
{
	DPMAIF_WRITE_PD_UL(NRL2_DPMAIF_UL_RESERVE_AO_RW,
		DPMAIF_PCIE_MODE_SET_VALUE);
}

void drv_dpmaif_tick_delay(unsigned int tick)
{
	unsigned int tmp;
	tmp = tick;
	if (tmp <= 0)
		return;

	while (1) {
		tmp = tmp - 1;
		if (tmp <= 0)
			return;
	}
}

void drv_dpmaif_hw_reset(void)
{
    DPMAIF_WRITE_PD_MISC(DPMAIF_AP_RGU_ASSERT, DPMAIF_AP_RST_BIT);
    drv_dpmaif_tick_delay(100);
    DPMAIF_WRITE_PD_MISC(DPMAIF_AP_RGU_DEASSERT, DPMAIF_AP_RST_BIT);
    drv_dpmaif_tick_delay(100);

    DPMAIF_WRITE_PD_MISC(DPMAIF_AP_AO_RGU_ASSERT, DPMAIF_AP_AO_RST_BIT);
    drv_dpmaif_tick_delay(100);
    DPMAIF_WRITE_PD_MISC(DPMAIF_AP_AO_RGU_DEASSERT, DPMAIF_AP_AO_RST_BIT);
    drv_dpmaif_tick_delay(100);
}


