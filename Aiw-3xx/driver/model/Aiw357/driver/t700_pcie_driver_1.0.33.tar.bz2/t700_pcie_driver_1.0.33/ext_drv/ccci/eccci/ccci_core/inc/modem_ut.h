/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MODEM_UT_H__
#define __MODEM_UT_H__

#include <linux/dmapool.h>

#define LOOP_BACK_UT // loop back, or gen Rx data
/*#ifdef LOOP_BACK
 * #ifdef CCCI_STATISTIC
 * #define STATISTIC // statistic data gathering for performance debug
 * #endif
 * //#define NO_RX_Q_LOCK // check comment in md_ut_rxq_process
 * #define NO_RX_Q_LOCK_IN_TX // check comment in md_ut_txq_process
 * #endif
 */

#define MD_UT_MAJOR 169
#define MAX_QUEUE_LENGTH 32
#define QUEUE_BUDGET 16
//seconds, don't make it too short when not using Rx queue lock
#define RX_TIMER_INTVAL 1
/*enum HIF_EX_STAGE {
 *	HIF_EX_INIT = 0, // interrupt
 *	HIF_EX_ACK, // AP->MD
 *	HIF_EX_INIT_DONE, // polling
 *	HIF_EX_CLEARQ_DONE, //interrupt
 *	HIF_EX_CLEARQ_ACK, // AP->MD
 *	HIF_EX_ALLQ_RESET, // polling
 *};
 */

/*CCIF UT related defines*/
#define CCIF_CCCI_TEST_HEADER   0x43434946 //"CCIF"
#define CCIF_TEST_RINGBUF_SIZE  (4 * 1024)
#define CCIF_RX_TX_BUFFER_SIZE  1800 //1500~CCIF_TEST_RINGBUF_SIZE/2
#define CCIF_TEST_QUEUE_NUM     1
#define CCIF_CASE_NOT_SUPPORT   0x4E4F5350 //"NOSP"
//#define CCIF_PRINT_RINGBUF



typedef int (*ut_testcase_fn_ptr)(void *param, void *test_case);
struct ccif_test_case_struct {
	ut_testcase_fn_ptr _main_fn;
	unsigned int         flags;
	void               *para;
	char           *description;
	char           *testplan_section;
};


void md_ut_rx_gen_func(unsigned long data);

void md_ut_sysfs_init(struct ccci_modem *md);

int md_ccif_MDsend(struct md_ccif_ctrl *md_ctrl, int channel_id);

void ccci_dump_req(struct sk_buff *skb);

#if defined(ENABLE_CCIF_UT)
extern int ccif_ut_test_result;
#endif


/*struct md_ut_queue {
 *	enum direction dir;
 *	unsigned char index;
 *	struct ccci_modem *modem;
 *
 *	struct list_head req_list;
 *	spinlock_t req_lock;
 *	int budget;
 *	int length;
 *	wait_queue_head_t req_wq;
 *	// now only for Tx, Rx won't wait, just drop
 *	int length_th;
 * #ifdef STATISTIC
 *	unsigned int process_count; // write or dispatch operation
 *	unsigned int not_complet_count; // have to wait due to list full
 *	unsigned int data_count; // packet size accumulation
 * #endif
 * };

 * struct md_ut_ctrl{
 *	struct md_ut_queue txq[3];
 *	struct md_ut_queue rxq[3];
 *	wait_queue_head_t sched_thread_wq;
 *	unsigned char sched_thread_kick;
 *	atomic_t reset_on_going;
 *	struct wake_lock trm_wake_lock;
 *
 *	struct task_struct *sched_thread;
 *	struct timer_list rx_gen_timer;
 * #ifdef STATISTIC
 *	struct timer_list statistic_timer;
 * #endif
 * };
 *
 * #define QUEUE_LEN(a) (sizeof(a)/sizeof(struct md_ut_queue))
 *
 * static void inline md_ut_queue_struct_init(struct md_ut_queue *queue,
 *	struct ccci_modem *md, enum direction dir,
 *	unsigned char index, int th, int bg)
 * {
 *	queue->dir = OUT;
 *	queue->index = index;
 *	queue->modem = md;
 *

 *	INIT_LIST_HEAD(&queue->req_list);
 *	init_waitqueue_head(&queue->req_wq);
 *	spin_lock_init(&queue->req_lock);
 *	queue->length_th = th;
 *	queue->budget = bg;
 *	queue->length = 0;
 * #ifdef STATISTIC
 *	queue->process_count = 0;
 *	queue->not_complet_count = 0;
 * #endif
 * }
 */
#endif //__MODEM_UT_H__
