// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


/*****************************************************************************
 *
 * Filename:
 * ---------
 *	 ccmni.c
 *
 * Project:
 * --------
 *
 *
 ****************************************************************************/
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/ipv6.h>
#include <net/ipv6.h>
#include <net/sch_generic.h>
#include <linux/skbuff.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/version.h>
#include <linux/sockios.h>
#include <linux/device.h>
#include <linux/debugfs.h>
#include <linux/preempt.h>
#include <linux/stacktrace.h>

#include "ccmni_m80.h"
#include "ccci_util_log.h"
#include "ccci_hif_dpmaif_m80.h"


#ifdef PORT_NET_TRACE
#include "port_net_events.h"
#endif

#define TAG "DATA"

#define __CORRECT_CCMNI__

unsigned int nic_interface_num = NIC_DEV_DEFAULT;
unsigned int nic_napi_poll_budget = NIC_NAPI_POLL_BUDGET;
bool nic_napi_enable = true;

__weak const struct header_ops eth_header_ops;

static unsigned char g_ul_skb_prio_queue_mapping[CCMNI_UL_PRIONUM] = {
		HIF_TXQ0, HIF_H_PRIO_QUEUE, HIF_TXQ0, HIF_TXQ0,
		HIF_TXQ0, HIF_TXQ0, HIF_TXQ0, HIF_TXQ0,
		HIF_TXQ0, HIF_TXQ0, HIF_TXQ0, HIF_TXQ0,
		HIF_TXQ0, HIF_TXQ0, HIF_TXQ0, HIF_TXQ0};

/********************internal function*********************/
static void ccmni_enable_napi(struct ccmni_ctl_block *ctlb)
{
	int i = 0;

	if (atomic_cmpxchg(&ctlb->napi_enable, 0, 1) == 0) {
		for (i = 0; i < RXQ_NUM; i++) {
			napi_enable(ctlb->napi[i]);
			napi_schedule(ctlb->napi[i]);
			MTK_DEBUG_LOG(TAG, "enable NAPI %d, 0x%lx\n", i, ctlb->napi[i]->state);
		}
	}
}

static void ccmni_disable_napi(struct ccmni_ctl_block *ctlb)
{
	int i = 0;

	if (atomic_cmpxchg(&ctlb->napi_enable, 1, 0) == 1) {
		for (i = 0; i < RXQ_NUM; i++) {
			napi_synchronize(ctlb->napi[i]);
			napi_disable(ctlb->napi[i]);
			MTK_DEBUG_LOG(TAG, "disable NAPI %d, 0x%lx\n", i, ctlb->napi[i]->state);
		}
	}
}


static void ccmni_make_etherframe(int md_id, struct net_device *dev,
	void *_eth_hdr, unsigned char *mac_addr, unsigned int packet_type)
{
	struct ethhdr *eth_hdr = _eth_hdr;

	memcpy(eth_hdr->h_dest, mac_addr, sizeof(eth_hdr->h_dest));
	memset(eth_hdr->h_source, 0, sizeof(eth_hdr->h_source));

	if (packet_type == 0x60)
		eth_hdr->h_proto = cpu_to_be16(ETH_P_IPV6);
	else
		eth_hdr->h_proto = cpu_to_be16(ETH_P_IP);
}

static inline int is_ack_skb(int md_id, struct sk_buff *skb)
{
	u32 packet_type;
	struct tcphdr *tcph;
	int ret = 0;

	packet_type = skb->data[0] & 0xF0;
	if (packet_type == IPV6_VERSION) {
		struct ipv6hdr *iph = (struct ipv6hdr *)skb->data;
		u32 total_len =
			sizeof(struct ipv6hdr) + ntohs(iph->payload_len);
		u8 nexthdr = iph->nexthdr;
		__be16 frag_off;
		u32 l4_off = ipv6_skip_exthdr(skb,
			sizeof(struct ipv6hdr), &nexthdr, &frag_off);

		tcph = (struct tcphdr *)(skb->data + l4_off);
		if (nexthdr == IPPROTO_TCP && !tcph->syn && !tcph->fin &&
			!tcph->rst
			&& ((total_len - l4_off) == (tcph->doff << 2)))
			ret = 1;
	} else if (packet_type == IPV4_VERSION) {
		struct iphdr *iph = (struct iphdr *)skb->data;

		tcph = (struct tcphdr *)(skb->data + (iph->ihl << 2));
		if (iph->protocol == IPPROTO_TCP && !tcph->syn && !tcph->fin &&
			!tcph->rst && (ntohs(iph->tot_len) ==
			(iph->ihl << 2) + (tcph->doff << 2)))
			ret = 1;
	}

	return ret;
}

static int ccmni_get_skb_prio_queue(
	struct ccmni_ctl_block *ctlb, struct sk_buff *skb)
{
	int txq = 0;
	unsigned int prio = 0;

	prio = CCMNI_GET_SKB_PRIO(skb->mark);
	
	/*available priority: 0, 1, 2, .... 15 */
	txq = ctlb->prio_mapping[prio];

	return txq;
}

/********************netdev register function********************/
#if defined(CONFIG_XS_MOD) && defined(__arm64__)
static u16 ccmni_select_queue(struct net_device *dev, struct sk_buff *skb,
		        struct net_device *sb_dev,select_queue_fallback_t fallback)

{
	        u16 queue_id = CCMNI_TXQ_NORMAL;
		        struct ccmni_instance *ccmni =
				                (struct ccmni_instance *)netdev_priv(dev);
			        struct ccmni_ctl_block *ctlb = ccmni->ctlb;

				        if (ctlb->capability & NIC_CAP_DATA_ACK_DVD) {
						                if (is_ack_skb(ccmni->md_id, skb))
									                        queue_id = CCMNI_TXQ_FAST;
								        }

					        return queue_id;
}

#elif (LINUX_VERSION_CODE < KERNEL_VERSION(0x4,0x13,0)) 
static u16 ccmni_select_queue(struct net_device *dev, struct sk_buff *skb,
	void *accel_priv, select_queue_fallback_t fallback)

{
	u16 queue_id = CCMNI_TXQ_NORMAL;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;


	if (ctlb->capability & NIC_CAP_DATA_ACK_DVD) {
		if (is_ack_skb(ccmni->md_id, skb))
			queue_id = CCMNI_TXQ_FAST;
	}

	return queue_id;
}
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(0x5,0x1,0x15))
static u16 ccmni_select_queue(struct net_device *dev, struct sk_buff *skb,
	struct net_device *sb_dev)

{
	u16 queue_id = CCMNI_TXQ_NORMAL;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;

	if (ctlb->capability & NIC_CAP_DATA_ACK_DVD) {
		if (is_ack_skb(ccmni->md_id, skb))
			queue_id = CCMNI_TXQ_FAST;
	}

	return queue_id;
}
#endif
static int ccmni_open(struct net_device *dev)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ccmni_ctl = ccmni->ctlb;
	struct ccmni_instance *ccmni_tmp = NULL;
	int usage_cnt = 0;

	if (unlikely(ccmni_ctl == NULL)) {
		MTK_ERR_LOG(TAG, "%s_Open: MD%d ctlb is NULL\n",
			dev->name, ccmni->md_id);
		return -1;
	}

	netif_carrier_on(dev);
	netif_tx_start_all_queues(dev);

	if (ccmni_ctl->capability & NIC_CAP_NAPI) {
		MTK_INFO_LOG(TAG, "enable NAPI, napi_usr_refcnt:%d\n", 
			atomic_read(&ccmni_ctl->napi_usr_refcnt));
		if (!atomic_read(&ccmni_ctl->napi_usr_refcnt)) {
			ccmni_enable_napi(ccmni_ctl);
			atomic_set(&ccmni_ctl->napi_usr_refcnt, 1);
		} else {
			atomic_inc(&ccmni_ctl->napi_usr_refcnt);
		}
	}

	atomic_inc(&ccmni->usage);
	ccmni_tmp = ccmni_ctl->ccmni_inst[ccmni->index];
	if (ccmni != ccmni_tmp) {
		usage_cnt = atomic_read(&ccmni->usage);
		atomic_set(&ccmni_tmp->usage, usage_cnt);
	}

	MTK_DEBUG_LOG(TAG, "%s_Open: cnt=(%d,%d), nic_capability=0x%X\n",
		dev->name, atomic_read(&ccmni->usage),
		atomic_read(&ccmni_tmp->usage),
		ccmni_ctl->capability);
	return 0;
}

static int ccmni_close(struct net_device *dev)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ccmni_ctl = ccmni->ctlb;
	struct ccmni_instance *ccmni_tmp = NULL;
	int usage_cnt = 0;

	if (unlikely(ccmni_ctl == NULL)) {
		MTK_ERR_LOG(TAG, "%s_Close: MD%d ctlb is NULL\n",
			dev->name, ccmni->md_id);
		return -1;
	}

	MTK_DEBUG_LOG(TAG,
		"ccmni%d usage is %d\n", ccmni->index,
		atomic_read(&ccmni->usage));
	if (atomic_read(&ccmni->usage) <= 0) {
		/* this means this ccmni device has been closed */
		MTK_INFO_LOG(TAG,
			"ccmni%d has already been closed!\n", ccmni->index);
		return 0;
	}

	if (ccmni_ctl->capability & NIC_CAP_NAPI) {
		MTK_INFO_LOG(TAG, "disable NAPI, napi_usr_refcnt:%d\n", 
			atomic_read(&ccmni_ctl->napi_usr_refcnt));
		if (atomic_dec_and_test(&ccmni_ctl->napi_usr_refcnt)) {
			ccmni_disable_napi(ccmni_ctl);
		}
	}

	atomic_dec(&ccmni->usage);
	ccmni_tmp = ccmni_ctl->ccmni_inst[ccmni->index];
	if (ccmni != ccmni_tmp) {
		usage_cnt = atomic_read(&ccmni->usage);
		atomic_set(&ccmni_tmp->usage, usage_cnt);
	}

	netif_carrier_off(dev);
	netif_tx_disable(dev);

	MTK_DEBUG_LOG(TAG, "%s_Close: cnt=(%d,%d)\n",
		dev->name, atomic_read(&ccmni->usage),
		atomic_read(&ccmni_tmp->usage));

	return 0;
}

static int ccmni_send_packet(int md_id, struct ccmni_instance *ccmni, void *data, int is_ack)
{
	struct ccci_header *ccci_h;
	struct sk_buff *skb = (struct sk_buff *)data;
	int ret = -1;
	unsigned char tx_qno = 0;
	struct iphdr *iph = NULL;
	unsigned int ccmni_idx = ccmni->index;
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;

#ifdef PORT_NET_TRACE
	unsigned long long send_time = 0;
	unsigned long long get_port_time = 0;
	unsigned long long total_time = 0;

	total_time = sched_clock();
#endif

#ifdef PORT_NET_TRACE
	get_port_time = sched_clock();
#endif

#ifdef PORT_NET_TRACE
	get_port_time = sched_clock() - get_port_time;
#endif

	iph = (struct iphdr *)(skb->data);
	ccci_h = (struct ccci_header *)skb_push(skb,
		sizeof(struct ccci_header));
	ccci_h = (struct ccci_header *)skb->data;
	ccci_h->channel = 0;
	ccci_h->data[0] = ccmni_idx;
	/* as skb->len already included ccci_header after skb_push */
	ccci_h->data[1] = skb->len;
	ccci_h->reserved = 0;

	MTK_DEBUG_LOG(TAG, "ccmni%d send: %08X, %08X, %08X, %08X\n", ccmni_idx,
			 ccci_h->data[0], ccci_h->data[1], 0, ccci_h->reserved);

#ifdef PORT_NET_TRACE
	send_time = sched_clock();
#endif

	/* select the HIF TXQ */
	if (is_ack) {
		tx_qno =  HIF_ACK_QUEUE;
	} else if (ccmni->prio_en) {
		tx_qno = ccmni_get_skb_prio_queue(ctlb, skb);
	} else {
		tx_qno = HIF_NORMAL_QUEUE;
	}

	MTK_DEBUG_LOG(TAG,
		"[TX]CCMNI%d, prio_en[%d], mark[0x%x], protocol[%d], txq[%d]\n",
		ccmni_idx, ccmni->prio_en,
		skb->mark, iph->protocol, tx_qno);

	ret = dpmaif_tx_send_skb(md_id, ctlb->hif_ctrl, tx_qno, skb, 0);

#ifdef PORT_NET_TRACE
	send_time = sched_clock() - send_time;
#endif

	if (ret) {
		skb_pull(skb, sizeof(struct ccci_header));
		/* undo header, in next retry, we'll reserve header again */
		ret = CCMNI_ERR_TX_BUSY;
	} else {
		ret = CCMNI_ERR_TX_OK;
	}
#ifdef PORT_NET_TRACE
	if (ret == CCMNI_ERR_TX_OK) {
		total_time = sched_clock() - total_time;
		trace_port_net_tx(md_id, -1, 0, (unsigned int)get_port_time,
			(unsigned int)send_time, (unsigned int)(total_time));
	}
#endif
	return ret;
}


static int ccmni_start_xmit(struct sk_buff *skb, struct net_device *dev)
{
	int ret;
	int skb_len = skb->len;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_ctl_block *ctlb = ccmni->ctlb;
	unsigned int is_ack = 0;

	dump_skb_info(skb, (const char *)__func__, (int)__LINE__);

	/* dev->mtu is changed	if dev->mtu is changed by upper layer */
	if (unlikely(skb->len > dev->mtu)) {
		MTK_ERR_LOG(TAG,
			"CCMNI%d write fail: len(0x%x)>MTU(0x%x, 0x%x)\n",
			ccmni->index, skb->len, CCMNI_MTU, dev->mtu);
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		return NETDEV_TX_OK;
	}

	if (unlikely(skb_headroom(skb) < sizeof(struct ccci_header))) {
		MTK_ERR_LOG(TAG,
			"CCMNI%d write fail: header room(%d) < ccci_header(%d)\n",
			ccmni->index, skb_headroom(skb), dev->hard_header_len);
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		return NETDEV_TX_OK;
	}

	if (ctlb->capability& NIC_CAP_DATA_ACK_DVD)
		is_ack = is_ack_skb(ccmni->md_id, skb);

	ret = ccmni_send_packet(ccmni->md_id, ccmni, skb, is_ack);

	if (ret == CCMNI_ERR_MD_NO_READY || ret == CCMNI_ERR_TX_INVAL) {
		dev_kfree_skb(skb);
		dev->stats.tx_dropped++;
		ccmni->tx_busy_cnt[is_ack] = 0;
		MTK_DEBUG_LOG(TAG,
			"[TX]CCMNI%d send tx_pkt=%ld(ack=%d) fail: %d\n",
			ccmni->index, (dev->stats.tx_packets + 1), is_ack, ret);
		return NETDEV_TX_OK;
	} else if (ret == CCMNI_ERR_TX_BUSY) {
		goto tx_busy;
	}
	dev->stats.tx_packets++;
	dev->stats.tx_bytes += skb_len;
	if (ccmni->tx_busy_cnt[is_ack] > 10) {
		MTK_NOTICE_LOG(TAG,
			"[TX]CCMNI%d TX busy: tx_pkt=%ld(ack=%d) retry %ld times done\n",
			ccmni->index, dev->stats.tx_packets,
			is_ack, ccmni->tx_busy_cnt[is_ack]);
	}
	ccmni->tx_busy_cnt[is_ack] = 0;

	return NETDEV_TX_OK;

tx_busy:
	if (unlikely(!(ctlb->capability & NIC_CAP_TXBUSY_STOP))) {
		if ((ccmni->tx_busy_cnt[is_ack]++) % 100 == 0)
			MTK_NOTICE_LOG(TAG,
				"[TX]CCMNI%d TX busy: tx_pkt=%ld(ack=%d) retry_times=%ld\n",
				ccmni->index, dev->stats.tx_packets,
				is_ack, ccmni->tx_busy_cnt[is_ack]);
	} else {
		ccmni->tx_busy_cnt[is_ack]++;
	}

	return NETDEV_TX_BUSY;
}

static int ccmni_change_mtu(struct net_device *dev, int new_mtu)
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);

	if (new_mtu > CCMNI_MTU_MAX)
		return -EINVAL;

	dev->mtu = new_mtu;
	MTK_DEBUG_LOG(TAG,
		"CCMNI%d change mtu_siz=%d\n", ccmni->index, new_mtu);
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
static void ccmni_tx_timeout(struct net_device *dev, unsigned int txqueue)
#else
static void ccmni_tx_timeout(struct net_device *dev)
#endif
{
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);

	MTK_DEBUG_LOG(TAG, "ccmni%d_tx_timeout: usage_cnt=%d, timeout=%ds\n",
		ccmni->index, atomic_read(&ccmni->usage),
		(ccmni->dev->watchdog_timeo/HZ));

	dev->stats.tx_errors++;
	if (atomic_read(&ccmni->usage) > 0)
		netif_tx_wake_all_queues(dev);
}

static int ccmni_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
	int	 usage_cnt;
	struct ccmni_instance *ccmni =
		(struct ccmni_instance *)netdev_priv(dev);
	struct ccmni_instance *ccmni_tmp = NULL;
	struct ccmni_ctl_block *ctlb = NULL;
	unsigned int timeout = 0;

	switch (cmd) {
	case SIOCSTXQSTATE:
		/* ifru_ivalue[3~0]:start/stop; ifru_ivalue[7~4]:reserve; */
		/* ifru_ivalue[15~8]:user id, bit8=rild, bit9=thermal */
		/* ifru_ivalue[31~16]: watchdog timeout value */
		ctlb = ccmni->ctlb;
		if ((ifr->ifr_ifru.ifru_ivalue & 0xF) == 0) {
			/*ignore txq stop/resume if dev is not running */
			if (atomic_read(&ccmni->usage) > 0
				&& netif_running(dev)) {
				atomic_dec(&ccmni->usage);

				netif_tx_disable(dev);
				/* stop queue won't stop Tx watchdog
				 * (ndo_tx_timeout)
				 */
				timeout = (ifr->ifr_ifru.ifru_ivalue &
					0xFFFF0000) >> 16;
				if (timeout == 0)
					dev->watchdog_timeo = 60 * HZ;
				else
					dev->watchdog_timeo = timeout*HZ;

				ccmni_tmp = ctlb->ccmni_inst[ccmni->index];
				if (ccmni_tmp != ccmni) { /* iRAT ccmni */
					usage_cnt = atomic_read(&ccmni->usage);
					atomic_set(&ccmni_tmp->usage,
						usage_cnt);
				}
			}
		} else {
			if (atomic_read(&ccmni->usage) <= 0
				&& netif_running(dev)) {
				netif_tx_wake_all_queues(dev);
				dev->watchdog_timeo = CCMNI_NETDEV_WDT_TO;
				atomic_inc(&ccmni->usage);

				ccmni_tmp = ctlb->ccmni_inst[ccmni->index];
				if (ccmni_tmp != ccmni) { /* iRAT ccmni */
					usage_cnt = atomic_read(&ccmni->usage);
					atomic_set(&ccmni_tmp->usage,
						usage_cnt);
				}
			}
		}
		if (likely(ccmni_tmp != NULL)) {
			MTK_INFO_LOG(TAG,
				"SIOCSTXQSTATE: %s_state=0x%x, cnt=(%d, %d)\n",
				dev->name, ifr->ifr_ifru.ifru_ivalue,
				atomic_read(&ccmni->usage),
				atomic_read(&ccmni_tmp->usage));
		} else {
			MTK_INFO_LOG(TAG,
				"SIOCSTXQSTATE: %s_state=0x%x, cnt=%d\n",
				dev->name, ifr->ifr_ifru.ifru_ivalue,
				atomic_read(&ccmni->usage));
		}
		break;

	case SIOCTXQPRIO:
		if ((ifr->ifr_ifru.ifru_ivalue) == 0)
			ccmni->prio_en = 0;
		else
			ccmni->prio_en = 1;

		MTK_INFO_LOG(TAG,
			"%s: SIOCTXQPRIO: ifru_ivalue=%d, prio_en=%d\n",
			dev->name, ifr->ifr_ifru.ifru_ivalue, ccmni->prio_en);
		break;

	default:
		MTK_ERR_LOG(TAG, "%s: unknown ioctl cmd=%x\n", dev->name, cmd);
		break;
	}

	return 0;
}

static const struct net_device_ops ccmni_netdev_ops = {
	.ndo_open		= ccmni_open,
	.ndo_stop		= ccmni_close,
	.ndo_start_xmit = ccmni_start_xmit,
	.ndo_tx_timeout = ccmni_tx_timeout,
	.ndo_do_ioctl	= ccmni_ioctl,
	.ndo_change_mtu = ccmni_change_mtu,
	.ndo_select_queue = ccmni_select_queue,
};


/***********ccmni driver register	ccci function***********/
static inline int ccmni_inst_init(int md_id,
	struct ccmni_instance *ccmni, struct net_device *dev)
{
	int ret = 0;
	int i = 0;
	ccmni->dev = dev;
	ccmni->md_id = md_id;
	ccmni->spinlock = kzalloc(sizeof(spinlock_t), GFP_KERNEL);
	if (ccmni->spinlock == NULL) {
		MTK_ERR_LOG(TAG, "Alloc spinlock fail\n");
		ret = -ENOMEM;
		goto err;
	}

	atomic_set(&ccmni->usage, 0);
	spin_lock_init(ccmni->spinlock);

	/* ul priority config, default disable*/
	ccmni->prio_en = 0;

	for (i = 0; i < 2; i++) {
		ccmni->tx_seq_num[i] = 0;
		ccmni->tx_full_cnt[i] = 0;
		ccmni->tx_irq_cnt[i] = 0;
		ccmni->tx_full_tick[i] = 0;
		ccmni->flags[i] &= ~CCMNI_TX_PRINT_F;
	}
	ccmni->rx_seq_num = 0;
	ccmni->rx_gro_cnt = 0;

	return 0;

err:
	return ret;
}

static void ccmni_inst_rel(struct ccmni_instance *ccmni)
{
	if (unlikely(ccmni == NULL))
		goto end;

	kfree(ccmni->spinlock);
	ccmni->spinlock = NULL;

end:
	return;
}

static void ccmni_start(struct ccmni_ctl_block *ctlb)
{
	unsigned char i = 0;
	struct ccmni_instance *ccmni = NULL;

	if (!ctlb) {
		MTK_INFO_LOG(TAG, "ctlb is null err.\n");
		return;
	}

	/* carry on the net link */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif		
		ccmni = ctlb->ccmni_inst[i];
		if (unlikely(ccmni == NULL)) {
			MTK_ERR_LOG(TAG, "ccmni%d is null\n", i);
			continue;
		}

		if (atomic_read(&ccmni->usage) > 0) {
			netif_tx_start_all_queues(ccmni->dev);
			netif_carrier_on(ccmni->dev);
		}
	}

	/* enable the NAPI */
	if ((ctlb->capability & NIC_CAP_NAPI) && 
		atomic_read(&ctlb->napi_usr_refcnt)) {
		ccmni_enable_napi(ctlb);
	}

}

static void ccmni_pre_stop(struct ccmni_ctl_block *ctlb)
{
	unsigned char i = 0;
	struct ccmni_instance *ccmni = NULL;

	if (!ctlb) {
		MTK_INFO_LOG(TAG, "ctlb is null err.\n");
		return;
	}

	/* stop tx */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		ccmni = ctlb->ccmni_inst[i];
		if (unlikely(ccmni == NULL)) {
			MTK_ERR_LOG(TAG, "ccmni%d is null\n", i);
			continue;
		}
		if (atomic_read(&ccmni->usage) > 0) {
			netif_tx_disable(ccmni->dev);
		}
	}
}

static void ccmni_pos_stop(struct ccmni_ctl_block *ctlb)
{
	unsigned char i = 0;
	struct ccmni_instance *ccmni = NULL;

	if (!ctlb) {
		MTK_INFO_LOG(TAG, "ctlb is null err.\n");
		return;
	}

	/* disable the NAPI */
	if ((ctlb->capability & NIC_CAP_NAPI) && 
		atomic_read(&ctlb->napi_usr_refcnt)) {
		ccmni_disable_napi(ctlb);
	}

	/* carry off the net link */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		ccmni = ctlb->ccmni_inst[i];
		if (unlikely(ccmni == NULL)) {
			MTK_ERR_LOG(TAG, "ccmni%d is null\n", i);
			continue;
		}

		if (atomic_read(&ccmni->usage) > 0) {
			netif_carrier_off(ccmni->dev);
		}
	}
}

static inline void ccmni_dev_init(int md_id,
	struct ccmni_ctl_block *ctlb, struct net_device *dev)
{
	dev->header_ops = NULL;
	dev->mtu = CCMNI_MTU;
	dev->max_mtu = CCMNI_MTU_MAX;
	dev->tx_queue_len = CCMNI_TX_QUEUE;
	dev->watchdog_timeo = CCMNI_NETDEV_WDT_TO;
	/* ccmni is a pure IP device */
	dev->flags = IFF_NOARP &
			(~IFF_BROADCAST & ~IFF_MULTICAST);

	/* not support VLAN */
	dev->features = NETIF_F_VLAN_CHALLENGED;

	if (ctlb->capability & NIC_CAP_SGIO) {
		dev->features |= NETIF_F_SG;
		dev->hw_features |= NETIF_F_SG;
	}

	/* uplink checksum offload */
	dev->features |= NETIF_F_HW_CSUM;
	dev->hw_features |= NETIF_F_HW_CSUM;

	/* downlink checksum offload */
	dev->features |= NETIF_F_RXCSUM;
	dev->hw_features |= NETIF_F_RXCSUM;


	if (ctlb->capability & NIC_CAP_NAPI) {
		dev->features |= NETIF_F_GRO;
		dev->hw_features |= NETIF_F_GRO;
	} else {
		dev->hard_header_len += sizeof(struct ccci_header);
	}
	dev->addr_len = ETH_ALEN;

	/* use kernel default free_netdev function */
	dev->needs_free_netdev = true;

	/* don't need to free again, because last step has called free_netdev */
	dev->priv_destructor = NULL;

	dev->netdev_ops = &ccmni_netdev_ops;
	random_ether_addr((u8 *) dev->dev_addr);
}

static int init_dummy_netdev_napi(int md_id, struct ccmni_ctl_block *ctlb)
{
	int ret = 0, i = 0, j = 0;

	/* one HW but mulit net device share,
	 * so we need ad dummy device for NAPI to work.
	 */
	init_dummy_netdev(&ctlb->dummy_dev);

	atomic_set(&ctlb->napi_usr_refcnt, 0);
	atomic_set(&ctlb->napi_enable, 0);
	/*ctlb->napi_poll_weigh = NAPI_POLL_WEIGHT;*/
    ctlb->napi_poll_weigh = nic_napi_poll_budget;   /* enlarge default budget to 128 */
	ctlb->napi_poll = dpmaif_napi_rx_poll;

	/* init all HW NAPI */
	for (i = 0; i < RXQ_NUM; i++) {
		ctlb->napi[i] = dpmaif_get_napi(ctlb->hif_ctrl, i);
		if (ctlb->napi[i] != NULL) {
			netif_napi_add(&ctlb->dummy_dev, ctlb->napi[i],
				ctlb->napi_poll,
				ctlb->napi_poll_weigh);
		} else {
			ret = -1;
			MTK_ERR_LOG(TAG,
				"dpmaif_get_napi faild: napi[%d]\n", i);
			goto add_napi_fail;
		}
	}

	return 0;

add_napi_fail:
	for (j = i - 1; j >= 0; j--) {
		netif_napi_del(ctlb->napi[j]);
	}
	return ret;
}

static void uninit_dummy_netdev_napi(int md_id, struct ccmni_ctl_block *ctlb)
{
	int i = 0;

	/* release the napi*/
	if ((ctlb->capability & NIC_CAP_NAPI)) {
		for (i = 0; i < RXQ_NUM; i++) {
			if(ctlb->napi[i] == NULL)
				continue;
			netif_napi_del(ctlb->napi[i]);
			ctlb->napi[i] = NULL;
		}
	}
}

void dump_skb_info(struct sk_buff *skb, const char *func, int line)
{
    struct skb_shared_info *info = NULL;

    if (unlikely(func == NULL)) {
        MTK_ERR_LOG(TAG, "func is NULL\n");
        return;
    }
    
    if (unlikely(skb == NULL)) {
        MTK_ERR_LOG(TAG, "skb is NULL\n");
        return;
    }

    info = skb_shinfo(skb);
    if (unlikely(info == NULL)) {
        MTK_ERR_LOG(TAG, "skb_shinfo is NULL\n");
        return;
    }

    MTK_DEBUG_LOG(TAG, "%s,%d: s%llx,h%llx,d%llx),t%llx,e%llx,l%u,d%u\n",
				func, line, (u64)skb, (u64)skb->head, (u64)skb->data, (u64)skb->tail, (u64)skb->end, (u32)skb->len, (u32)skb->data_len);

	MTK_DEBUG_LOG(TAG, "s%d,p%x,d%llx,i%llx,f%llx,n%u)\n", 
                skb->ip_summed, skb->protocol, (u64)skb->dev, (u64)info, (u64)info->frag_list, (u32)info->nr_frags);
}


static void ccmni_dump(struct ccmni_ctl_block *ctlb)
{
	int ccmni_idx = 0;
	struct ccmni_instance *ccmni = NULL;
	struct ccmni_instance *ccmni_tmp = NULL;
	struct net_device *dev = NULL;
	struct netdev_queue *dev_queue = NULL;
	struct netdev_queue *ack_queue = NULL;
	struct Qdisc *qdisc;
	struct Qdisc *ack_qdisc;

	if (ctlb == NULL)
		return;

	for (ccmni_idx = 0; ccmni_idx < ctlb->nic_dev_num; ccmni_idx++) {
		ccmni_tmp = ctlb->ccmni_inst[ccmni_idx];
		if (unlikely(ccmni_tmp == NULL))
			return;

		if ((ccmni_tmp->dev->stats.rx_packets == 0) &&
			(ccmni_tmp->dev->stats.tx_packets == 0))
			return;

		dev = ccmni_tmp->dev;
		/* ccmni diff from ccmni_tmp for MD IRAT */
		ccmni = (struct ccmni_instance *)netdev_priv(dev);
		dev_queue = netdev_get_tx_queue(dev, 0);
		if (ctlb->capability & NIC_CAP_CCMNI_MQ) {
			ack_queue = netdev_get_tx_queue(dev, CCMNI_TXQ_FAST);
			qdisc = dev_queue->qdisc;
			ack_qdisc = ack_queue->qdisc;
			/* stats.rx_dropped is dropped in ccmni, dev->rx_dropped is
			 * dropped in net device layer stats.tx_packets is count by
			 * ccmni, bstats.packets is count by qdisc in net device layer
			 */
			MTK_INFO_LOG(TAG,
				"%s(%d,%d), irat_MD%d, rx=(%ld,%ld,%d), tx=(%ld,%lld,%lld)\n",
				dev->name, atomic_read(&ccmni->usage),
				atomic_read(&ccmni_tmp->usage), (ccmni->md_id + 1),
				dev->stats.rx_packets, dev->stats.rx_bytes,
				ccmni->rx_gro_cnt, dev->stats.tx_packets,
				qdisc->bstats.packets, ack_qdisc->bstats.packets);
			MTK_INFO_LOG(TAG,
				"txq_len=(%d,%d), tx_drop=(%ld,%d,%d), rx_drop=(%ld,%ld)\n",
				qdisc->q.qlen, ack_qdisc->q.qlen,
				dev->stats.tx_dropped, qdisc->qstats.drops,
				ack_qdisc->qstats.drops, dev->stats.rx_dropped,
				atomic_long_read(&dev->rx_dropped));
			MTK_INFO_LOG(TAG,
				"tx_busy=(%ld,%ld), sta=(0x%lx,0x%x,0x%lx,0x%lx)\n",
				ccmni->tx_busy_cnt[0], ccmni->tx_busy_cnt[1],
				dev->state, dev->flags, dev_queue->state,
				ack_queue->state);
		} else {
			MTK_INFO_LOG(TAG,
				"%s(%d,%d), irat_MD%d, rx=(%ld,%ld,%d), tx=(%ld,%ld)\n",
				dev->name, atomic_read(&ccmni->usage),
				atomic_read(&ccmni_tmp->usage), (ccmni->md_id + 1),
				dev->stats.rx_packets, dev->stats.rx_bytes,
				ccmni->rx_gro_cnt, dev->stats.tx_packets,
				dev->stats.tx_bytes);
			MTK_INFO_LOG(TAG,
				"txq_len=%d, tx_drop=(%ld,%d), rx_drop=(%ld,%ld)\n",
				dev->qdisc->q.qlen, dev->stats.tx_dropped,
				dev->qdisc->qstats.drops, dev->stats.rx_dropped,
				atomic_long_read(&dev->rx_dropped));
			MTK_INFO_LOG(TAG, "tx_busy=(%ld,%ld), sta=(0x%lx,0x%x,0x%lx)\n",
				ccmni->tx_busy_cnt[0], ccmni->tx_busy_cnt[1],
				dev->state, dev->flags, dev_queue->state);
		}
	}
}

#ifdef MODEM_MANAGER_SUPPORT
static int ccmni_netdev_create(struct ccmni_ctl_block *ctlb)
{
	int i = 0, j = 0, ret = 0;
	struct ccmni_instance *ccmni = NULL;
	struct net_device *dev = NULL;

	if (!ctlb) {
		MTK_ERR_LOG(TAG, "ctlb null!\n");
		return -1;
	}

	MTK_INFO_LOG(TAG, "ccmni_netdev_create--nic_num: %d\n", ctlb->nic_dev_num);

	/* init all net devices */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		/* allocate netdev */
		if (ctlb->capability & NIC_CAP_CCMNI_MQ) {
			/* alloc multiple tx queue, 2 txq and 1 rxq */
			dev = alloc_etherdev_mqs(
				sizeof(struct ccmni_instance), CCMNI_TXQ_NUM, 1);
		} else {
			dev = alloc_etherdev(sizeof(struct ccmni_instance));
		}

		if (unlikely(dev == NULL)) {
			MTK_ERR_LOG(TAG, "Alloc netdev fail\n");
			ret = -ENOMEM;
			goto alloc_netdev_fail;
		}

		/* init net device */
		ccmni_dev_init(ctlb->md_id, ctlb, dev);
		dev->type = ARPHRD_PPP;

		strcpy(dev->name, "ccmni%d");

		/* init private structure of netdev */
		ccmni = netdev_priv(dev);
		ccmni->index = i;
		ccmni->ctlb = ctlb;
		ret = ccmni_inst_init(ctlb->md_id, ccmni, dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "Initial ccmni instance fail\n");
			goto alloc_netdev_fail;
		}
		ctlb->ccmni_inst[i] = ccmni;

		/* register net device */
		ret = register_netdev(dev);
		if (ret)
			goto alloc_netdev_fail;
	}

	return 0;

alloc_netdev_fail:
	if (dev) {
		free_netdev(dev);
		dev = NULL;
		ctlb->ccmni_inst[i] = NULL;
	}

	for (j = i - 1; j >= 0; j--) {
		ccmni = ctlb->ccmni_inst[j];
		unregister_netdev(ccmni->dev);
		/* free_netdev(ccmni->dev); */
		ctlb->ccmni_inst[j] = NULL;
	}

	return ret;
}


static void ccmni_netdev_destroy(struct ccmni_ctl_block *ctlb)
{
	int i = 0;
	struct ccmni_instance *ccmni = NULL;

	MTK_INFO_LOG(TAG, "ccmni_netdev_destroy\r\n");

	/* close and release all NIC devices */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		ccmni = ctlb->ccmni_inst[i];
		if (ccmni) {
			if (ccmni->dev) {
				MTK_INFO_LOG(TAG, "ccmni_netdev_destroy--Unregister %s dev\n",
					ccmni->dev->name);
				ccmni_close(ccmni->dev);
				ccmni_inst_rel(ccmni);
				unregister_netdev(ccmni->dev);
				/*free_netdev(ccmni->dev);*/
				/* no need free again */
			}
			ctlb->ccmni_inst[i] = NULL;
		}
	}

	ctlb->nic_dev_created = false;
}
#endif


static int ccmni_md_state_callback(enum MD_STATE state, void *para)
{
	int ret = 0;
	struct ccmni_ctl_block *ctlb = (struct ccmni_ctl_block *)para;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid input para, md_sta=%d\n",
			state);
		ret = -1;
		goto err;
	}

	ctlb->md_sta = state;

	switch (state) {
	case BOOT_WAITING_FOR_HS1:
		/* hif layer*/
		ret = dpmaif_md_state_callback(
			ctlb->md_id, ctlb->hif_ctrl, state);
		if (ret < 0)
			MTK_ERR_LOG(TAG,
				"dpmaif md state callback err, md_sta=%d\n", state);
#ifndef MODEM_MANAGER_SUPPORT
		ccmni_start(ctlb);
#endif
		break;

#ifdef MODEM_MANAGER_SUPPORT
	case READY:
		/* only create and register netdev once */
		if (ctlb->nic_dev_created == false) {
			ret = ccmni_netdev_create(ctlb);
			if (unlikely(ret < 0))
				MTK_ERR_LOG(TAG, "failed to create ccmni netdev:%d\n", ret);
			else {
				MTK_INFO_LOG(TAG, "Create ccmni netdev successfully\n");
				ctlb->nic_dev_created = true;
			}
		}

		if (ctlb->nic_dev_created == true)
			ccmni_start(ctlb);

		break;
#endif

	case EXCEPTION:
		ccmni_dump(ctlb);
		ccmni_pre_stop(ctlb);
		ret = dpmaif_md_state_callback(ctlb->md_id, ctlb->hif_ctrl, state);
		if (ret < 0)
			MTK_ERR_LOG(TAG,"dpmaif md state callback err, md_sta=%d\n", state);
		ccmni_pos_stop(ctlb);
		break;
	case STOPPED:
		ccmni_pre_stop(ctlb);
		/* hif layer*/
		ret = dpmaif_md_state_callback(
			ctlb->md_id, ctlb->hif_ctrl, state);
		if (ret < 0)
			MTK_ERR_LOG(TAG,
				"dpmaif md state callback err, md_sta=%d\n", state);
		ccmni_pos_stop(ctlb);
	#ifdef MODEM_MANAGER_SUPPORT
		ccmni_netdev_destroy(ctlb);
	#endif
		break;

	case WAITING_TO_STOP:
		/* hif layer*/
		ret = dpmaif_md_state_callback(
			ctlb->md_id, ctlb->hif_ctrl, state);
		if (ret < 0)
			MTK_ERR_LOG(TAG,
				"dpmaif md state callback err, md_sta=%d\n", state);
		break;

	default:
		break;
	}
	
err:
	return ret;
}


static int init_md_status_notifier(struct ccmni_ctl_block *ctlb)
{
	int ret = 0;
	struct fsm_notifier_block *md_status_notifier = &ctlb->md_status_notify;

	INIT_LIST_HEAD(&md_status_notifier->entry);
	md_status_notifier->notifier_fn = ccmni_md_state_callback;
	md_status_notifier->data = ctlb;

	ret = fsm_notifier_register(ctlb->md_id, md_status_notifier);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "ccmni fsm_notifier_register fail\n");

	return ret;
}

static int uninit_md_status_notifier(struct ccmni_ctl_block *ctlb)
{
	int ret = 0;

	ret = fsm_notifier_unregister(ctlb->md_id, &ctlb->md_status_notify);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "ccmni fsm_notifier_unregister fail\n");

	return ret;
}

int ccmni_get_nic_cap(struct ccmni_ctl_block *ctlb)
{
	if (!ctlb){
		MTK_ERR_LOG(TAG, "ctlb NULL err\n");
		return -EINVAL;
	}

	return ctlb->capability;
}

#ifdef MODEM_MANAGER_SUPPORT
int ccmni_init(int md_id, struct mtk_pci_dev *mtk_dev)
{
	int ret = 0;
	struct ccmni_ctl_block *ctlb = NULL;

	MTK_INFO_LOG(TAG, "ccmni init start, mtk_dev:0x%llx\n", (u64)mtk_dev);

	/* Alloc the ccmni_ctl_block */
	ctlb = kzalloc(sizeof(struct ccmni_ctl_block), GFP_KERNEL);
	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc ccmni_ctl_block struct fail\n");
		return -ENOMEM;
	}

	mtk_dev->ccmni_ctlb = ctlb;
	ctlb->md_id = md_id;
	ctlb->mtk_dev = mtk_dev;
	ctlb->capability = NIC_CAP_TXBUSY_STOP | NIC_CAP_SGIO |
		NIC_CAP_DATA_ACK_DVD | NIC_CAP_CCMNI_MQ;
	ctlb->nic_dev_created = false;

	if (nic_napi_enable)
		ctlb->capability |= NIC_CAP_NAPI;

	/* init the ul skb priority and txq mapping  */
	ctlb->prio_mapping = g_ul_skb_prio_queue_mapping;

	/* Alloc/Init the dpmaif hif */
	ret = dpmaif_hif_init(md_id, ctlb);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "init dpmaif hif fail\n");
		goto alloc_mem_fail;
	}

	/* check NIC devices number */
	ctlb->nic_dev_num = nic_interface_num;
	if (ctlb->nic_dev_num > NIC_DEV_MAX) {
		MTK_ERR_LOG(TAG, "The NIC devices number err, please check(MAX = 20).\n");
		ret = -1;
		goto alloc_mem_fail;
	}

	if (ctlb->capability & NIC_CAP_NAPI) {
		/* init dummy netdev and napi */
		init_dummy_netdev_napi(md_id, ctlb);
		if (ret < 0) {
			MTK_ERR_LOG(TAG, "initial dummy netdev and napi fail\n");
			goto alloc_mem_fail;
		}
	}

	/* init the md status notifier */
	ret = init_md_status_notifier(ctlb);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "initial fsm notifier fail\n");
		goto alloc_mem_fail;
	}

	MTK_INFO_LOG(TAG, "ccmni init success, ccmni_ctl_block:0x%llx\n", (u64)ctlb);
	return 0;

alloc_mem_fail:
	kfree(ctlb);
	ctlb = NULL;

	return ret;
}
#else
int ccmni_init(int md_id, struct mtk_pci_dev *mtk_dev)
{
	int i = 0, j = 0, ret = 0;
	struct ccmni_ctl_block *ctlb = NULL;
	struct ccmni_instance *ccmni = NULL;
	struct net_device *dev = NULL;

	MTK_INFO_LOG(TAG, "ccmni init start, mtk_dev:0x%llx\n", (u64)mtk_dev);

	/* Alloc the ccmni_ctl_block */
	ctlb = kzalloc(sizeof(struct ccmni_ctl_block), GFP_KERNEL);
	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "Alloc ccmni_ctl_block struct fail\n");
		return -ENOMEM;
	}

	mtk_dev->ccmni_ctlb = ctlb;
	ctlb->md_id = md_id;
	ctlb->mtk_dev = mtk_dev;
	ctlb->capability = NIC_CAP_TXBUSY_STOP | NIC_CAP_SGIO |
		NIC_CAP_DATA_ACK_DVD | NIC_CAP_CCMNI_MQ;

	if (nic_napi_enable)
		ctlb->capability |= NIC_CAP_NAPI;

	/* init the ul skb priority and txq mapping  */
	ctlb->prio_mapping = g_ul_skb_prio_queue_mapping;

	/* Alloc/Init the dpmaif hif */
	ret = dpmaif_hif_init(md_id, ctlb);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "init dpmaif hif fail\n");
		goto alloc_mem_fail;
	}

	/* check NIC devices number */
	ctlb->nic_dev_num = nic_interface_num;
	if (ctlb->nic_dev_num > NIC_DEV_MAX) {
		MTK_ERR_LOG(TAG, "The NIC devices number err, please check(MAX = 20).\n");
		ret = -1;
		goto alloc_mem_fail;
	}

	MTK_INFO_LOG(TAG, "ccmni_init--nic_num: %d\n", ctlb->nic_dev_num);

	/* init all net devices */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		/* allocate netdev */
		if (ctlb->capability & NIC_CAP_CCMNI_MQ) {
			/* alloc multiple tx queue, 2 txq and 1 rxq */
			dev = alloc_etherdev_mqs(
				sizeof(struct ccmni_instance), CCMNI_TXQ_NUM, 1);
		} else {
			dev = alloc_etherdev(sizeof(struct ccmni_instance));
		}

		if (unlikely(dev == NULL)) {
			MTK_ERR_LOG(TAG, "Alloc netdev fail\n");
			ret = -ENOMEM;
			goto alloc_netdev_fail;
		}

		/* init net device */
		ccmni_dev_init(md_id, ctlb, dev);
		dev->type = ARPHRD_PPP;

		strcpy(dev->name, "ccmni%d");

		/* init private structure of netdev */
		ccmni = netdev_priv(dev);
		ccmni->index = i;
		ccmni->ctlb = ctlb;
		ret = ccmni_inst_init(md_id, ccmni, dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "Initial ccmni instance fail\n");
			goto alloc_netdev_fail;
		}
		ctlb->ccmni_inst[i] = ccmni;

		/* register net device */
		ret = register_netdev(dev);
		if (ret)
			goto alloc_netdev_fail;
	}

	if (ctlb->capability & NIC_CAP_NAPI) {
		/* init dummy netdev and napi */
		init_dummy_netdev_napi(md_id, ctlb);
		if (ret < 0) {
			MTK_ERR_LOG(TAG, "initial dummy netdev and napi fail\n");
			goto alloc_netdev_fail;
		}
	}

	/* init the md status notifier */
	ret = init_md_status_notifier(ctlb);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "initial fsm notifier fail\n");
		goto alloc_netdev_fail;
	}

	MTK_INFO_LOG(TAG, "ccmni init success, ccmni_ctl_block:0x%llx\n", (u64)ctlb);
	return 0;

alloc_netdev_fail:
	if (dev) {
		free_netdev(dev);
		dev = NULL;
		ctlb->ccmni_inst[i] = NULL;
	}

	for (j = i - 1; j >= 0; j--) {
		ccmni = ctlb->ccmni_inst[j];
		unregister_netdev(ccmni->dev);
		/* free_netdev(ccmni->dev); */
		ctlb->ccmni_inst[j] = NULL;
	}

alloc_mem_fail:
	kfree(ctlb);
	ctlb = NULL;

	return ret;
}
#endif

void ccmni_exit(int md_id, struct mtk_pci_dev *mtk_dev)
{
	int i = 0;
	struct ccmni_ctl_block *ctlb = NULL;
	struct ccmni_instance *ccmni = NULL;

	MTK_INFO_LOG(TAG, "ccmni exit start\n");

	if (mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "The mtk_dev is NULL err\n");
		return;
	}

	ctlb = mtk_dev->ccmni_ctlb;
	if (ctlb == NULL) {
		MTK_ERR_LOG(TAG, "The mtk_dev ctlb is NULL err\n");
		return;
	}

	/* uninit fsm notifier */
	uninit_md_status_notifier(ctlb);

	/* close and release all NIC devices */
#ifdef __CORRECT_CCMNI__
	for (i = 0; i <= ctlb->nic_dev_num; i++) {
#else
	for (i = 0; i < ctlb->nic_dev_num; i++) {
#endif
		ccmni = ctlb->ccmni_inst[i];
		if (ccmni) {
			if (ccmni->dev) {
				MTK_INFO_LOG(TAG, "Unregister %s dev\n",
					ccmni->dev->name);
				ccmni_close(ccmni->dev);
				ccmni_inst_rel(ccmni);
				unregister_netdev(ccmni->dev);
				/*free_netdev(ccmni->dev);*/
				/* no need free again */
			}
			ctlb->ccmni_inst[i] = NULL;
		}
	}

	if (ctlb->capability & NIC_CAP_NAPI)
		uninit_dummy_netdev_napi(md_id, ctlb);

	/* hif dpamif exit */
	dpmaif_hif_exit(md_id, ctlb);

	kfree(ctlb);
	mtk_dev->ccmni_ctlb = NULL;

	MTK_INFO_LOG(TAG, "ccmni exit success\n");
}


#define IPV4_VERSION 0x40
#define IPV6_VERSION 0x60

static int is_skb_gro(struct sk_buff *skb)
{
	u32 packet_type;
	packet_type = skb->data[0] & 0xF0;
	if (packet_type == IPV4_VERSION &&
		ip_hdr(skb)->protocol == IPPROTO_TCP)
		return 1;
	else if (packet_type == IPV6_VERSION &&
		ipv6_hdr(skb)->nexthdr == IPPROTO_TCP)
		return 1;
	else
		return 0;
}

int ccmni_rx_callback(struct ccmni_ctl_block *ctlb,
	int ccmni_idx, struct sk_buff *skb, void *priv_data)
{
	/* struct ccci_header *ccci_h = (struct ccci_header*)skb->data; */
	struct ccmni_instance *ccmni = NULL;
	struct net_device *dev = NULL;
	int pkt_type, skb_len;
	unsigned int md_id = ctlb->md_id;

#if defined(CCCI_SKB_TRACE)
	struct iphdr *iph;
	unsigned long long *netif_rx_profile = ctlb->netif_rx_profile;
	unsigned long long netif_time;
#endif

#ifdef PORT_NET_TRACE
	unsigned long long rx_cb_time = 0;
	unsigned long long total_time = 0;
#endif

#ifdef PORT_NET_TRACE
	rx_cb_time = sched_clock();
#endif

	int is_gro = 0;
	struct napi_struct *napi = (struct napi_struct *)priv_data;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG,
			"Invalid CCMNI%d ctrl/ops struct\n", ccmni_idx);
		dev_kfree_skb(skb);
		DPMAIF_ASSERT_NODUMP();
		return -1;
	}

	ccmni = ctlb->ccmni_inst[ccmni_idx];
	if (ccmni == NULL) {
		MTK_INFO_LIMITED_LOG(TAG,
			"Invalid ccmni pointer,ccmni_idx:%d!\n", ccmni_idx);
		dev_kfree_skb(skb);
		return 0;
	}

	dev = ccmni->dev;

	pkt_type = skb->data[0] & 0xF0;
	ccmni_make_etherframe(md_id, dev,
		skb->data - ETH_HLEN, dev->dev_addr, pkt_type);
	skb_set_mac_header(skb, -ETH_HLEN);
	skb_reset_network_header(skb);
	skb->dev = dev;
	if (pkt_type == 0x60)
		skb->protocol  = htons(ETH_P_IPV6);
	else
		skb->protocol  = htons(ETH_P_IP);

	skb_len = skb->len;

#if defined(NETDEV_TRACE) && defined(NETDEV_DL_TRACE)
	skb->dbg_flag = 0x1;
#endif

#if defined(CCCI_SKB_TRACE)
	iph = (struct iphdr *)skb->data;
	ctlb->net_rx_delay[2] = iph->id;
	ctlb->net_rx_delay[0] = dev->stats.rx_bytes + skb_len;
	ctlb->net_rx_delay[1] = dev->stats.tx_bytes;
#endif

#if defined(CCCI_SKB_TRACE)
		netif_rx_profile[4] = sched_clock()
			- (unsigned long long)skb->tstamp;
		skb->tstamp = 0;
		netif_time = sched_clock();
#endif

	dump_skb_info(skb, (const char *)__func__, (int)__LINE__);
	
	is_gro = is_skb_gro(skb);
	if (likely(ctlb->capability & NIC_CAP_NAPI)) {
		if (is_gro && napi)
			napi_gro_receive(napi, skb);
		else if (napi)
			netif_receive_skb(skb);
        else
            netif_rx_ni(skb);
	} else {
		if (!in_interrupt())
			netif_rx_ni(skb);
		else
			netif_rx(skb);
	}
	dev->stats.rx_packets++;
	dev->stats.rx_bytes += skb_len;

#ifdef CCCI_SKB_TRACE
	netif_rx_profile[3] = sched_clock() - netif_time;
#endif

#ifdef PORT_NET_TRACE
	rx_cb_time = sched_clock() - rx_cb_time;
	total_time = sched_clock() - total_time;
	trace_port_net_rx(md_id, 0xff, ccmni_idx,
		(unsigned int)rx_cb_time, (unsigned int)total_time);
#endif


	return 0;
}

void ccmni_queue_state_notify(struct ccmni_ctl_block *ctlb,
	enum HIF_STATE state, int qno)
{
	int ccmni_idx = 0;
	struct ccmni_instance *ccmni = NULL;
	struct ccmni_instance *ccmni_tmp = NULL;
	struct net_device *dev = NULL;
	struct netdev_queue *net_queue = NULL;
	int is_ack = 0;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid ccmni ctrl when hif_sta=%d\n", state);
		return;
	}

	if (unlikely(ctlb->md_sta != READY)) {
		MTK_DEBUG_LOG(TAG, "md state is %d, don't notify NIC txq\n", ctlb->md_sta);
		return;
	}

	/* check ack packet: HIF_ACK_QUEUE <->  CCMNI_TXQ_FAST*/
	if (qno == HIF_ACK_QUEUE)
		is_ack = 1;

	/* notify all nic */
	for (ccmni_idx = 0; ccmni_idx < ctlb->nic_dev_num; ccmni_idx++) {
		ccmni_tmp = ctlb->ccmni_inst[ccmni_idx];
		if (unlikely(ccmni_tmp == NULL)) {
			MTK_ERR_LOG(TAG, "ccmni%d is null\n", ccmni_idx);
			continue;
		}


		dev = ccmni_tmp->dev;
		ccmni = (struct ccmni_instance *)netdev_priv(dev);

		switch (state) {
		case TX_IRQ:
			if (netif_running(ccmni->dev) &&
				atomic_read(&ccmni->usage) > 0) {
				if (likely(ctlb->capability & NIC_CAP_CCMNI_MQ)) {
					if (is_ack)
						net_queue = netdev_get_tx_queue(
							ccmni->dev, CCMNI_TXQ_FAST);
					else
						net_queue = netdev_get_tx_queue(
							ccmni->dev, CCMNI_TXQ_NORMAL);
					if (netif_tx_queue_stopped(net_queue))
						netif_tx_wake_queue(net_queue);
				} else {
					is_ack = 0;
					if (netif_queue_stopped(ccmni->dev))
						netif_wake_queue(ccmni->dev);
				}
				ccmni->tx_irq_cnt[is_ack]++;
				if ((ccmni->flags[is_ack] & CCMNI_TX_PRINT_F) ||
					time_after(jiffies,
					ccmni->tx_irq_tick[is_ack] + 2)) {
					ccmni->flags[is_ack] &= ~CCMNI_TX_PRINT_F;
					MTK_DEBUG_LOG(TAG,
						"%s(%d), idx=%d, md_sta=TX_IRQ, ack=%d, cnt(%u, %u), time=%lu\n",
						ccmni->dev->name,
						atomic_read(&ccmni->usage),
						ccmni->index, is_ack,
						ccmni->tx_full_cnt[is_ack],
						ccmni->tx_irq_cnt[is_ack],
						(jiffies - ccmni->tx_irq_tick[is_ack]));
				}
			}
			break;

		case TX_FULL:
			MTK_INFO_LOG(TAG, "TX FULL!\n");
			if (atomic_read(&ccmni->usage) > 0) {
				if (ctlb->capability & NIC_CAP_CCMNI_MQ) {
					if (is_ack)
						net_queue = netdev_get_tx_queue(
							ccmni->dev, CCMNI_TXQ_FAST);
					else
						net_queue = netdev_get_tx_queue(
						ccmni->dev, CCMNI_TXQ_NORMAL);
					netif_tx_stop_queue(net_queue);
				} else {
					is_ack = 0;
					netif_stop_queue(ccmni->dev);
				}
				MTK_INFO_LOG(TAG, "netif_tx_stop_queue: txq(%d)\n", is_ack);
				ccmni->tx_full_cnt[is_ack]++;
				ccmni->tx_irq_tick[is_ack] = jiffies;
				if (time_after(jiffies,
					ccmni->tx_full_tick[is_ack] + 4)) {
					ccmni->tx_full_tick[is_ack] = jiffies;
					ccmni->flags[is_ack] |= CCMNI_TX_PRINT_F;
					MTK_DEBUG_LOG(TAG,
						"%s(%d), idx=%d, hif_sta=TX_FULL, ack=%d, cnt(%u, %u)\n",
						ccmni->dev->name,
						atomic_read(&ccmni->usage),
						ccmni->index, is_ack,
						ccmni->tx_full_cnt[is_ack],
						ccmni->tx_irq_cnt[is_ack]);
				}
			}
			break;
		default:
			break;
		}
	}
}

module_param(nic_interface_num, uint, 0644);
MODULE_PARM_DESC(nic_interface_num, "The value is used to NIC interface enumeration, default 21\n");
module_param(nic_napi_enable, bool, 0644);
MODULE_PARM_DESC(nic_napi_enable, "The value is used to enable the NIC NAPI feature, default enable\n");

module_param(nic_napi_poll_budget, uint, 0644);
MODULE_PARM_DESC(nic_napi_poll_budget, "The value is the polling budget of NIC's NAPI, default 128\n");

