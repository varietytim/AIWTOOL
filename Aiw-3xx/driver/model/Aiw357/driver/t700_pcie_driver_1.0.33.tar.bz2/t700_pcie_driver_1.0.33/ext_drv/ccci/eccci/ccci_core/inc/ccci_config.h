/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */


#ifndef __ECCCI_INTERNAL_OPTION__
#define __ECCCI_INTERNAL_OPTION__

/* buffer management customization */
#define CCCI_MTU_64KB		(64512) //63kB
#define CCCI_MTU            (3568) //3.5kB -16
#define CCCI_NET_MTU        (1500)
// tx gpd list(16), rx gpd list(16), rx skb list(16)
//tx going skb(1), rx going skb(1)
#define SKB_POOL_SIZE_64K    (50)
#define SKB_POOL_SIZE_4K    (256)
#define SKB_POOL_SIZE_1_5K  (256)
#define SKB_POOL_SIZE_16    (64)
#define BM_POOL_SIZE (SKB_POOL_SIZE_4K+SKB_POOL_SIZE_1_5K+SKB_POOL_SIZE_16)
/*reload pool if pool size dropped below 1/RELOAD_TH */
#define RELOAD_TH           (3)

/* EE dump cunstomization */
#define CCCI_SMEM_SIZE_RUNTIME_AP (0x800) /* AP runtime data size */
#define CCCI_SMEM_SIZE_RUNTIME_MD (0x800) /* MD runtime data size */

/* ccci logic channel enable & disable flag  */
#define CCCI_CHAN_ENABLE (1)
#define CCCI_CHAN_DISABLE (0)

/*port name*/
#define DEVICE_POST_DUMP_PORT_NAME		("ttyDUMP")
#define DEVICE_MINIDUMP_NOTIFY_PORT_NAME	("minidump_notify")

#endif
