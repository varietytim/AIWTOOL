/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CCCI_TTY_H__
#define __CCCI_TTY_H__

#include <linux/device.h>
#include <linux/serial.h>
#include <linux/tty.h>
#include <linux/module.h>
#include <mt-plat/mtk_ccci_common.h>
#include "ccci_config.h"
#include "port_tty.h"
#include "port_proxy.h"



/*should be the same as ccci_config.h*/

struct tty_ccci_ops {
	int                tty_num;
	unsigned char      name[16];
	unsigned int       md_ability;
	int (*send_pkt)(int md_id, int tty_idx, const void *data, int len);
};

struct tty_ctl_block {
	struct tty_driver *driver;
	struct tty_ccci_ops   *ccci_ops;
	unsigned int       md_sta;
};

struct tty_dev_ops {
	/*tty port information*/
	bool tty_driver_status;
	atomic_t port_installed_num;
	/* must-have */
	int  (*init)(int md_id, struct tty_ccci_ops *ccci_info, struct port_t *port);
	int (*tty_port_create)(int md_id, int minor, char *port_name);
	int (*tty_port_destroy)(int md_id, int minor);
	int  (*rx_callback)(int md_id, int tty_idx, void *data, int len);
	void (*md_state_callback)(int md_id, int tty_idx, enum MD_STATE state);
	void (*queue_state_callback)(int md_id, int tty_idx,
		enum HIF_STATE state);
	void (*exit)(int md_id);
	void (*dump)(int md_id, int tty_idx, unsigned int flag);
	void (*dump_rx_status)(int md_id, unsigned long long *status);
};
#endif
