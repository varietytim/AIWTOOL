// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/kobject.h>
#include <linux/atomic.h>

#include "ccci_config.h"
#include "ccci_platform.h"
#include "ccci_core.h"
#include "ccci_bm.h"
#include "modem_sys.h"
#include "ccci_hif.h"

#include "modem_sys_1.h"
#include "ccci_util_lib_main.h"

#include <mt-plat/mtk_ccci_common.h>
#include <mt-plat/mtk_boot_common.h>
#include <asm/cacheflush.h>




#define TAG "md"

struct ccci_modem *modem_sys[MAX_MD_NUM];

static struct ccci_smem_region *get_smem_by_user_id(
	struct ccci_smem_region *regions, enum SMEM_USER_ID user_id)
{
	int i;

	for (i = 0; ; i++) {
		if (!regions || regions[i].id == SMEM_USER_MAX)
			return NULL;

		if (regions[i].id == user_id)
			return regions + i;
	}
	return NULL;
}


void ccci_md_reset(struct ccci_modem *md)
{
	if (!md) {
		MTK_ERR_LOG(TAG,
			"Invalid arguments\n");
		return;
	}

	md->per_md_data.config.setting |= MD_SETTING_FIRST_BOOT;
	md->per_md_data.is_in_ee_dump = 0;
	md->is_force_asserted = 0;
	md->per_md_data.md_dbg_dump_flag = MD_DBG_DUMP_AP_REG;
	md->md_init_finish = 0;
}


/* setup function is only for data structure initialization */
struct ccci_modem *ccci_md_alloc(int private_size)
{
	struct ccci_modem *md = kzalloc(sizeof(struct ccci_modem), GFP_KERNEL);

	if (!md) {
		MTK_ERR_LOG(TAG,
			"fail to allocate memory for modem structure\n");
		goto out;
	}
	if (private_size > 0)
		md->private_data = kzalloc(private_size, GFP_KERNEL);
	else
		md->private_data = NULL;
	md->per_md_data.config.setting |= MD_SETTING_FIRST_BOOT;
	md->per_md_data.is_in_ee_dump = 0;
	md->is_force_asserted = 0;
	md->per_md_data.md_dbg_dump_flag = MD_DBG_DUMP_AP_REG;
	md->md_init_finish = 0;
	md->mem_layout.ccci_rt_smem_base = NULL;
 out:
	return md;
}


int ccci_md_register_reset(struct ccci_modem *md)
{
	int ret = 0;
	
	modem_sys[md->index] = md;
	ccci_fsm_reset(md->index);
	return ret;

}

int ccci_md_register(struct ccci_modem *md)
{
	int ret = 0;
	if (md->ops->init)	
		md->ops->init(md);
	modem_sys[md->index] = md;
	ccci_sysfs_add_md(md->index, (void *)&md->kobj);
	ccci_fsm_init(md->index);
	return ret;
}

int ccci_md_unregister(struct ccci_modem *modem)
{
	MTK_INFO_LOG(TAG, "ccci port exit.\n");
	ccci_port_uninit(modem->index);
	MTK_INFO_LOG(TAG, "ccci fsm exit.\n");
	ccci_fsm_uninit(modem->index);
	MTK_INFO_LOG(TAG, "ccci sysfs exit.\n");
	ccci_sysfs_remove_md(modem->index, (void *)&modem->kobj);
	if (modem->ops->uninit)
		modem->ops->uninit(modem);
	return 0;
}

struct ccci_mem_layout *ccci_md_get_mem(int md_id)
{
	if (md_id >= MAX_MD_NUM)
		return NULL;
	return &modem_sys[md_id]->mem_layout;
}
struct ccci_smem_region *ccci_md_get_smem_by_user_id(
	int md_id, enum SMEM_USER_ID user_id)
{
	struct ccci_smem_region *curr = NULL;

	if (md_id >= MAX_MD_NUM)
		return NULL;
	if (&modem_sys[md_id]->mem_layout)
		curr = get_smem_by_user_id(
			modem_sys[md_id]->mem_layout.md_bank4_noncacheable,
			user_id);
	return curr;
}

int ccci_md_pre_stop(unsigned char md_id, unsigned int stop_type)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;

	if (md && md->ops->pre_stop) {
		ret =  md->ops->pre_stop(md, stop_type);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;
}

int ccci_md_stop(unsigned char md_id, unsigned int stop_type)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;


	if (md && md->ops->stop) {
		ret = md->ops->stop(md, stop_type);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;
}

int ccci_md_start(unsigned char md_id)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;

	if (md && md->ops->start) {
		ret = md->ops->start(md);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;
}

int ccci_md_soft_stop(unsigned char md_id, unsigned int sim_mode)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;

	if (md && md->ops->soft_stop) {
		ret = md->ops->soft_stop(md, sim_mode);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;

}

int ccci_md_soft_start(unsigned char md_id, unsigned int sim_mode)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;

	if (md && md->ops->soft_start) {
		ret = md->ops->soft_start(md, sim_mode);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;
}

int ccci_md_send_runtime_data(unsigned char md_id)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);
	int ret = 0;

	if (md && md->ops->send_runtime_data) {
		ret = md->ops->send_runtime_data(md);
	} else {
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
		ret = -1;
	}
	return ret;
}

void ccci_md_dump_info(unsigned char md_id,
	enum modem_dump_flag flag, void *buff, int length)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);

	if (md && md->ops->dump_info)
		md->ops->dump_info(md, flag, buff, length);
	else
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
}

void ccci_md_exception_handshake(unsigned char md_id, int timeout)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);

	if (md && md->ops->ee_handshake)
		md->ops->ee_handshake(md, timeout);
	else
		MTK_ERR_LOG(TAG, "Callback Fail,Pmd:%p\n", md);
}

int ccci_md_force_assert(unsigned char md_id,
	MD_FORCE_ASSERT_TYPE type, char *param, int len)
{
	int ret = 0;
	return ret;
}

void append_runtime_feature(char **p_rt_data,
	struct ccci_runtime_feature *rt_feature, void *data)
{
	memcpy_toio(*p_rt_data, rt_feature,
		sizeof(struct ccci_runtime_feature));
	*p_rt_data += sizeof(struct ccci_runtime_feature);
	if (data != NULL) {
		memcpy_toio(*p_rt_data, data, rt_feature->data_len);
		*p_rt_data += rt_feature->data_len;
	}
}



struct ccci_runtime_feature *ccci_md_get_rt_feature_by_id(unsigned char md_id,
	u8 feature_id, u8 ap_query_md)
{
	struct ccci_runtime_feature *rt_feature = NULL;
	u8 i = 0;
	u8 max_id = 0;

	struct ccci_smem_region *rt_data_region =
		ccci_md_get_smem_by_user_id(md_id, SMEM_USER_RAW_RUNTIME_DATA);

	if (ap_query_md) {
		rt_feature = (struct ccci_runtime_feature *)
			(rt_data_region->base_ap_view_vir +
			CCCI_SMEM_SIZE_RUNTIME_AP);
		max_id = RT_ID_MAX;
	} else {
		rt_feature = (struct ccci_runtime_feature *)
			(rt_data_region->base_ap_view_vir);
		max_id = RT_ID_MAX;
	}
	while (i < max_id) {
		if (feature_id == rt_feature->feature_id)
			return rt_feature;
		if (rt_feature->data_len >
			sizeof(struct ccci_misc_info_element)) {
			MTK_ERR_LOG(TAG, "get invalid feature, id %u\n", i);
			return NULL;
		}
		rt_feature =
			(struct ccci_runtime_feature *)
			((char *)rt_feature->data + rt_feature->data_len);
		i++;
	}

	return NULL;
}

int ccci_md_parse_rt_feature(unsigned char md_id,
	struct ccci_runtime_feature *rt_feature, void *data, u32 data_len)
{
	if (unlikely(!rt_feature)) {
		MTK_ERR_LOG(TAG, "parse_md_rt_feature: rt_feature == NULL\n");
		return -EFAULT;
	}
	if (unlikely(rt_feature->data_len > data_len ||
		rt_feature->data_len == 0)) {
		MTK_ERR_LOG(TAG,
			"rt_feature %u data_len = %u, expected data_len %u\n",
			rt_feature->feature_id, rt_feature->data_len, data_len);
		return -EFAULT;
	}
	memcpy(data, (const void *)((char *)rt_feature->data),
		rt_feature->data_len);

	return 0;
}

struct ccci_per_md *ccci_get_per_md_data(unsigned char md_id)
{
	struct ccci_modem *md = ccci_md_get_modem_by_id(md_id);

	if (md)
		return &md->per_md_data;
	else
		return NULL;
}


