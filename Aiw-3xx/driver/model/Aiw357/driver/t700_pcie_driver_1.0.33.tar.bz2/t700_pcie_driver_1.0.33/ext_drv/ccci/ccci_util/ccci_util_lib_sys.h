/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



typedef int (*get_status_func_t)(int, char*, int);
typedef int (*boot_md_func_t)(int);

int ccci_sysfs_add_modem(int md_id, void *kobj,
	void *ktype, get_status_func_t get_sta_func, boot_md_func_t boot_func);
int ccci_sysfs_remove_modem(int md_id, void *kobj);
void ccci_common_sysfs_rel(void);
int ccci_common_sysfs_init(void);

extern int get_dump_buf_usage(char buf[], int size);
extern int port_enumeration_test(int argc, char **argv);
extern int brom_jp_bl_cmd_test(int argc, char **argv);
extern int exception_flow_test(int argc, char **argv);
extern int cldma_low_power_test(int argc, char **argv);
extern int fsm_state_test(int argc, char **argv);


