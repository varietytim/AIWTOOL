// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/list.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/err.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <linux/netdevice.h>
#include <linux/ip.h>
#include <linux/random.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_fdt.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/syscore_ops.h>
#include <linux/version.h>

#include "ccci_hif_dpmaif_m80.h"
#include "ccci_hif_dpmaif_ut_m80.h"
#include "ccmni_m80.h"
#include "mtk-pci-ext.h"
#include "dpmaif_drv_m80.h"
#include "mtk-pci.h"
#include "mhccif.h"


#define TAG "DATA"

#if defined(CCCI_SKB_TRACE)
#undef TRACE_SYSTEM
#define TRACE_SYSTEM ccci
#include <linux/tracepoint.h>
#endif

#define DP_UNUSED(x)   ((x) = (x))

/* module parameter */
unsigned int dpmaif_pcie_lock_res_try_wait_cnt =  DPMF_PCIE_LOCK_RES_TRY_WAIT_CNT;
unsigned int dpmaif_dl_workqueue_time_limit = DPMF_WORKQUEUE_TIME_LIMIT;
unsigned int dpmaif_ul_workqueue_delay_time = DPMF_TX_REL_TIMEOUT;
unsigned int dpmaif_bat_burst_release_cnt = DPMF_BAT_CNT_UPDATE_THRESHOLD;
unsigned int dpmaif_pit_burst_release_cnt = DPMF_PIT_CNT_UPDATE_THRESHOLD;


#ifdef DPMA_FTRACE_DEBUG
static u64 g_total_isr;
static u64 g_pkt_cnt_per_isr;
static u64 g_pkt_cnt_per_lp_lock;
#endif

#define DPMF_SET_SKB_CS_TYPE(cs_result, skb) {\
	if (cs_result == DPMF_CS_RESULT_PASS)\
		skb->ip_summed = CHECKSUM_UNNECESSARY;\
	else\
		skb->ip_summed = CHECKSUM_NONE;\
}

#define NOMAL_PIT_BID(pit_info) ( ((pit_info)->h_bid << 13) + (pit_info)->buffer_id)


/* DPMAIF throughput statistics */
#ifdef DATA_PATH_TP_CALC
extern struct ccci_dp_tput_configure g_tput_config;
static struct dpmaif_tp_statistics g_dpmf_tp_stat;
#endif


/* CPU information */
#define DPMF_GET_CUR_CPU(cpu) {\
	*(cpu) = get_cpu(); \
	put_cpu(); \
}

#define DPMF_CUR_CPU_INVALID	(-1)

/* CPU CACHE LINE */
unsigned long g_DPMAIF_CACHE_LINE_SIZE;


/* trigger md dump */
static int g_dpmaif_trigger_md_dump = 0;


#define DPMAIF_DUMP_PIT_NUM			(60)


#define DPMAIF_SET_MD_DUMP()	do {	\
	g_dpmaif_trigger_md_dump = 1;	\
} while (0)


#define DPMAIF_RESET_MD_DUMP()	do {	\
	g_dpmaif_trigger_md_dump = 0;	\
} while (0)


#define DPMAIF_IS_SET_MD_DUMP()		(g_dpmaif_trigger_md_dump == 1)


/* =======================================================
 *
 * Descriptions: Debug part
 *
 * ========================================================
 */

#if defined(CCCI_SKB_TRACE)
TRACE_EVENT(ccci_skb_rx,
	TP_PROTO(unsigned long long *dl_delay),
	TP_ARGS(dl_delay),
	TP_STRUCT__entry(
		__array(unsigned long long, dl_delay, 8)
	),

	TP_fast_assign(
		memcpy(__entry->dl_delay, dl_delay,
			8*sizeof(unsigned long long));
	),

	TP_printk(
	"  %llu  %llu  %llu  %llu  %llu  %llu  %llu  %llu",
		__entry->dl_delay[0], __entry->dl_delay[1],
		__entry->dl_delay[2], __entry->dl_delay[3],
		__entry->dl_delay[4], __entry->dl_delay[5],
		__entry->dl_delay[6], __entry->dl_delay[7])
);
#endif


#define DPMF_MAP_SKB_ENQ(entry, skb_list) {\
		list_add_tail(&entry, &skb_list.head); \
		skb_list.qlen++; \
	}

static struct dpmaif_skb_info *dpmaif_skb_dequeue(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index);

static unsigned int	 ring_buf_get_next_wrdx(unsigned int  buf_len,
	unsigned int buf_idx);

static inline int dpmaif_find_reload_cpu(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int cpu = DPMF_CUR_CPU_INVALID;
	bool found = true;
	int i = 0;

	for_each_online_cpu(cpu) {
		found = true;

		for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
			if (cpu == dpmaif_ctrl->rxq[i].cur_irq_cpu || cpu ==
				dpmaif_ctrl->rxq[i].cur_rx_thrd_cpu) {
				found = false;
				break;
			}
		}

		if (found == true)
			break;
	}

	if (false == found)
		DPMF_GET_CUR_CPU(&cpu);

	return cpu;
}


#ifdef DPMAIF_DEBUG_DUMP
/* this funciton just fot debug */
static void dpmaif_dump_packet_data(char *data, unsigned int length)
{
	const unsigned int LINE_LEN = 0x10;
	unsigned int i = 0;
	unsigned int j = 0;
	char line_data[500] = {0};
	char tmp_data[10] = {0};

	for (i = 0; i < length/LINE_LEN; i++) {
		memset(line_data, 0, sizeof(line_data));
		for (j = 0; j < LINE_LEN; j++) {
			snprintf(tmp_data, 4, "%02X ",
				(unsigned char)data[i*LINE_LEN + j]);
			strncat(line_data, tmp_data, 3);
		}
		MTK_DEBUG_LOG(TAG, "%06X %s\n",
			i*0x10, line_data);
	}

	if (length % LINE_LEN > 0) {
		memset(line_data, 0, sizeof(line_data));
		for (j = 0; j < length%LINE_LEN; j++) {
			snprintf(tmp_data, 4, "%02X ",
				(unsigned char)data[i*LINE_LEN + j]);
			strncat(line_data, tmp_data, 3);
		}
		MTK_DEBUG_LOG(TAG, "%06X %s\n",
			i*0x10, line_data);
	}
}


/* this funciton just fot debug */
static void dpmaif_dump_tx_ip_packet_data(unsigned short is_frag,
	char *data, unsigned int length)
{
	/* count of dump IP packets */
	static u64 s_dump_tx_cnt_main;
	/* frag index of dump IP packets */
	static u32 s_dump_tx_idx_frag;

	if (is_frag == 0) {
		s_dump_tx_cnt_main++;
		s_dump_tx_idx_frag = 0;
	} else {
		s_dump_tx_idx_frag++;
	}
	MTK_DEBUG_LOG(TAG,
		"====== DUMP TX IP PACKET(No.%llu - %u) TO DPMAIF HW BEGIN ======\n",
		s_dump_tx_cnt_main, s_dump_tx_idx_frag);
	dpmaif_dump_packet_data(data, length);
	MTK_DEBUG_LOG(TAG,
		"======= DUMP TX IP PACKET(No.%llu - %u) TO DPMAIF HW END =======\n",
		s_dump_tx_cnt_main, s_dump_tx_idx_frag);
}

static void dpmaif_dump_skb_ip_info(int qno, struct sk_buff *skb)
{
	struct iphdr *iph = NULL;
	__be32 src_addr, dst_addr;

	if (skb == NULL) {
		MTK_DEBUG_LOG(TAG, "skb is a NULL pointer!\n");
		goto err;
	}

	iph = (struct iphdr *)(skb->data);
	src_addr = iph->saddr;
	dst_addr = iph->daddr;
	MTK_DEBUG_LOG(TAG,
		"rx_qno: %d, original IP header's src address is %u.%u.%u.%u\n",
		qno,
		(u8)(src_addr & 0xFF), (u8)(src_addr >> 8 & 0xFF),
		(u8)(src_addr >> 16 & 0xFF), (u8)(src_addr >> 24 & 0xFF));
	MTK_DEBUG_LOG(TAG,
		"dst address is %u.%u.%u.%u",
		(u8)(dst_addr & 0xFF), (u8)(dst_addr >> 8 & 0xFF),
		(u8)(dst_addr >> 16 & 0xFF), (u8)(dst_addr >> 24 & 0xFF));

err:
	return;
}

static void dpmaif_dump_msg_pit_entry(unsigned char md_id,
	struct dpmaifq_msg_pit *msg_pit)
{
	if (msg_pit == NULL)
		goto exit;

	MTK_DEBUG_LOG(TAG, "======== DUMP MSG PIT START ========\n");
	MTK_DEBUG_LOG(TAG,
		"packet_type = %u, c_bit = %u\n",
		msg_pit->packet_type, msg_pit->c_bit);
	MTK_DEBUG_LOG(TAG,
		"check_sum = %u, error_bit = %u, src_qid = %u\n",
		msg_pit->check_sum, msg_pit->error_bit,
		msg_pit->src_qid);
	MTK_DEBUG_LOG(TAG,
		"channel_id = %u, network_type = %u\n",
		msg_pit->channel_id, msg_pit->network_type);
	MTK_DEBUG_LOG(TAG,
		"dp = %u, count_l = %u, flow = %u\n",
		msg_pit->dp, msg_pit->count_l, msg_pit->flow);
	MTK_DEBUG_LOG(TAG,
		"cmd = %u, vbid = %u, pit_seq = %u, ulq_done = %u, dlq_done = %u\n",
		msg_pit->cmd, msg_pit->vbid, msg_pit->pit_seq,
		msg_pit->ulq_done, msg_pit->dlq_done);

	MTK_DEBUG_LOG(TAG,
		"hpc_idx = %u, hp_idx: = %u, mr = %u\n",
		msg_pit->hpc_idx, msg_pit->hp_idx, msg_pit->mr);
	MTK_DEBUG_LOG(TAG,
		"ip = %u, pro = %u, hash = 0x%x\n",
		msg_pit->ip, msg_pit->pro, msg_pit->hash);

	MTK_DEBUG_LOG(TAG, "========  DUMP MSG PIT END	========\n");

exit:
	return;
}


static void dpmaif_dump_nor_pit_entry(unsigned char md_id,
	struct dpmaifq_normal_pit *nor_pit)
{
	if (nor_pit == NULL)
		goto exit;

	MTK_DEBUG_LOG(TAG, "======== DUMP NORMAL PIT START ========\n");
	MTK_DEBUG_LOG(TAG,
		"packet_type = %u, c_bit = %u, buffer_type = %u, buffer_id = %u, data_len = %u\n",
		nor_pit->packet_type, nor_pit->c_bit,
		nor_pit->buffer_type, nor_pit->buffer_id,
		nor_pit->data_len);

	MTK_DEBUG_LOG(TAG,
		"p_data_addr = %x, data_addr_ext = %x, pit_seq = %u, h_bid = %u, ig = %u\n",
		nor_pit->p_data_addr, nor_pit->data_addr_ext,
		nor_pit->pit_seq, nor_pit->h_bid, nor_pit->ig);

	MTK_DEBUG_LOG(TAG,
		"bi_f = %u, header_offset = %u, ulq_done = %u, dlq_done = %u\n",
		nor_pit->bi_f, nor_pit->header_offset,
		nor_pit->ulq_done, nor_pit->dlq_done);
	MTK_DEBUG_LOG(TAG, "========  DUMP NORMAL PIT END  ========\n");

exit:
	return;
}
#endif

static void dpmaif_dump_register(struct md_dpmaif_ctrl *hif_ctrl,
	int buf_type)
{
	drv_dpmaif_dump_debug_regs(&hif_ctrl->hif_hw_info);
}


static void dpmaif_dump_rxq_history(struct md_dpmaif_ctrl *dpmaif_ctrl,
	int qno, int dump_multi)
{
	unsigned char md_id = dpmaif_ctrl->md_id;

	if (qno > DPMAIF_RXQ_NUM) {
		MTK_ERR_LOG(TAG, "Invalid rxq%d\n", qno);
		return;
	}

	ccci_md_dump_log_history(md_id, &dpmaif_ctrl->traffic_info,
		dump_multi, -1, qno);
}

static void dpmaif_dump_txq_history(struct md_dpmaif_ctrl *dpmaif_ctrl,
	int qno, int dump_multi)
{
	unsigned char md_id = dpmaif_ctrl->md_id;

	if (qno > DPMAIF_TXQ_NUM) {
		MTK_ERR_LOG(TAG, "Invalid txq%d\n", qno);
		return;
	}

	ccci_md_dump_log_history(md_id, &dpmaif_ctrl->traffic_info,
			dump_multi, qno, -1);
}

static void dpmaif_dump_rxq_remain(struct md_dpmaif_ctrl *hif_ctrl,
	int qno, int dump_multi)
{
	int i, rx_qno;
#ifdef DPMAIF_DEBUG_DUMP
	unsigned char md_id = hif_ctrl->md_id;
#endif
	struct dpmaif_rx_queue *rxq;

	MTK_ERR_LOG(TAG, "md_dpmaif_ctrl: 0x%llx\n", (u64)hif_ctrl);

	if (!dump_multi && (qno >= DPMAIF_RXQ_NUM)) {
		MTK_ERR_LOG(TAG, "Invalid rxq%d\n", qno);
		return;
	}

	if (dump_multi) {
		rx_qno = ((qno <= MAX_RXQ_NUM) ? qno : MAX_RXQ_NUM);
		i = 0;
	} else {
		rx_qno = qno + 1;
		i = qno;
	}

	for (; i < rx_qno; i++) {
		rxq = &hif_ctrl->rxq[i];

		MTK_ERR_LOG(TAG, "===dump rxq%d: 0x%llx===\n", i, (u64)rxq);

		/* PIT mem dump */
		MTK_ERR_LOG(TAG,
			"pit base: 0x%llx(%d*%d), rel_cnt: %d\n",
			(u64)rxq->pit_base,
			(int)sizeof(struct dpmaifq_normal_pit),
			rxq->pit_size_cnt, rxq->pit_remain_rel_cnt);
		MTK_ERR_LOG(TAG,
			"rxq%d pit-w/r/rel-%u,%u,%u\n", i,
			rxq->pit_wr_idx, rxq->pit_rd_idx,
			rxq->pit_rel_rd_idx);
		MTK_ERR_LOG(TAG,
			"rxq:%d umask:0x%x,0x%x,0x%x,0x%x.\n",i,
			rxq->dpmaif_ctrl->hif_hw_info.dpmaif_drv_ctrl.dpmaif_isr_en_mask.AP_UL_L2INTR_En_Msk,
			rxq->dpmaif_ctrl->hif_hw_info.dpmaif_drv_ctrl.dpmaif_isr_en_mask.AP_DL_L2INTR_En_Msk,
			rxq->dpmaif_ctrl->hif_hw_info.dpmaif_drv_ctrl.dpmaif_isr_en_mask.AP_UDL_IP_BUSY_En_Msk,
			rxq->dpmaif_ctrl->hif_hw_info.dpmaif_drv_ctrl.dpmaif_isr_en_mask.AP_DL_L2INTR_ERR_En_Msk);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP, rxq->pit_base,
			(rxq->pit_size_cnt *
			sizeof(struct dpmaifq_normal_pit)));
#endif
		/* BAT mem dump */
		MTK_ERR_LOG(TAG, "rxq%d bat base: 0x%llx(%d*%u)\n", i,
			(u64)rxq->bat_req->bat_base,
			(int)sizeof(struct dpmaif_bat_t),
			rxq->bat_req->bat_size_cnt);
		MTK_ERR_LOG(TAG,
			"rxq%d bat-w/r/rel-%u,%u,%u\n", i,
			rxq->bat_req->bat_wr_idx, rxq->bat_req->bat_rd_idx,
			rxq->bat_req->bat_rel_rd_idx);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP,
			rxq->bat_req->bat_base,
			(rxq->bat_req->bat_size_cnt *
			sizeof(struct dpmaif_bat_t)));
#endif
		/* BAT SKB mem dump */
		MTK_ERR_LOG(TAG, "rxq%d bat skb base: 0x%llx(%d*%d)\n", i,
			(u64)rxq->bat_req->bat_skb_ptr,
			(int)sizeof(struct dpmaif_bat_skb_t),
			rxq->bat_req->bat_size_cnt);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP,
			rxq->bat_req->bat_skb_ptr,
			(rxq->bat_req->skb_pkt_cnt *
			sizeof(struct dpmaif_bat_skb_t)));
#endif
		/* BAT frg mem dump */
		MTK_ERR_LOG(TAG,
			"rxq%d bat_frag base: 0x%llx(%d*%d)\n", i,
			(u64)rxq->bat_frag->bat_base,
			(int)sizeof(struct dpmaif_bat_t),
			rxq->bat_frag->bat_size_cnt);
		MTK_ERR_LOG(TAG,
			"rxq%d frag_bat-w/r/rel-%u,%u,%u\n", i,
			rxq->bat_frag->bat_wr_idx, rxq->bat_frag->bat_rd_idx,
			rxq->bat_frag->bat_rel_rd_idx);

		/* BAT fragment mem dump */
		MTK_ERR_LOG(TAG, "bat_frag skb ptr base: 0x%llx(%d*%d)\n",
			(u64)rxq->bat_frag->bat_skb_ptr,
			(int)sizeof(struct dpmaif_bat_page_t),
			rxq->bat_frag->bat_size_cnt);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(md_id, CCCI_DUMP_MEM_DUMP,
			rxq->bat_frag->bat_skb_ptr,
			(rxq->bat_frag->skb_pkt_cnt *
			sizeof(struct dpmaif_bat_page_t)));
#endif
	}
}

static void dpmaif_dump_txq_remain(struct md_dpmaif_ctrl *hif_ctrl,
	int qno, int dump_multi)
{
	struct dpmaif_tx_queue *txq;
	int i, tx_qno;

	MTK_ERR_LOG(TAG, "md_dpmaif_ctrl: 0x%llx\n", (u64)hif_ctrl);

	if (!dump_multi && (qno >= DPMAIF_TXQ_NUM)) {
		MTK_ERR_LOG(TAG, "Invalid txq%d\n", qno);
		return;
	}

	if (dump_multi) {
		tx_qno = ((qno <= MAX_TXQ_NUM) ? qno : MAX_TXQ_NUM);
		i = 0;
	} else {
		tx_qno = qno + 1;
		i = qno;
	}

	for (; i < tx_qno; i++) {
		txq = &hif_ctrl->txq[i];

		MTK_ERR_LOG(TAG, "===dump txq%d: 0x%llx===\n", i, (u64)txq);

		/* dump drb buffer */
		MTK_ERR_LOG(TAG, "drb base: 0x%llx(%d*%d)\n", (u64)txq->drb_base,
			(int)sizeof(struct dpmaif_drb_pd), txq->drb_size_cnt);
		MTK_ERR_LOG(TAG, "drb-w/r/rel-%d,%d,%d\n", txq->drb_wr_idx,
			txq->drb_rd_idx, txq->drb_rel_rd_idx);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(0,
			CCCI_DUMP_MEM_DUMP, txq->drb_base,
			(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)));
#endif
		/* dump drb skb */
		MTK_ERR_LOG(TAG, "txq%d drb skb base: 0x%llx(%d*%d)\n", txq->index, 
			(u64)txq->drb_skb_base, (int)sizeof(struct dpmaif_drb_skb),
			txq->drb_size_cnt);
#ifdef DPMAIF_DEBUG_DUMP
		ccci_util_mem_dump(0,
			CCCI_DUMP_MEM_DUMP, txq->drb_skb_base,
			(txq->drb_size_cnt * sizeof(struct dpmaif_drb_skb)));
#endif
	}
}


/*actrually, length is dump flag's private argument*/
static int dpmaif_dump_status(struct md_dpmaif_ctrl *dpmaif_ctrl,
	enum modem_dump_flag flag, int length)
{
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl NULL Pointer!");
		return 0;
	}

	/* dump the dpmaif register for MD Debug need */
	if (flag & DUMP_FLAG_REG) {
		dpmaif_dump_register(dpmaif_ctrl, CCCI_DUMP_MEM_DUMP);
	}

	/* dump txq/rxq data */
	if (length == -1) {
		dpmaif_dump_rxq_history(dpmaif_ctrl, DPMAIF_RXQ_NUM, 1);
		dpmaif_dump_rxq_remain(dpmaif_ctrl, DPMAIF_RXQ_NUM, 1);
		dpmaif_dump_txq_history(dpmaif_ctrl, DPMAIF_TXQ_NUM, 1);
		dpmaif_dump_txq_remain(dpmaif_ctrl, DPMAIF_TXQ_NUM, 1);
	}

	return 0;
}


int dpmaif_dump_full_pit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int i = 0, j = 0;
	unsigned int *temp_pit = NULL;

	if (!dpmaif_ctrl) {
		MTK_ERR_LOG(TAG, "dpmaif_dump_full_pit--empty hif_ctrl\r\n");
		return -1;
	}

	for (i = 0; i < DPMAIF_RXQ_NUM; ++i) {
		MTK_ERR_LOG(TAG, "qno: %d, rd_idx: %d, wr_idx: %d, rel_rd_idx: %d, expect_pit_seq: %d, remain_rel_cnt: %d\r\n",
			i, dpmaif_ctrl->rxq[i].pit_rd_idx, dpmaif_ctrl->rxq[i].pit_wr_idx,
			dpmaif_ctrl->rxq[i].pit_rel_rd_idx, dpmaif_ctrl->rxq[i].expect_pit_seq, 
			dpmaif_ctrl->rxq[i].pit_remain_rel_cnt);
		MTK_ERR_LOG(TAG, "dpmaif_dump_full_pit start~~~~~~~~~~~~~");
		for (j = 0; j < dpmaif_ctrl->rxq[i].pit_size_cnt; ++j) {
			temp_pit = (unsigned int *)((struct dpmaifq_normal_pit *)dpmaif_ctrl->rxq[i].pit_base + j);
			MTK_ERR_LOG(TAG, "j: %d (%08X %08X %08X %08X)\r\n", j, temp_pit[0], temp_pit[1], temp_pit[2], temp_pit[3]);
		}
		MTK_ERR_LOG(TAG, "dpmaif_dump_full_pit end~~~~~~~~~~~~~");
	}

	return 0;
}


static int dpmaif_dump_bat(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int i = 0;
	struct dpmaif_bat_t *cur_bat = NULL;
	struct dpmaif_bat_skb_t *cur_bat_skb = NULL;

	if (!dpmaif_ctrl) {
	    MTK_ERR_LOG(TAG, "dpmaif_dump_bat--empty hif_ctrl\r\n");
	    return -1;
	}

	MTK_ERR_LOG(TAG, "dpmaif_dump_bat--bat_wr_idx: %u, bat_rd_idx: %u, bat_rel_rd_idx: %u\r\n",
		dpmaif_ctrl->bat_req.bat_wr_idx, dpmaif_ctrl->bat_req.bat_rd_idx, 
		dpmaif_ctrl->bat_req.bat_rel_rd_idx);
	MTK_ERR_LOG(TAG, "dpmaif_dump_bat start~~~~~~~~~~~~~");
	for (i = 0; i < dpmaif_ctrl->bat_req.bat_size_cnt; ++i) {
		cur_bat = ((struct dpmaif_bat_t *)dpmaif_ctrl->bat_req.bat_base + i);
		cur_bat_skb = ((struct dpmaif_bat_skb_t *)dpmaif_ctrl->bat_req.bat_skb_ptr + i);

		MTK_ERR_LOG(TAG, "i: %d, mask: %u, addr(0x%08X %08X)--skb: 0x%016llx, base_addr: 0x%016llx, data_len: %u\r\n",
			i, dpmaif_ctrl->bat_req.bat_mask[i],
			cur_bat->buffer_addr_ext, cur_bat->p_buffer_addr, (u64)(cur_bat_skb->skb), 
			(u64)(cur_bat_skb->data_bus_addr), cur_bat_skb->data_len);
    }
	MTK_ERR_LOG(TAG, "dpmaif_dump_bat end~~~~~~~~~~~~~");

	return 0;
}


static void dpmaif_dump_partial_pit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned short start_idx = 0;
	int ki = 0, i = 0, half = 0;
	unsigned int *temp_pit = NULL;
	struct dpmaif_rx_queue *rxq = NULL;

	MTK_ERR_LOG(TAG, "dpmaif_dump_partial_pit--num: %d\r\n", DPMAIF_DUMP_PIT_NUM);

	if (!dpmaif_ctrl) {
		MTK_ERR_LOG(TAG, "dpmaif_dump_partial_pit-empty hif_ctrl\r\n");
		return;
	}

	half = DPMAIF_DUMP_PIT_NUM / 2;

	for (ki = 0; ki < DPMAIF_RXQ_NUM; ki++) {
		rxq = &dpmaif_ctrl->rxq[ki];
		/* dump pit info */
		if (rxq->pit_rd_idx >= half) {
			start_idx = rxq->pit_rd_idx - half;
		} else {
			start_idx = rxq->pit_size_cnt + rxq->pit_rd_idx - half;
		}

		MTK_ERR_LOG(TAG, "dpmaif_dump_partial_pit--qno: %d, rd_idx: %d, wr_idx: %d, rel_rd_idx: %d, expect_pit_seq: %d, remain_rel_cnt: %d\r\n",
			ki, rxq->pit_rd_idx, rxq->pit_wr_idx, rxq->pit_rel_rd_idx,
			rxq->expect_pit_seq, rxq->pit_remain_rel_cnt);

		for (i = 0; i < DPMAIF_DUMP_PIT_NUM; ++i) {
			temp_pit = (unsigned int *)((struct dpmaifq_normal_pit *)rxq->pit_base + start_idx);
			MTK_ERR_LOG(TAG, "i=%d, idx=%d--pit(%08X, %08X, %08X, %08X)\r\n", i, start_idx, 
				temp_pit[0], temp_pit[1], temp_pit[2], temp_pit[3]);
			start_idx = ring_buf_get_next_wrdx(rxq->pit_size_cnt, start_idx);
		}
	}
}


static void dpmaif_md_assert_hdr(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (DPMAIF_IS_SET_MD_DUMP()) {
		MTK_ERR_LOG(TAG, "dpmaif_md_assert_hdr--already trigger md dump");
		return;
	}

	/* set md dump flag */
	DPMAIF_SET_MD_DUMP();
	/* dump partial pit info */
	dpmaif_dump_partial_pit(dpmaif_ctrl);
	/* dump full bat info */
	dpmaif_dump_bat(dpmaif_ctrl);
	/* dump reg info */
	dpmaif_dump_status(dpmaif_ctrl, DUMP_FLAG_REG, -1);
	/* trigger md dump */
	mhccif_rc2ep_swint_trigger(dpmaif_ctrl->mtk_dev, MHCCIF_H2D_RESERVED_FOR_DPMAIF);
}


#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
static void dpmaif_clear_traffic_data(unsigned char md_id,
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	memset(dpmaif_ctrl->tx_traffic_monitor, 0,
		sizeof(dpmaif_ctrl->tx_traffic_monitor));
	memset(dpmaif_ctrl->rx_traffic_monitor, 0,
		sizeof(dpmaif_ctrl->rx_traffic_monitor));
	memset(dpmaif_ctrl->tx_pre_traffic_monitor, 0,
		sizeof(dpmaif_ctrl->tx_pre_traffic_monitor));
	memset(dpmaif_ctrl->tx_payload_monitor, 0,
		sizeof(dpmaif_ctrl->tx_payload_monitor));
	memset(dpmaif_ctrl->tx_done_last_count, 0,
		sizeof(dpmaif_ctrl->tx_done_last_count));
	memset(dpmaif_ctrl->tx_done_last_start_time, 0,
		sizeof(dpmaif_ctrl->tx_done_last_start_time));
	dpmaif_ctrl->traffic_info.isr_time_bak = 0;
	dpmaif_ctrl->traffic_info.isr_cnt = 0;
	dpmaif_ctrl->traffic_info.rx_full_cnt = 0;

	dpmaif_ctrl->traffic_info.rx_done_isr_cnt[0] = 0;
	dpmaif_ctrl->traffic_info.rx_other_isr_cnt[0] = 0;
	dpmaif_ctrl->traffic_info.rx_tasket_cnt = 0;

	dpmaif_ctrl->traffic_info.tx_done_isr_cnt[0] = 0;
	dpmaif_ctrl->traffic_info.tx_done_isr_cnt[1] = 0;
	dpmaif_ctrl->traffic_info.tx_done_isr_cnt[2] = 0;
	dpmaif_ctrl->traffic_info.tx_done_isr_cnt[3] = 0;
	dpmaif_ctrl->traffic_info.tx_other_isr_cnt[0] = 0;
	dpmaif_ctrl->traffic_info.tx_other_isr_cnt[1] = 0;
	dpmaif_ctrl->traffic_info.tx_other_isr_cnt[2] = 0;
	dpmaif_ctrl->traffic_info.tx_other_isr_cnt[3] = 0;
}
#endif

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
static inline unsigned int dpmaif_skb_avail_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index);

static void dpmaif_traffic_monitor_func(struct timer_list *t)
{
	struct md_dpmaif_ctrl *hif_ctrl =
		from_timer(hif_ctrl, t, traffic_monitor);
	struct ccci_hif_traffic *tinfo = &hif_ctrl->traffic_info;
	unsigned long q_rx_rem_nsec[DPMAIF_RXQ_NUM] = {0};
	unsigned long isr_rem_nsec;
	int i, q_state = 0;
	unsigned long long total_tx_cnt = 0;
	unsigned long long total_pre_tx_cnt = 0;
	unsigned long long total_tx_payload_cnt = 0;
	unsigned long long total_rx_cnt = 0;
	unsigned int dl_vail_cnt = 0;

#ifdef DATA_PATH_TP_CALC
	u64 dl_bytes_cnt = 0, dl_rec_start_tm = 0,
	dl_tm_now = 0, dl_tm_del = 0;

	u64 ul_bytes_cnt_sw = 0, ul_bytes_cnt_hw = 0,
		ul_rec_start_tm = 0, ul_tm_now = 0, ul_tm_del = 0;

	unsigned char ul_tp_calc = g_tput_config.ul_tput_monitor_enable;
	unsigned char dl_tp_calc = g_tput_config.dl_tput_monitor_enable;
#endif

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		if (hif_ctrl->txq[i].busy_count != 0) {
			MTK_DEBUG_LOG(TAG,
				"Txq%d(%d) busy count %d\n",
				i, hif_ctrl->txq[i].que_started,
				hif_ctrl->txq[i].busy_count);
			hif_ctrl->txq[i].busy_count = 0;
		}
		q_state |= (hif_ctrl->txq[i].que_started << i);
		MTK_DEBUG_LOG(TAG,
			"Current txq%d pos: w/r/rel=%d, %d, %d\n", i,
			hif_ctrl->txq[i].drb_wr_idx,
			hif_ctrl->txq[i].drb_rd_idx,
			hif_ctrl->txq[i].drb_rel_rd_idx);
	}

	/* calculates total tx packets count */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		total_tx_cnt += hif_ctrl->tx_traffic_monitor[i];
		total_pre_tx_cnt += hif_ctrl->tx_pre_traffic_monitor[i];
		total_tx_payload_cnt += hif_ctrl->tx_payload_monitor[i];
	}

	if (3 < DPMAIF_TXQ_NUM)
		MTK_DEBUG_LOG(TAG,
			"net Txq0-3(status=0x%x):%d-%llu-%llu, %d-%llu-%llu, %d-%llu-%llu, %d-%llu-%llu\n",
			q_state, atomic_read(&hif_ctrl->txq[0].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[0],
			hif_ctrl->tx_traffic_monitor[0],
			atomic_read(&hif_ctrl->txq[1].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[1],
			hif_ctrl->tx_traffic_monitor[1],
			atomic_read(&hif_ctrl->txq[2].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[2],
			hif_ctrl->tx_traffic_monitor[2],
			atomic_read(&hif_ctrl->txq[3].tx_budget),
			hif_ctrl->tx_pre_traffic_monitor[3],
			hif_ctrl->tx_traffic_monitor[3]);

	isr_rem_nsec = (tinfo->latest_isr_time == 0 ?
		0 : do_div(tinfo->latest_isr_time, NSEC_PER_SEC));
	MTK_DEBUG_LOG(TAG,
		"net Rx ISR %lu.%06lu, active %d\n",
		(unsigned long)tinfo->latest_isr_time, isr_rem_nsec / 1000,
		hif_ctrl->rxq[0].que_started);
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		/* calculates total rx packets count */
		total_rx_cnt += hif_ctrl->rx_traffic_monitor[i];

		q_rx_rem_nsec[i] = (tinfo->latest_q_rx_isr_time[i] == 0 ?
			0 : do_div(tinfo->latest_q_rx_isr_time[i],
			NSEC_PER_SEC));
		MTK_DEBUG_LOG(TAG, "net RX:%lu.%06lu, %llu\n",
			(unsigned long)tinfo->latest_q_rx_isr_time[i],
			q_rx_rem_nsec[i] / 1000,
			hif_ctrl->rx_traffic_monitor[i]);

		q_rx_rem_nsec[i] = (tinfo->latest_q_rx_time[i] == 0 ?
			0 : do_div(tinfo->latest_q_rx_time[i], NSEC_PER_SEC));
		MTK_DEBUG_LOG(TAG, "net RXq%d:%lu.%06lu\n",
			i, (unsigned long)tinfo->latest_q_rx_time[i],
			q_rx_rem_nsec[i] / 1000);
	}

#ifdef DATA_PATH_TP_CALC
	/* DL throughput */
	if (dl_tp_calc) {
		if (true == g_dpmf_tp_stat.rx_rec_enable) {
			/* total DL bytes count */
			dl_bytes_cnt = g_dpmf_tp_stat.rx_num;

			dl_tm_now = DPMA_UT_TIME_NOW();
			dl_rec_start_tm = g_dpmf_tp_stat.rx_rec_start_tm;
			g_dpmf_tp_stat.rx_rec_enable = false;

			/* total time */
			dl_tm_del = dl_tm_now - dl_rec_start_tm;
		}

		MTK_CRIT_LOG(TAG, "#[HIF-DPMAIF-THROUGHPUT], [DL], (total bytes, total time): #%llu#%llu\n", 
						dl_bytes_cnt, dl_tm_del);

		if (false == g_dpmf_tp_stat.rx_rec_enable) {
			g_dpmf_tp_stat.rx_num = 0;
			g_dpmf_tp_stat.rx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_rx_pkt = true;

			/* this setting should be last */
			g_dpmf_tp_stat.rx_rec_enable = true;
		}
	} else {
		if (true == g_dpmf_tp_stat.rx_rec_enable) {
			g_dpmf_tp_stat.rx_rec_enable = false;
			g_dpmf_tp_stat.rx_num = 0;
			g_dpmf_tp_stat.rx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_rx_pkt = true;
		}
	}
	
	/* UL throughput  */
	if (ul_tp_calc) {
		if (true == g_dpmf_tp_stat.tx_rec_enable) {
			g_dpmf_tp_stat.tx_rec_enable = false;

			/* SW: total DL bytes count */
			ul_bytes_cnt_sw = g_dpmf_tp_stat.tx_num[0];
			ul_bytes_cnt_hw = g_dpmf_tp_stat.tx_num[1];
			ul_tm_now = DPMA_UT_TIME_NOW();

			ul_rec_start_tm = g_dpmf_tp_stat.tx_rec_start_tm;

			/* total time */
			ul_tm_del = ul_tm_now - ul_rec_start_tm;
		}

		MTK_CRIT_LOG(TAG, 
			"#[HIF-DPMAIF-THROUGHPUT], [UL], (SW total bytes, HW total bytes, total time): #%llu#%llu#%llu\n", 
			ul_bytes_cnt_sw, ul_bytes_cnt_hw, ul_tm_del);

		if (false == g_dpmf_tp_stat.tx_rec_enable) {
			memset(g_dpmf_tp_stat.tx_num, 0x00, sizeof(g_dpmf_tp_stat.tx_num));
			g_dpmf_tp_stat.tx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_tx_pkt = true;

			/* this setting should be last */
			g_dpmf_tp_stat.tx_rec_enable = true;
		}
	} else {
		if (true == g_dpmf_tp_stat.tx_rec_enable) {
			g_dpmf_tp_stat.tx_rec_enable = false;
			memset(g_dpmf_tp_stat.tx_num, 0x00, sizeof(g_dpmf_tp_stat.tx_num));
			g_dpmf_tp_stat.tx_rec_start_tm = 0;
			g_dpmf_tp_stat.first_tx_pkt = true;
		}
	}
	
#endif

	/* debug log for total tx, rx packets count */
	MTK_DEBUG_LOG(TAG,
		"TX_RX info: tx_count = %llu, tx_done_count = %llu\n",
					total_pre_tx_cnt, total_tx_cnt);
	MTK_DEBUG_LOG(TAG,
		"tx_payload_count = %llu, rx_count = %llu\n",
		total_tx_payload_cnt, total_rx_cnt);

	/* interrupt count */
	MTK_DEBUG_LOG(TAG,
		"INTERRUPT info: total(%llu), tx_0(%llu), tx_1(%llu)\n",
		tinfo->isr_cnt,
		tinfo->tx_done_isr_cnt[0],
		tinfo->tx_done_isr_cnt[1]);
	MTK_DEBUG_LOG(TAG,
		"tx_2(%llu), tx_3(%llu), rx0(%llu)\n",
		tinfo->tx_done_isr_cnt[2],
		tinfo->tx_done_isr_cnt[3],
		tinfo->rx_done_isr_cnt[0]);

	/* error interrupt count */
	MTK_DEBUG_LOG(TAG,
		"ERROR INTERRUPT: bat_len_err(%llu), pit_len_err(%llu)\n",
		tinfo->rx_isr_bat_len_err_cnt[0],
		tinfo->rx_isr_pit_len_err_cnt[0]);

	/* poll pit empty count */
	MTK_DEBUG_LOG(TAG,
		"POLL EMPTY PIT %llu time(s)\n", tinfo->poll_pit_empty[0]);

	/* available DL skb count */
	for (i = 0; i < DPMA_SKB_QUEUE_CNT; i++) {
		dl_vail_cnt = dpmaif_skb_avail_cnt(hif_ctrl, i);
		MTK_DEBUG_LOG(TAG,
			"DL skb queue%d avail_cnt(%u)\n", i, dl_vail_cnt);
	}

	mod_timer(&hif_ctrl->traffic_monitor,
			jiffies + DPMAIF_TRAFFIC_MONITOR_INTERVAL * HZ);
}


#endif

/* =======================================================
 *
 * Descriptions: common part
 *
 * ========================================================
 */
static int dpmaif_queue_broadcast_state(struct md_dpmaif_ctrl *dpmaif_ctrl,
	enum HIF_STATE state, enum direction dir, char qno)
{
	MTK_DEBUG_LOG(TAG,
		"queue_broadcase_state: %s sta(q%d) %d\n",
		((dir == MTK_IN) ? "RX":"TX"), (int)qno, (int)state);

	ccmni_queue_state_notify(dpmaif_ctrl->ctlb, state, qno);

	return 0;
}

static unsigned int	 ring_buf_get_next_wrdx(unsigned int  buf_len,
	unsigned int buf_idx)
{
	buf_idx++;
	if (buf_idx >= buf_len)
		buf_idx -= buf_len;
	return buf_idx;
}

static unsigned int ring_buf_readable(unsigned int	total_cnt,
	unsigned int rd_idx, unsigned int  wrt_idx)
{
	unsigned int pkt_cnt = 0;

	if (wrt_idx >= rd_idx)
		pkt_cnt = wrt_idx - rd_idx;
	else
		pkt_cnt = total_cnt + wrt_idx - rd_idx;

	return pkt_cnt;
}

static unsigned int ring_buf_writeable(unsigned int	 total_cnt,
	unsigned int rel_idx, unsigned int	wrt_idx)
{
	unsigned int pkt_cnt = 0;

	if (wrt_idx < rel_idx)
		pkt_cnt = rel_idx - wrt_idx - 1;
	else
		pkt_cnt = total_cnt + rel_idx - wrt_idx - 1;

	return pkt_cnt;
}

static unsigned int ring_buf_releasable(unsigned int  total_cnt,
	unsigned int rel_idx, unsigned int	rd_idx)
{
	unsigned int pkt_cnt = 0;

	if (rel_idx <= rd_idx)
		pkt_cnt = rd_idx - rel_idx;
	else
		pkt_cnt = total_cnt + rd_idx - rel_idx;

	return pkt_cnt;
}

static inline struct device *dpmaif_get_hw_device(
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	return dpmaif_ctrl->pcie_hw_info.pcie_dev;
}

/* =======================================================
 *
 * Descriptions: RX part start
 *
 * ========================================================
 */
static inline int dpmaif_set_cpu_affinity(unsigned int cpu)
{
	return set_cpus_allowed_ptr(current, cpumask_of(cpu));
}

static inline bool dpmaif_rx_push_need_reschedule(
	struct dpmaif_rx_queue *rxq)
{
	return (DPMF_CUR_CPU_INVALID ==
		rxq->cur_rx_thrd_cpu ||
		rxq->cur_rx_thrd_cpu ==
		rxq->cur_irq_cpu);
}
static inline int dpmaif_find_rx_push_cpu(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int cpu = -1;
	bool found = false;
	int i = 0;

	for_each_online_cpu(cpu) {
		found = true;

		for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
			if (cpu == dpmaif_ctrl->rxq[i].cur_irq_cpu) {
				found = false;
				break;
			}
		}

		if (found == true)
			break;
	}

	if (false == found)
		DPMF_GET_CUR_CPU(&cpu);

	return cpu;
}

static inline void dpmaif_rx_push_thrd_reschedule(
	struct dpmaif_rx_queue *rxq)
{
	int cpu = -1;
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	if (dpmaif_ctrl == NULL){
		MTK_ERR_LOG(TAG,"invalid para!\n");
		return;
	}
	cpu = dpmaif_find_rx_push_cpu(dpmaif_ctrl);
	if (likely(!dpmaif_set_cpu_affinity(cpu))) {
		rxq->cur_rx_thrd_cpu = cpu;
		MTK_DEBUG_LOG(TAG,
			"Re-schedule rxq%d push thread(pid = %d) to cpu(%d)\n",
			rxq->index, current->pid, cpu);
	} else {
		MTK_ERR_LOG(TAG,
			"Try to schedule rxq%d push thread(pid = %d) to cpu(%d) failed!\n",
			rxq->index, current->pid, cpu);
	}
}

static int dpmaif_net_rx_push_thread(void *arg)
{
	struct sk_buff *skb = NULL;
	struct dpmaif_rx_queue *queue = (struct dpmaif_rx_queue *)arg;
	struct md_dpmaif_ctrl *hif_ctrl = queue->dpmaif_ctrl;
#ifdef CCCI_SKB_TRACE
	struct ccci_per_md *per_md_data = ccci_get_per_md_data(hif_ctrl->md_id);
#endif
	int count = 0;
	int ret;
	int netif_id = 0;

	while (1) {
		if (skb_queue_empty(&queue->skb_list.skb_list)) {
			dpmaif_queue_broadcast_state(hif_ctrl, RX_FLUSH,
				MTK_IN, queue->index);
			count = 0;

			ret = wait_event_interruptible(queue->rx_wq,
				(!skb_queue_empty(&queue->skb_list.skb_list) ||
				kthread_should_stop()));
			if (ret == -ERESTARTSYS)
				continue;	/* FIXME */
		}
		if (kthread_should_stop())
			break;

		if (dpmaif_rx_push_need_reschedule(queue))
			dpmaif_rx_push_thrd_reschedule(queue);

		skb = ccci_skb_dequeue(&queue->skb_list);
		if (!skb)
			continue;

#ifdef CCCI_SKB_TRACE
		per_md_data->netif_rx_profile[6] = sched_clock();
		if (count > 0)
			skb->tstamp = sched_clock();
#endif
		/*ccci_md_recv_skb(hif_ctrl->md_id, hif_ctrl->hif_id, skb);*/
		netif_id = ((struct lhif_header *)skb->data)->netif;
		skb_pull(skb, sizeof(struct lhif_header));
		ccmni_rx_callback(hif_ctrl->ctlb, netif_id, skb, NULL);
		count++;

#ifdef CCCI_SKB_TRACE
		per_md_data->netif_rx_profile[6] = sched_clock() -
			per_md_data->netif_rx_profile[6];
		per_md_data->netif_rx_profile[5] = count;
		trace_ccci_skb_rx(per_md_data->netif_rx_profile);
#endif

		/* avoid the rx thread soft lockup */
		if (need_resched())
			cond_resched();
	}
	return 0;
}

/* SW write, Update write index of ring buffer to HW */
static int dpmaifq_set_rx_bat(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned int bat_cnt)
{
	struct dpmaif_rx_queue *rxq = &dpmaif_ctrl->rxq[q_num];
	struct dpmaif_bat_request *bat_req = rxq->bat_req;
	int ret = 0;
	unsigned short old_sw_rl_idx = 0, new_sw_wr_idx = 0, old_sw_wr_idx = 0;

	if (unlikely((rxq->que_started != true) ||
		(bat_cnt >= bat_req->bat_size_cnt))) {
		MTK_ERR_LOG(TAG, "que_start is false, bat_cnt:%d\n", bat_cnt);
		return FLOW_CHECK_ERR;
	}

	old_sw_rl_idx = bat_req->bat_rel_rd_idx;

	old_sw_wr_idx = bat_req->bat_wr_idx;
	new_sw_wr_idx = old_sw_wr_idx + bat_cnt;

	if (old_sw_rl_idx > old_sw_wr_idx) {
		if (new_sw_wr_idx >= old_sw_rl_idx) {
			MTK_ERR_LOG(TAG,
				"Rx bat flow check fail: new_sw_wr_idx >= old_sw_rl_idx\n");
			ret = FLOW_CHECK_ERR;
		}
	} else {
		if (new_sw_wr_idx >= bat_req->bat_size_cnt) {
			new_sw_wr_idx = new_sw_wr_idx - bat_req->bat_size_cnt;
			if (new_sw_wr_idx >= old_sw_rl_idx) {
				MTK_ERR_LOG(TAG,
					"Rx bat flow check fail: new_sw_wr_idx >= old_sw_rl_idx\n");
				ret = FLOW_CHECK_ERR;
			}
		}
	}

	if (ret < 0)
		goto exit;

	bat_req->bat_wr_idx = new_sw_wr_idx;

	MTK_DEBUG_LOG(TAG, "dpmaifq_set_rx_bat--bat_wr_idx: %d, bat_cnt: %d, ret: %d\n",
		bat_req->bat_wr_idx, bat_cnt, ret);

exit:
	MTK_DEBUG_LOG(TAG, "bat_cnt:%d, ret:%d\n", bat_cnt, ret);
	return ret;
}


#define GET_SKB_BY_ENTRY(skb_entry)\
	list_entry(skb_entry, struct dpmaif_skb_info, entry)

static struct dpmaif_skb_info *dpmaif_skb_dma_map(
	struct md_dpmaif_ctrl *dpmaif_ctrl, struct sk_buff *skb)
{
	struct dpmaif_skb_info *skb_info = NULL;
	unsigned long long data_bus_addr;
	size_t data_len = 0;

	if (unlikely(skb == NULL))
		goto err;

	skb_info = kmalloc(sizeof(struct dpmaif_skb_info), GFP_KERNEL);
	if (unlikely(skb_info == NULL))
		goto err;

	/* DMA mapping */
	data_len = skb_data_size(skb);
	data_bus_addr = dma_map_single(
		dpmaif_get_hw_device(dpmaif_ctrl),
		skb->data, data_len,
		DMA_FROM_DEVICE);
	if (unlikely(dma_mapping_error(dpmaif_get_hw_device(dpmaif_ctrl),
		data_bus_addr))) {
		MTK_ERR_LOG(TAG, "dma mapping fail\n");
		kfree(skb_info);
		skb_info = NULL;
		goto err;
	}

	INIT_LIST_HEAD(&skb_info->entry);
	skb_info->skb = skb;
	skb_info->data_len = data_len;
	skb_info->data_bus_addr = data_bus_addr;

#ifdef DPMAIF_DEBUG_DUMP
	MTK_DEBUG_LOG(TAG,
		"skb_info(0x%llx), skb(0x%llx), data_len(%zu), data_bus_addr(%llx)\n",
		(u64)skb_info, (u64)skb, data_len, data_bus_addr);
#endif

	return skb_info;

err:
	return NULL;
}

static void *dpmaif_alloc_skb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int size, int blocking)
{
	struct sk_buff *skb = NULL;
	unsigned int index = 0;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_info *skb_info = NULL;

	if (unlikely(size > DPMA_SKB_SIZE_MAX))
		goto from_kernel;

	for (index = 0; index < dpmaif_ctrl->skb_pool.queue_cnt; index++) {
		queue = &dpmaif_ctrl->skb_pool.queue[
			DPMA_SKB_QUEUE_CNT - 1 - index];
		if (size <= queue->size) {
			//skb = dpmaif_skb_dequeue(dpmaif_ctrl,
			//DPMA_SKB_QUEUE_CNT - 1 - index);
			skb_info = dpmaif_skb_dequeue(dpmaif_ctrl,
				DPMA_SKB_QUEUE_CNT - 1 - index);
			if (unlikely(skb_info == NULL ||
				skb_info->skb == NULL)) {
				MTK_DEBUG_LOG(TAG,
					"Dequeue from skb(%u) queue fail, try alloc form kernel\n",
					size);
				if (skb_info != NULL) {
					kfree(skb_info);
					skb_info = NULL;
				}
				goto from_kernel;
			}

			break;
		}
	}

	return skb_info;

from_kernel:
	skb = __dev_alloc_skb(size, GFP_KERNEL);
	if (likely(skb)) {
		skb_info = dpmaif_skb_dma_map(dpmaif_ctrl, skb);
		if (unlikely(skb_info  == NULL)) {
			MTK_INFO_LOG(TAG, "skb dma mapping fail\n");
			dev_kfree_skb_any(skb);
			skb = NULL;
		}
	}
	return skb_info;
}

static int dpmaif_alloc_rx_buf(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req, unsigned char q_num,
	unsigned int buf_cnt, int blocking, bool first_time)
{
	struct sk_buff *new_skb = NULL;
	struct dpmaif_bat_t *cur_bat;
	struct dpmaif_bat_skb_t *cur_skb;
	struct dpmaif_skb_info *skb_info = NULL;
	int ret = 0, ret_hw = 0;
	unsigned int alloc_cnt, i;
	unsigned int bat_cnt, bat_max_cnt;
	unsigned short bat_star_idx, cur_bat_idx;
	unsigned long long data_base_addr;
	size_t data_len = 0;
	unsigned int hw_wr_idx = 0;

	alloc_cnt = buf_cnt;
	if (alloc_cnt == 0 || alloc_cnt > bat_req->bat_size_cnt) {
		MTK_ERR_LOG(TAG, "Alloc_cnt is invalid !\n");
		return 0;
	}

	/*check bat buffer space*/
	bat_max_cnt = bat_req->bat_size_cnt;
	bat_cnt = ring_buf_writeable(bat_max_cnt, bat_req->bat_rel_rd_idx,
					bat_req->bat_wr_idx);

	MTK_DEBUG_LOG(TAG,
		"Alloc_cnt:%d, bat_size_cnt:%d, writeable bat_cnt: %d\n",
		alloc_cnt, bat_req->bat_size_cnt, bat_cnt);

	if (unlikely(alloc_cnt > bat_cnt)) {
		MTK_ERR_LOG(TAG, "Alloc bat buf not enough(%d>%d)\n",
			alloc_cnt, bat_cnt);
		return FLOW_CHECK_ERR;
	}

	bat_star_idx = bat_req->bat_wr_idx;

	/*Set buffer to be used*/
	for (i = 0 ; i < alloc_cnt ; i++) {
		cur_bat_idx = bat_star_idx + i;
		if (cur_bat_idx >= bat_max_cnt)
			cur_bat_idx = cur_bat_idx - bat_max_cnt;

		/* re-init check  */
		cur_skb = ((struct dpmaif_bat_skb_t *)bat_req->bat_skb_ptr +
			cur_bat_idx);
		if (cur_skb->skb == NULL) {
			skb_info = dpmaif_alloc_skb(
				dpmaif_ctrl, bat_req->pkt_buf_sz, blocking);
			if (likely(skb_info)) {
				new_skb = skb_info->skb;
				data_base_addr = skb_info->data_bus_addr;
				data_len = skb_info->data_len;
				/* we won't use skb_info any more, so free it */
				kfree(skb_info);
				skb_info = NULL;
			} else {
				MTK_ERR_LOG(TAG, "Dpmaif alloc skb fail\n");
				break;
			}

			if (unlikely(!new_skb)) {
				MTK_ERR_LOG(TAG, "Alloc skb(%d) fail on q%d!(%d/%d)\n",
					bat_req->pkt_buf_sz, q_num, cur_bat_idx,
					blocking);
				break;
			}

			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);

			cur_bat->buffer_addr_ext = (data_base_addr >> 32) & 0xFFFFFFFF;
			cur_bat->p_buffer_addr = data_base_addr & 0xFFFFFFFF;

			cur_skb->skb = new_skb;
			cur_skb->data_bus_addr = data_base_addr;
			cur_skb->data_len = data_len;
			MTK_DEBUG_LOG(TAG, "dpmaif_alloc_rx_buf(1)--bat_idx: %d, len: %u, base_addr: 0x%llx, addr(0x%08X %08X)--skb: 0x%016llx\r\n",
				cur_bat_idx, cur_skb->data_len, data_base_addr, 
				cur_bat->buffer_addr_ext, cur_bat->p_buffer_addr, (u64)cur_skb->skb);
		} else {
			data_base_addr = cur_skb->data_bus_addr;
			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);
			cur_bat->buffer_addr_ext = (data_base_addr >> 32) & 0xFFFFFFFF;
			cur_bat->p_buffer_addr = data_base_addr & 0xFFFFFFFF;
			MTK_DEBUG_LOG(TAG, "dpmaif_alloc_rx_buf(2)--bat_idx: %d, len: %u, base_addr: 0x%llx, addr(0x%08X %08X)--skb: 0x%016llx\r\n",
				cur_bat_idx, cur_skb->data_len, data_base_addr, 
				cur_bat->buffer_addr_ext, cur_bat->p_buffer_addr, (u64)cur_skb->skb);
		}
	}
	wmb(); /* flush data before notify HW. */
	if(unlikely(i == 0))	
		return LOW_MEMORY_SKB;

	ret = dpmaifq_set_rx_bat(dpmaif_ctrl, q_num, i);
	if (unlikely(ret < 0)) {
		return ret;
	}

	if (false == first_time)
		ret_hw = drv_dpmaif_dl_add_bat_cnt(&dpmaif_ctrl->hif_hw_info, q_num, i);

	hw_wr_idx = drv_dpmaif_dl_get_bat_wridx(&dpmaif_ctrl->hif_hw_info, DPF_RX_QNO_DFT);

	if (false == first_time
		&& hw_wr_idx != bat_req->bat_wr_idx) {
		MTK_ERR_LOG(TAG, "dpmaif_alloc_rx_buf--err: wr_idx miss match! hw_wr_idx: %d, sw_wr_idx: %d\n",
				hw_wr_idx, bat_req->bat_wr_idx);
		if (!DPMAIF_IS_SET_MD_DUMP()) {
			DPMAIF_MD_ASSERT(dpmaif_ctrl);
		}
	}

	return ret_hw < 0 ? ret_hw : ret;
}

static int dpmaifq_rel_rx_pit_entry(struct dpmaif_rx_queue *rxq,
			unsigned short rel_entry_num)
{
	unsigned short old_sw_rel_idx = 0, new_sw_rel_idx = 0,
		old_hw_wr_idx = 0;
	int ret = 0;

	if (unlikely(rxq->que_started != true))
		return 0;

	if (unlikely(rel_entry_num >= rxq->pit_size_cnt)) {
		MTK_ERR_LOG(TAG, "Release pit entry check fail\n");
		return -1;
	}

	MTK_DEBUG_LOG(TAG, "old: pit-rel/w/r-%d,%d,%d, to rel_count%d\n",
		rxq->pit_rel_rd_idx, rxq->pit_wr_idx,
		rxq->pit_rd_idx, rel_entry_num);

	MTK_DEBUG_LOG(TAG, "dpmaifq_rel_rx_pit_entry--index: %d, old: pit-rel/w/r-%d,%d,%d, to rel_count%d\n",
		rxq->index, rxq->pit_rel_rd_idx, rxq->pit_wr_idx,
		rxq->pit_rd_idx, rel_entry_num);

	old_sw_rel_idx = rxq->pit_rel_rd_idx;
	new_sw_rel_idx = old_sw_rel_idx + rel_entry_num;


	old_hw_wr_idx = rxq->pit_wr_idx;

	/*queue had empty and no need to release*/
	if (old_hw_wr_idx == old_sw_rel_idx)
		MTK_DEBUG_LOG(TAG, "(old_hw_wr_idx == old_sw_rel_idx)\n");

	if (old_hw_wr_idx > old_sw_rel_idx) {
		if (new_sw_rel_idx > old_hw_wr_idx)
			MTK_DEBUG_LOG(TAG, "(new_rel_idx > old_hw_wr_idx)\n");
	} else if (old_hw_wr_idx < old_sw_rel_idx) {
		if (new_sw_rel_idx >= rxq->pit_size_cnt) {
			new_sw_rel_idx = new_sw_rel_idx - rxq->pit_size_cnt;
			if (new_sw_rel_idx > old_hw_wr_idx)
				MTK_DEBUG_LOG(TAG,
					"(new_rel_idx > old_wr_idx)\n");
		}
	}

	ret = drv_dpmaif_dl_add_dlq_pit_remain_cnt(&rxq->dpmaif_ctrl->hif_hw_info,
		rxq->index, rel_entry_num);

	if (likely(ret == 0)) {
		rxq->pit_rel_rd_idx = new_sw_rel_idx;
	} else {
		MTK_ERR_LOG(TAG,
			"Release pit fail, pit-r/w/rel-%d,%d%d; rel_entry_num = %d, ret=%d\n",
			rxq->pit_rd_idx, rxq->pit_wr_idx, 
			rxq->pit_rel_rd_idx, rel_entry_num, ret);
	}

	return ret;
}


static inline void dpmaif_set_frag_bat_mask(struct dpmaif_rx_queue *rxq,
	unsigned int bat_idx)
{
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->frag_bat_release_lock;
	unsigned long flags = 0;

	spin_lock_irqsave(spin_lock, flags);
	if (likely(rxq->bat_frag->bat_mask[bat_idx] == 0))
		rxq->bat_frag->bat_mask[bat_idx] = 1;
	else {
		MTK_ERR_LOG(TAG,
			"Try to set a bat mask value which already has been 1!\n");
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
	}

	spin_unlock_irqrestore(spin_lock, flags);
}


static inline void dpmaif_set_pkt_bat_mask(struct dpmaif_rx_queue *rxq,
	unsigned int bat_idx)
{
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->bat_release_lock;
	unsigned long flags = 0;

	spin_lock_irqsave(spin_lock, flags);
	if (likely(rxq->bat_req->bat_mask[bat_idx] == 0))
		rxq->bat_req->bat_mask[bat_idx] = 1;
	else {
		MTK_ERR_LOG(TAG,
			"Try to set a bat mask value which already has been 1!\n");
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
	}

	spin_unlock_irqrestore(spin_lock, flags);
	MTK_DEBUG_LOG(TAG, "dpmaif_set_pkt_bat_mask--bat_idx: %d, mask: %d\r\n", bat_idx, rxq->bat_req->bat_mask[bat_idx]);
}

static int frag_bat_cur_bid_check(struct dpmaif_rx_queue *rxq,
	unsigned int cur_pit, unsigned int cur_bid)
{
	int ret = 0;
	struct dpmaif_bat_request *bat_frag = rxq->bat_frag;
	struct page *page = NULL;

	if (unlikely(cur_bid >= DPMAIF_DL_FRG_ENTRY_SIZE)) {
		MTK_ERR_LOG(TAG,
			"cur_bid[%d] err\n", cur_bid);
		ret = DATA_CHECK_FAIL;
		goto err;
	} else {
		page = ((struct dpmaif_bat_page_t *)bat_frag->bat_skb_ptr +
			cur_bid)->page;
		DP_UNUSED(cur_pit);
		if (unlikely(page == NULL)) {
			rxq->check_bid_fail_cnt++;
			ret = DATA_CHECK_FAIL;
			goto err;
		}
	}
	return 0;
err:
	return ret;
}

static void dpmaif_dl_frg_bat_handle(struct dpmaif_rx_queue *rxq,
	unsigned int cur_bid)
{
	dpmaif_set_frag_bat_mask(rxq, cur_bid);
}

static int dpmaif_alloc_rx_frag(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req, unsigned char q_num,
	unsigned int buf_cnt, int blocking, bool first_time)
{
	struct dpmaif_bat_t *cur_bat;
	struct dpmaif_bat_page_t *cur_page;
	void *data;
	struct page *page;
	unsigned long long data_base_addr;
	unsigned long offset;
	int size = L1_CACHE_ALIGN(bat_req->pkt_buf_sz);
	unsigned short cur_bat_idx;
	int ret = 0, i = 0;
	unsigned int buf_space;

	if (buf_cnt == 0 || buf_cnt > bat_req->bat_size_cnt) {
		MTK_ERR_LOG(TAG, "frag alloc_cnt is invalid !\n");
		return 0;
	}

	/*check bat buffer space*/
	buf_space = ring_buf_writeable(bat_req->bat_size_cnt,
		bat_req->bat_rel_rd_idx, bat_req->bat_wr_idx);

	MTK_DEBUG_LOG(TAG,
		"alloc_cnt:%d, bat_size_cnt:%d, writeable bat_cnt: %d\n",
		buf_cnt, bat_req->bat_size_cnt, buf_space);

	if (buf_cnt > buf_space) {
		MTK_ERR_LOG(TAG,
			"alloc rx frag not enough(%d>%d)\n",
			buf_cnt, buf_space);
		return FLOW_CHECK_ERR;
	}

	cur_bat_idx = bat_req->bat_wr_idx;

	for (i = 0; i < buf_cnt; i++) {
		cur_page = ((struct dpmaif_bat_page_t *)bat_req->bat_skb_ptr +
			cur_bat_idx);

		if (cur_page->page == NULL) {
			/* Alloc a new receive buffer*/
			/*allocates a frag from a page for receive buffer. */
			data = netdev_alloc_frag(size);/* napi_alloc_frag(size) */
			if (!data) {
				ret = LOW_MEMORY_BAT; /*-ENOMEM;*/
				break;
			}

			page = virt_to_head_page(data);
			offset = data - page_address(page);

			/* Get physical address of the RB */
			data_base_addr = dma_map_page(
				dpmaif_get_hw_device(dpmaif_ctrl),
				page, offset, bat_req->pkt_buf_sz,
				DMA_FROM_DEVICE);
			if (unlikely(dma_mapping_error(dpmaif_get_hw_device(dpmaif_ctrl),
				data_base_addr))) {
				MTK_ERR_LOG(TAG, "DMA mapping fail\n");
				put_page(virt_to_head_page(data));
				ret = DMA_MAPPING_ERR;
				break;
			}

			/* set to dpmaif HW */
			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);
			cur_bat->buffer_addr_ext = data_base_addr >> 32;
			cur_bat->p_buffer_addr =
				(unsigned int)(data_base_addr & 0xFFFFFFFF);

			/* record frag information*/
			cur_page->page = page;
			cur_page->data_bus_addr = data_base_addr;
			cur_page->offset = offset;
			cur_page->data_len = bat_req->pkt_buf_sz;
		}else {
			data_base_addr = cur_page->data_bus_addr;

			/* set to dpmaif HW */
			cur_bat = ((struct dpmaif_bat_t *)bat_req->bat_base +
				cur_bat_idx);
			cur_bat->buffer_addr_ext = data_base_addr >> 32;
			cur_bat->p_buffer_addr =
				(unsigned int)(data_base_addr & 0xFFFFFFFF);
		}

		cur_bat_idx = ring_buf_get_next_wrdx(bat_req->bat_size_cnt,
			cur_bat_idx);
	}
	wmb(); /* flush data before notify HW. */

	bat_req->bat_wr_idx = cur_bat_idx;

	/* all rxq share one frag_bat table */
	q_num = DPF_RX_QNO_DFT;

	/*notify to HW*/
	if (first_time == false)
		drv_dpmaif_dl_add_frg_cnt(&dpmaif_ctrl->hif_hw_info, q_num, i);

	return ret;
}

static int dpmaif_set_rx_frag_to_skb(struct dpmaif_rx_queue *rxq,
	struct dpmaifq_normal_pit *pkt_inf_t,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	struct sk_buff *base_skb = rx_skb_info->cur_skb;
	struct dpmaif_bat_page_t *cur_page_info = ((struct dpmaif_bat_page_t *)
		rxq->bat_frag->bat_skb_ptr + NOMAL_PIT_BID(pkt_inf_t));
	struct page *page = cur_page_info->page;

	unsigned long long data_bus_addr, data_base_addr;
	int data_offset = 0;
	unsigned int data_len;
	int ret = 0;

	/* rx current frag data unmapping */
	dma_unmap_page(
		dpmaif_get_hw_device(dpmaif_ctrl),
		cur_page_info->data_bus_addr, cur_page_info->data_len,
		DMA_FROM_DEVICE);
	if (unlikely(page == NULL)) {
		MTK_ERR_LOG(TAG, "frag check fail-bid:%d", NOMAL_PIT_BID(pkt_inf_t));
		return DATA_CHECK_FAIL;
	}

	/* 2. calculate data address && data len. */
	data_bus_addr = pkt_inf_t->data_addr_ext;
	data_bus_addr = (data_bus_addr<<32) + pkt_inf_t->p_data_addr;
	data_base_addr = (unsigned long long)cur_page_info->data_bus_addr;
	data_offset = (int)(data_bus_addr - data_base_addr);

	data_len = pkt_inf_t->data_len;

	/* 3. record to skb for user: fragment data to nr_frags */
	skb_add_rx_frag(base_skb, skb_shinfo(base_skb)->nr_frags,
		page, cur_page_info->offset + data_offset,
		data_len, cur_page_info->data_len);

	MTK_DEBUG_LOG(TAG, "frags[]: ip.id:%d, Frag_nr_num:%d\n",
		dpmaif_ut_get_packet_id((struct iphdr *)base_skb->data),
		skb_shinfo(base_skb)->nr_frags);

	MTK_DEBUG_LOG(TAG, "frags[] len: %u + %u = %u => %u\n",
			skb_headlen(base_skb), base_skb->data_len,
			base_skb->len, base_skb->truesize);

	cur_page_info->page = NULL;
	cur_page_info->offset = 0;
	cur_page_info->data_len = 0;

	return ret;
}

static int dpmaif_get_rx_frag(struct dpmaif_rx_queue *rxq,
	int blocking, struct dpmaifq_normal_pit *pkt_inf_t,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	int ret = 0;
	unsigned int cur_bid, cur_pit;

	cur_pit = rxq->pit_rd_idx;
	/*cur BID in pit info*/
	cur_bid = NOMAL_PIT_BID(pkt_inf_t); 
	MTK_DEBUG_LOG(TAG, "frag cur_bid = %d\n", cur_bid);

	/* 1.  check frag bid */
	ret = frag_bat_cur_bid_check(rxq, cur_pit, cur_bid);
	if (unlikely(ret < 0)) {
		MTK_DEBUG_LOG(TAG, "frag_bat_cur_bid_check returns %d\n", ret);
		goto err;
	}

	/* 2. set frag data to cur_skb skb_shinfo->frags[] */
	ret = dpmaif_set_rx_frag_to_skb(rxq, pkt_inf_t, rx_skb_info);
	if (ret < 0) {
		MTK_ERR_LOG(TAG,
			"dpmaif_set_rx_frag_to_skb fail, ret = %d\n", ret);
		goto err;
	}

	/* 3. handle DL Frag bat:
	 * mask bat and update BAT and reallocate buffer if needed
	 */
	dpmaif_dl_frg_bat_handle(rxq, cur_bid);

	return 0;

err:
	return ret;
}

static int bat_cur_bid_check(struct dpmaif_rx_queue *rxq,
	unsigned int cur_pit, unsigned int cur_bid)
{
	int ret = 0;
	struct dpmaif_bat_request *bat_req = rxq->bat_req;
	struct sk_buff *skb =
		((struct dpmaif_bat_skb_t *)bat_req->bat_skb_ptr +
			cur_bid)->skb;

	DP_UNUSED(cur_pit);
	if (unlikely((skb == NULL) ||
		(cur_bid >= DPMAIF_DL_BAT_ENTRY_SIZE))) {
		rxq->check_bid_fail_cnt++;
		if (skb) {
			dev_kfree_skb_any(skb);
			((struct dpmaif_bat_skb_t *)bat_req->bat_skb_ptr + cur_bid)->skb = NULL;
		}
		if (!DPMAIF_IS_SET_MD_DUMP()) {
			DPMAIF_MD_ASSERT(rxq->dpmaif_ctrl);
		}
		//DPMAIF_ASSERT(dpmaif_ctrl);
		ret = DATA_CHECK_FAIL;
	}

	return ret;
}

static inline void dpmaif_handle_tx_done_if_need(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int que_mask)
{
	int i;
	unsigned int intr_ul_que_done;

	if (likely(que_mask)) {
		drv_dpmaif_hw_ul_mask_multiple_tx_done_intr(&dpmaif_ctrl->hif_hw_info, que_mask);

		MTK_DEBUG_LOG(TAG, "UL done que_mask(0x%x)\n", que_mask);
		for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
			intr_ul_que_done = que_mask & (1 << i);
			if (intr_ul_que_done) {
				queue_delayed_work(dpmaif_ctrl->txq[i].worker,
					&dpmaif_ctrl->txq[i].dpmaif_tx_work,
					msecs_to_jiffies(dpmaif_ul_workqueue_delay_time));
			}
		}
	}
}

#define DPMF_HDL_UL_DONE_INTR_IF_NEED(dpmaif_ctrl, que_mask) {\
	if (que_mask) \
		dpmaif_handle_tx_done_if_need(dpmaif_ctrl, que_mask); \
}

static int dpmaif_check_pit_seq(struct dpmaif_rx_queue *rxq,
	struct dpmaifq_normal_pit *pit)
{
	int ret = -1;
	unsigned int expect_pit_seq = 0;
	unsigned int cur_pit_seq = 0;
	unsigned int count = 0;

	/* checks inputs */
	if (unlikely(pit == NULL)) {
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		goto exit;
	}

	expect_pit_seq = rxq->expect_pit_seq;

	while (count <= DPMF_POLL_SAME_PIT_CNT_MAX) {
		cur_pit_seq = pit->pit_seq;
		if (cur_pit_seq > DPMF_PIT_SEQ_MAX) {
			MTK_ERR_LOG(TAG,
				"txq%d Invalid PIT SEQ: current PIT SEQ(%u) > max PIT SEQ number(%u)\n",
				rxq->index, cur_pit_seq, DPMF_PIT_SEQ_MAX);
			ret = -1;
			break;
		}

		if (cur_pit_seq == expect_pit_seq) {
			/* Check result pass */
			rxq->expect_pit_seq++;
			if (rxq->expect_pit_seq >= DPMF_PIT_SEQ_MAX)
				rxq->expect_pit_seq = 0;

			rxq->pit_seq_fail_cnt = 0;
			ret = 0;

			goto exit;
		} else
			count++;

		udelay(20);
	}

	MTK_INFO_LIMITED_LOG(TAG,
		"txq%d Check PIT SEQ failed: cur_pit_seq:%u != exp_pit_seq:%u\n",
		rxq->index, cur_pit_seq, expect_pit_seq);

	rxq->pit_seq_fail_cnt++;
	if (rxq->pit_seq_fail_cnt >= DPMAIF_PIT_SEQ_CHECK_FAIL_CNT) {
		if (!DPMAIF_IS_SET_MD_DUMP()) {
			DPMAIF_MD_ASSERT(rxq->dpmaif_ctrl);
		}
		ret = -1;
		//DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		rxq->pit_seq_fail_cnt = 0;
	}

exit:
	return ret;
}

static unsigned int dpmaif_chk_avail_pkt_bat_cnt(struct dpmaif_rx_queue *rxq)
{
	unsigned int count = 0;
	unsigned int i = 0;
	unsigned int index = 0;
	unsigned char mask_val = 0;
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->bat_release_lock;
	unsigned long flags = 0;

	MTK_DEBUG_LOG(TAG,
		"bat_rel_rd_idx = %u, bat_size_cnt = %u\n",
		rxq->bat_req->bat_rel_rd_idx, rxq->bat_req->bat_size_cnt);

	for (i = 0; i < rxq->bat_req->bat_size_cnt; i++) {
		index = rxq->bat_req->bat_rel_rd_idx + i;
		if (index >= rxq->bat_req->bat_size_cnt)
			index -= rxq->bat_req->bat_size_cnt;

		spin_lock_irqsave(spin_lock, flags);
		mask_val = rxq->bat_req->bat_mask[index];
		spin_unlock_irqrestore(spin_lock, flags);

		if (mask_val == 1)
			count++;
		else
			break;
	}

	if (unlikely(count > rxq->bat_req->bat_size_cnt)) {
		MTK_ERR_LOG(TAG,
			"got available PKT_BAT count(%u) > total PKT_BAT count(%u)\n",
			count, rxq->bat_req->bat_size_cnt);
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		return 0;
	}
	MTK_DEBUG_LOG(TAG, "count = %u\n", count);

	DPMA_FT_LOG("bat-c/s/w/r/rel-%u,%u,%u,%u,%u", count,
		rxq->bat_req->bat_size_cnt, rxq->bat_req->bat_wr_idx,
		rxq->bat_req->bat_rd_idx, rxq->bat_req->bat_rel_rd_idx);

	return count;
}


static unsigned int dpmaif_chk_avail_frag_bat_cnt(
	struct dpmaif_rx_queue *rxq)
{
	unsigned int count = 0;
	unsigned int i = 0;
	unsigned int index = 0;
	unsigned char mask_val = 0;
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->frag_bat_release_lock;
	unsigned long flags = 0;

	MTK_DEBUG_LOG(TAG,
		"frag_bat_rel_rd_idx = %u, frag_bat_size_cnt = %u\n",
		rxq->bat_frag->bat_rel_rd_idx,
		rxq->bat_frag->bat_size_cnt);

	for (i = 0; i < rxq->bat_frag->bat_size_cnt; i++) {
		index = rxq->bat_frag->bat_rel_rd_idx + i;
		if (index >= rxq->bat_frag->bat_size_cnt)
			index -= rxq->bat_frag->bat_size_cnt;

		spin_lock_irqsave(spin_lock, flags);
		mask_val = rxq->bat_frag->bat_mask[index];
		spin_unlock_irqrestore(spin_lock, flags);

		if (mask_val == 1)
			count++;
		else
			break;
	}

	if (unlikely(count > rxq->bat_frag->bat_size_cnt)) {
		MTK_ERR_LOG(TAG,
			"Got available FRAG_BAT count(%u) > total FRAG_BAT count(%u)\n",
			count, rxq->bat_frag->bat_size_cnt);
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		return 0;
	}

	MTK_DEBUG_LOG(TAG, "count = %u\n", count);
	return count;
}

static int dpmaif_rel_dl_bat_entry(struct dpmaif_rx_queue *rxq,
	unsigned int rel_entry_num)
{
	unsigned char q_num = rxq->index;
	unsigned short old_sw_rel_idx = 0, new_sw_rel_idx = 0, hw_rd_idx = 0;
	unsigned int i = 0;
	unsigned int index = 0;
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->bat_release_lock;
	unsigned long flags = 0;

	if (unlikely(false == rxq->que_started))
		goto error;

	if (unlikely(rel_entry_num >= rxq->bat_req->bat_size_cnt ||
		rel_entry_num == 0)) {
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		goto error;
	}

	old_sw_rel_idx = rxq->bat_req->bat_rel_rd_idx;
	new_sw_rel_idx = old_sw_rel_idx + rel_entry_num;

	hw_rd_idx = drv_dpmaif_dl_get_bat_ridx(&rxq->dpmaif_ctrl->hif_hw_info, q_num);
	rxq->bat_req->bat_rd_idx = hw_rd_idx;
	MTK_DEBUG_LOG(TAG,
		"normal_bat_rel: bat_rd_idx = %u, old_sw_rel_idx = %u\n",
		rxq->bat_req->bat_rd_idx, old_sw_rel_idx);
	MTK_DEBUG_LOG(TAG,
		"new_sw_rel_idx = %u, bat_size_cnt = %u\n",
		new_sw_rel_idx, rxq->bat_req->bat_size_cnt);

	MTK_DEBUG_LOG(TAG, "dpmaif_rel_dl_bat_entry--rel_cnt: %d, bat_rel_rd_idx: %d, bat_rd_idx: %d, bat_wr_idx: %d",
		rel_entry_num, rxq->bat_req->bat_rel_rd_idx, rxq->bat_req->bat_rd_idx, 
		rxq->bat_req->bat_wr_idx);
	/*queue had empty and no need to release*/
	if (rxq->bat_req->bat_wr_idx == old_sw_rel_idx) {
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		goto error;
	}

	if (hw_rd_idx > old_sw_rel_idx) {
		if (new_sw_rel_idx > hw_rd_idx) {
			DPMAIF_ASSERT(rxq->dpmaif_ctrl);
			goto error;
		}
	} else if (hw_rd_idx < old_sw_rel_idx) {
		if (new_sw_rel_idx >= rxq->bat_req->bat_size_cnt) {
			new_sw_rel_idx =
				new_sw_rel_idx - rxq->bat_req->bat_size_cnt;

			if (new_sw_rel_idx > hw_rd_idx) {
				DPMAIF_ASSERT(rxq->dpmaif_ctrl);
				goto error;
			}
		}
	}

	/* reset bat mask value */
	for (i = 0; i < rel_entry_num; i++) {
		index = rxq->bat_req->bat_rel_rd_idx + i;
		if (index >= rxq->bat_req->bat_size_cnt)
			index -= rxq->bat_req->bat_size_cnt;

		spin_lock_irqsave(spin_lock, flags);
		rxq->bat_req->bat_mask[index] = 0;
		spin_unlock_irqrestore(spin_lock, flags);
	}

	rxq->bat_req->bat_rel_rd_idx = new_sw_rel_idx;

	return rel_entry_num;

error:
	return -1;
}


static int dpmaif_rel_dl_frag_bat_entry(struct dpmaif_rx_queue *rxq,
	unsigned int rel_entry_num)
{
	unsigned char q_num = rxq->index;
	unsigned short old_sw_rel_idx = 0, new_sw_rel_idx = 0, hw_rd_idx = 0;
	unsigned int i = 0;
	unsigned int index = 0;
	spinlock_t *spin_lock = &rxq->dpmaif_ctrl->frag_bat_release_lock;
	unsigned long flags = 0;

	if (unlikely(false == rxq->que_started))
		goto err;

	if (unlikely(rel_entry_num >= rxq->bat_frag->bat_size_cnt ||
		rel_entry_num == 0)) {
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		goto err;
	}
	old_sw_rel_idx = rxq->bat_frag->bat_rel_rd_idx;
	new_sw_rel_idx = old_sw_rel_idx + rel_entry_num;

	hw_rd_idx = drv_dpmaif_dl_get_frg_ridx(
		&rxq->dpmaif_ctrl->hif_hw_info, q_num);
	rxq->bat_frag->bat_rd_idx = hw_rd_idx;
	MTK_DEBUG_LOG(TAG,
		"frag_bat_rel: bat_rd_idx = %u, old_sw_rel_idx = %u\n",
		rxq->bat_frag->bat_rd_idx, old_sw_rel_idx);
	MTK_DEBUG_LOG(TAG,
		"new_sw_rel_idx = %u, bat_size_cnt = %u",
		new_sw_rel_idx, rxq->bat_frag->bat_size_cnt);

	/*queue had empty and no need to release*/
	if (rxq->bat_frag->bat_wr_idx == old_sw_rel_idx) {
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		goto err;
	}

	if (hw_rd_idx > old_sw_rel_idx) {
		if (new_sw_rel_idx > hw_rd_idx) {
			DPMAIF_ASSERT(rxq->dpmaif_ctrl);
			goto err;
		}
	} else if (hw_rd_idx < old_sw_rel_idx) {
		if (new_sw_rel_idx >= rxq->bat_frag->bat_size_cnt) {
			new_sw_rel_idx =
				new_sw_rel_idx - rxq->bat_frag->bat_size_cnt;
			if (new_sw_rel_idx > hw_rd_idx) {
				DPMAIF_ASSERT(rxq->dpmaif_ctrl);
				goto err;
			}
		}
	}

	/* reset bat mask value */
	for (i = 0; i < rel_entry_num; i++) {
		index = rxq->bat_frag->bat_rel_rd_idx + i;
		if (index >= rxq->bat_frag->bat_size_cnt)
			index -= rxq->bat_frag->bat_size_cnt;

		spin_lock_irqsave(spin_lock, flags);
		rxq->bat_frag->bat_mask[index] = 0;
		spin_unlock_irqrestore(spin_lock, flags);
	}

	rxq->bat_frag->bat_rel_rd_idx = new_sw_rel_idx;
	return rel_entry_num;

err:
	return -1;
}

static int dpmaif_dl_pit_rel_and_add(struct dpmaif_rx_queue *rxq)
{
	int ret = 0;

	if (likely(rxq->pit_remain_rel_cnt)) {
		if (rxq->pit_remain_rel_cnt >= dpmaif_pit_burst_release_cnt) {
			ret = dpmaifq_rel_rx_pit_entry(rxq,
				rxq->pit_remain_rel_cnt);
			if (likely(ret == 0)) {
				rxq->pit_remain_rel_cnt = 0;
			} else {
				MTK_ERR_LOG(TAG,
					"release pit fail, ret:%d\n", ret);
			}

			return ret;
		}
	}
	return ret;
}

static inline void dpmaif_dl_pit_add_remain_rel_cnt(
	struct dpmaif_rx_queue *rxq)
{
	rxq->pit_remain_rel_cnt++;
}

static int dpmaif_dl_pkt_bat_rel_and_add(struct dpmaif_rx_queue *rxq,
	int blocking)
{
	int ret = 0;
	unsigned int bid_cnt = 0;

	bid_cnt = dpmaif_chk_avail_pkt_bat_cnt(rxq);
	if (bid_cnt == 0)
		goto exit;

	/* batch release: DPMF_BAT_CNT_UPDATE_THRESHOLD */
	if (bid_cnt < dpmaif_bat_burst_release_cnt)
		goto exit;

	ret = dpmaif_rel_dl_bat_entry(rxq, bid_cnt);
	if (unlikely(ret <= 0)) {
		MTK_ERR_LOG(TAG, "Release PKT BAT failed!\n");
		goto exit;
	}

	ret = dpmaif_alloc_rx_buf(rxq->dpmaif_ctrl, rxq->bat_req,
		rxq->index, bid_cnt, blocking, false);

	if (unlikely(ret < 0)) {
		MTK_ERR_LOG(TAG,
			"Allocate new RX buffer failed! ret(%d)\n", ret);
		goto exit;
	}

exit:
	return ret;
}


static int dpmaif_dl_frag_bat_rel_and_add(struct dpmaif_rx_queue *rxq,
	int blocking)
{
	int ret = 0;
	unsigned int bid_cnt = 0;

	bid_cnt = dpmaif_chk_avail_frag_bat_cnt(rxq);
	if (bid_cnt == 0)
		goto exit;

	/* Frag BAT batch release: DPMF_BAT_CNT_UPDATE_THRESHOLD */
	if (bid_cnt < dpmaif_bat_burst_release_cnt)
		goto exit;

	ret = dpmaif_rel_dl_frag_bat_entry(rxq, bid_cnt);
	if (unlikely(ret <= 0)) {
		MTK_ERR_LOG(TAG, "Release PKT BAT failed!\n");
		goto exit;
	}

	ret = dpmaif_alloc_rx_frag(rxq->dpmaif_ctrl, rxq->bat_frag,
			rxq->index, bid_cnt, blocking, false);
	if (unlikely(ret < 0)) {
		MTK_DEBUG_LOG(TAG,
			"Allocate new RX buffer failed! ret(%d)\n", ret);
		goto exit;
	}

exit:
	return ret;
}

static void dpmaif_dl_pkt_bat_handle(struct dpmaif_rx_queue *rxq,
	unsigned int cur_bid)
{
	dpmaif_set_pkt_bat_mask(rxq, cur_bid);
}

static inline void dpmaif_rx_msg_pit(struct dpmaif_rx_queue *rxq,
	struct dpmaifq_msg_pit *msg_pit,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	rx_skb_info->cur_chn_idx = msg_pit->channel_id;
	rx_skb_info->check_sum = msg_pit->check_sum;
	rx_skb_info->pit_dp = msg_pit->dp;
	MTK_DEBUG_LOG(TAG,
		"rxq%d received a message pkt: channel=%d, checksum=%d, dp=%d\n",
		rxq->index, rx_skb_info->cur_chn_idx, rx_skb_info->check_sum,
		rx_skb_info->pit_dp);
}

static int dpmaif_rx_set_data_to_skb(struct dpmaif_rx_queue *rxq,
	struct dpmaifq_normal_pit *pkt_inf_t,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	struct sk_buff *new_skb = NULL;
	struct dpmaif_bat_skb_t *cur_bat_skb = ((struct dpmaif_bat_skb_t *)
		rxq->bat_req->bat_skb_ptr + NOMAL_PIT_BID(pkt_inf_t));

	unsigned long long data_bus_addr, data_base_addr;
	int data_offset = 0;
	unsigned int data_len;
	unsigned int *temp_u32;
	/* rx current skb data unmapping */
	dma_unmap_single(dpmaif_get_hw_device(dpmaif_ctrl),
		cur_bat_skb->data_bus_addr, cur_bat_skb->data_len,
		DMA_FROM_DEVICE);

	/* 2. calculate data address && data len. */
	/* cur pkt physical address(in a buffer bid pointed) */
	data_bus_addr = pkt_inf_t->data_addr_ext;
	data_bus_addr = (data_bus_addr << 32) + pkt_inf_t->p_data_addr;
	data_base_addr = (unsigned long long)cur_bat_skb->data_bus_addr;
	data_offset = (int)(data_bus_addr - data_base_addr);

	data_len = pkt_inf_t->data_len;
	/* cur pkt data len */
	/* 3. record to skb for user: wapper, enqueue */
	/* get skb which data contained pkt data */
	new_skb = cur_bat_skb->skb;
	new_skb->len = 0;
	skb_reset_tail_pointer(new_skb);
	/*set data len, data pointer*/
	skb_reserve(new_skb, data_offset);

	/* for debug: */
	if (unlikely((new_skb->tail + data_len) > new_skb->end)) {
		/*dump*/
		MTK_ERR_LOG(TAG,
			"rxq%d pkt(%d/%d): len = 0x%x, offset=0x%llx-0x%llx\n",
			rxq->index, rxq->pit_rd_idx, NOMAL_PIT_BID(pkt_inf_t),
			data_len, data_bus_addr, data_base_addr);
		MTK_ERR_LOG(TAG,
			"skb(%p, %p, 0x%x, 0x%x)\n",
			new_skb->head, new_skb->data,
			(unsigned int)new_skb->tail,
			(unsigned int)new_skb->end);
		if (rxq->pit_rd_idx > 2) {
			temp_u32 = (unsigned int *)
				((struct dpmaifq_normal_pit *)
				rxq->pit_base + rxq->pit_rd_idx - 2);
			MTK_ERR_LOG(TAG,
				"pit(%d):data(%x, %x, %x, %x, %x, %x, %x, %x, %x)\n",
				rxq->pit_rd_idx - 2, temp_u32[0], temp_u32[1],
				temp_u32[2], temp_u32[3], temp_u32[4],
				temp_u32[5], temp_u32[6],
				temp_u32[7], temp_u32[8]);
		}
		if (!DPMAIF_IS_SET_MD_DUMP()) {
			DPMAIF_MD_ASSERT(rxq->dpmaif_ctrl);
		}
		//DPMAIF_ASSERT(dpmaif_ctrl);
		return DATA_CHECK_FAIL;
	}

	dump_skb_info(new_skb, (const char *)__func__, (int)__LINE__);
	skb_put(new_skb, data_len);

#ifdef DPMAIF_DEBUG_DUMP
	dpmaif_dump_skb_ip_info(rxq->index, new_skb);
#endif

	MTK_DEBUG_LOG(TAG,
		"set_data_to_skb: rx_skb_info->cur_skb len: %u+%u = %u => %u\n",
		skb_headlen(new_skb), new_skb->data_len,
		new_skb->len, new_skb->truesize);

	rx_skb_info->cur_skb = new_skb;
	cur_bat_skb->skb = NULL;
	return 0;
}

static int dpmaif_get_rx_pkt(struct dpmaif_rx_queue *rxq,
	int blocking, struct dpmaifq_normal_pit *pkt_inf_t,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	unsigned int cur_bid, cur_pit;
	int ret = 0;
	struct sk_buff *skb = NULL;

	cur_pit = rxq->pit_rd_idx;
	/*cur BID in pit info*/
	cur_bid = NOMAL_PIT_BID(pkt_inf_t); 
	MTK_DEBUG_LOG(TAG, "normal cur_bid = %d\n", cur_bid);

	skb = ((struct dpmaif_bat_skb_t *)rxq->bat_req->bat_skb_ptr + cur_bid)->skb;

	MTK_DEBUG_LOG(TAG, "dpmaif_get_rx_pkt--cur_pit: %u, cur_bid: %u, skb: %llx\r\n",
		cur_pit, cur_bid, (u64)skb);

	/* 1. check bid */
	ret = bat_cur_bid_check(rxq, cur_pit, cur_bid);
	if (ret < 0) {
		MTK_DEBUG_LOG(TAG, "bat_cur_bid_check returns %d\n", ret);
		goto err;
	}

	/* 2. set data to skb->data. */
	ret = dpmaif_rx_set_data_to_skb(rxq, pkt_inf_t, rx_skb_info);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "rx set data to skb failed! ret = %d\n", ret);
		goto err;
	}

	/* 3. handle DL bat:
	 * mask bat, update BAT and reallocate buffer if needed
	 */
	dpmaif_dl_pkt_bat_handle(rxq, cur_bid);

	return 0;
err:
	return ret;
}

static int dpmaifq_rx_notify_hw(struct dpmaif_rx_queue *rxq, int blocking)
{
	int ret = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;

	/* normal bat release and add */
	queue_work_on(dpmaif_find_reload_cpu(dpmaif_ctrl),
		dpmaif_ctrl->bat_rel_work_queue, &dpmaif_ctrl->bat_rel_work);

	/* pit release and add */
	ret = dpmaif_dl_pit_rel_and_add(rxq);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "dlq%d update pit fail\n", rxq->index);

	MTK_DEBUG_LOG(TAG, "dpmaifq_rx_notify_hw--dlq%d pit-w/r/rel-%d,%d,%d\n",
		rxq->index, rxq->pit_wr_idx, rxq->pit_rd_idx,
		rxq->pit_rel_rd_idx);

	DPMA_FT_LOG("dlq%d pit-w/r/rel-%d,%d,%d\n",
		rxq->index, rxq->pit_wr_idx, rxq->pit_rd_idx,
		rxq->pit_rel_rd_idx);


	return ret;
}


static int dpmaif_rx_skb(struct dpmaif_rx_queue *rxq,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	struct sk_buff *new_skb = rx_skb_info->cur_skb;
	int ret = 0;
	struct lhif_header *lhif_h;
	/* for uplayer: port/ccmni */
	struct ccci_header ccci_h;

	/* for collect debug info. */
	if (rx_skb_info->pit_dp) {
		MTK_DEBUG_LOG(TAG, "dpmaif HW notifies software to drop the packet\n");
		dev_kfree_skb_any(new_skb);
		goto err;
	}

	DPMF_SET_SKB_CS_TYPE(rx_skb_info->check_sum, new_skb);

	MTK_DEBUG_LOG(TAG,
		"checksum type = %d, netif index = %d\n",
		new_skb->ip_summed, rx_skb_info->cur_chn_idx);

    MTK_DEBUG_LOG(TAG,
    	"DL skb: nr_frags:%u, skb len: %u+%u = %u=> %u\n",
    	skb_shinfo(new_skb)->nr_frags,
    	skb_headlen(new_skb), new_skb->data_len,
    	new_skb->len, new_skb->truesize);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
    dpmaif_ctrl->rx_traffic_monitor[rxq->index]++;
#endif

    if (!dpmaif_ctrl->napi_enable) {
    	/* md put the ccmni_index to the msg pkt,
            * so we need push it by self. maybe no need
            */
    	lhif_h = (struct lhif_header *)(skb_push(new_skb,
    		sizeof(struct lhif_header)));
    	lhif_h->netif = rx_skb_info->cur_chn_idx;

    	/* record before add to skb list. */
    	ccci_h = *(struct ccci_header *)new_skb->data;
    	ccci_md_add_log_history(&dpmaif_ctrl->traffic_info, MTK_IN,
    		(int)rxq->index, &ccci_h, 0);

        /* Add data to rx thread SKB list */
	    ccci_skb_enqueue(&rxq->skb_list, new_skb);
    } else {
        ccmni_rx_callback(dpmaif_ctrl->ctlb, 
                        rx_skb_info->cur_chn_idx, new_skb, NULL);
    }

err:
	rx_skb_info->cur_skb = NULL;
	return ret;
}

static int dpmaif_rx_start(struct dpmaif_rx_queue *rxq, unsigned short pit_cnt,
		int blocking, unsigned long time_limit)
{
	struct dpmaifq_normal_pit *pkt_inf_t = NULL;
#ifdef DPMAIF_DEBUG_DUMP
	struct dpmaifq_msg_pit *msg_pit = NULL;
#endif

	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	unsigned short rx_cnt;
	unsigned int pit_len = rxq->pit_size_cnt;
	unsigned int cur_pit;
	unsigned short recv_skb_cnt = 0;
	struct dpmaif_cur_rx_skb_info *cur_rx_skb_info = NULL;
	int ret = 0, ret_hw = 0;
#ifdef DATA_PATH_TP_CALC
    unsigned char dl_tp_stat_enable = g_tput_config.dl_tput_monitor_enable;
#endif

#ifdef DPMA_FTRACE_DEBUG
	unsigned int pkt_read = 0;
#endif

	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "NULL pointer!\n");
		goto error;
	}

	cur_rx_skb_info = &rxq->rx_data_info;

	dpmaif_ctrl = rxq->dpmaif_ctrl;
	cur_pit = rxq->pit_rd_idx;

	for (rx_cnt = 0; rx_cnt < pit_cnt; rx_cnt++) {
		if (cur_rx_skb_info->msg_pit_received == false) {
			if (!blocking && time_after_eq(jiffies, time_limit)) {
				MTK_DEBUG_LOG(TAG, "dlq%u rx timeout, cnt = %d/%d\n",
					rxq->index, rx_cnt, pit_cnt);
				break;
			}
		}

		/*GET_PKT_INFO_PTR(rxq, cur_pit); pit item */
		pkt_inf_t = (struct dpmaifq_normal_pit *)
			rxq->pit_base + cur_pit;

#ifdef DPMAIF_DEBUG_DUMP
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			dpmaif_dump_nor_pit_entry(
				dpmaif_ctrl->md_id, pkt_inf_t);
		} else {
			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			dpmaif_dump_msg_pit_entry(dpmaif_ctrl->md_id, msg_pit);
		}
#endif

		/* checks PIT SEQ firstly */
		if (unlikely(dpmaif_check_pit_seq(rxq, pkt_inf_t) != 0)) {
			MTK_INFO_LIMITED_LOG(TAG,
				"dlq%u checks PIT SEQ fail\n", rxq->index);
			goto error;
		}

		if (pkt_inf_t->packet_type == DES_PT_MSG) {
			if (cur_rx_skb_info->msg_pit_received == true) {
				MTK_ERR_LOG(TAG,
					"dlq%u receive repeat msg_pit err\n",
					rxq->index);
				DPMAIF_ASSERT(dpmaif_ctrl);
			}
			cur_rx_skb_info->msg_pit_received = true;
			dpmaif_rx_msg_pit(rxq,
				(struct dpmaifq_msg_pit *)pkt_inf_t,
				cur_rx_skb_info);
		} else if (pkt_inf_t->packet_type == DES_PT_PD) {
			if (pkt_inf_t->buffer_type != PKT_BUF_FRAG) {
				/*skb->data: add to skb ptr && record ptr.*/
				ret = dpmaif_get_rx_pkt(rxq, blocking,
					pkt_inf_t, cur_rx_skb_info);
			} else if (cur_rx_skb_info->cur_skb == NULL) {
				/* msg + frag pit, no data pkt received. */
				MTK_ERR_LOG(TAG,
					"rxq%d skb_idx < 0 pit/bat/frag = %d, %d; buf: %d; %d, %d\n",
					rxq->index, cur_pit,  NOMAL_PIT_BID(pkt_inf_t),
					pkt_inf_t->buffer_type, rx_cnt,
					pit_cnt);

				DPMAIF_ASSERT(dpmaif_ctrl);
				ret = DATA_CHECK_FAIL;
			} else {
				/*skb->frags[]: add to frags[]*/
				ret = dpmaif_get_rx_frag(rxq, blocking,
					pkt_inf_t, cur_rx_skb_info);
			}

			/* check rx status */
			if (ret < 0) {
				cur_rx_skb_info->err_payload = 1;
				MTK_INFO_LIMITED_LOG(TAG, "rxq%d error payload!\n", rxq->index);
				if (DPMAIF_IS_SET_MD_DUMP()) {
					MTK_ERR_LOG(TAG, "dpmaif_rx_start--already trigger md dump\n");
					return ret;
				}
			}

			if (pkt_inf_t->c_bit == 0) {
#ifdef DATA_PATH_TP_CALC
				/* DL throughput statistics */
				if (dl_tp_stat_enable) {
					if (g_dpmf_tp_stat.rx_rec_enable) {
						if (unlikely(g_dpmf_tp_stat.first_rx_pkt)) {
							g_dpmf_tp_stat.first_rx_pkt = false;
							g_dpmf_tp_stat.rx_rec_start_tm = DPMA_UT_TIME_NOW();
						}
						
						g_dpmf_tp_stat.rx_num += pkt_inf_t->data_len;
					}
				}
#endif
				if (0 == cur_rx_skb_info->err_payload)
					ret = dpmaif_rx_skb(rxq, cur_rx_skb_info);
				else {
					if (cur_rx_skb_info->cur_skb) {
						dev_kfree_skb_any(cur_rx_skb_info->cur_skb);
						cur_rx_skb_info->cur_skb = NULL;
					}
				}
					
				/*reinit cur_rx_skb_info*/
				memset(cur_rx_skb_info, 0x00,
					sizeof(struct dpmaif_cur_rx_skb_info));
				cur_rx_skb_info->msg_pit_received = false;

				if (ret < 0) {
					MTK_INFO_LIMITED_LOG(TAG, "rxq%d rx skb fail!\n", rxq->index);
				}


#ifdef DPMA_FTRACE_DEBUG
				pkt_read++;
#endif
                if (!dpmaif_ctrl->napi_enable) {
        			recv_skb_cnt++;
        			if ((recv_skb_cnt & DPMF_RX_PUSH_THRESHOLD_MASK) == 0) {
        				wake_up_all(&rxq->rx_wq);
        				recv_skb_cnt = 0;
        			}
                }
			}
		}

		/* get next pointer to get pkt data */
		cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
		rxq->pit_rd_idx = cur_pit;

		/*notify HW++;*/
		dpmaif_dl_pit_add_remain_rel_cnt(rxq);
		if (rx_cnt > 0 && (rx_cnt % DPMF_NOTIFY_RELEASE_COUNT) == 0) {
			ret_hw = dpmaifq_rx_notify_hw(rxq, blocking);
			if (ret_hw < 0)
				break;
		}
	}


	/*still need sync to SW/HW cnt*/
    if (!dpmaif_ctrl->napi_enable) {
    	if (recv_skb_cnt)
    		wake_up_all(&rxq->rx_wq);
    }

	/*update to HW*/
	if (ret_hw == 0)
		ret_hw = dpmaifq_rx_notify_hw(rxq, blocking);
	if (ret_hw < 0 && ret == 0)
		ret = ret_hw;

	MTK_DEBUG_LOG(TAG, "dlq%u-ret: %d, rx_cnt:%d\n", rxq->index, ret, rx_cnt);

#ifdef DPMA_FTRACE_DEBUG
	g_pkt_cnt_per_isr += pkt_read;
#endif

	return ret < 0 ? ret : rx_cnt;

error:
#ifdef DPMA_FTRACE_DEBUG
	g_pkt_cnt_per_isr += pkt_read;
#endif
	return ONCE_MORE;
}

static unsigned int dpmaifq_poll_rx_pit(struct dpmaif_rx_queue *rxq)
{
	unsigned int pit_cnt = 0;
	unsigned short sw_rd_idx = 0, hw_wr_idx = 0;

	if (rxq->que_started == false)
		return pit_cnt;

	sw_rd_idx = rxq->pit_rd_idx;
	hw_wr_idx = drv_dpmaif_dl_dlq_pit_get_wridx(&rxq->dpmaif_ctrl->hif_hw_info, rxq->index);
	pit_cnt = ring_buf_readable(rxq->pit_size_cnt, sw_rd_idx, hw_wr_idx);
	rxq->pit_wr_idx = hw_wr_idx;

	MTK_DEBUG_LOG(TAG, "dpmaifq_poll_rx_pit--index: %d, hw_wr_idx: %d, rd_idx: %d, cnt: %d",
		rxq->index, hw_wr_idx, rxq->pit_rd_idx, pit_cnt);

	return pit_cnt;
}

struct napi_struct *dpmaif_get_napi(struct md_dpmaif_ctrl *dpmaif_ctrl,
	int qno)
{
	struct dpmaif_rx_queue *rxq;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto error;
	}

	rxq = &dpmaif_ctrl->rxq[qno];
	if (rxq  == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif queue is a NULL pointer!\n");
		goto error;
	}

	return &(rxq->napi);

error:
	return NULL;
}

static int dpmaif_napi_rx_skb(struct dpmaif_rx_queue *rxq,
	struct dpmaif_cur_rx_skb_info *rx_skb_info)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	struct sk_buff *new_skb = rx_skb_info->cur_skb;
	int ret = 0;

	/* for collect debug info. */
	if (unlikely(rx_skb_info->pit_dp)) {
		MTK_DEBUG_LOG(TAG, "dpmaif HW notifies software to drop the packet\n");
		dev_kfree_skb_any(new_skb);
		goto err;
	}

	DPMF_SET_SKB_CS_TYPE(rx_skb_info->check_sum, new_skb);

	MTK_DEBUG_LOG(TAG, "checksum type = %d, netif index = %d\n",
		new_skb->ip_summed, rx_skb_info->cur_chn_idx);

	MTK_DEBUG_LOG(TAG, "skb len: %u+%u = %u=> %u\n",
		skb_headlen(new_skb), new_skb->data_len,
		new_skb->len, new_skb->truesize);

	/* upload to ccmni.*/
	ret = ccmni_rx_callback(dpmaif_ctrl->ctlb,
		rx_skb_info->cur_chn_idx, new_skb,  &(rxq->napi));

err:
	rx_skb_info->cur_skb = NULL;
	return ret;
}

static int dpmaif_napi_rx_start(struct dpmaif_rx_queue *rxq,
	unsigned short pit_cnt, int blocking, unsigned int budget, int *once_more)
{
	struct dpmaifq_normal_pit *pkt_inf_t = NULL;
#ifdef DPMAIF_DEBUG_DUMP
	struct dpmaifq_msg_pit *msg_pit = NULL;
#endif
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	unsigned short rx_cnt;
	unsigned int pit_len = rxq->pit_size_cnt;
	unsigned int cur_pit;
	struct dpmaif_cur_rx_skb_info *cur_rx_skb_info = NULL;
	int ret = 0, ret_hw = 0;
#ifdef DPMA_FTRACE_DEBUG
	unsigned int pkt_read = 0;
#endif
	unsigned int packets_cnt = 0;
#ifdef DATA_PATH_TP_CALC
	unsigned char dl_tp_stat_enable = g_tput_config.dl_tput_monitor_enable;
#endif

	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "NULL pointer!\n");
		DPMAIF_ASSERT(rxq->dpmaif_ctrl);
		ret = -1;
		goto err;
	}

	cur_rx_skb_info = &rxq->rx_data_info;

	dpmaif_ctrl = rxq->dpmaif_ctrl;
	cur_pit = rxq->pit_rd_idx;

	for (rx_cnt = 0; rx_cnt < pit_cnt; rx_cnt++) {
		if (cur_rx_skb_info->msg_pit_received == false) {
			/* reach budget */
			if (packets_cnt >= budget)
				break;
		}

		/*GET_PKT_INFO_PTR(rxq, cur_pit); pit item */
		pkt_inf_t = (struct dpmaifq_normal_pit *)
			rxq->pit_base + cur_pit;

#ifdef DPMAIF_DEBUG_DUMP
		if (pkt_inf_t->packet_type == DES_PT_PD) {
			dpmaif_dump_nor_pit_entry(
				dpmaif_ctrl->md_id, pkt_inf_t);
		} else {
			msg_pit = (struct dpmaifq_msg_pit *)
				rxq->pit_base + cur_pit;
			dpmaif_dump_msg_pit_entry(dpmaif_ctrl->md_id, msg_pit);
		}
#endif
		/* checks PIT SEQ firstly */
		if (unlikely(dpmaif_check_pit_seq(rxq, pkt_inf_t) != 0)) {
			MTK_INFO_LIMITED_LOG(TAG,
				"dlq%u checks PIT SEQ fail\n", rxq->index);
			ret = ONCE_MORE;
			*once_more = 1;
			goto err;
		}

		if (pkt_inf_t->packet_type == DES_PT_MSG) {
			if (cur_rx_skb_info->msg_pit_received == true) {
				MTK_ERR_LOG(TAG,
					"dlq%u receive repeat msg_pit err\n",
					rxq->index);
				DPMAIF_ASSERT(dpmaif_ctrl);
			}
			cur_rx_skb_info->msg_pit_received = true;
			dpmaif_rx_msg_pit(rxq,
				(struct dpmaifq_msg_pit *)pkt_inf_t,
				cur_rx_skb_info);
		} else if (pkt_inf_t->packet_type == DES_PT_PD) {
			if (pkt_inf_t->buffer_type != PKT_BUF_FRAG) {
				/*skb->data: add to skb ptr && record ptr.*/
				ret = dpmaif_get_rx_pkt(rxq, blocking,
					pkt_inf_t, cur_rx_skb_info);
			} else if (cur_rx_skb_info->cur_skb == NULL) {
				/* msg+frag pit, no data pkt received. */
				MTK_ERR_LOG(TAG,
					"rxq%d skb_idx < 0 pit/bat/frag = %d, %d; buf: %d; %d, %d\n",
					rxq->index, cur_pit,  NOMAL_PIT_BID(pkt_inf_t),
					pkt_inf_t->buffer_type, rx_cnt,
					pit_cnt);

				DPMAIF_ASSERT(dpmaif_ctrl);
				ret = DATA_CHECK_FAIL;
			} else {
				/*skb->frags[]: add to frags[]*/
				ret = dpmaif_get_rx_frag(rxq, blocking,
					pkt_inf_t, cur_rx_skb_info);
			}

			if (ret < 0) {
				/* move on pit index to skip error data */
				cur_rx_skb_info->err_payload = 1;
				MTK_INFO_LIMITED_LOG(TAG, "rxq%d error payload!\n", rxq->index);
			}

			if (pkt_inf_t->c_bit == 0) {
#ifdef DATA_PATH_TP_CALC
				/* throughput statistics */
				if (dl_tp_stat_enable) {
					if (g_dpmf_tp_stat.rx_rec_enable) {
						if (unlikely(g_dpmf_tp_stat.first_rx_pkt)) {
							g_dpmf_tp_stat.first_rx_pkt = false;
							g_dpmf_tp_stat.rx_rec_start_tm = DPMA_UT_TIME_NOW();
						}
						
						g_dpmf_tp_stat.rx_num += pkt_inf_t->data_len;
					}
				}
#endif
				/*last one, not msg pit, && data had rx.*/
				if (0 == cur_rx_skb_info->err_payload)
					ret = dpmaif_napi_rx_skb(rxq, cur_rx_skb_info);
				else {
					if (cur_rx_skb_info->cur_skb) {
						dev_kfree_skb_any(cur_rx_skb_info->cur_skb);
						cur_rx_skb_info->cur_skb = NULL;
					}
				}
				/*reinit cur_rx_skb_info*/
				memset(cur_rx_skb_info, 0x00,
					sizeof(struct dpmaif_cur_rx_skb_info));
				cur_rx_skb_info->msg_pit_received = false;
				if (ret < 0) {
					MTK_INFO_LIMITED_LOG(TAG, "rxq%d napi rx skb fail!\n", rxq->index);
				}
#ifdef DPMA_FTRACE_DEBUG
				pkt_read++;
#endif
				packets_cnt++;
			}
		}

		/* get next pointer to get pkt data */
		cur_pit = ring_buf_get_next_wrdx(pit_len, cur_pit);
		rxq->pit_rd_idx = cur_pit;

		/*notify HW++;*/
		dpmaif_dl_pit_add_remain_rel_cnt(rxq);
		if (rx_cnt > 0 && (rx_cnt % DPMF_NOTIFY_RELEASE_COUNT) == 0) {
			ret_hw = dpmaifq_rx_notify_hw(rxq, blocking);
			if (ret_hw < 0)
				break;
		}
	}


	/*update to HW*/
	if (ret_hw == 0)
		ret_hw = dpmaifq_rx_notify_hw(rxq, blocking);

	if (ret_hw < 0 && ret == 0)
		ret = ret_hw;

	MTK_DEBUG_LOG(TAG, "dlq%u ret: %d, rx_cnt:%d\n", rxq->index, ret, rx_cnt);

#ifdef DPMA_FTRACE_DEBUG
	g_pkt_cnt_per_isr += pkt_read;
#endif

err:
	return ret < 0 ? ret : packets_cnt;
}

/*
 * be called from NAPI context,
 * NAPI with blocking=false
 */
static int dpmaif_napi_rx_data_collect(struct md_dpmaif_ctrl *hif_ctrl,
		unsigned char q_num, int budget, int *once_more)
{
	struct dpmaif_rx_queue *rxq = &hif_ctrl->rxq[q_num];
	unsigned int cnt = 0;
	int ret = 0, real_cnt = 0;

	if (unlikely(once_more == NULL)) {
		DPMAIF_ASSERT(hif_ctrl);
		return 0;
	}

	cnt = dpmaifq_poll_rx_pit(rxq);
	MTK_DEBUG_LOG(TAG,
		"dlq%u poll rx pit return %d, budget = %d, blocking = %d\n",
		rxq->index, cnt, budget, false);

	MTK_DEBUG_LOG(TAG, "dpmaif_napi_rx_data_collect--dlq%u poll rx pit return %d, budget = %d, blocking = %d\n",
		rxq->index, cnt, budget, false);

	if (cnt) {
		DPMA_FT_LOG("start poll: pit_cnt(%u), packet_budget(%u)",
			cnt, budget);
		real_cnt = dpmaif_napi_rx_start(rxq, cnt, false, budget, once_more);
		DPMA_FT_LOG("end poll: packet_read(%d)", real_cnt);
		MTK_DEBUG_LOG(TAG, "dlq%u dpmaif_napi_rx_start return %d\n",
			rxq->index, real_cnt);

		if (unlikely(real_cnt < 0)) {
			ret = -1;
			if (real_cnt < LOW_MEMORY_TYPE_MAX) {
				MTK_ERR_LOG(TAG,
					"dlq%u rx low mem: %d\n",
					rxq->index, real_cnt);
			} else if (real_cnt <= ERROR_STOP_MAX) {
				MTK_ERR_LOG(TAG,
					"dlq%u rx ERR_STOP: %d\n",
					rxq->index, real_cnt);
			} else {
				MTK_ERR_LOG(TAG,
					"dlq%u rx ERROR: %d\n",
					rxq->index, real_cnt);
			}
		} else {
			ret = real_cnt;
		}
	} else {
		ret = 0;
	}

	return ret;
}

int dpmaif_napi_rx_poll(struct napi_struct *napi, int budget)
{
	int once_more = 0;
	int work_done = 0;
	int rx_cnt = 0;
	int each_budget = 0;
    bool wait_complete = false;
    unsigned short try_cnt = 0;
	struct dpmaif_rx_queue *rxq =
		container_of(napi, struct dpmaif_rx_queue, napi);

    atomic_set(&rxq->rx_processing, 1);
	smp_mb(); /* for cpu exec. */

	/* RPM lock */
	mtk_pm_runtime_get(rxq->dpmaif_ctrl->mtk_dev);

    mtk_pci_l_resource_lock(
		rxq->dpmaif_ctrl->mtk_dev, rxq->dpmaif_ctrl->lock_user);

    /* We check the wait result with one or several "try wait"
        for not blocking in interrupt contex*/
    do {
        wait_complete = mtk_pci_l_resource_try_wait_complete(rxq->dpmaif_ctrl->mtk_dev,
						rxq->dpmaif_ctrl->lock_user);

        if (wait_complete)
            break;
        else
            udelay(10);
        
        try_cnt++;
    } while (try_cnt < dpmaif_pcie_lock_res_try_wait_cnt); /* try wait up to 200us */

    if (!wait_complete) {
        MTK_INFO_LOG(TAG, "rxq%d NAPI try wait lock resource complete fail after %d attempts\n",
                    rxq->index, try_cnt);
        /* not use NAPI this time */
        napi_complete_done(napi, work_done);

        /* it's better not to try more times in interrupt context */
        /* we defer it to workqueue */
        queue_work(rxq->worker, &rxq->dpmaif_rxq_work);

        drv_dpmaif_clr_ip_busy_sts(&rxq->dpmaif_ctrl->hif_hw_info);
    } else {
    	if (likely(true == rxq->que_started)) {
    		do {
    			each_budget = budget - work_done;
    			if (each_budget) {
    				rx_cnt = dpmaif_napi_rx_data_collect(
    					rxq->dpmaif_ctrl,
    					rxq->index, each_budget, &once_more);
    				if (rx_cnt > 0) {
    					work_done += rx_cnt;
    				} else {
    					if (work_done == 0) {
    						/* empty interrupt */
    						rxq->dpmaif_ctrl->traffic_info.poll_pit_empty[rxq->index]++;
    					}
    					break;
    				}
    			}
    		} while (work_done <= budget && each_budget > 0 && rx_cnt > 0);

#ifdef DPMA_FTRACE_DEBUG
    		g_pkt_cnt_per_isr += work_done;
#endif

    		if (unlikely(once_more)) {
    			napi_gro_flush(napi, false);
    			work_done = budget;

                drv_dpmaif_clr_ip_busy_sts(&rxq->dpmaif_ctrl->hif_hw_info);
    		} else {
    			if (work_done < budget) {
#ifdef DPMA_FTRACE_DEBUG
    				g_total_isr++;
    				DPMA_FT_LOG(
    					"NAPI_STATISTICS: intr_index(%llu), packet_cnt(%llu) --- #%llu#%llu#",
    					g_total_isr, g_pkt_cnt_per_isr,
    					g_total_isr, g_pkt_cnt_per_isr);
    				g_pkt_cnt_per_isr = 0;
#endif
    				napi_complete_done(napi, work_done);

                    drv_dpmaif_clr_ip_busy_sts(&rxq->dpmaif_ctrl->hif_hw_info);
    				drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(&rxq->dpmaif_ctrl->hif_hw_info, rxq->index);
    				MTK_DEBUG_LOG(TAG,
    					"dlq%u complete napi: work_done(%d) < budget(%d)\n",
    					rxq->index, work_done, budget);
    			} else {
    			    drv_dpmaif_clr_ip_busy_sts(&rxq->dpmaif_ctrl->hif_hw_info);
                }
    		}
    	}
    }
    
    mtk_pci_l_resource_unlock(
            rxq->dpmaif_ctrl->mtk_dev, rxq->dpmaif_ctrl->lock_user);

	/* RPM unlock */
	mtk_pm_runtime_put(rxq->dpmaif_ctrl->mtk_dev);

    atomic_set(&rxq->rx_processing, 0);

	return work_done;
}

/*
 * may be called from workqueue or tasklet context,
 * tasklet with blocking=false
 */
static int dpmaif_rx_data_collect(struct md_dpmaif_ctrl *dpmaif_ctrl,
		unsigned char q_num, int budget, int blocking)
{
	struct dpmaif_rx_queue *rxq = &dpmaif_ctrl->rxq[q_num];
	unsigned int cnt, rd_cnt = 0, max_cnt = budget;
	int ret = ALL_CLEAR, real_cnt = 0;
	unsigned long time_limit = jiffies + msecs_to_jiffies(dpmaif_dl_workqueue_time_limit);

poll_again:
	cnt = dpmaifq_poll_rx_pit(rxq);
	MTK_DEBUG_LOG(TAG,
		"dlq%u poll rx pit return %d, budget = %d, blocking = %d\n",
		rxq->index, cnt, budget, blocking);

	if (cnt) {
		max_cnt = cnt;
		rd_cnt = (cnt > budget && !blocking) ? budget: cnt;

		DPMA_FT_LOG("start poll: pit_cnt(%u), pit_budget(%u)",
			cnt, budget);
		if (DPMAIF_IS_SET_MD_DUMP()) {
			MTK_ERR_LOG(TAG, "dpmaif_rx_data_collect(1)--already trigger md dump\n");
			return ALL_CLEAR;
		}

		real_cnt = dpmaif_rx_start(rxq, rd_cnt, blocking, time_limit);
		DPMA_FT_LOG("end poll: pit_read(%d)", real_cnt);
		MTK_DEBUG_LOG(TAG, "dlq%u dpmaif_rx_start return %d\n",
			rxq->index, real_cnt);

		if (DPMAIF_IS_SET_MD_DUMP()) {
			MTK_ERR_LOG(TAG, "dpmaif_rx_data_collect(2)--already trigger md dump\n");
			return ALL_CLEAR;
		}


		if (real_cnt < LOW_MEMORY_TYPE_MAX) {
			ret = LOW_MEMORY;
			MTK_ERR_LOG(TAG,
				"dlq%u rx low mem: %d\n", rxq->index, real_cnt);
		} else if (real_cnt <= ERROR_STOP_MAX) {
			ret = ERROR_STOP;
			MTK_ERR_LOG(TAG,
				"dlq%u rx ERR_STOP: %d\n",
				rxq->index, real_cnt);
		} else if (real_cnt < 0) {
			ret = LOW_MEMORY;
			MTK_ERR_LOG(TAG, "dlq%u rx ERROR: %d\n",
				rxq->index, real_cnt);
		} else if (real_cnt < max_cnt)
			ret = ONCE_MORE;
		else
			ret = ALL_CLEAR;
	} else {
		ret = ALL_CLEAR;
		dpmaif_ctrl->traffic_info.poll_pit_empty[0]++;
	}

	if (cnt && ret == ALL_CLEAR) {
		MTK_DEBUG_LOG(TAG, "dlq%u last cnt(%d), try poll again\n",
			rxq->index, cnt);
		goto poll_again;
	} else if (ret == ONCE_MORE) {
		MTK_DEBUG_LOG(TAG, "dlq%u try once more\n", rxq->index);
	}

#ifdef DPMA_FTRACE_DEBUG
	if (ret == ALL_CLEAR) {
		g_total_isr++;
		DPMA_FT_LOG(
			"NONE_NAPI_STATISTICS: intr_index(%llu), packet_cnt(%llu) --- #%llu#%llu#",
			g_total_isr, g_pkt_cnt_per_isr,
			g_total_isr, g_pkt_cnt_per_isr);
		g_pkt_cnt_per_isr = 0;
	}
#endif
	return ret;
}

static void dpmaif_rxq_work(struct work_struct *work)
{
	struct dpmaif_rx_queue *rxq =
		container_of(work, struct dpmaif_rx_queue, dpmaif_rxq_work);
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	int ret;

	atomic_set(&rxq->rx_processing, 1);
	smp_mb(); /* for cpu exec. */

	if (unlikely(rxq->que_started != true)) {
		ret = ALL_CLEAR;
		atomic_set(&rxq->rx_processing, 0);
		MTK_INFO_LOG(TAG, "RXQ:%d has not been started.\n", rxq->index);
		return;
	}

    dpmaif_ctrl->traffic_info.latest_q_rx_time[rxq->index] = local_clock();

	/* RPM lock */
	mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);

    mtk_pci_l_resource_lock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

    /* we can try blocking wait for lock resource here in process context */
    mtk_pci_l_resource_wait_complete(dpmaif_ctrl->mtk_dev,
						dpmaif_ctrl->lock_user);

	/* blocking=0:
		because of data performance, we want to finish the workqueue and
		reschedule the NAPI/tasklet mode after time_limit.
	*/
	ret = dpmaif_rx_data_collect(dpmaif_ctrl, rxq->index, rxq->budget, 0);

	if (ret == ONCE_MORE) {
        if (dpmaif_ctrl->napi_enable)
		    napi_schedule(&rxq->napi);
    	else
    		tasklet_hi_schedule(&rxq->dpmaif_rxq_task);

        drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
	} else if (unlikely(ret == LOW_MEMORY)) {
		/*Rx done and empty interrupt will be enabled in workqueue*/
		queue_work(rxq->worker,
			&rxq->dpmaif_rxq_work);

        drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
	} else if (unlikely(ret == ERROR_STOP)) {
		DPMAIF_ASSERT(dpmaif_ctrl);
        /*maybe we can try one more time*/
		queue_work(rxq->worker,
			&rxq->dpmaif_rxq_work);

        drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
	} else {
		drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
		drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(&dpmaif_ctrl->hif_hw_info, rxq->index);
	}

    mtk_pci_l_resource_unlock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

	/* RPM unlock */
	mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

	atomic_set(&rxq->rx_processing, 0);

}

static void dpmaif_rxq_tasklet(unsigned long data)
{
	struct dpmaif_rx_queue *rxq = (struct dpmaif_rx_queue *)data;
	struct md_dpmaif_ctrl *dpmaif_ctrl = rxq->dpmaif_ctrl;
	int ret = 0;
    unsigned short try_cnt = 0;
    bool wait_complete = false;

	atomic_set(&rxq->rx_processing, 1);
	dpmaif_ctrl->traffic_info.rx_tasket_cnt++;
	smp_mb(); /* for cpu exec. */

	if (unlikely(rxq->que_started != true)) {
		ret = ALL_CLEAR;
		atomic_set(&rxq->rx_processing, 0);
		MTK_INFO_LOG(TAG, "tasklet RXQ:%d has not been started.\n", rxq->index);
		return;
	}

    dpmaif_ctrl->traffic_info.latest_q_rx_time[rxq->index] = local_clock();

	/* RPM lock */
	mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);

    mtk_pci_l_resource_lock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

    /* We check the wait result with one or several "try wait"
        for not blocking in interrupt contex*/
    do {
        wait_complete = mtk_pci_l_resource_try_wait_complete(dpmaif_ctrl->mtk_dev,
						dpmaif_ctrl->lock_user);

        if (wait_complete)
            break;
        else
            udelay(10);
        
        try_cnt++;
    } while (try_cnt < dpmaif_pcie_lock_res_try_wait_cnt); /* try wait up to 200us */

    if (!wait_complete) {
        MTK_DEBUG_LOG(TAG, "rxq%d tasklet try wait lock resource complete fail after %d attempts\n",
                    rxq->index, try_cnt);
        /* it's better not to try more times in interrupt context */
        /* we defer it to workqueue */
        queue_work(rxq->worker,
			&rxq->dpmaif_rxq_work);

        drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
    } else {
    	ret = dpmaif_rx_data_collect(dpmaif_ctrl, rxq->index, rxq->budget, 0);
    	MTK_DEBUG_LOG(TAG,
    		"rxq%d tasklet- dpmaif_rx_data_collect return %d\n",
    		rxq->index, ret);

	if (DPMAIF_IS_SET_MD_DUMP()) {
		MTK_ERR_LOG(TAG, "dpmaif_rxq_tasklet--already trigger md dump\n");
		goto lab_md_dump;
	}

    	if (ret == ONCE_MORE) {
    		tasklet_hi_schedule(&rxq->dpmaif_rxq_task);

            drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
    	} else if (unlikely(ret == LOW_MEMORY)) {
    		/*Rx done and empty interrupt will be enabled in workqueue*/
    		queue_work(rxq->worker,
    			&rxq->dpmaif_rxq_work);

            drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
    	} else if (unlikely(ret == ERROR_STOP)) {
    		DPMAIF_ASSERT(dpmaif_ctrl);
            /*maybe we can try one more time*/
    		queue_work(rxq->worker,
    			&rxq->dpmaif_rxq_work);

            drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
    	} else {
    		drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
    		drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(&dpmaif_ctrl->hif_hw_info, rxq->index);
    	}
    }
    
lab_md_dump:
    mtk_pci_l_resource_unlock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);
    
	/* RPM unlock */
	mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

	atomic_set(&rxq->rx_processing, 0);

	MTK_DEBUG_LOG(TAG, "rxq%d tasklet result %d\n", rxq->index, ret);

}

/* =======================================================
 *
 * Descriptions:  TX part start
 *
 * ========================================================
 */

static unsigned int dpmaifq_poll_tx_drb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num)
{
	struct dpmaif_tx_queue *txq;
	unsigned int drb_cnt = 0;
	unsigned short old_sw_rd_idx = 0, new_hw_rd_idx = 0;
	unsigned int hw_read_idx = 0;
	unsigned long flags;

	txq = &dpmaif_ctrl->txq[q_num];
	if (txq->que_started == false)
		return drb_cnt;

	old_sw_rd_idx = txq->drb_rd_idx;

	hw_read_idx = drv_dpmaif_ul_get_ridx(&dpmaif_ctrl->hif_hw_info, q_num);

	new_hw_rd_idx = hw_read_idx / DPMAIF_UL_DRB_ENTRY_WORD;
	MTK_DEBUG_LOG(TAG,
		"txq(%d) read index = %d, new_hw_rd_idx = %d, old_sw_rd_idx = %d\n",
		q_num, hw_read_idx, new_hw_rd_idx, old_sw_rd_idx);

	if (new_hw_rd_idx >= DPMAIF_UL_DRB_ENTRY_SIZE) {
		MTK_ERR_LOG(TAG,
			"dpmaifq_poll_tx_drb--txq(%d) hw_read_idx: %d, new_hw_rd_idx: %d, drb_rd_idx: %d, drb_wr_idx: %d, drb_rel_rd_idx: %d\n",
			q_num, hw_read_idx, new_hw_rd_idx, txq->drb_rd_idx, txq->drb_wr_idx,
			txq->drb_rel_rd_idx);
		return 0;
	}

	if (old_sw_rd_idx <= new_hw_rd_idx)
		drb_cnt = new_hw_rd_idx - old_sw_rd_idx;
	else
		drb_cnt = txq->drb_size_cnt - old_sw_rd_idx + new_hw_rd_idx;

	spin_lock_irqsave(&txq->tx_lock, flags);
	txq->drb_rd_idx = new_hw_rd_idx;
	spin_unlock_irqrestore(&txq->tx_lock, flags);

	MTK_DEBUG_LOG(TAG,
		"txq%d: drb-w/r/rel-%u,%u,%u) drb_cnt=%u\n",
		q_num, txq->drb_wr_idx, txq->drb_rd_idx, txq->drb_rel_rd_idx, drb_cnt);

	return drb_cnt;
}

static unsigned short dpmaif_release_tx_buffer(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char q_num,
	unsigned int release_cnt)
{
	unsigned int drb_entry_num, idx;
	unsigned short cur_idx;
	struct dpmaif_drb_pd *cur_drb, *drb_base =
		(struct dpmaif_drb_pd *)(dpmaif_ctrl->txq[q_num].drb_base);
	struct sk_buff *skb_free = NULL;
	struct dpmaif_tx_queue *txq = &dpmaif_ctrl->txq[q_num];
	struct dpmaif_drb_skb *cur_drb_skb = NULL;
	unsigned long flags;
#ifdef DATA_PATH_TP_CALC
	unsigned char ul_tp_stat_enable = g_tput_config.ul_tput_monitor_enable;
#endif

	if (release_cnt <= 0)
		return 0;

	spin_lock_irqsave(&txq->tx_lock, flags);
	drb_entry_num = txq->drb_size_cnt;
	cur_idx = txq->drb_rel_rd_idx;
	spin_unlock_irqrestore(&txq->tx_lock, flags);
	MTK_DEBUG_LOG(TAG,
		"cur_idx:%d, release_cnt:%d\n", cur_idx, release_cnt);

	for (idx = 0 ; idx < release_cnt ; idx++) {
		cur_drb = drb_base + cur_idx;
		if (cur_drb->dtyp == DES_DTYP_PD) {
			MTK_DEBUG_LOG(TAG,
				"txq%d release tx drb %d\n",
				q_num, cur_idx);
			cur_drb_skb =
				((struct dpmaif_drb_skb *)txq->drb_skb_base +
				cur_idx);

			dma_unmap_single(
				dpmaif_get_hw_device(dpmaif_ctrl),
				cur_drb_skb->bus_addr, cur_drb_skb->data_len,
				DMA_TO_DEVICE);

			if (cur_drb->c_bit == 0) {
				skb_free = cur_drb_skb->skb;
				MTK_DEBUG_LOG(TAG,
					"txq%u drb_skb = 0x%llx, cur_idx = %u, skb = 0x%llx\n",
					q_num, (u64)cur_drb_skb, cur_idx, (u64)skb_free);
				if (skb_free == NULL) {
					MTK_ERR_LOG(TAG,
						"txq%u: pkt(%u): drb check fail, drb-w/r/rel-%u,%u,%u)\n",
						q_num, cur_idx, txq->drb_wr_idx,
						txq->drb_rd_idx,
						txq->drb_rel_rd_idx);
					MTK_ERR_LOG(TAG,
						" release_cnt = %u, this time index = %u\n",
						release_cnt, idx);
					DPMAIF_ASSERT(dpmaif_ctrl);
					return DATA_CHECK_FAIL;
				}

#ifdef DATA_PATH_TP_CALC
				if (ul_tp_stat_enable) {
					if (g_dpmf_tp_stat.tx_rec_enable) {
						g_dpmf_tp_stat.tx_num[1] += skb_free->len;
					}
				}
#endif

				/* release buffer */
				if (skb_free)
					dev_kfree_skb_any(skb_free);
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
				dpmaif_ctrl->tx_traffic_monitor[txq->index]++;
#endif
			}

			cur_drb_skb->skb = NULL;
		} else {
			txq->last_ch_id =
				((struct dpmaif_drb_msg *)cur_drb)->channel_id;
		}

		spin_lock_irqsave(&txq->tx_lock, flags);
		cur_idx = ring_buf_get_next_wrdx(drb_entry_num, cur_idx);
		txq->drb_rel_rd_idx = cur_idx;
		atomic_inc(&txq->tx_budget);
		spin_unlock_irqrestore(&txq->tx_lock, flags);

		if (ccmni_get_nic_cap(dpmaif_ctrl->ctlb)
			& NIC_CAP_TXBUSY_STOP) {
			if (atomic_read(&txq->tx_budget) >
				txq->drb_size_cnt / 8)
				dpmaif_queue_broadcast_state(dpmaif_ctrl,
					TX_IRQ, MTK_OUT, txq->index);
		}
	}
	if (cur_drb->c_bit != 0)
		MTK_ERR_LOG(TAG,
			"txq(%d)_done: last one: c_bit != 0 ???\n", q_num);

	return idx;
}

static int dpmaif_tx_release(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short budget)
{
	unsigned int rel_cnt, hw_rd_cnt;
	int real_rel_cnt;
	struct dpmaif_tx_queue *txq = &dpmaif_ctrl->txq[q_num];

	/* update rd idx: from HW */
	hw_rd_cnt = dpmaifq_poll_tx_drb(dpmaif_ctrl, q_num);
	rel_cnt = ring_buf_releasable(txq->drb_size_cnt,
				txq->drb_rel_rd_idx, txq->drb_rd_idx);

	if (budget != 0 && rel_cnt > budget)
		real_rel_cnt = budget;
	else
		real_rel_cnt = rel_cnt;

	MTK_DEBUG_LOG(TAG,
		"txq%d: rel:%u,%u,%u\n",
		q_num, hw_rd_cnt, rel_cnt, real_rel_cnt);

	DPMA_FT_LOG("tx start poll: drb_cnt(%u), drb_budget(%u)",
		real_rel_cnt, budget);

	if (real_rel_cnt) {
		/* release data buff */
		real_rel_cnt = dpmaif_release_tx_buffer(
			dpmaif_ctrl, q_num, real_rel_cnt);
	}

	/* not need to know release idx hw, hw just update rd, and read wrt */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_done_last_count[q_num] = real_rel_cnt;
#endif

    return ((real_rel_cnt < rel_cnt) ? ONCE_MORE : ALL_CLEAR);
}

/* check if it is spurious TX done interrupt */
/* return false indicates there are remaining spurious interrupt */
static inline bool dpmaif_no_remain_spurious_tx_done_intr(struct dpmaif_tx_queue *txq)
{
    return (dpmaifq_poll_tx_drb(txq->dpmaif_ctrl, txq->index) > 0);
}

/*=== tx done =====*/
static void dpmaif_tx_done(struct work_struct *work)
{
	struct delayed_work *dwork = to_delayed_work(work);
	struct dpmaif_tx_queue *txq =
		container_of(dwork, struct dpmaif_tx_queue, dpmaif_tx_work);
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	int ret;

	dpmaif_ctrl = txq->dpmaif_ctrl;
	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "hif_ctrl is a NULL pointer!\n");
		goto exit;
	}

    mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);

    /* lock deep sleep as early as possible */
	mtk_pci_l_resource_lock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

	MTK_DEBUG_LOG(TAG, "tx release begin\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_done_last_start_time[txq->index] = local_clock();
#endif

    /* ensure that we are not in deep sleep */
    mtk_pci_l_resource_wait_complete(dpmaif_ctrl->mtk_dev,
						dpmaif_ctrl->lock_user);

	ret = dpmaif_tx_release(dpmaif_ctrl, txq->index, txq->drb_size_cnt);
	MTK_DEBUG_LOG(TAG, "tx release done\n");

	if (ret == ONCE_MORE || 
		(drv_dpmaif_hw_check_clr_ul_done_status(&dpmaif_ctrl->hif_hw_info, txq->index) && 
		dpmaif_no_remain_spurious_tx_done_intr(txq))) {
        ret = queue_delayed_work(dpmaif_ctrl->txq[txq->index].worker,
			&dpmaif_ctrl->txq[txq->index].dpmaif_tx_work,
			msecs_to_jiffies(dpmaif_ul_workqueue_delay_time));
        /* clear IP busy here for giving more chance to device to enter low power state */
        drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
	} else {
		drv_dpmaif_clr_ip_busy_sts(&dpmaif_ctrl->hif_hw_info);
		drv_dpmaif_unmask_ul_que_interrupt(&dpmaif_ctrl->hif_hw_info, txq->index);
		DPMA_FT_LOG("unmask ulq%d", txq->index);
	}

	mtk_pci_l_resource_unlock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

    mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

exit:
	return;
}

static void set_drb_msg(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short cur_idx,
	unsigned int pkt_len, unsigned short count_l,
	unsigned char channel_id, unsigned short network_type)
{
	struct dpmaif_drb_msg *drb =
		((struct dpmaif_drb_msg *)dpmaif_ctrl->txq[q_num].drb_base +
		cur_idx);
	unsigned int *temp;
	
#ifdef DATA_PATH_TP_CALC
	count_l = 0;

	/* md mode */
	count_l |= (g_tput_config.md_tput_mode << T_DPMAIF_MD_TPUT_MODE_OFFSET);

	/* start/stop dl */
	count_l |= (g_tput_config.md_start_dl_tput << T_DPMAIF_MD_DL_CTL_OFFSET);

	/* pkt per ms*/
	count_l |= (g_tput_config.md_pkt_number_per_ms << T_DPMAIF_MD_PKT_OFFSET);
#endif

	drb->dtyp = DES_DTYP_MSG;
	drb->c_bit = 1;
	drb->packet_len = pkt_len;
	drb->count_l = count_l;
	drb->channel_id = channel_id;
	drb->l4_chk = 1;

#ifdef DATA_PATH_TP_CALC
	drb->network_type = g_tput_config.md_dl_tput_test_time;
	MTK_DEBUG_LOG(TAG, "count_l = 0x%x, network_type:%d\n",
		count_l, g_tput_config.md_dl_tput_test_time);
#else
	drb->network_type = 0;
#endif

	temp = (unsigned int *)drb;
	MTK_DEBUG_LOG(TAG,
		"txq%d 0x%llx: drb message(%d): 0x%x, 0x%x\n",
		q_num, (u64)drb, cur_idx, temp[0], temp[1]);
}

static void set_drb_payload(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short cur_idx,
	unsigned long long data_addr, unsigned int pkt_size, char last_one)
{
	struct dpmaif_drb_pd *drb =
		((struct dpmaif_drb_pd *)dpmaif_ctrl->txq[q_num].drb_base +
		cur_idx);
	unsigned int *temp;

	drb->dtyp = DES_DTYP_PD;
	if (last_one)
		drb->c_bit = 0;
	else
		drb->c_bit = 1;
	drb->data_len = pkt_size;
	drb->p_data_addr = data_addr & 0xFFFFFFFF;
	drb->data_addr_ext = (data_addr >> 32) & 0xFFFFFFFF;
	temp = (unsigned int *)drb;
	MTK_DEBUG_LOG(TAG,
		"txq%d 0x%llx: drb payload(%d): 0x%x, 0x%x, 0x%x, 0x%x\n",
		q_num, (u64)drb, cur_idx, temp[0], temp[1], temp[2], temp[3]);
}

static void record_drb_skb(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned char q_num, unsigned short cur_idx,
	struct sk_buff *skb, unsigned short is_msg, unsigned short is_frag,
	unsigned short is_last_one, dma_addr_t bus_addr, unsigned int data_len)
{
	struct dpmaif_drb_skb *drb_skb =
		((struct dpmaif_drb_skb *)dpmaif_ctrl->txq[q_num].drb_skb_base +
		cur_idx);
	unsigned int *temp;

	drb_skb->skb = skb;
	drb_skb->bus_addr = bus_addr;
	drb_skb->data_len = data_len;
	drb_skb->drb_idx = cur_idx;
	drb_skb->is_msg = is_msg;
	drb_skb->is_frag = is_frag;
	drb_skb->is_last_one = is_last_one;

	temp = (unsigned int *)drb_skb;
	MTK_DEBUG_LOG(TAG,
		"txq%d 0x%llx: drb skb(%d): 0x%x, 0x%x, 0x%x, 0x%x\n",
		q_num, (u64)drb_skb, cur_idx, temp[0], temp[1], temp[2], temp[3]);
}


#ifdef DATA_PATH_UT_LOOPBACK
void dpmaif_ut_loopback_rx_skb(struct dpmaif_rx_queue *rxq,
	struct sk_buff *skb)
{
	struct ccci_header ccci_h;
	struct lhif_header *lhif_h;

	/* remove the ccci header */
	ccci_h = *(struct ccci_header *)skb->data;
	skb_pull(skb, sizeof(struct ccci_header));
	MTK_DEBUG_LOG(TAG, "TX interface ID = %d\n", ccci_h.data[0]);

	/* UT loopback */
	dpmaif_ut_loopback_pkt(skb);

	/* add lhif header for upper layer */
	lhif_h = (struct lhif_header *)(skb_push(skb,
		sizeof(struct lhif_header)));
	lhif_h->netif = ccci_h.data[0];
	ccci_skb_enqueue(&rxq->skb_list, skb);
	wake_up_all(&rxq->rx_wq);
}
#endif

static int dpmaif_tx_send_skb_on_tx_thread(
	struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_tx_event *event)
{
	struct sk_buff *skb = event->skb;
	int qno = event->qno;
	struct dpmaif_tx_queue *txq;
	struct skb_shared_info *info = NULL;
	void *data_addr;
	unsigned int data_len;
	int ret = 0;
	unsigned short cur_idx, is_frag, is_last_one;
	struct ccci_header ccci_h;
	/* struct iphdr *iph = NULL;  add at port net layer? */
	unsigned int wt_cnt = 0, send_cnt = 0, payload_cnt = 0;
	dma_addr_t bus_addr;
	unsigned long flags;
	bool skb_pulled = false;
	int drb_wr_idx_backup = -1;
	
#ifdef DATA_PATH_TP_CALC
	unsigned char ul_tp_stat_enable = g_tput_config.ul_tput_monitor_enable;
#endif
	/* UL throughput statistics */
#ifdef DATA_PATH_TP_CALC
	if (ul_tp_stat_enable) {
		if (g_dpmf_tp_stat.tx_rec_enable) {
			if (unlikely(g_dpmf_tp_stat.first_tx_pkt)) {
				g_dpmf_tp_stat.first_tx_pkt = false;
				g_dpmf_tp_stat.tx_rec_start_tm = DPMA_UT_TIME_NOW();
			}
		}
	}
#endif

	/* 1. parameters check*/
	if (unlikely(!skb))
		return 0;

	txq = &dpmaif_ctrl->txq[qno];

	MTK_DEBUG_LOG(TAG,
		"ulq%d, drb: size:%d, w/r/rel-%d,%d,%d\n",
		qno, txq->drb_size_cnt, txq->drb_wr_idx,
		txq->drb_rd_idx, txq->drb_rel_rd_idx);

	atomic_set(&txq->tx_processing, 1);

	/* for cpu exec */
	smp_mb();

	if (unlikely((txq->que_started != true) || 
		(dpmaif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON))) {
		ret = -CCCI_ERR_HIF_NOT_POWER_ON;
		goto exit;
	}

#ifdef DATA_PATH_UT_LOOPBACK
	dpmaif_ut_loopback_rx_skb(&dpmaif_ctrl->rxq[0], skb);
	return 0;
#endif

	info = skb_shinfo(skb);

	if (unlikely(info->frag_list != NULL))
		MTK_ERR_LOG(TAG,
			"Attention:ulq%d skb frag_list not supported!\n", qno);

	payload_cnt = info->nr_frags + 1;
	/* nr_frags: frag cnt, 1: skb->data, 1: msg drb */
	send_cnt = payload_cnt + 1;

	MTK_DEBUG_LOG(TAG,
		"send_cnt=%u, tx_budget=%d, que_started=%d, tx_processing=%d\n",
		send_cnt, (int)atomic_read(&txq->tx_budget),
		(int)txq->que_started, (int)atomic_read(&txq->tx_processing));

	ccci_h = *(struct ccci_header *)skb->data;
	skb_pull(skb, sizeof(struct ccci_header));
	skb_pulled = true;

	spin_lock_irqsave(&txq->tx_lock, flags);
	/* update the drb_wr_idx */
	cur_idx = txq->drb_wr_idx;
	drb_wr_idx_backup = cur_idx;
	txq->drb_wr_idx += send_cnt;
	if (txq->drb_wr_idx >= txq->drb_size_cnt)
		txq->drb_wr_idx -= txq->drb_size_cnt;

	/* 3 send data. */
	/* 3.1 a msg drb first, then payload drb. */
	set_drb_msg(dpmaif_ctrl, txq->index, cur_idx, skb->len, 0,
				ccci_h.data[0], skb->protocol);
	record_drb_skb(dpmaif_ctrl, txq->index, cur_idx, skb, 1, 0, 0, 0, 0);
	spin_unlock_irqrestore(&txq->tx_lock, flags);

	/* for debug */
	MTK_DEBUG_LOG(TAG, "#%s#ip.id#%d\n", __func__,
		dpmaif_ut_get_packet_id((struct iphdr *)skb->data));

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	ccci_md_add_log_history(&dpmaif_ctrl->traffic_info, MTK_OUT,
		(int)txq->index, &ccci_h, 0);
#endif
	/* get next index. */
	cur_idx = ring_buf_get_next_wrdx(txq->drb_size_cnt, cur_idx);

	/* 3.2 payload drb: skb->data + frags[] */
	for (wt_cnt = 0; wt_cnt < payload_cnt; wt_cnt++) {
		/* get data_addr && data_len */
		if (wt_cnt == 0) {
			data_len = skb_headlen(skb);
			data_addr = skb->data;
			is_frag = 0;
		} else {
			skb_frag_t *frag = info->frags + wt_cnt - 1;
			data_len = skb_frag_size(frag);
			data_addr = skb_frag_address(frag);
			is_frag = 1;
		}
		if (wt_cnt == payload_cnt - 1) {
			is_last_one = 1;
		} else {
			/* set 0~(n-1) drb, mabye none */
			is_last_one = 0;
		}

		/* tx mapping */
		bus_addr = dma_map_single(
			dpmaif_get_hw_device(dpmaif_ctrl),
				data_addr, data_len, DMA_TO_DEVICE);
		if (dma_mapping_error(
			dpmaif_get_hw_device(dpmaif_ctrl), bus_addr)) {
			MTK_ERR_LOG(TAG, "dma mapping fail\n");
			ret = DMA_MAPPING_ERR;
			goto exit;
		}

		spin_lock_irqsave(&txq->tx_lock, flags);
		set_drb_payload(dpmaif_ctrl, txq->index, cur_idx, bus_addr, data_len,
			is_last_one);
		record_drb_skb(dpmaif_ctrl, txq->index, cur_idx, skb, 0, is_frag,
			is_last_one, bus_addr, data_len);
		spin_unlock_irqrestore(&txq->tx_lock, flags);

		cur_idx = ring_buf_get_next_wrdx(txq->drb_size_cnt, cur_idx);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
		dpmaif_ctrl->tx_payload_monitor[txq->index]++;
#endif

#ifdef DPMAIF_DEBUG_DUMP
    	/* dump IP data for debugging */
    	dpmaif_dump_tx_ip_packet_data(is_frag, data_addr, data_len);
#endif
	}

	/* debug: tx on ccci_channel && HW Q */
	ccci_channel_update_packet_counter(
		dpmaif_ctrl->traffic_info.logic_ch_pkt_pre_cnt, &ccci_h);
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->tx_pre_traffic_monitor[txq->index]++;
#endif
	atomic_sub(send_cnt, &txq->tx_budget);

exit:
	MTK_DEBUG_LOG(TAG,
		"send_skb end: txq%d, ret=%d, size=%d, drb-w/r/rel-%d,%d,%d\n",
		qno, ret, txq->drb_size_cnt, txq->drb_wr_idx,
		txq->drb_rd_idx, txq->drb_rel_rd_idx);

	atomic_set(&txq->tx_processing, 0);

	/* UL throughput data statistics */
#ifdef DATA_PATH_TP_CALC
	if (ul_tp_stat_enable && (ret >= 0)) {
		if (g_dpmf_tp_stat.tx_rec_enable) {
			g_dpmf_tp_stat.tx_num[0] += skb->len;
		}
	}
#endif

	/* send fail, should recover the skb data. */
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "send fail: drb_wr_idx_backup:%d, ret:%d\n",
			drb_wr_idx_backup, ret);

		if (skb_pulled == true)
			skb_push(skb, sizeof(struct ccci_header));

		if (drb_wr_idx_backup >= 0) {
			spin_lock_irqsave(&txq->tx_lock, flags);
			txq->drb_wr_idx = drb_wr_idx_backup;
			spin_unlock_irqrestore(&txq->tx_lock, flags);
		}
	}

	return ret;
}

/* must be called within protection of event_lock */
static inline void dpmaif_finish_event(struct dpmaif_tx_event *event)
{
	list_del(&event->entry);
	kfree(event);
}

static inline bool all_tx_list_is_empty(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int i = 0;
	bool is_empty = true;
	
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		if (!list_empty(&dpmaif_ctrl->txq[i].tx_event_queue)) {
			is_empty = false;
			break;
		}
	}

	return is_empty;
}

static inline int select_tx_queue(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned char i = 0;
	unsigned char txq_id = 0;
	int ret = -1;
	unsigned char txq_prio[HIF_TXQ_IN_USE] = {HIF_ACK_QUEUE, HIF_NORMAL_QUEUE};

	for (i = 0; i < HIF_TXQ_IN_USE; i++) {
		txq_id = txq_prio[dpmaif_ctrl->txq_select_times % HIF_TXQ_IN_USE];
		if (unlikely(!dpmaif_ctrl->txq[txq_id].que_started)) {
			break;
		}

		if (!list_empty(&dpmaif_ctrl->txq[txq_id].tx_event_queue)) {
			ret = txq_id;
			dpmaif_ctrl->txq_select_times++;
			break;
		}
		dpmaif_ctrl->txq_select_times++;
	}

	return ret;
}

static int txq_burst_send_skb(struct dpmaif_tx_queue *txq)
{
	int ret = LOW_MEMORY_DRB;
	unsigned long flags;
	struct dpmaif_tx_event *event = NULL;
	int i = 0;
	int drb_cnt = 0;
	int drb_remain_cnt = 0;

	spin_lock_irqsave(&txq->tx_lock, flags);
	drb_remain_cnt = ring_buf_writeable(txq->drb_size_cnt,
			txq->drb_rel_rd_idx, txq->drb_wr_idx);
	spin_unlock_irqrestore(&txq->tx_lock, flags);

	/* write DRB descriptor information */
	for (i = 0; i < DPMF_SKB_TX_BURST_CNT; i++) {
		if (list_empty(&txq->tx_event_queue)) {
			ret = 0;
			break;
		}

		spin_lock_irqsave(&txq->tx_event_lock, flags);
		event = list_first_entry(&txq->tx_event_queue,
		   struct dpmaif_tx_event, entry);
		spin_unlock_irqrestore(
			&txq->tx_event_lock, flags);

		if (drb_remain_cnt < event->drb_cnt) {
			spin_lock_irqsave(&txq->tx_lock, flags);
			drb_remain_cnt = ring_buf_writeable(txq->drb_size_cnt,
					txq->drb_rel_rd_idx, txq->drb_wr_idx);
			spin_unlock_irqrestore(&txq->tx_lock, flags);
			continue;
		}

		drb_remain_cnt -= event->drb_cnt;

		ret = dpmaif_tx_send_skb_on_tx_thread(
			txq->dpmaif_ctrl, event);

		if (unlikely(ret < 0)) {
			MTK_CRIT_LOG(TAG, "txq%d send skb fail, ret=%d\n", event->qno, ret);
			break;
		} else {
			drb_cnt += event->drb_cnt;
			spin_lock_irqsave(&txq->tx_event_lock, flags);
			dpmaif_finish_event(event);
			txq->tx_submit_skb_cnt--;
			spin_unlock_irqrestore(&txq->tx_event_lock, flags);
#ifdef DPMA_FTRACE_DEBUG
			g_pkt_cnt_per_lp_lock++;
#endif
		}
	}

	/* check send result if success */
	if (drb_cnt > 0) {
		txq->drb_lack = false;
		ret = drb_cnt;
	} else {
		if (ret == LOW_MEMORY_DRB)
			txq->drb_lack = true;
	}

	return ret;
}

static inline bool check_all_txq_drb_lack(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	bool ret = true;
	unsigned char i = 0;
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		if (!list_empty(&dpmaif_ctrl->txq[i].tx_event_queue) &&
			(dpmaif_ctrl->txq[i].drb_lack == false)) {
			ret = false;
			break;
		}
	}

	return ret;
}

static int dpmaif_tx_hw_push_thread(void *arg)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)arg;
	int ret = 0;
	bool first_time = false;
	unsigned char txq_id;
	struct dpmaif_tx_queue *txq;
	int drb_send_cnt = 0;

	while (1) {
		if (all_tx_list_is_empty(dpmaif_ctrl) ||
			(dpmaif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON)) {
			ret = wait_event_interruptible(dpmaif_ctrl->tx_wq,
				((!all_tx_list_is_empty(dpmaif_ctrl) && 
				(dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON)) ||
				kthread_should_stop()));

			if (ret == -ERESTARTSYS)
				continue;
		}

		if (kthread_should_stop())
			break;

		/* RPM get*/
		ret = mtk_pm_runtime_get_sync(dpmaif_ctrl->mtk_dev);
		if (ret < 0) {
			MTK_ERR_LOG(TAG, "rpm lock fail, ret:%d\n", ret);
			ret = -1;
			continue;
		}

		/* lock the pcie resource */
		mtk_pci_l_resource_lock(
			dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

		first_time = true;
		dpmaif_ctrl->txq_select_times = 0;
#ifdef DPMA_FTRACE_DEBUG
		g_pkt_cnt_per_lp_lock = 0;
#endif
		do {
			ret = select_tx_queue(dpmaif_ctrl);
			if (ret >= 0) {
				txq_id = (unsigned char)ret;
				txq = &dpmaif_ctrl->txq[txq_id];
				/* send skb */
				ret = txq_burst_send_skb(txq);
				if (ret > 0) {
					/* wait for the pcie resoure locked done */
					if (first_time) {
						mtk_pci_l_resource_wait_complete(dpmaif_ctrl->mtk_dev,
							dpmaif_ctrl->lock_user);
					}
					/* notify the dpmaif HW */
					drb_send_cnt = ret;
					ret = drv_dpmaif_ul_add_wcnt(&dpmaif_ctrl->hif_hw_info, txq_id,
						drb_send_cnt * DPMAIF_UL_DRB_ENTRY_WORD);
					if (ret < 0) {
						MTK_ERR_LOG(TAG, "txq%d: drv_dpmaif_ul_add_wcnt fail!\n", txq_id);
						if (ccci_fsm_get_md_state(0) == READY) {
							DPMAIF_ASSERT(dpmaif_ctrl);
						}
					}
				} else {
					DPMA_FT_LOG("ulq%d, drb: s/w/r/rel-%d,%d,%d,%d",
							txq_id, txq->drb_size_cnt, txq->drb_wr_idx,
							txq->drb_rd_idx, txq->drb_rel_rd_idx);

					/* all txq: the lack of DRB count */
					if (check_all_txq_drb_lack(dpmaif_ctrl))
						usleep_range(10, 20);
				}
			}
			first_time = false;

			/* avoid the soft lockup */
			if (need_resched())
				cond_resched();
		} while (!all_tx_list_is_empty(dpmaif_ctrl) &&
			!kthread_should_stop() && (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON));

#ifdef DPMA_FTRACE_DEBUG
		DPMA_FT_LOG("pkt_cnt_per_lp_lock:(%llu)", g_pkt_cnt_per_lp_lock);
#endif
		/* unlock the pcie resource */
		mtk_pci_l_resource_unlock(dpmaif_ctrl->mtk_dev,
			dpmaif_ctrl->lock_user);

		/* RPM put*/
		mtk_pm_runtime_put_sync(dpmaif_ctrl->mtk_dev);
	}

	return 0;
}

static int dpmaif_tx_thread_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is NULL pointer!\n");
		return -1;
	}

	init_waitqueue_head(&dpmaif_ctrl->tx_wq);
	dpmaif_ctrl->tx_thread = kthread_run(dpmaif_tx_hw_push_thread,
		dpmaif_ctrl, "dpmaif_tx_hw_push");

	return 0;
}

static int dpmaif_tx_thread_uninit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	/* stop rx thread */
	if (dpmaif_ctrl->tx_thread)
		kthread_stop(dpmaif_ctrl->tx_thread);

	return 0;
}

static unsigned char get_drb_cnt_per_skb(struct sk_buff *skb)
{
	/* normal drb (frags data + skb linear data) + msg drb*/
	return (skb_shinfo(skb)->nr_frags + 1 + 1);
}

static bool check_tx_queue_drb_available(struct dpmaif_tx_queue *txq,
	int send_drb_cnt)
{
	bool ret = true;
	unsigned long flags;
	int drb_remain_cnt;

	spin_lock_irqsave(&txq->tx_lock, flags);
	drb_remain_cnt = ring_buf_writeable(txq->drb_size_cnt,
			txq->drb_rel_rd_idx, txq->drb_wr_idx);
	spin_unlock_irqrestore(&txq->tx_lock, flags);

	MTK_DEBUG_LOG(TAG, "Writeable drb count:%d\n", drb_remain_cnt);

	/* Check tx buffer full */
	if (unlikely(drb_remain_cnt < send_drb_cnt)) {
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
		txq->busy_count++;
#endif
		ret = false;
	}
	
	return ret;
}


int dpmaif_tx_send_skb(
	unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl,
	int qno, struct sk_buff *skb, int blocking)
{
	int ret = 0;
	struct dpmaif_tx_event *event = NULL;
	unsigned long flags;
	bool tx_drb_available = true;
	struct dpmaif_tx_queue *txq;
	int send_drb_cnt = get_drb_cnt_per_skb(skb);

	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "hif_ctrl is a NULL pointer!\n");
		DPMAIF_ASSERT(dpmaif_ctrl);
		return 0;
	}

	if (unlikely(qno >= DPMAIF_TXQ_NUM)) {
		MTK_ERR_LOG(TAG, "txq(%d) > %d\n", qno, DPMAIF_TXQ_NUM);
		ret = -CCCI_ERR_INVALID_QUEUE_INDEX;
		DPMAIF_ASSERT(dpmaif_ctrl);
		goto fail;
	}

	txq = &dpmaif_ctrl->txq[qno];

	/* check tx queue drb full */
	if ((txq->tx_skb_stat++ % DPMF_SKB_TX_BURST_CNT) == 0)
		tx_drb_available = check_tx_queue_drb_available(txq, send_drb_cnt);

	if (likely((txq->tx_submit_skb_cnt < txq->tx_list_max_len) &&
			tx_drb_available)) {
		event = kmalloc(sizeof(struct dpmaif_tx_event),
			in_interrupt() ? GFP_ATOMIC : GFP_KERNEL);
		if (unlikely(!event)) {
			MTK_ERR_LOG(TAG, "qno%d: fail to alloc event\n", qno);
			ret = -EBUSY;
			goto fail;
		}

		INIT_LIST_HEAD(&event->entry);
		event->md_id = md_id;
		event->qno = qno;
		event->skb = skb;
		event->blocking = blocking;
		event->drb_cnt = send_drb_cnt;

		spin_lock_irqsave(&txq->tx_event_lock, flags);
		list_add_tail(&event->entry, &txq->tx_event_queue);
		txq->tx_submit_skb_cnt++;
		spin_unlock_irqrestore(&txq->tx_event_lock, flags);
	} else {
		/* notify to ccmni layer, ccmni should carry off the net device tx queue. */
		if (likely(ccmni_get_nic_cap(dpmaif_ctrl->ctlb)
				& NIC_CAP_TXBUSY_STOP)) {
			dpmaif_queue_broadcast_state(
				dpmaif_ctrl, TX_FULL, MTK_OUT, qno);
			MTK_CRIT_LOG(TAG, "TX FULL!\n");
		}
		ret = -EBUSY;
	}

	/* wake up the tx thread */
	wake_up(&dpmaif_ctrl->tx_wq);

fail:
	return ret;
}

/* =======================================================
 *
 * Descriptions: ISR part start
 *
 * ========================================================
 */
static void dpmaif_enable_irq(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int i = 0;
	struct dpmaif_isr_para *isr_para = NULL;

	if (atomic_cmpxchg(&dpmaif_ctrl->dpmaif_irq_enabled, 0, 1) == 0) {
		for (i = 0; i < ARRAY_SIZE(dpmaif_ctrl->isr_para); i++) {
			isr_para = &dpmaif_ctrl->isr_para[i];
			if (mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, 
				isr_para->pcie_ext_int, DRV_FALSE) != 0)
				MTK_ERR_LOG(TAG,
					"unmask DPMAIF interrupt%d failed!\n", i);
		}
	}
}

static void dpmaif_disable_irq(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int i = 0;
	struct dpmaif_isr_para *isr_para = NULL;

	if (atomic_cmpxchg(&dpmaif_ctrl->dpmaif_irq_enabled, 1, 0) == 1) {
		for (i = 0; i < ARRAY_SIZE(dpmaif_ctrl->isr_para); i++) {
			isr_para = &dpmaif_ctrl->isr_para[i];
			if (mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev,
				isr_para->pcie_ext_int, DRV_TRUE) != 0)
				MTK_ERR_LOG(TAG,
					"mask DPMAIF interrupt%d failed!\n", i);
		}
	}
}

static void dpmaif_irq_rx_done(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
	struct dpmaif_rx_queue *rxq = NULL;
	int qno = 0;

	/* get the que id*/
	qno = ffs(que_mask) - 1;
	if ((qno < 0) || (qno > (DPMAIF_RXQ_NUM - 1))) {
		MTK_ERR_LOG(TAG,
			"rxq err, qno:%u\n", qno);
		goto err;
	}

	rxq = &dpmaif_ctrl->rxq[qno];

	/* debug information colloect */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.latest_q_rx_isr_time[qno] = local_clock();
#endif

	if (dpmaif_ctrl->napi_enable)
		napi_schedule(&rxq->napi);
	else
		tasklet_hi_schedule(&dpmaif_ctrl->rxq[qno].dpmaif_rxq_task);

	/* get current CPU */
	DPMF_GET_CUR_CPU(&dpmaif_ctrl->rxq[qno].cur_irq_cpu);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.rx_done_isr_cnt[qno]++;
#endif

err:
	return;
}

static void dpmaif_irq_tx_done(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int que_mask)
{
	int i, ret;
	unsigned int intr_ul_que_done;

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		intr_ul_que_done =
			que_mask & (1 << i);
		if (intr_ul_que_done) {
			ret = queue_delayed_work(dpmaif_ctrl->txq[i].worker,
				&dpmaif_ctrl->txq[i].dpmaif_tx_work,
				msecs_to_jiffies(dpmaif_ul_workqueue_delay_time));
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.tx_done_isr_cnt[i]++;
#endif
		}
	}
}

static void dpmaif_irq_cb(struct dpmaif_isr_para *isr_para)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = isr_para->dpmaif_ctrl;
	struct dpmaif_hw_intr_st_para intr_status;
	int index = 0;
	int hw_ret = 0;

	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "hif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	memset(&intr_status, 0, sizeof(struct dpmaif_hw_intr_st_para));

	/* gets HW interrupt types */
	/* in dpmaif_hw_get_interrupt_status, we have already clear
	 * DPMAIF interrupt status
	 */
	hw_ret = drv_dpmaif_hw_get_interrupt_status(&dpmaif_ctrl->hif_hw_info,
		(void *)&intr_status, isr_para->dlq_id);
	if (hw_ret == -1) {
		MTK_ERR_LOG(TAG, "Get HW interrupt status failed!\n");
		goto exit;
	}

	/* Clear level 1 interrupt status */
	/*Clear level 2 DPMAIF interrupt status firstly,
	 * then clear level 1 PCIE interrupt status
	 * to avoid empty interrupt
	 */
	mtk_pcie_clr_ext_int_sts(dpmaif_ctrl->mtk_dev, isr_para->pcie_ext_int);

	/* handles interrupts */
	for (index = 0; index < intr_status.intr_cnt; index++) {
		switch (intr_status.intr_types[index]) {
		/* UL part */
		case DPF_INTR_UL_DONE:
			MTK_DEBUG_LOG(TAG,
				"UL interrupt: queue_mask(0x%x) UL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_tx_done(dpmaif_ctrl,
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_UL_DRB_EMPTY:
			MTK_DEBUG_LOG(TAG,
				"UL interrupt: queue_mask(0x%x) DRB empty!\n",
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_UL_MD_NOTREADY:
			MTK_DEBUG_LOG(TAG, "UL interrupt: MD not ready!\n");
			break;

		case DPF_INTR_UL_MD_PWR_NOTREADY:
			MTK_DEBUG_LOG(TAG,
				"UL interrupt: MD power not ready!\n");
			break;

		case DPF_INTR_UL_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG, "UL interrupt: length error!\n");
			DPMAIF_ASSERT(dpmaif_ctrl);
			break;

		/*DL part*/
		case DPF_INTR_DL_DONE:
			MTK_DEBUG_LOG(TAG,
				"DL interrupt: queue_mask(0x%x) DL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_rx_done(dpmaif_ctrl,
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_DL_SKB_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG, "DL interrupt: skb length error!\n");
#ifdef DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_other_isr_cnt[0]++;
#endif
			DPMAIF_ASSERT(dpmaif_ctrl);
			break;

		case DPF_INTR_DL_BATCNT_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: packet BAT count length error!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_isr_bat_len_err_cnt[0]++;
#endif
			drv_dpmaif_unmask_dl_batcnt_len_err_interrupt(&dpmaif_ctrl->hif_hw_info);
			break;

		case DPF_INTR_DL_PITCNT_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: PIT count length error!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_isr_pit_len_err_cnt[0]++;
#endif
			drv_dpmaif_unmask_dl_pitcnt_len_err_interrupt(&dpmaif_ctrl->hif_hw_info);
			break;

		case DPF_INTR_DL_PKT_EMPTY_SET:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: packet BAT buffer empty!\n");
			break;

		case DPF_INTR_DL_FRG_EMPTY_SET:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: fragment BAT buffer empty!\n");
			break;

		case DPF_INTR_DL_MTU_ERR:
			MTK_INFO_LIMITED_LOG(TAG, "DL interrupt: MTU size error!\n");
			DPMAIF_ASSERT(dpmaif_ctrl);
			break;

		case DPF_INTR_DL_FRGCNT_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: fragment BAT count length error!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_full_cnt++;
#endif
			break;

		case DPF_DL_INT_DLQ0_PITCNT_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: DLQ0 PIT count length error!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_isr_pit_len_err_cnt[
				DPF_RX_QNO_DFT]++;
#endif
			drv_dpmaif_dlq_unmask_rx_pit_cnt_len_err_intr(
				&dpmaif_ctrl->hif_hw_info, DPF_RX_QNO_DFT);
			break;

		case DPF_DL_INT_DLQ1_PITCNT_LEN_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: DLQ1 PIT count length error!\n");
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
			dpmaif_ctrl->traffic_info.rx_isr_pit_len_err_cnt[
				DPF_RX_QNO1]++;
#endif
			drv_dpmaif_dlq_unmask_rx_pit_cnt_len_err_intr(
				&dpmaif_ctrl->hif_hw_info, DPF_RX_QNO1);
			break;

		case DPF_DL_INT_HPC_ENT_TYPE_ERR:
			MTK_INFO_LIMITED_LOG(TAG,
				"DL interrupt: HPC ENT type error!\n");
			break;

		case DPF_INTR_DL_DLQ0_DONE:
			MTK_DEBUG_LOG(TAG,
				"DL DLQ0 interrupt: queue_mask(0x%x) DL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_rx_done(dpmaif_ctrl,
				intr_status.intr_queues[index]);
			break;

		case DPF_INTR_DL_DLQ1_DONE:
			MTK_DEBUG_LOG(TAG,
				"DL DLQ1 interrupt: queue_mask(0x%x) DL done\n",
				intr_status.intr_queues[index]);
			dpmaif_irq_rx_done(dpmaif_ctrl,
				intr_status.intr_queues[index]);
			break;

		default:
			MTK_DEBUG_LOG(TAG,
				"DL interrupt: unknown interrupt!\n");
		}
	}

exit:
	return;
}

static int dpmaif_isr(void *data)
{
	unsigned char ext_int = 0;
	struct dpmaif_isr_para *isr_para = (struct dpmaif_isr_para *)data;
	struct md_dpmaif_ctrl *dpmaif_ctrl = isr_para->dpmaif_ctrl;

	if (dpmaif_ctrl->dpmaif_state != HIFDPMAIF_STATE_PWRON) {
		drv_dpmaif_hw_dump_interrupt_status(&dpmaif_ctrl->hif_hw_info);
		MTK_ERR_LOG(TAG, "the unexpected dpmaif isr!");
		goto exit;
	}

	ext_int = isr_para->pcie_ext_int;

	// mask PCIE interrupt first
	mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, ext_int, DRV_TRUE);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_ctrl->traffic_info.latest_isr_time = local_clock();
#endif

	dpmaif_irq_cb(isr_para);
	mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, ext_int, DRV_FALSE);

exit:
	return IRQ_HANDLED;
}


/* =======================================================
 *
 * Descriptions: State part start(1/3): init(RX) -- 1.1.2 rx sw init
 *
 * ========================================================
 */
static int dpmaif_bat_init(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req,
	enum bat_type buf_type)
{
	int sw_buf_size = (buf_type == FRAG_BUF) ?
		sizeof(struct dpmaif_bat_page_t) :
		sizeof(struct dpmaif_bat_skb_t);

	bat_req->bat_size_cnt = (buf_type == FRAG_BUF) ?
		DPMAIF_DL_FRG_ENTRY_SIZE :
		DPMAIF_DL_BAT_ENTRY_SIZE;

	bat_req->skb_pkt_cnt = bat_req->bat_size_cnt;
	bat_req->pkt_buf_sz = (buf_type == FRAG_BUF) ?
		DPMAIF_BUF_FRAG_SIZE :
		DPMAIF_BUF_PKT_SIZE;

	bat_req->bat_rd_idx = 0;
	bat_req->bat_wr_idx = 0;
	bat_req->bat_rel_rd_idx = 0;

	/* alloc buffer for HW && AP SW */
#if (DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
	 bat_req->bat_base = dma_alloc_coherent(
		dpmaif_get_hw_device(dpmaif_ctrl),
		(bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)),
		&bat_req->bat_bus_addr, GFP_KERNEL);
#else
	bat_req->bat_base = dma_pool_alloc(dpmaif_ctrl->rx_bat_dmapool,
		GFP_KERNEL, &bat_req->bat_bus_addr);
#endif

	/* alloc buffer for AP SW to record skb information */
	bat_req->bat_skb_ptr =
		kzalloc((bat_req->skb_pkt_cnt * sw_buf_size), GFP_KERNEL);

	if (bat_req->bat_base == NULL || bat_req->bat_skb_ptr == NULL) {
		MTK_ERR_LOG(TAG, "buf_type:%d, bat request fail\n", buf_type);
		return LOW_MEMORY_BAT;
	}

	memset(bat_req->bat_base, 0, (bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)));

	/* alloc buffer for BAT mask */
	bat_req->bat_mask = kcalloc(bat_req->bat_size_cnt,
		sizeof(unsigned char), GFP_KERNEL);
	if (bat_req->bat_mask == NULL) {
		MTK_ERR_LOG(TAG, "buf_type:%d, bat mask alloc fail\n", buf_type);
		return LOW_MEMORY_BAT;
	}

	MTK_INFO_LOG(TAG,
		"buf_type:%d, bat_base=0x%llx, bat_bus_addr=0x%llx, bat_size_cnt=%u, skb_ptr=0x%llx, bat_mask=0x%llx\n",
		buf_type, (u64)bat_req->bat_base, bat_req->bat_bus_addr,
		bat_req->bat_size_cnt, (u64)bat_req->bat_skb_ptr, (u64)bat_req->bat_mask);

	atomic_set(&bat_req->refcnt, 0);

	return 0;
}

static void dpmaif_bat_rel(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req)
{
	struct dpmaif_bat_skb_t *cur_skb = NULL;
	unsigned int index = 0;

	if (unlikely(bat_req == NULL || dpmaif_ctrl == NULL))
		return;

	if (!atomic_dec_and_test(&bat_req->refcnt))
		return;

	kfree(bat_req->bat_mask);
	bat_req->bat_mask = NULL;

	if (bat_req->bat_skb_ptr) {
		for (index = 0; index < bat_req->bat_size_cnt; index++) {
			cur_skb =
				((struct dpmaif_bat_skb_t *)
				bat_req->bat_skb_ptr + index);

			if (cur_skb->skb) {
				dma_unmap_single(
					dpmaif_get_hw_device(dpmaif_ctrl),
					cur_skb->data_bus_addr,
					cur_skb->data_len,
					DMA_FROM_DEVICE);

				kfree_skb(cur_skb->skb);
				cur_skb->skb = NULL;
			}
		}

		kfree(bat_req->bat_skb_ptr);
		bat_req->bat_skb_ptr = NULL;
	}

	if (bat_req->bat_base) {
#if (DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(dpmaif_ctrl),
			(bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)),
			bat_req->bat_base,
			bat_req->bat_bus_addr);
#else
		dma_pool_free(dpmaif_ctrl->rx_bat_dmapool, bat_req->bat_base,
			bat_req->bat_bus_addr);
#endif
	}
}

static void dpmaif_frag_bat_rel(struct md_dpmaif_ctrl *dpmaif_ctrl,
	struct dpmaif_bat_request *bat_req)
{
	unsigned int index = 0;
	struct page *page = NULL;
	struct dpmaif_bat_page_t *cur_page = NULL;

	if (unlikely(bat_req == NULL || dpmaif_ctrl == NULL))
		return;

	if (!atomic_dec_and_test(&bat_req->refcnt))
		return;

	kfree(bat_req->bat_mask);
	bat_req->bat_mask = NULL;

	if (bat_req->bat_skb_ptr) {
		for (index = 0; index < bat_req->bat_size_cnt; index++) {
			cur_page = ((struct dpmaif_bat_page_t *)
				bat_req->bat_skb_ptr + index);
			page = cur_page->page;
			if (page != NULL) {
				/* rx unmapping */
				dma_unmap_page(
					dpmaif_get_hw_device(dpmaif_ctrl),
					cur_page->data_bus_addr,
					cur_page->data_len,
					DMA_FROM_DEVICE);
				put_page(page);
				cur_page->page = NULL;
			}
		}
		kfree(bat_req->bat_skb_ptr);
		bat_req->bat_skb_ptr = NULL;
	}

	if (bat_req->bat_base) {
#if (DPMAIF_DL_BAT_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(dpmaif_ctrl),
			(bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)),
			bat_req->bat_base,
			bat_req->bat_bus_addr);
#else
		dma_pool_free(dpmaif_ctrl->rx_bat_dmapool, bat_req->bat_base,
			bat_req->bat_bus_addr);
#endif
	}
}

static int dpmaif_rx_buf_init(struct dpmaif_rx_queue *rxq)
{
	int ret = 0;

	/* PIT buffer init */
	rxq->pit_size_cnt = DPMAIF_DL_PIT_ENTRY_SIZE;
	rxq->pit_rd_idx = 0;
	rxq->pit_wr_idx = 0;
	rxq->pit_rel_rd_idx = 0;
	rxq->expect_pit_seq = 0;
	rxq->pit_remain_rel_cnt = 0;

	rxq->cur_irq_cpu = DPMF_CUR_CPU_INVALID;
	rxq->cur_rx_thrd_cpu = DPMF_CUR_CPU_INVALID;
	rxq->pit_seq_fail_cnt = 0;

	memset(&rxq->rx_data_info, 0x00, sizeof(struct dpmaif_cur_rx_skb_info));
	rxq->rx_data_info.msg_pit_received = false;

	/* PIT init */
#if (DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
	rxq->pit_base = dma_alloc_coherent(
		dpmaif_get_hw_device(rxq->dpmaif_ctrl),
		(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)),
		&rxq->pit_bus_addr, GFP_KERNEL);
#else
	rxq->pit_base = dma_pool_alloc(rxq->dpmaif_ctrl->rx_pit_dmapool,
		GFP_KERNEL, &rxq->pit_bus_addr);
#endif

	if (rxq->pit_base == NULL) {
		MTK_ERR_LOG(TAG, "pit request fail\n");
		return LOW_MEMORY_PIT;
	}

	MTK_DEBUG_LOG(TAG, "sizeof(normal pit) = %lu, sizeof(msg pit) = %lu\n",
		sizeof(struct dpmaifq_normal_pit),
		sizeof(struct dpmaifq_msg_pit));

	MTK_INFO_LOG(TAG,
		"rxq%d: pit_base=0x%llx, pit_bus_addr=0x%llx, pit_size_cnt=%u\n",
		rxq->index, (u64)rxq->pit_base,
		rxq->pit_bus_addr, rxq->pit_size_cnt);

	memset(rxq->pit_base, 0, DPMAIF_DL_PIT_SIZE);

	/* BAT init */
	/* RXQ BAT table init */
	rxq->bat_req = &rxq->dpmaif_ctrl->bat_req;
	atomic_inc(&rxq->bat_req->refcnt);

	/* RXQ Frag BAT table init*/
	rxq->bat_frag = &rxq->dpmaif_ctrl->bat_frag;
	atomic_inc(&rxq->bat_frag->refcnt);

#ifdef DPMAIF_DEBUG_DUMP
	dpmaif_dump_rxq_remain(rxq->dpmaif_ctrl, rxq->index, 0);
#endif

	return ret;
}

static void dpmaif_rx_buf_rel(struct dpmaif_rx_queue *rxq)
{
	if (unlikely(rxq == NULL || rxq->dpmaif_ctrl == NULL))
		return;

	dpmaif_bat_rel(rxq->dpmaif_ctrl, rxq->bat_req);
	dpmaif_frag_bat_rel(rxq->dpmaif_ctrl, rxq->bat_frag);

	if (rxq->pit_base) {
#if (DPMAIF_DL_PIT_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(rxq->dpmaif_ctrl),
			(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)),
			rxq->pit_base,
			rxq->pit_bus_addr);
#else
		dma_pool_free(rxq->dpmaif_ctrl->rx_pit_dmapool, rxq->pit_base,
			rxq->pit_bus_addr);
#endif
	}
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(RX) -- 1.1.0 rx init
 *
 * =======================================================
 */
static int dpmaif_rxq_init(struct dpmaif_rx_queue *queue)
{
	int ret = -1;

	/* rxq data buffer(pit, bat...) init */
	ret = dpmaif_rx_buf_init(queue);
	if (ret) {
		MTK_ERR_LOG(TAG, "RX buffer init fail, %d\n", ret);
		return ret;
	}

    INIT_WORK(&queue->dpmaif_rxq_work, dpmaif_rxq_work);
    queue->worker = alloc_workqueue("dpmaif_rx%d_worker",
			WQ_UNBOUND | WQ_MEM_RECLAIM | WQ_HIGHPRI, 1, queue->index);

	/* init none napi resources */
	if (queue->dpmaif_ctrl->napi_enable == false) {
		tasklet_init(&queue->dpmaif_rxq_task, dpmaif_rxq_tasklet,
			(unsigned long)queue);

		/* rx push thread and skb list init */
		init_waitqueue_head(&queue->rx_wq);
		ccci_skb_queue_init(&queue->skb_list, queue->bat_req->skb_pkt_cnt,
			SKB_RX_LIST_MAX_LEN, 0);
		queue->rx_thread = kthread_run(dpmaif_net_rx_push_thread,
			queue, "dpmaif_rx%d_push", queue->index);
	}

	return 0;
}

void ccci_skb_queue_rel(struct ccci_skb_queue *queue)
{
	struct sk_buff *skb = NULL;

	if (unlikely(queue == NULL))
		return;

	while ((skb = skb_dequeue(&queue->skb_list)) != NULL) {
		kfree_skb(skb);
		skb = NULL;
	}
}

static void dpmaif_rxq_rel(struct dpmaif_rx_queue *queue)
{
	if (unlikely(queue == NULL))
		return;

    
    if (queue->worker) {
        flush_workqueue(queue->worker);
        destroy_workqueue(queue->worker);
    }
    
	if (queue->dpmaif_ctrl->napi_enable == false) {
		if (queue->rx_thread)
			kthread_stop(queue->rx_thread);

		
		tasklet_disable(&queue->dpmaif_rxq_task);
		tasklet_kill(&queue->dpmaif_rxq_task);

		ccci_skb_queue_rel(&queue->skb_list);
	}

	dpmaif_rx_buf_rel(queue);
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(TX) -- 1.2.2 tx sw init
 *
 * ========================================================
 */
static int dpmaif_tx_buf_init(struct dpmaif_tx_queue *txq)
{
	int ret = 0;

	/* DRB buffer init */
	txq->drb_size_cnt = DPMAIF_UL_DRB_ENTRY_SIZE;

	/* alloc buffer for HW && AP SW */
#if (DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
	txq->drb_base = dma_alloc_coherent(
		dpmaif_get_hw_device(txq->dpmaif_ctrl),
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)),
		&txq->drb_bus_addr, GFP_KERNEL);
#else
	txq->drb_base = dma_pool_alloc(txq->dpmaif_ctrl->tx_drb_dmapool,
		GFP_KERNEL, &txq->drb_bus_addr);
#endif

	if (txq->drb_base == NULL) {
		MTK_ERR_LOG(TAG, "drb request fail\n");
		return LOW_MEMORY_DRB;
	}

	memset(txq->drb_base, 0, DPMAIF_UL_DRB_SIZE);

	/* alloc buffer for AP SW to record the skb information */
	txq->drb_skb_base =
		kzalloc((txq->drb_size_cnt * sizeof(struct dpmaif_drb_skb)),
		GFP_KERNEL);
	if (txq->drb_skb_base == NULL) {
		MTK_ERR_LOG(TAG, "drb skb buffer request fail\n");
		return LOW_MEMORY_DRB;
	}

	MTK_INFO_LOG(TAG,
		"txq%d: drb_base=0x%llx, drb_bus_addr=0x%llx, drb_size_cnt=%u, skb_ptr=0x%llx\n",
		txq->index, (u64)txq->drb_base, txq->drb_bus_addr, txq->drb_size_cnt, (u64)txq->drb_skb_base);

	return ret;
}

static void dpmaif_tx_buf_rel(struct dpmaif_tx_queue *txq)
{
	unsigned int index = 0;
	struct dpmaif_drb_skb *drb_skb = NULL;

	if (unlikely(txq == NULL || txq->dpmaif_ctrl == NULL))
		return;

	if (txq->drb_base) {
#if (DPMAIF_UL_DRB_SIZE > PAGE_SIZE)
		dma_free_coherent(dpmaif_get_hw_device(txq->dpmaif_ctrl),
			(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)),
			txq->drb_base,
			txq->drb_bus_addr);
#else
		dma_pool_free(txq->dpmaif_ctrl->tx_drb_dmapool,
			txq->drb_base, txq->drb_bus_addr);
#endif
	}

	if (txq->drb_skb_base) {
		for (index = 0; index < txq->drb_size_cnt; index++) {
			drb_skb = ((struct dpmaif_drb_skb *)
				txq->drb_skb_base + index);
			if (drb_skb->skb) {
				dma_unmap_single(
						dpmaif_get_hw_device(txq->dpmaif_ctrl),
						drb_skb->bus_addr, drb_skb->data_len,
						DMA_TO_DEVICE);
				if (drb_skb->is_last_one) {
					kfree_skb(drb_skb->skb);
					drb_skb->skb = NULL;
				}
			}
		}

		kfree(txq->drb_skb_base);
		txq->drb_skb_base = NULL;
	}
}


/* =======================================================
 *
 * Descriptions: State part start(1/3): init(TX) -- 1.2.0 tx init
 *
 * ========================================================
 */
static int dpmaif_txq_init(struct dpmaif_tx_queue *txq)
{
	int ret = -1;

	/* TXQ tx list size init */
	spin_lock_init(&txq->tx_event_lock);
	INIT_LIST_HEAD(&txq->tx_event_queue);
	txq->tx_submit_skb_cnt = 0;
	txq->tx_skb_stat = 0;
	txq->tx_list_max_len = DPMAIF_UL_DRB_ENTRY_SIZE / 2;
	txq->drb_lack = false;

	init_waitqueue_head(&txq->req_wq);
	atomic_set(&txq->tx_budget, DPMAIF_UL_DRB_ENTRY_SIZE);

	/* init the drb dma buffer and tx skb record infor buffer */
	ret = dpmaif_tx_buf_init(txq);
	if (ret) {
		MTK_ERR_LOG(TAG, "tx buffer init fail %d\n", ret);
		return ret;
	}

	/* init the tx delay workqueue */
	txq->worker = alloc_workqueue("md%d_dpmaif_tx%d_worker",
		WQ_UNBOUND | WQ_MEM_RECLAIM |
		(txq->index == 0 ? WQ_HIGHPRI : 0),
		1, txq->dpmaif_ctrl->md_id + 1, txq->index);
	INIT_DELAYED_WORK(&txq->dpmaif_tx_work, dpmaif_tx_done);
	spin_lock_init(&txq->tx_lock);

#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	txq->busy_count = 0;
#endif

#ifdef DPMAIF_DEBUG_DUMP
	dpmaif_dump_txq_remain(txq->dpmaif_ctrl, txq->index, 0);
#endif

	return 0;
}

static void dpmaif_txq_rel(struct dpmaif_tx_queue *txq)
{
	unsigned long flags;
	struct dpmaif_tx_event *event, *event_next;

	if (unlikely(txq == NULL))
		return;

	if (txq->worker) {
		flush_workqueue(txq->worker);
		destroy_workqueue(txq->worker);
	}

	spin_lock_irqsave(&txq->tx_event_lock, flags);
	list_for_each_entry_safe(event, event_next,
		&txq->tx_event_queue, entry) {
		MTK_INFO_LOG(TAG,
			"Drop ulq%d hw send event after stop\n", event->qno);
		if (event->skb)
			dev_kfree_skb_any(event->skb);
		dpmaif_finish_event(event);
	}
	spin_unlock_irqrestore(&txq->tx_event_lock, flags);

	dpmaif_tx_buf_rel(txq);
}

/* =======================================================
 *
 * Descriptions: State part start(1/3): init(ISR) -- 1.3
 *
 * ========================================================
 */
static void dpmaif_isr_parameter_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned char i = 0;
	struct dpmaif_isr_para *isr_para = NULL;

	/* set up the RXQ and ext_isr relation */
	dpmaif_ctrl->rxq_ext_int_mapping[DPF_RX_QNO0] = DPMAIF_INT;
	dpmaif_ctrl->rxq_ext_int_mapping[DPF_RX_QNO1] = DPMAIF2_INT;

	/* init the ext isr parameter */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		isr_para = &(dpmaif_ctrl->isr_para[i]);
		isr_para->dpmaif_ctrl = dpmaif_ctrl;
		isr_para->dlq_id = i;
		isr_para->pcie_ext_int = dpmaif_ctrl->rxq_ext_int_mapping[i];
	}
}

static int dpmaif_platform_irq_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	int i = 0;
	pcie_ext_int_e ext_int = 0;
	struct dpmaif_isr_para *isr_para = NULL;

	/* pcie isr parameter init */
	dpmaif_isr_parameter_init(dpmaif_ctrl);

	/* register isr */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		isr_para = &dpmaif_ctrl->isr_para[i];
		ext_int = isr_para->pcie_ext_int;
		mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, ext_int, true);
		ret = mtk_pcie_register_ext_int_callback(dpmaif_ctrl->mtk_dev, ext_int,
			dpmaif_isr, (void *)isr_para);
		if (ret < 0)
			MTK_ERR_LOG(TAG,
			"Fail to regist pcie ext interrupt isr\n");
		mtk_pcie_clr_ext_int_sts(dpmaif_ctrl->mtk_dev, ext_int);
		mtk_pcie_set_ext_int_mask(dpmaif_ctrl->mtk_dev, ext_int, false);
	}

	return ret;
}

static inline void *dpmaif_map_skb_deq(struct dpmaif_map_skb *skb_list)
{
	struct list_head *entry = NULL;

	entry = skb_list->head.next;
	if (likely(!list_empty(&skb_list->head) && entry)) {
		list_del(entry);
		skb_list->qlen--;
	} else {
		entry = NULL;
	}

	return (void *)entry;
}

#define DPMF_MAP_SKB_QUE_EMPTY(skb_list)	list_empty(&skb_list.head)

static void dpmaif_skb_queue_rel(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index)
{
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_info *skb_info = NULL;
	struct list_head *entry = NULL;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_SKB_QUEUE_CNT))
		goto exit;

	queue = &dpmaif_ctrl->skb_pool.queue[index];
	while (!DPMF_MAP_SKB_QUE_EMPTY(queue->skb_list)) {
		entry = dpmaif_map_skb_deq(&queue->skb_list);
		if (likely(entry)) {
			skb_info = (struct dpmaif_skb_info *)
				GET_SKB_BY_ENTRY(entry);
			if (likely(skb_info)) {
				if (likely(skb_info->skb)) {
					dev_kfree_skb_any(skb_info->skb);
					skb_info->skb = NULL;
				}
				kfree(skb_info);
				skb_info = NULL;
			}
		}
	}

exit:
	return;
}

static struct dpmaif_skb_info *dpmaif_skb_dequeue(
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned int index)
{
	unsigned long flags;
	struct dpmaif_skb_info *skb_info = NULL;
	struct list_head *entry = NULL;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_pool *pool = NULL;
	unsigned int max_len, qlen;

	if (unlikely(dpmaif_ctrl == NULL || index >= DPMA_SKB_QUEUE_CNT))
		goto err;

	pool = &dpmaif_ctrl->skb_pool;
	queue = &pool->queue[index];

	spin_lock_irqsave(&queue->skb_list.lock, flags);
	entry = dpmaif_map_skb_deq(&queue->skb_list);
	max_len = queue->max_len;
	qlen = queue->skb_list.qlen;
	spin_unlock_irqrestore(&queue->skb_list.lock, flags);
	if (unlikely(entry == NULL))
		goto busy;

	/* reload the skb pool */
	if (qlen < max_len * DPMA_RELOAD_TH_1 / DPMA_RELOAD_TH_2) {
		queue_work_on(dpmaif_find_reload_cpu(dpmaif_ctrl),
			pool->pool_reload_work_queue, &pool->reload_work);
	}

	skb_info = (struct dpmaif_skb_info *)GET_SKB_BY_ENTRY(entry);

busy:
	if (skb_info == NULL) {
		queue->busy_cnt++;
		MTK_INFO_LOG(TAG,
			"skb queue(%u, %u, %lu, %u) empty, dequeue fail\n",
			index, queue->size, queue->busy_cnt,
			queue->skb_list.qlen);
	}

	return skb_info;

err:
	return NULL;
}

static void skb_reload_work(struct work_struct *work)
{
	struct sk_buff *skb;
	unsigned int index = 0;
	struct dpmaif_skb_queue *queue = NULL;
	struct dpmaif_skb_pool *pool = NULL;
	unsigned int cnt = 0;
	unsigned int size = 0;
	unsigned int max_cnt = 0;
	unsigned long flags;
	unsigned int qlen = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct dpmaif_skb_info *skb_info = NULL;

	if(unlikely(work == NULL))
		goto err;

	pool = (struct dpmaif_skb_pool *)container_of(work,
		struct dpmaif_skb_pool, reload_work);

	dpmaif_ctrl = (struct md_dpmaif_ctrl *)container_of(pool,
		struct md_dpmaif_ctrl, skb_pool);

	for (index = 0; index < DPMA_SKB_QUEUE_CNT; index++) {
		queue = &pool->queue[index];

		spin_lock_irqsave(&queue->skb_list.lock, flags);
		size = queue->size;
		max_cnt = queue->max_len;
		qlen = queue->skb_list.qlen;
		spin_unlock_irqrestore(&queue->skb_list.lock, flags);

		if (qlen < max_cnt * DPMA_RELOAD_TH_1 / DPMA_RELOAD_TH_2) {
			cnt = max_cnt - qlen;
			while (cnt > 0) {
				skb = __dev_alloc_skb(size, GFP_KERNEL);
				if (skb) {
					skb_info = dpmaif_skb_dma_map(
						dpmaif_ctrl, skb);
					if (skb_info != NULL) {
						spin_lock_irqsave(
							&queue->skb_list.lock,
							flags);
						DPMF_MAP_SKB_ENQ(
							skb_info->entry,
							queue->skb_list);
						spin_unlock_irqrestore(&
							queue->skb_list.lock,
							flags);
					} else {
						dev_kfree_skb_any(skb);
						skb = NULL;
					}
				} else {
					MTK_ERR_LOG(TAG,
						"Fail to alloc a skb for skb_queue(%d)\n",
						index);
				}
				cnt--;
			}
		}
	}

err:
	return;
}

static inline unsigned int dpmaif_skb_avail_cnt(
	struct md_dpmaif_ctrl *dpmaif_ctrl, int q_index)
{
	struct dpmaif_skb_queue *queue = NULL;
	unsigned long flags;
	unsigned int result = 0;

	if (likely(dpmaif_ctrl)) {
		queue = &dpmaif_ctrl->skb_pool.queue[q_index];

		spin_lock_irqsave(&queue->skb_list.lock, flags);

		result = queue->skb_list.qlen;

		spin_unlock_irqrestore(&queue->skb_list.lock, flags);
	}

	return result;
}

static int dpmaif_skb_queue_init_struct(struct md_dpmaif_ctrl *dpmaif_ctrl,
	unsigned int index)
{
	int ret = 0;
	struct dpmaif_skb_queue *queue = NULL;
	unsigned int size = 0;
	unsigned int max_cnt = 0;

	queue = &dpmaif_ctrl->skb_pool.queue[index];
	size = DPMA_SKB_SIZE_MAX / (1 << index);
	max_cnt = DPMA_SKB_QUEUE_SIZE / DPMA_SKB_SIZE_TRUE(size);

	if (size < DPMA_SKB_TRUE_SIZE_MIN) {
		return 0;
	}

	INIT_LIST_HEAD(&queue->skb_list.head);
	spin_lock_init(&queue->skb_list.lock);
	queue->skb_list.qlen = 0;
	queue->size = size;
	queue->max_len = max_cnt;
	queue->busy_cnt = 0;

	return ret;
}

static int dpmaif_skb_pool_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_skb_pool *pool = NULL;
	int index = 0;

	pool = &dpmaif_ctrl->skb_pool;
	pool->queue_cnt = DPMA_SKB_QUEUE_CNT;

	/* init the skb queue structure */
	for (index = 0; index < pool->queue_cnt; index++) {
		if (unlikely(dpmaif_skb_queue_init_struct(dpmaif_ctrl, index))) {
			MTK_ERR_LOG(TAG,
				"Init skb_queue(%d) fail\n",
				index);
			goto err;
		}
	}

	/* init pool reload work */
	pool->pool_reload_work_queue = alloc_workqueue(
		"dpmaif_skb_pool_reload_work", WQ_MEM_RECLAIM | WQ_HIGHPRI, 1);
	if (!pool->pool_reload_work_queue) {
		MTK_ERR_LOG(TAG, "Creat the pool_reload_work_queue fail\n");
		goto err;
	}
	INIT_WORK(&pool->reload_work, skb_reload_work);

	/* schedule the skb pool reload workqueue */
	queue_work_on(dpmaif_find_reload_cpu(dpmaif_ctrl),
		pool->pool_reload_work_queue, &pool->reload_work);
err:
	return 0;
}

static void dpmaif_skb_pool_rel(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	unsigned int index = 0;
	struct dpmaif_skb_pool *pool = NULL;

	if (unlikely(dpmaif_ctrl == NULL))
		goto exit;

	pool = &dpmaif_ctrl->skb_pool;

	flush_work(&pool->reload_work);

	if (pool->pool_reload_work_queue) {
		flush_workqueue(pool->pool_reload_work_queue);
		destroy_workqueue(pool->pool_reload_work_queue);
		pool->pool_reload_work_queue = NULL;
	}

	for (index = 0; index < DPMA_SKB_QUEUE_CNT; index++)
		dpmaif_skb_queue_rel(dpmaif_ctrl, index);

exit:
	return;
}

static void dpmaif_bat_rel_work(struct work_struct *work)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct dpmaif_rx_queue *rxq = NULL;
	int blocking = 1;
	int ret = 0;

	dpmaif_ctrl = (struct md_dpmaif_ctrl *)container_of(work,
		struct md_dpmaif_ctrl, bat_rel_work);
	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "Invalid parameter\n");
	}

	mtk_pm_runtime_get(dpmaif_ctrl->mtk_dev);
    
	mtk_pci_l_resource_lock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

	/* ALL RXQ use one bat table, so choose  DPF_RX_QNO_DFT */
	rxq = &dpmaif_ctrl->rxq[DPF_RX_QNO_DFT];

	mtk_pci_l_resource_wait_complete(dpmaif_ctrl->mtk_dev,
						dpmaif_ctrl->lock_user);

	if (DPMAIF_IS_SET_MD_DUMP()) {
		goto lab_trigger;
	}

	/* normal bat release and add */
	ret = dpmaif_dl_pkt_bat_rel_and_add(rxq, blocking);
	if (ret < 0)
		MTK_DEBUG_LOG(TAG, "Update normal bat fail\n");

	/* frag bat release and add */
	dpmaif_dl_frag_bat_rel_and_add(rxq, blocking);
	if (ret < 0)
		MTK_DEBUG_LOG(TAG, "Update frag bat fail\n");

lab_trigger:

    mtk_pci_l_resource_unlock(
		dpmaif_ctrl->mtk_dev, dpmaif_ctrl->lock_user);

    mtk_pm_runtime_put(dpmaif_ctrl->mtk_dev);

	MTK_DEBUG_LOG(TAG, "noraml bat: w/r/rel-%d,%d,%d\n",
		rxq->bat_req->bat_wr_idx, rxq->bat_req->bat_rd_idx,
		rxq->bat_req->bat_rel_rd_idx);
	MTK_DEBUG_LOG(TAG, "frag bat: w/r/rel-%d,%d,%d\n",
		rxq->bat_frag->bat_wr_idx, rxq->bat_frag->bat_rd_idx,
		rxq->bat_frag->bat_rel_rd_idx);

}


static int dpmaif_bat_rel_work_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (unlikely(dpmaif_ctrl == NULL))
		goto err;

	dpmaif_ctrl->bat_rel_work_queue =
		alloc_workqueue("dpmaif_bat_rel_work_queue", WQ_MEM_RECLAIM, 1);
	if (!dpmaif_ctrl->bat_rel_work_queue)
		goto err;

	INIT_WORK(&dpmaif_ctrl->bat_rel_work, dpmaif_bat_rel_work);

	return 0;

err:
	return -1;
}

static void dpmaif_bat_rel_work_rel(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (unlikely(dpmaif_ctrl == NULL))
		goto exit;

	flush_work(&dpmaif_ctrl->bat_rel_work);

	if (dpmaif_ctrl->bat_rel_work_queue) {
		flush_workqueue(dpmaif_ctrl->bat_rel_work_queue);
		destroy_workqueue(dpmaif_ctrl->bat_rel_work_queue);
		dpmaif_ctrl->bat_rel_work_queue = NULL;
	}

exit:
	return;
}

/* we put initializations which takes too much time here: SW init only */
static int dpmaif_sw_init(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rx_q;
	struct dpmaif_tx_queue *tx_q;
	int ret, i;

	/* gets dpmaif_ctrl firstly */
	if (unlikely(dpmaif_ctrl == NULL)) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is NULL pointer!\n");
		goto err;
	}

	/* RX PIT/BAT DMA pool init */
#if (DPMAIF_DL_PIT_SIZE <= PAGE_SIZE)
	dpmaif_ctrl->rx_pit_dmapool = dma_pool_create("dpmaif_pit_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_DL_PIT_ENTRY_SIZE * sizeof(struct dpmaifq_normal_pit)),
		64, 0);
#endif

#if (DPMAIF_DL_BAT_SIZE <= PAGE_SIZE)
	dpmaif_ctrl->rx_bat_dmapool = dma_pool_create("dpmaif_bat_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_DL_BAT_ENTRY_SIZE * sizeof(struct dpmaif_bat_t)), 64, 0);
#endif

	/* RX normal bat table init */
	ret = dpmaif_bat_init(dpmaif_ctrl, &dpmaif_ctrl->bat_req, NORMAL_BUF);
	if (ret) {
		MTK_ERR_LOG(TAG, "dpmaif normal bat table init fail, %d!\n", ret);
		goto err;
	}
	spin_lock_init(&dpmaif_ctrl->bat_release_lock);

	/* RX frag bat table init */
	ret = dpmaif_bat_init(dpmaif_ctrl, &dpmaif_ctrl->bat_frag, FRAG_BUF);
	if (ret) {
		MTK_ERR_LOG(TAG, "dpmaif frag bat table init fail, %d!\n", ret);
		goto err;
	}
	spin_lock_init(&dpmaif_ctrl->frag_bat_release_lock);

	/* dpmaif RXQ resource init */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rx_q = &dpmaif_ctrl->rxq[i];
		rx_q->index = i;
		rx_q->dpmaif_ctrl = dpmaif_ctrl;
		dpmaif_rxq_init(rx_q);
	}

	/* TX DRB DMA pool init  */
#if (DPMAIF_UL_DRB_SIZE <= PAGE_SIZE)
	dpmaif_ctrl->tx_drb_dmapool = dma_pool_create("dpmaif_drb_req_DMA",
		dpmaif_get_hw_device(dpmaif_ctrl),
		(DPMAIF_UL_DRB_ENTRY_SIZE * sizeof(struct dpmaif_drb_pd)), 64, 0);
#endif

	/* dpmaif TXQ resource init */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		tx_q = &dpmaif_ctrl->txq[i];
		tx_q->index = i;
		tx_q->dpmaif_ctrl = dpmaif_ctrl;
		dpmaif_txq_init(tx_q);
	}

	/* init TX thread : send skb data to dpmaif HW*/
	dpmaif_tx_thread_init(dpmaif_ctrl);

	/* Init the RX skb pool */
	if (dpmaif_skb_pool_init(dpmaif_ctrl))
		goto err;

	/* Release the bat resource workqueue */
	if (dpmaif_bat_rel_work_init(dpmaif_ctrl))
		goto err;

	return 0;

err:
	return -1;
}

static void dpmaif_sw_rel(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rx_q = NULL;
	struct dpmaif_tx_queue *tx_q = NULL;
	int i = 0;

	if (unlikely(dpmaif_ctrl == NULL))
		return;

	/* release the tx thread */
	dpmaif_tx_thread_uninit(dpmaif_ctrl);

	/* release the bat release workqueue */
	dpmaif_bat_rel_work_rel(dpmaif_ctrl);

	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		tx_q = &dpmaif_ctrl->txq[i];
		dpmaif_txq_rel(tx_q);
	}

	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rx_q = &dpmaif_ctrl->rxq[i];
		dpmaif_rxq_rel(rx_q);
	}

#if (DPMAIF_DL_PIT_SIZE <= PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->rx_pit_dmapool);
#endif

#if (DPMAIF_DL_BAT_SIZE <= PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->rx_bat_dmapool);
#endif

#if (DPMAIF_UL_DRB_SIZE <= PAGE_SIZE)
	dma_pool_destroy(dpmaif_ctrl->tx_drb_dmapool);
#endif

	/* release the skb pool */
	dpmaif_skb_pool_rel(dpmaif_ctrl);
}

/* =======================================================
 *
 * Descriptions: State part start(2/3): Start -- 2.
 *
 * ========================================================
 */
static int dpmaif_start(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rxq;
	struct dpmaif_tx_queue *txq;
	int i, ret = 0;
	struct dpmaif_hw_init_para hw_init_para;
	unsigned int buf_cnt = 0;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto err;
	}

	MTK_INFO_LOG(TAG,
		"md%d, dpmaif_ctrl:0x%llx, dpmaif_state:%d, nic_capability:0x%x\n", md_id,
		(u64)dpmaif_ctrl, dpmaif_ctrl->dpmaif_state,
		ccmni_get_nic_cap(dpmaif_ctrl->ctlb));

	if (dpmaif_ctrl->dpmaif_sw_init_done != true) {
		MTK_ERR_LOG(TAG, "dpmaif sw init fail\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWRON) {
		MTK_INFO_LOG(TAG, "dpmaif in poweron status\n");
		goto err;
	}

	memset(&hw_init_para, 0, sizeof(struct dpmaif_hw_init_para));

	/* rx rx */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rxq = &dpmaif_ctrl->rxq[i];
		rxq->que_started = true;
		rxq->index = i;
		rxq->budget = rxq->bat_req->bat_size_cnt - 1;
		rxq->check_bid_fail_cnt = 0;

		/* DPMAIF HW RX queue init parameter */
		hw_init_para.pkt_bat_base_addr[i] = rxq->bat_req->bat_bus_addr;
		hw_init_para.pkt_bat_size_cnt[i] = rxq->bat_req->bat_size_cnt;
		hw_init_para.pit_base_addr[i] = rxq->pit_bus_addr;
		hw_init_para.pit_size_cnt[i] = rxq->pit_size_cnt;
		hw_init_para.frg_bat_base_addr[i] = rxq->bat_frag->bat_bus_addr;
		hw_init_para.frg_bat_size_cnt[i] = rxq->bat_frag->bat_size_cnt;
	}

	/*rx normal bat mask init*/
	memset(dpmaif_ctrl->bat_req.bat_mask, 0,
		dpmaif_ctrl->bat_req.bat_size_cnt * sizeof(unsigned char));
	/*normal bat - skb buffer and submit bat*/
	buf_cnt = dpmaif_ctrl->bat_req.bat_size_cnt - 1;
	ret = dpmaif_alloc_rx_buf(dpmaif_ctrl,
		&dpmaif_ctrl->bat_req, 0, buf_cnt, 1, true);
	if (ret) {
		MTK_ERR_LOG(TAG, "dpmaif_alloc_rx_buf fail, ret:%d\n", ret);
		return LOW_MEMORY;
	}

	/*frag bat - page buffer init*/
	buf_cnt = dpmaif_ctrl->bat_frag.bat_size_cnt - 1;
	ret = dpmaif_alloc_rx_frag(dpmaif_ctrl, &dpmaif_ctrl->bat_frag,
		0, buf_cnt, 1, true);
	if (ret) {
		MTK_ERR_LOG(TAG, "dpmaif_alloc_rx_frag fail, ret:%d\n", ret);
		return LOW_MEMORY;
	}


	/* tx tx */
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		txq = &dpmaif_ctrl->txq[i];
		txq->que_started = true;

		/* DPMAIF HW TX queue init parameter */
		hw_init_para.drb_base_addr[i] = txq->drb_bus_addr;
		hw_init_para.drb_size_cnt[i] = txq->drb_size_cnt;
	}

	drv_dpmaif_hw_init(&dpmaif_ctrl->hif_hw_info, (void *)&hw_init_para);

	/* notifies DPMAIF HW for available BAT count */
	drv_dpmaif_dl_add_bat_cnt(&dpmaif_ctrl->hif_hw_info, 0, rxq->bat_req->bat_size_cnt - 1);
	drv_dpmaif_dl_add_frg_cnt(&dpmaif_ctrl->hif_hw_info, 0, rxq->bat_frag->bat_size_cnt - 1);

#ifdef DPMAIF_DEBUG_DUMP
	drv_dpmaif_dump_all_config_regs(&dpmaif_ctrl->hif_hw_info);
#endif

	drv_dpmaif_clr_ul_all_interrupt(&dpmaif_ctrl->hif_hw_info);
	drv_dpmaif_clr_dl_all_interrupt(&dpmaif_ctrl->hif_hw_info);

	/* debug */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	mod_timer(&dpmaif_ctrl->traffic_monitor,
			jiffies + DPMAIF_TRAFFIC_MONITOR_INTERVAL * HZ);
#endif

	dpmaif_ctrl->dpmaif_state = HIFDPMAIF_STATE_PWRON;
	dpmaif_enable_irq(dpmaif_ctrl);

	/* wake up the dpmaif tx thread */
	wake_up(&dpmaif_ctrl->tx_wq);

	return 0;

err:
	return -1;
}

static void dpmaif_pre_start_hw(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rxq;
	struct dpmaif_tx_queue *txq;
	unsigned int que_cnt;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "pre start hw\n");

	/* ===Enable UL SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_TXQ_NUM; que_cnt++) {
		txq = &dpmaif_ctrl->txq[que_cnt];
		MTK_DEBUG_LOG(TAG, "ulq%d: drb-r/w/rel-%d,%d,%d; tx_processing:%d \n", que_cnt,
			txq->drb_rd_idx, txq->drb_wr_idx, txq->drb_rel_rd_idx,
			atomic_read(&txq->tx_processing));
		txq->que_started = true;
	}

	/* ===Enable DL/RX SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_RXQ_NUM; que_cnt++) {
		rxq = &dpmaif_ctrl->rxq[que_cnt];
		MTK_DEBUG_LOG(TAG,
			"dlq%d: pit-r/w/rel-%d,%d,%d\n",
			que_cnt, rxq->pit_rd_idx, rxq->pit_wr_idx,
			rxq->pit_rel_rd_idx);

		rxq->que_started = true;
	}

exit:
	return;
}


/* =======================================================
 *
 * Descriptions: State part start(3/3): Stop -- 3.
 *
 * ========================================================
 */
static void dpmaif_suspend_tx_sw_stop(unsigned char md_id,
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_tx_queue *txq;
	unsigned int que_cnt;
	int count;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "tx suspend stop SW\n");

	/* ===Disable UL SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_TXQ_NUM; que_cnt++) {
		txq = &dpmaif_ctrl->txq[que_cnt];
		MTK_DEBUG_LOG(TAG,
			"txq%d: drb-r/w/rel-%d,%d,%d; tx_processing:%d\n", que_cnt,
			txq->drb_rd_idx, txq->drb_wr_idx, txq->drb_rel_rd_idx,
			atomic_read(&txq->tx_processing));

		txq->que_started = false;
		/* for cpu exec*/
		smp_mb();

		/* just confirm sw will not update drb_wcnt reg. */
		count = 0;
		do {
			if (++count >= DPMA_CHECK_REG_TIMEOUT) {
				MTK_ERR_LOG(TAG, "Pool stop Tx failed\n");
				break;
			}
		} while (atomic_read(&txq->tx_processing) != 0);
	}
	MTK_DEBUG_LOG(TAG, "Stop tx proc cnt: %d\n", count);

exit:
	return;
}

static void dpmaif_suspend_rx_sw_stop(unsigned char md_id,
	struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rxq;
	unsigned int que_cnt;
	int count;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto exit;
	}

	MTK_DEBUG_LOG(TAG, "rx suspend stop SW\n");


	/* ===Disable DL/RX SW active=== */
	for (que_cnt = 0; que_cnt < DPMAIF_RXQ_NUM; que_cnt++) {
		rxq = &dpmaif_ctrl->rxq[que_cnt];

		/* flush work */
        flush_work(&rxq->dpmaif_rxq_work);

		/* for BAT add_cnt register */
		count = 0;
		do {
			/*retry handler*/
			if (++count >= DPMA_CHECK_REG_TIMEOUT) {
				MTK_ERR_LOG(TAG,
					"Stop Rx sw failed, %d\n", count);
				MTK_DEBUG_LOG(TAG,
					"dpmaif_stop_rxq%d, pit-r/w/rel-%u,%u,%u\n",
					rxq->index, rxq->pit_rd_idx, rxq->pit_wr_idx,
					rxq->pit_rel_rd_idx);
				break;
			}
		} while (atomic_read(&rxq->rx_processing) != 0);

		MTK_DEBUG_LOG(TAG, "Stop rx proc cnt %d\n", count);

		/* for cpu exec */
		smp_mb();
		rxq->que_started = false;
	}



exit:
	return;
}

static void dpmaif_pos_stop_hw(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	dpmaif_suspend_tx_sw_stop(md_id, dpmaif_ctrl);
	dpmaif_suspend_rx_sw_stop(md_id, dpmaif_ctrl);
}

static void dpmaif_stop_hw(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	MTK_DEBUG_LOG(TAG, "dpmaif: stop tx/rx queue HW\n");
	drv_dpmaif_hw_stop_tx_queue(&dpmaif_ctrl->hif_hw_info);
	drv_dpmaif_hw_stop_rx_queue(&dpmaif_ctrl->hif_hw_info);
}

static int dpmaif_stop_txq(struct dpmaif_tx_queue *txq)
{
    int index = 0;
    struct dpmaif_drb_skb *drb_skb = NULL;

	if (txq->drb_base == NULL)
		return -1;
	txq->que_started = false;

	/* flush work */
	cancel_delayed_work(&txq->dpmaif_tx_work);
	flush_delayed_work(&txq->dpmaif_tx_work);

	/* reset sw */
	MTK_DEBUG_LOG(TAG, "stop_txq%d: drb-r/w/rel-%d,%d,%d\n",
		txq->index, txq->drb_rd_idx, txq->drb_wr_idx,
		txq->drb_rel_rd_idx);

	if (txq->drb_skb_base) {
		for (index = 0; index < txq->drb_size_cnt; index++) {
			drb_skb = ((struct dpmaif_drb_skb *)
				txq->drb_skb_base + index);
			if (drb_skb->skb) {
				dma_unmap_single(
						dpmaif_get_hw_device(txq->dpmaif_ctrl),
						drb_skb->bus_addr, drb_skb->data_len,
						DMA_TO_DEVICE);
				if (drb_skb->is_last_one) {
					kfree_skb(drb_skb->skb);
					drb_skb->skb = NULL;
				}
			}
		}
	}

	memset(txq->drb_base, 0,
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_pd)));
	memset(txq->drb_skb_base, 0,
		(txq->drb_size_cnt * sizeof(struct dpmaif_drb_skb)));

	txq->drb_rd_idx = 0;
	txq->drb_wr_idx = 0;
	txq->drb_rel_rd_idx = 0;

	return 0;
}

static int dpmaif_stop_rxq(struct dpmaif_rx_queue *rxq)
{
	int j, cnt;

	if (rxq->pit_base == NULL || rxq->bat_req->bat_base == NULL)
		return -1;

	/* flush work */
    flush_work(&rxq->dpmaif_rxq_work);

	/* reset sw */
	rxq->que_started = false;
	j = 0;
	do {
		/*Disable HW arb and check idle*/
		cnt = ring_buf_readable(rxq->pit_size_cnt,
			rxq->pit_rd_idx, rxq->pit_wr_idx);
		/*retry handler*/
		if (++j >= DPMA_CHECK_REG_TIMEOUT) {
			MTK_ERR_LOG(TAG,
				"stop Rx sw failed, %d\n", cnt);
			MTK_DEBUG_LOG(TAG,
				"rxq%d, pit-r/w/rel-%u,%u,%u\n",
				rxq->index, rxq->pit_rd_idx, rxq->pit_wr_idx,
				rxq->pit_rel_rd_idx);
			break;
		}
	} while (cnt != 0);

	memset(rxq->pit_base, 0,
		(rxq->pit_size_cnt * sizeof(struct dpmaifq_normal_pit)));
	memset(rxq->bat_req->bat_base, 0,
		(rxq->bat_req->bat_size_cnt * sizeof(struct dpmaif_bat_t)));
	memset(rxq->bat_req->bat_mask, 0,
		(rxq->bat_req->bat_size_cnt * sizeof(unsigned char)));

	memset(&rxq->rx_data_info, 0x00, sizeof(struct dpmaif_cur_rx_skb_info));
	rxq->rx_data_info.msg_pit_received = false;

	rxq->pit_rd_idx = 0;
	rxq->pit_wr_idx = 0;
	rxq->pit_rel_rd_idx = 0;

	rxq->expect_pit_seq = 0;
	rxq->pit_remain_rel_cnt = 0;
	rxq->pit_seq_fail_cnt = 0;

	rxq->bat_req->bat_rd_idx = 0;
	rxq->bat_req->bat_rel_rd_idx = 0;
	rxq->bat_req->bat_wr_idx = 0;

	rxq->bat_frag->bat_rd_idx = 0;
	rxq->bat_frag->bat_rel_rd_idx = 0;
	rxq->bat_frag->bat_wr_idx = 0;

	return 0;
}

static int dpmaif_stop_rx_sw(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_rx_queue *rxq;
	int i;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto error;
	}

	/* rx rx clear */
	for (i = 0; i < DPMAIF_RXQ_NUM; i++) {
		rxq = &dpmaif_ctrl->rxq[i];
		dpmaif_stop_rxq(rxq);
#ifdef DPMAIF_DEBUG_DUMP
		dpmaif_dump_rxq_remain(dpmaif_ctrl, i, 0);
#endif
	}
	return 0;

error:
	return -1;
}

static int dpmaif_stop_tx_sw(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	struct dpmaif_tx_queue *txq;
	int i;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto error;
	}

	/*flush and release UL descriptor*/
	for (i = 0; i < DPMAIF_TXQ_NUM; i++) {
		txq = &dpmaif_ctrl->txq[i];
		dpmaif_stop_txq(txq);
	}
	return 0;

error:
	return -1;
}

static int dpmaif_stop(unsigned char md_id, struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_sw_init_done != true) {
		MTK_ERR_LOG(TAG, "dpmaif sw init fail\n");
		goto err;
	}

	if (dpmaif_ctrl->dpmaif_state == HIFDPMAIF_STATE_PWROFF) {
		MTK_INFO_LOG(TAG, "dpmaif in poweroff status\n");
		goto err;
	}

	dpmaif_disable_irq(dpmaif_ctrl);

	dpmaif_ctrl->dpmaif_state = HIFDPMAIF_STATE_PWROFF;
	/* 1. post stop HW */
	/* dpmaif_stop_hw(md_id, hif_id); */
	dpmaif_pos_stop_hw(md_id, dpmaif_ctrl);

	/* 2. stop sw */
	/* skb pool workqueue stop */
	flush_work(&dpmaif_ctrl->skb_pool.reload_work);

	/* tx tx clear */
	dpmaif_stop_tx_sw(dpmaif_ctrl);

	/* rx rx clear */
	dpmaif_stop_rx_sw(dpmaif_ctrl);
	/* stop debug mechnism */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	del_timer(&dpmaif_ctrl->traffic_monitor);
#endif

	/* 3. todo: reset IP */
//	dpmaif_hw_reset(&dpmaif_ctrl->hif_hw_info);

	MTK_DEBUG_LOG(TAG, "dpmaif stop done\n");
	return 0;

err:
	return -1;
}

/* =======================================================
 *
 * Descriptions: State part start(6/3): PM -- 6.
 *
 * ========================================================
 */
static int dpmaif_suspend(struct mtk_pci_dev *mtk_dev, void *param)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl =
		(struct md_dpmaif_ctrl *)param;

	MTK_INFO_LOG(TAG, "Dpmaif suspend\n");

	/* stop dpmaif tx*/
	dpmaif_suspend_tx_sw_stop(dpmaif_ctrl->md_id, dpmaif_ctrl);
	drv_dpmaif_hw_stop_tx_queue(&dpmaif_ctrl->hif_hw_info);

	/* stop dpmaif rx*/
	drv_dpmaif_hw_stop_rx_queue(&dpmaif_ctrl->hif_hw_info);

	/* mask PCIE DPMAIF interrupt */
	dpmaif_disable_irq(dpmaif_ctrl);

	dpmaif_suspend_rx_sw_stop(dpmaif_ctrl->md_id, dpmaif_ctrl);

	return 0;
}

static int dpmaif_suspend_late(struct mtk_pci_dev *mtk_dev, void *param)
{
	return 0;
}
static int dpmaif_resume_early(struct mtk_pci_dev *mtk_dev, void *param)
{
	return 0;
}

static void dpmaif_unmask_dlq_interrupt(struct md_dpmaif_ctrl* dpmaif_ctrl)
{
	int qno = 0;
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "null dpmaif_ctrl pointer.\n");
		return;
	}
	for (qno = 0; qno < DPMAIF_RXQ_NUM; qno++) {
		MTK_INFO_LOG(TAG, "Dpmaif unmask rx dlq:%d.\n", qno);
		drv_dpmaif_hw_dl_dlq_unmask_rx_done_intr(&(dpmaif_ctrl->hif_hw_info), qno);
	}
}

static int dpmaif_resume(struct mtk_pci_dev *mtk_dev, void *param)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl = (struct md_dpmaif_ctrl *)param;

	MTK_INFO_LOG(TAG, "Dpmaif resume\n");

	/* start dpmaif tx/rx queue SW */
	dpmaif_pre_start_hw(dpmaif_ctrl->md_id, dpmaif_ctrl);

	/* unmask PCIE DPMAIF interrupt */
	dpmaif_enable_irq(dpmaif_ctrl);

	/* unmask dlq interrupt. */
	dpmaif_unmask_dlq_interrupt(dpmaif_ctrl);

	/* start dpmaif HW */
	drv_dpmaif_start_hw(&dpmaif_ctrl->hif_hw_info);

	/* wake up the dpmaif tx thread */
	wake_up(&dpmaif_ctrl->tx_wq);

	return 0;
}

static int dpmaif_pm_entity_init(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	struct md_pm_entity *dpmaif_pm_entity = NULL;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		ret = -1;
		goto err;
	}

	dpmaif_ctrl->lock_user = L_RES_USER_DATA;

	dpmaif_pm_entity = &dpmaif_ctrl->dpmaif_pm_entity;
	INIT_LIST_HEAD(&dpmaif_pm_entity->entity);
	dpmaif_pm_entity->suspend = &dpmaif_suspend;
	dpmaif_pm_entity->suspend_late = &dpmaif_suspend_late;
	dpmaif_pm_entity->resume_early = &dpmaif_resume_early;
	dpmaif_pm_entity->resume = &dpmaif_resume;

	dpmaif_pm_entity->key = PM_ENTITY_KEY_DATA;
	dpmaif_pm_entity->entity_param = (void *)dpmaif_ctrl;

	ret = mtk_pci_pm_entity_register(dpmaif_ctrl->mtk_dev,
		dpmaif_pm_entity);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "dpmaif register pm_entity fail.\n");

err:
	return ret;
}

static int dpmaif_pm_entity_uninit(struct md_dpmaif_ctrl *dpmaif_ctrl)
{
	int ret = 0;
	struct md_pm_entity *dpmaif_pm_entity = NULL;

	if ((dpmaif_ctrl == NULL) || (dpmaif_ctrl->mtk_dev == NULL)) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		ret = -1;
		goto err;
	}

	dpmaif_pm_entity = &dpmaif_ctrl->dpmaif_pm_entity;
	ret = mtk_pci_pm_entity_unregister(
		dpmaif_ctrl->mtk_dev, dpmaif_pm_entity);
	if (ret < 0)
		MTK_ERR_LOG(TAG, "dpmaif register pm_entity fail.\n");

err:
	return ret;
}


int dpmaif_md_state_callback(unsigned char md_id,
	struct md_dpmaif_ctrl *dpmaif_ctrl, unsigned char state)
{
	int ret = 0;

	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "dpmaif_ctrl is a NULL pointer!\n");
		ret = -1;
		goto err;
	}

	switch (state) {
	case BOOT_WAITING_FOR_HS1:
		ret = dpmaif_start(md_id, dpmaif_ctrl);
		break;

	case EXCEPTION:
		dpmaif_dump_status(dpmaif_ctrl, DUMP_FLAG_REG, -1);
		ret = dpmaif_stop(md_id, dpmaif_ctrl);
		break;
	case STOPPED:
		ret = dpmaif_stop(md_id, dpmaif_ctrl);
		break;

	case WAITING_TO_STOP:
		dpmaif_stop_hw(md_id, dpmaif_ctrl);
		break;

	default:
		break;
	}

err:
	return ret;
}


/* =======================================================
 *
 * Descriptions: State Module part End
 *
 * ========================================================
 */
int dpmaif_hif_init(unsigned char md_id, struct ccmni_ctl_block *ctlb)
{
	int ret = 0;
	struct md_dpmaif_ctrl *dpmaif_ctrl = NULL;
	struct mtk_pci_dev *mtk_dev = NULL;

	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "ccmni_ctl_block is NULL fail!\n");
		ret = -1;
		goto err;
	}

	mtk_dev = ctlb->mtk_dev;

	/* allocates memory for md_dpmaif_ctrl */
	dpmaif_ctrl = kzalloc(sizeof(struct md_dpmaif_ctrl), GFP_KERNEL);
	if (dpmaif_ctrl == NULL) {
		MTK_ERR_LOG(TAG, "Allocates memory for md_ctrl fail!\n");
		ret = -1;
		goto err;
	}

	ctlb->hif_ctrl = dpmaif_ctrl;
	dpmaif_ctrl->ctlb = ctlb;
	dpmaif_ctrl->mtk_dev = mtk_dev;
	dpmaif_ctrl->dpmaif_sw_init_done = false;
	dpmaif_ctrl->md_id = md_id;
	dpmaif_ctrl->napi_enable = !!(ccmni_get_nic_cap(dpmaif_ctrl->ctlb) & NIC_CAP_NAPI);

	/* get PCIe device HW info */
	dpmaif_ctrl->pcie_hw_info.hw_base_addr = mtk_dev->base_addr.pcie_dev_reg_trsl_addr;
	dpmaif_ctrl->pcie_hw_info.hw_map_base_addr = mtk_dev->base_addr.pcie_ext_reg_base;
	dpmaif_ctrl->pcie_hw_info.pcie_dev = &(mtk_dev->pdev->dev);

	/* HW layer driver init */
	drv_dpmaif_hw_addr_init(&dpmaif_ctrl->hif_hw_info, &dpmaif_ctrl->pcie_hw_info);

	/* dpmaif PM init */
	dpmaif_pm_entity_init(dpmaif_ctrl);

	/* registers dpmaif irq by PCIe driver API */
	ret = dpmaif_platform_irq_init(dpmaif_ctrl);
	if (ret < 0) {
		MTK_ERR_LOG(TAG,
			"Register DPMAIF callback isr with PCIE driver fail! %d!\n", ret);
		goto err1;
	}

	atomic_set(&dpmaif_ctrl->dpmaif_irq_enabled, 1);
	dpmaif_disable_irq(dpmaif_ctrl);

	/* Alloc TX/RX resource */
	ret = dpmaif_sw_init(md_id, dpmaif_ctrl);
	if (ret < 0) {
		MTK_ERR_LOG(TAG, "init the dpmaif hif SW resource fail! %d!\n", ret);
		goto err1;
	}

	dpmaif_ctrl->dpmaif_sw_init_done = true;

	/* set debug related */
#if DPMAIF_TRAFFIC_MONITOR_INTERVAL
	dpmaif_clear_traffic_data(md_id, dpmaif_ctrl);
	timer_setup(&dpmaif_ctrl->traffic_monitor,
		dpmaif_traffic_monitor_func, 0);
#endif

	g_DPMAIF_CACHE_LINE_SIZE = (unsigned long)cache_line_size();
	MTK_DEBUG_LOG(TAG, "Cache line size = %lu\n",
		g_DPMAIF_CACHE_LINE_SIZE);

	/* throughput parameter clear */
#ifdef DATA_PATH_TP_CALC
	memset(&g_dpmf_tp_stat, 0, sizeof(struct dpmaif_tp_statistics));
	g_dpmf_tp_stat.rx_rec_enable = false;
	g_dpmf_tp_stat.tx_rec_enable = false;
#endif

	return 0;

err1:
	kfree(dpmaif_ctrl);
	ctlb->hif_ctrl = NULL;

err:
	return ret;
}

void dpmaif_hif_exit(unsigned char md_id, struct ccmni_ctl_block *ctlb)
{
	struct md_dpmaif_ctrl *dpmaif_ctrl;
	if (unlikely(ctlb == NULL)) {
		MTK_ERR_LOG(TAG, "input para is null err\n");
		return;
	}
	if (ctlb->hif_ctrl == NULL){
		MTK_ERR_LOG(TAG, "input para is null err\n");
		return;
	}
	
	dpmaif_ctrl = ctlb->hif_ctrl;
	
	if (dpmaif_ctrl->dpmaif_sw_init_done) {
		dpmaif_stop(md_id, dpmaif_ctrl);
		dpmaif_pm_entity_uninit(dpmaif_ctrl);
		dpmaif_sw_rel(md_id, dpmaif_ctrl);
		dpmaif_ctrl->dpmaif_sw_init_done = false;
	}

	if (dpmaif_ctrl != NULL) {
		kfree(dpmaif_ctrl);
		dpmaif_ctrl = NULL;
		ctlb->hif_ctrl = NULL;
	}

	MTK_INFO_LOG(TAG, "dpmaif hif exit done\n");
}

module_param(dpmaif_pcie_lock_res_try_wait_cnt, uint, 0644);
MODULE_PARM_DESC(dpmaif_pcie_lock_res_try_wait_cnt, "The PCIe lock try wait max count to dpmaif DLQ polling, default 20\n");
module_param(dpmaif_dl_workqueue_time_limit, uint, 0644);
MODULE_PARM_DESC(dpmaif_dl_workqueue_time_limit, "The timeout in milliseconds to dpmaif DLQ workqueue execute, default 2ms\n");
module_param(dpmaif_ul_workqueue_delay_time, uint, 0644);
MODULE_PARM_DESC(dpmaif_ul_workqueue_delay_time, "The timeout in milliseconds to dpmaif ULQ workqueue execute, default 0ms\n");
module_param(dpmaif_bat_burst_release_cnt, uint, 0644);
MODULE_PARM_DESC(dpmaif_bat_burst_release_cnt, "The value is the count that dpmaif burst release bat, default 30\n");
module_param(dpmaif_pit_burst_release_cnt, uint, 0644);
MODULE_PARM_DESC(dpmaif_pit_burst_release_cnt, "The value is the count that dpmaif burst release pit, default 60\n");

