/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PORT_NET_H__
#define __PORT_NET_H__
#include "ccmni.h"
#include "port_t.h"
extern struct ccmni_dev_ops ccmni_ops;

struct port_t *find_net_port_by_ccmni_idx(int md_id, int ccmni_idx);

#endif /*__PORT_NET_H__*/
