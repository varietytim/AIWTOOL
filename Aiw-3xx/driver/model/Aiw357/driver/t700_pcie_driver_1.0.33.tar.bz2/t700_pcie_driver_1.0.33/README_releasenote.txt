=================================================
version: 1.0.33
release date: 2023/08/22
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
	1. Redmine  #334  issue (How to check ccmni0 or ccmni1 by at command ?)
	   Enlarge the ccmni interface number to 8
	2. Fix the reboot crash issue after remove module

=================================================
version: 1.0.32
release date: 2023/06/08
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
	1. Fixed the PCIe mode can't be recognized when ubuntu reboot



=================================================
version: 1.0.31
release date: 2021/12/10
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
    1. Fixed the interrupt mask issue when the host suspends to idle state.
        1) description  :  When the device is resumed from s2idle state, the device's interrupts are in masked state.
        2) solution     :  When the device is resumed from s2idle state, the device's interrupts should be enabled.

=================================================
version: 1.0.30
release date: 2021/11/11
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Dump more CLDMA registers for debugging if TX ERR interrupts received.
        1) description  : use md_cldma_dump_status() instead of cldma_debug_dump() in cldma_irq_work_cb().
B. Fix issues
    1. Fix iperf TCP test, TP drop 0
        1) description  :  Observing intermittent throughput drops at higher layer while executing iperf test.
        2) solution     :  remove writing UL unmaks checking.

=================================================
version: 1.0.29
release date: 2021/07/27
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Decoupling the device and host system's low power feature.
        1) description  : Wraping the host driver's system related low power feature with linux system macro.

B. Fix issues
    1. Fix multi-thread access port issue.
        1) description  :  if multiple threads concurrently access port write, they would get same seq number, then exception will be triggered.
        2) solution     :  Add mutex to protect the seq number operation and skb sending .

    2. Masking the device interrupts before the device is resumed by host system.
        1) description  :  Before the host system resumes the device, the device's interrupts occur.
        2) solution     :  Masking the device interrupts before the device is resumed by host system.

=================================================
version: 1.0.28
release date: 2021/06/25
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
    1. Fix device DDR status abnormal issue after FLDR
        1) description  :  DDR status is not expected after FLDR, host needs disable DRM by itself.
        2) solution     :  To disable DRM (via MHCCIF bit 14) before FLDR.

    2. Fixed MSIX merge issue.
        1) description  :  When the max count of the MSIX entry is failed to be allocated, the MSIX merge flow will not be executed.
        2) solution     :  Changed the mininum number of the MSIX entry when trying to allocate MSIX entry from linux kernel.

    3. Fixed host dpmaif trigger crash if ul_get_ridx returned 0xffff.
        1) description  :  When ul_get_ridx get 0xffff, host dpmaif will reset hw_ridx and it lead to crash.
        2) solution     :  Check ridx range and add error handle flow if ridx is invalid.

=================================================
version: 1.0.27
release date: 2021/06/02
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
   1. Fix DPMAIF UDP freeze issue 
        1) description  :  IPERF UDP test, suffer UDP throughput freeze issue.
        2) solution     :  add error handle to match bat_wr_idx 

   2. Fix uninstall driver blocking issue during host driver exception handshake.
        1) description  :  Uninstall driver is blocking due to exception flow not finished (host driver is waiting for MD EE done).
        2) solution     :  Stop FSM exception timer when RGU IRQ received.

=================================================
version: 1.0.26
release date: 2021/05/14
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Enhance debug information while checking pci state registers.
        1) description  : Dump more pci registers for debugging if failed to read dummy register in driver probe procedure.

    2. Remove misleading comment in mtk_pci_l_resource_lock().
        1) description  : The comment in function mtk_pci_l_resource_lock() is unclear and misleading, remove it.

    3. Support maximum control transfer value for MBIM_OPEN_MSG.
        1) description  : MBIM 4K -> host driver 3.5K + 0.5K (split into two packets) -> MD CCCI 3.5K + 0.5K -> MBIM 4K.

    4. ccmniX net dev port re-create during S4/D3/L3 resume.
        1) description  : md_state change 4->8->2->3->4, net dev port will be removed and re-created.

B. Fix issues
   1. Fix CLDMA NULL pointer issue.
        1) description  :  There is an issue of no null pointer handling that may cause crash.
        2) solution     :  Add NULL pointer protection in md_cldma_start().
                        :  And add more spin lock protection in CLDMA function.

   2. Fix DPMAIF trigger pc crash 
        1) description  :  Device RGU, PCIe link off, then DPMAIF write DRB fail and trigger crash
        2) solution     :  check fsm state before trigger crash

=================================================
version: 1.0.25
release date: 2021/05/03
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Enhance data path debug information
        1) description  : replace crash PC with trigger modem dump.

    2. Modify preload WQ flag and clear BAT_CNT status
        1) description  : To reduce dequeue fail notice and clear bat count error status.

B. Fix issues
    1. Fix host driver async handshake and exception handshake race condition issue.
        1) description  :  a) In S4L3D3 test, async handshake is ongoing, MD EE comes later, both async and exception handshake doesn't work well.
                           b) In MD early EE test, async handshake comes later, both async and exception handshake doesn't work well.
        2) solution     :  a) HS2_EXIT event is first appended in core_reset which causes other events could't be read by list_first_entry.
                           b) Don't trigger async handshake when exception handshake is ongoing.
    2. Fixed the issue that the delayed unlock work queue was not cancelled, when the device has entried D3 state.
        1) description  :  When the device has entried D3 state, the delayed unlock work queue is not cancelled.
        2) solution     :  When the device has entried D3 state, the delayed unlock work queue will be always cancelled.

=================================================
version: 1.0.24
release date: 2021/04/19
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
    1. Fix host driver exception handshake timeout issue.
        1) description  :  In MD early EE test, host driver regards as timeout, but in fact exception handshake is pass.
        2) solution     :  HS2_EXIT event is first appended for exception which causes MD_EX/MD_EX_PASS event could't be read by list_first_entry.

=================================================
version: 1.0.23
release date: 2021/04/02
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
    1. Fix the issue that flash download port didn't pop during download stress test
        1) description  :  The polling counter in PRE_START command handler accumulates up to 200 so the dummy register query stops during stress test.
        2) solution     :  The counter should be reset if dummy register query done.

    2. Fixed host driver low power entity node unregister issue.
        1) description  :  When unregistering the low power entity, the enity note delete operation is not safe.
        2) solution     :  Used the safe function to iterate the list and delete the node.

=================================================
version: 1.0.22
release date: 2021/03/08
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
    1. Fix the issue that host driver could't enter Linux stage in BROM PCIE download timeout case.
        1) description  :  In SMPU test, host driver hangs in BROM stage when B2 is read, but B4 is not read before.
        2) solution     :  Start the dummy register polling timer in that case.

    2. Fix timing issue during host driver async handshake.
        1) description  :  In some race condition, host driver sets WAIT_FOR_HS2 first and then WAIT_FOR_HS1, which
                           leads to host driver couldn't enter ready state any more.
        2) solution     :  Always sets WAIT_FOR_HS1 first.

=================================================
version: 1.0.21
release date: 2021/02/22
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance

B. Fix issues
	1. Fixed interrupt unmask issue. 
		1) description	:  When the system is trying to go to low power mode, 
		                   the data path's interrupt's bottom half exited before the interupts 
		                   were not unmasked. 
		2) solution     :  After resuming the system, the host driver will 
                           unmask the downlink queue's interrupts.

	2. Fixed alloc port_proxy issue. 
		1) description	:  When run install-uninstall many times, the device major number will alloc fail. 
		2) solution     :  Modify the count in unregister flow to same to register.

=================================================
version: 1.0.20
release date: 2021/02/04
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	NA

B. Fix issues
    1. Fix BOOT HS failure during Hibernation Exit (S4/D3/L3) issue.
        1) description  :  In reinit flow, host driver sends handshake1 message twice. This ia a timing issue.
        2) solution     :  Swap the execution sequence of the two functions: md_evt_notify_hd & pcie_mhccif_isr

=================================================
version: 1.0.19
release date: 2021/01/27
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Enhance data path port initialization flow for supporting Modem manager 
        1) description  : The data port was created 2.5 seconds earlier than control port, so Modem Manager failed to create modem interface.
        2) solution     : Defer the data port creation till modem status is ready.

    2. Dump configuration space registers
        1) description  : To provide more information, dump configuration space registers when can't read dummy register

    3. Modify the delay time befor FLDR/PLDR in RGU IRQ handler from 2s to 10ms
        1) description  : To shorten the recovery time as much as possible

B. Fix issues
    1. Fix issues about g_mtk_rescan_context
        1) description  : Global varialbe g_mtk_rescan_context is not protected by spin_lock when read
        2) solution     : Protect the variable with spin_lock when read to prevent race condition

=================================================
version: 1.0.18
release date: 2020/12/29
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
    1. Enhance data path lowpower flow
        1) description  :  reduce driver access register over PCIe frequency
        2) solution     :  Add PIT and BAT release burst count, add NAPI polling budget count
        
B. Fix issues
    1. Fix BOOT HS failure during Hibernation Exit (S4/D3/L3) issue.
        1) description  :  Sometimes the work "core_hk_handler" can not be executed if the last handshake wasn't done yet.
        2) solution     :  Append HS2 EXIT event to exit the work "core_hk_handler" if the last handshake wasn't done yet. Must clear this event before entering the work "core_hk_handler".
	2. Fix Type error for license anouncement to BSD-3-Clause-Clear
		
=================================================
version: 1.0.17
release date: 2020/12/14
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. add dss port 
		1) description  :  add ttyCMBIMDSS0~ttyCMBIMDSS7 port for MBIM dss requirement.
		2) solution     :  add port entry in port configuration table.

	2. Enhance data path lowpower flow
		1) description	:  Because holding DPMAIF IP busy status too long, the device won't enter PCIe L1.2 status.
		2) solution     :  Try best to clear DPMAIF IP busy status in DL/UL flow.

	3. Enhance PCIe power resource lock/unlock API
		1) description	:  We can't use blocking API in atomic/interrupt context.
		2) solution     :  Add non-blocking PCIe power resource lock/unlock API.

	4. Enhance pm_counter for debugging
		1) description  :  To make it easier to synchronize logs for device's debugging.
		2) solution     :  Add a counter to distinguish each suspending and remusing.

	5. change license anouncement to BSD-3-Clause-Clear
		
B. Fix issues:
	1. md1_hif1_rx7_worker thread cause soft lockup
		1) description	:  md1_hif1_rx7_worker thread trys to send packet repeatly, however, if pcie link disconnect,
						   which will cause md1_hif1_rx7_worker enter while loop.
		2) solution     :  PCIe Link disconnect error handling.	
	2. fix exception issue in lowpower state
		1) description	:  device unexpected device PMIC reboot after AP kernel exception reboot in S0ix/D3/L2 on RVP. 
							That causes full DRAM dump failure.
		2) solution     :  set PCI status as D0 to increase power reference count and not to invoke PCI remove procedure after RVP resumed from S0ix/D3/L2.
	3. fix logic issue in cldma dump status
	4. fix a rx collect thread timing issue
		1) description  :  cldma_late_uninit is called firstly, then cancel_work is executed. at the time, rx workqueue maybe is running between cldma_sw_reset
							and cancel_work, which will cause crash.
		2) solution		: change cldma_late_uninit and  cancel_work sequence, and add workqueue stop condition.
    5. Fix downlink down ISR bottom half Concurrency issue.
		1) description  :  when dpmaif RX done interrupt mask fail, the NAPI and workqueue maybe have concurrency issue.
		2) solution     :  when we make sure the dpmaif RX done interrupt mask status is set successfully, we can schedule the dpmaif RX done interrupt bottom half. 

=================================================
version: 1.0.16
release date: 2020/11/09
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. Modify the default number of NIC
		1) description	:  Modify the default number of network interface.
		2) solution   	:  Modify the default nmber of NIC.

B. Fix issues:
	1. fix some issue which is found by coverity
		1) description	:  some error handling is enhanced.
		2) solution     :  multiple patch.
	2. Enhance dma pool create logic
		1) description	:  there are some software issues when dma mapping from pool.
		2) solution   	:  enhance dma pool create logic.
	3. fix CLDMA rx collect issue
		1) description	:  the second packets maybe lose, when multiple packets trigger single interrupt.
		2) solution     :  enhance cldma_rx_collect.
	4. Brom Download fail issue
		1) description	:  Download DA with 1 TGPD will be fail, Download other image with 16 TGPDs will be fail.
		2) solution     :  Host Driver will adjust TGPD dynamically.

		
=================================================
version: 1.0.15
release date: 2020/11/4
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. Enhance data path error handling in rx flow
		1) description	:  there are some software issues when driver checks pit sequeuece fail.
		2) solution   	:  enhance pit sequeuece check flow.
B. Fix issues:
	1. fix IP busy mask disable error
		1) description	:  IP BUSY BIT is set to mask, it will cause device enter sleep during data transmission.
		2) solution     :  unmask IP BUSY BIT in the function cldma_hw_init().
	2. Enhance dma pool create logic
		1) description	:  there are some software issues when dma mapping from pool.
		2) solution   	:  enhance dma pool create logic.
	3. fix deadlock when remove pci_device
		1) description  :  Using mtk_queue_rescan_work() may deadlock.
		2) solution     :  Reduce the protection scope of the spin_lock.

=================================================
version: 1.0.14
release date: 2020/10/29
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. Set the data path NAPI mode as default
		1) description	:  Linux NAPI GRO will increase the tcp througthput.
		2) solution   	:  Set the data path NAPI mode as default.
	2. Change driver's polling counts
		1) description	:  Add more polling count for waiting pit_seq ready.
		2) solution   	:  Add polling count.
	3. Remove unused code of MD reset 
		1) description	:  Host driver does not reset MD directly after MD exception flow is done. 
		2) solution   	:  remove unused code of MD reset 
B. Fix issues:
	1. fix data path null pointer issue
		1) description	:  data path accesses null pointer in ccmni exit flow on NAPI mode.
		2) solution   	:  modify the ccmni_close() and uninit_dummy_netdev_napi()	calling order.	
	2. fix rmmod memleak
		1) description  : When rmmod, device reference count is not zero, so it 
		does not be released.
		2) solution		: Use put_device() to reduce the increase in reference 
		count caused by driver_find_device().
	3. fix crash issue because of null pointer
	    1) description  : There is an issue of no null pointer handling that may cause crash.
		2) solution		: Add NULL pointer handle in ccci_fsm_get_current_state().
    4. fix issue of that memory dump can't be got after CLDMA assert.
	    1) description  : After CLDMA assert, memory dump can't be got.
		2) solution		: Achieve CLDMA hardware reset during MD EE.
	5. fix kernel hung crash
		1) description	:  Remove PCI device when MD assert happens at handshake stage cause kernel hung. Since handshake work is not stopped.
		2) solution   	:  stop handshake work in MD assert flow.

		
=================================================
version: 1.0.13
release date: 2020/10/15
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. Enhance the way to release skb in data path feature
		1) description	: data path uses ccci_free_skb(skb_free) to release skb in dpmaif_release_tx_buffer(), but,
							it's confusing, because data path don't use ccci_alloc_skb() to allocate skb.
		2) solution   	: data path replace ccci_free_skb(skb_free) with dev_kfree_skb_any(skb_free) in dpmaif_release_tx_buffer(). 
	2. Add function calling FLDR and PLDR inside to reset device in RGU IRQ handler 
		1) description	: device exception flow requires host to reset device 2s later after host receives RGU IRQ.
		2) solution   	: add function naming reset_device_via_pmic which finally controls PMIC RESET# and EN# pins.
	3. Add some enhance : L2 resume would shutdown PCIe to save more power, so when it resumes, host driver should configure to re-initialize PCIe.

B. Fix issues:
	1. fix memleak
		1) description  : md_hif_cldma_sw_reset set is_late_init flag to 0 but doesn't free ringbuffer memory, that cause memleak
		2) solution		: change setting is_late_init to 0 to calling ccci_cldma_late_init()
	2. the CPU loading consume too much by tx_collect thread
		1) description  : when user application write data too quickly, but cldma queue is busy, which will leads tx_collect thread 
		  consume too much CPU resource
		2) solution     : add port_write_room_to_md in port_dev_write() 
	3. fix data path memory leak issue
      	1) description	: only release one skb, but not all skb in rx skb list in ccci_skb_queue_rel() function.
      	2) solution   	: release all skb in rx skb list in ccci_skb_queue_rel() function. 
	4. fix two uninitialized spin lock
      	1) description	: "exp_spinlock" in "struct md_sys1_info" and "spinlock" in "struct ccci_hw_ctrl" did not be initialized.
      	2) solution   	: add spin_lock_init() in ccci_md_structure_reset() and ccci_cldma_get_hw_info(), for synchronize customers to fix the problem of blue screen.
	5. fix kernel hardlock issue
      	1) description	: dpmaif driver polling hardware blocks CPU in some corner case like device unexpected reboot.
      	2) solution   	: narrow spinlock protection scope in function fsm_state_notify()
	6. fix kernel crash issue
      	1) description	: userspace tool like putty still accesses deprecated tty port after PCI device is removed. That causes kernel crash.
      	2) solution   	: hung up tty before unregistering tty device
=================================================
version: 1.0.12
release date: 2020/9/21
Linux PCIE driver release with following function:
=================================================
A. New Feature or enhance
	1. Add lock_state attr file
		1) description	: lock_state attribute file
		2) solution   	: for lowpower debug
	2. Add PCIe logging enhance
		1) description	: PCIe log might not be enough for debugging.
		2) solution   	: Change some debug level to info level.
	3. Add md state attr file
		1) description	: md_state attribute file that help user get md state  
		2) solution   	: /sys/kernel/ccci/mdsys1/md_state
	4. Add data path througthput tuning feature
		1) description: code changes for data path througthput tuning
		2) solution: add some througthput tuning flow, data path configurations, TX/RX flow enhancement for data path througthput tuning.
	5. Add data path dpmaif registers dump feature
		1) description: dump dpmaif hardware registers for debugging when host data path asserts.
		2) solution: add dpmaif registers dump.
	6. Add data path functions and variables naming enhancement
		1) description: some data path function and variable names are confusing.
		2) solution: refine some data path function and variable names.	
	7. Enhance PCIe rescan flow
		1) description	: device may reboot 30s later after RGU IRQ sent to host.
		2) solution   	: extend the maximum timeout of rescan work to 35s.
B. Fix issues:
	1. Fix one PCIe issue:
		1) description  : When M80 init, MSIX interrut default value is on, causing interrupt comes in when driver not ready.
		2) solution		: mask all the interrupt before PCIe init done, and user would unmask their own interrupt when they are ready.
	2. Fix fsm_routine_pre_start is called infinitely
      	1) description 	: when dummy register change to invaild value(0xffffffff) during brom event monitor timer is running, the fsm_routine_pre_start
							will be scheduled infinitely.
      	2) Root Cause	: CCCI can't record invaild value as last dummy register, which cause brom event monitor timer check the difference of dummy 
							register, then the fsm_routine_pre_start will be re-scheduled.
      	3) solution		: record the invalid value as last dummy register value. 
	3. Fix Brom Download tx/rx fail issue:
      	1) description 	: In brom stage, flash tool download fail 
      	2) Root Cause	: when device enter download agent, the BROM_EVENT_JUMP_DA event will trigger host driver start execute hw_init, which will stop 
						   CLDMA.
      	3) solution		: adjuset cldma ccci_hif_hw_init()
	4. Fix one data path enable/disable dpmaif irq issue
		1) description: during Low Power suspend/resume, dpmaif only enables/disables DPMAIF_INT.
		2) Solution: during Low Power suspend/resume, dpmaif should enables/disables DPMAIF_INT and DPMAIF2_INT.

	5. Fix one spin_lock issue:
	    1) description  : In cldma_gpd_rx_collect() function, it may call twice "spin_unlock_irqrestore" and may cause system crash.
		2) solution		: Move "spin_unlock_irqrestore" to right location; make sure that it only call spin_unlock once. 
	6. Fix one CLDMA issue:
		1) description  : PCIe L2 accession has higher latency compared to L1, casusing fake CLDMA interrupt after CLDMA IRQ handler is done.
		2) solution		: read back register to flush L2 write
	7. Fix one timing issue:
		1) description  : when device self reboot with RGU IRQ sent to host while host PC enabled hot-plug. causiong timing issue like use-after-free memory.
		2) solution		: remove duplicated procedure for resouce release in RGU IRQ handler



=================================================
version: 1.0.11
release date: 2020/9/4
Linux PCIE driver release with following function:
=================================================
1. Support emergency download feature
2. Fix issues:
	1). fix ut_framework_work Issue
	2). fix control one PCIE remove blocking issue
	3). fix one data patch issue
	4). fix one handshake flow issue
	5). fix one brom event monitor timer Issue
3. Enhance CLDMA empty interrupt handler.

=================================================
version: 1.0.10
release date: 2020/8/24
Linux PCIE driver release with following function:
=================================================
1. Fix Issue:
	1). Fix one illegal memory access issue
	2). Fix one memleak issue
	3). Fix one NULL pointer issue
	4). Fix one low power issue
	5). Fix one port enumeration issue during re-initialization
2. support Linux Kernel 5.4 (build pass)
3. MHCCIF ISR Handler enhancement: Use difference ASPM_ENABLE_DISABLE_BIT with suspend
4. New feature: emergency download feature

=================================================
version: 1.0.9
release date: 2020/8/12
Linux PCIE driver release with following function:
=================================================
1. Add some enhance:
   1) Enable M80 Deep sleep state query
   2) Enhance some log print
   3) Enhance the dpmaif irq check
2. Fix some issue:
   1) Fix potential kernel crash issue
   2) Fix the TX thread softlock issue
   3) Fix timing issue that scheduling in atomic context
   4) Fix potential HIF layer overflow issue

=================================================
version: 1.0.8
release date: 2020/7/29
Linux PCIE driver release with following function:
=================================================
1. Support M80
2. Fix CLDMA register base address setting error issue
3. Add CLDMA right register dump capability that is useful to debug
4. Fix data plane issue
	1) Fix data plane dead lock issue
	2) Fix data plane DL error handling

=================================================
version: 1.0.7
release date: 2020/7/10
M70 linux PCIE driver release with following function:
=================================================
1. re-initialization flow
2. re-install flow
3. PCIe single context
4. Data path feature: GRO(generic receive offload) for NAPI Mode
5. Low power feature: D3/L2, D3/L3
6. Fix some Warning, Error of checkpatch
7. CCCI FSM refine

=================================================
version: 1.0.6
release date: 2020/6/24
M70 linux PCIE driver release with following function:
=================================================
1. add async handshake flow
2. files format refine for checkpatch in folder /ext_drv/
3. fix cldma_hw_stop_queue block issue when PCIe link down

=================================================
version: 1.0.5
release date: 2020/5/11
M70 linux PCIE driver release with following function:
=================================================
1. add low power feature code(Must use new released device load to test together)
	-- PCIE resource lock
	-- Suspend/Resume (S0ix)
	-- Suspend/Resume (S3/S4/S5 not tested)
	-- Finetune some logic
	-- Code change mainly see mtk-pci.c
2. refine cldma_gpd_rx_collect() function
3. add Meta port "ttyCMdMeta" and change MD logging port name to "ttyCMdLog"
4. refine host driver log level
	-- See util/mtk_util_log.c(.h)

=================================================
version: 1.0.4
release date: 2020/3/30
M70 linux PCIE driver release with following function:
=================================================
1. change AT/MIPC port from character device to TTY device
2. add port enumeration code for M80 reference
	-- generate "brom_download" port during BROM download flow
	-- generate "ttyDUMP" port during exception flow
3. add dpmaif HW change code for M80 reference
4. add PCIe HW change code for M80 reference
5. add ut_framework deamon readme.txt
6. add GPL license anouncement header
7. m70_host folder is removed

=================================================
version: 1.0.3
release date: 2020/2/28
M70 linux PCIE driver release with following function:
=================================================
1. add port enumeration code reference
2. merge pcie.ko and ccci.ko to mtk_pcie_wwan_m70.ko
3. add prefix to avoid name conflict in mtk_pcie_wwan_m70.ko
4. add new ports: ccci_sap_meta, ccci_sap_gnss, ccci_sap_log, ttyCMBIM0

=================================================
version: 1.0.2
release date: 2019/12/31
M70 linux PCIE driver release with following function:
=================================================
Description
1. remove unuseful register define
2. merge ccci_util.ko and ccci.ko to ccci.ko
3. remove exception related dump function
4. add prefix to avoid name conflict in pcie.ko
5. disable ccci_sap_lb_it function
6. enable ttyCMIPC0 function

=================================================
version: 1.0.1
release date: 2019/10/31
M70 linux PCIE driver release with basic function:
1. control path
2. data path
=================================================
Description:
This directory contains the source codes of M70 host CCCI(Cross Core Communication Interface) driver,running in kernel space. CCCI is the data/control interface between host Linux and M70 device.

The host CCCI driver provides standard linux device nodes, which can be find in directory /dev/. User can use this device nodes with linux standard API--open/close and read/write.
You can execute command "make" in driver top directory, then will get driver object files(*.ko) in folder /out, and the directory structure is shown as following.
(Note kernel version: 4.15.0-29-generic, gcc version: 5.4.0 20160609)
Common:PCIe core utilities like register access logic, irq handle logic, external driver interfaces.
ccci_util: the files in the folder provide common utility to CCCI core, such as CCCI logging system, sysfs and so on.
ccmni: cross-core Modem Network interface, which is network device driver layer for data path.
ccci_core: the files in the folder are abstract objects of modem hardware, used to control modem.
fsm: it is responsible for managing device states, and dealing with event in different device states.
hif: Hardware Interface, which includes cldma and dpmaif hardware operation.
m70_host: it includes some description files which mainly describe device related hardware operation and are different from hif.
port: the files in the folder are responsible for extending physical channel to logical channel, and provide device nodes or intermediate interface to other kernel modules.
pcie_drv: initialization of PCIE driver.
tools: driver installing script files and loopback testing files.
out: driver object -- *.ko and build_log



