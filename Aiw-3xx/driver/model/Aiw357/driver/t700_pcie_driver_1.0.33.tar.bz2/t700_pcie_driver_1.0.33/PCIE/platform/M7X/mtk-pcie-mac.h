/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_PCIE_MAC_H__
#define __MTK_PCIE_MAC_H__

#include "PCIE_MAC_IREG_c_header.h"

#define ATR_PORT_OFFSET         0x100
#define ATR_TABLE_OFFSET        0x20
#define ATR_TABLE_NUM_PER_ATR     8

#define MEMIO_BAR				BAR_4_5
#define MEMIO_SRC_PORT              ATR_SRC_PCI_WIN1
#define MEMIO_DST_PORT           ATR_DST_AXIM_0
#define MEMIO_TABLE_NUM		0
#define MEMIO_TRSL_ADDR(BASE)		MTK_PCIE_DUMMY_0(BASE)

#define OPERATION_GET 0
#define OPERATION_CLEAR 1
/* Interrupt offsert for ext interrupt */
#define PCIE_EXT_INTERRUPT_OFFSET		24

#define mtk_pcie_get_sw_trig_int(pbase)	\
	(MTK_PCIE_SW_TRIG_INT(pbase))
#define mtk_pcie_ext_int_status_clear(pbase, intr) \
	REG_SET(MTK_ISTATUS_HOST(pbase), \
	(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr)))
#define mtk_pcie_int_status_clear(pbase, intr)	\
	REG_SET(MTK_ISTATUS_HOST(pbase), (intr))
#define mtk_pcie_get_ep_data_buffer(pbase)	\
	(MTK_PCIE_DMA_DUMMY_0(pbase))
#define mtk_pcie_get_swint_status(pbase)		\
	(MTK_ISTATUS_HOST(pbase) & MTK_INT_ENABLE_HOST(pbase))
#define mtk_pcie_ext_int_status_clear_msix(pbase, intr) \
	REG_SET(MTK_MSIX_ISTATUS_HOST_GRP0_0(pbase), \
	(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr)))
#define mtk_pcie_set_msix_mask(pbase, ext_id)	\
	REG_SET(MTK_IMASK_HOST_MSIX_CLR_GRP0_0(pbase), 1 << ext_id)


struct mtk_addr_base {
	PPCIE_MAC_IREG_REGS  pcie_mac_ireg_base; /*PCIE MAC register base*/
	u64    pcie_ext_reg_base;  /*ext reg base*/
	u64    pcie_ext_mem_base;  /*pcie mem base*/
	/*device view base address, harcode for now*/
	u64    pcie_dev_reg_trsl_addr;
	u64    infracfg_ao_dev;  /*device view infra ao base*/
	u64    infracfg_ao_base;  /*host view infra ao base*/
	u64    mhccif_rc_base;  /*host view of mhccif rc base addr  */
	u64    mhccif_ep_base;  /*host view of mhccif ep base addr*/
};

typedef enum _atr_type {
	ATR_PCI2AXI = 0,
	ATR_AXI2PCI
} atr_type_e;

typedef enum _atr_src_port {
	ATR_SRC_PCI_WIN0 = 0,
	ATR_SRC_PCI_WIN1,
	ATR_SRC_AXIS_0,
	ATR_SRC_AXIS_1,
	ATR_SRC_AXIS_2,
	ATR_SRC_AXIS_3,
} atr_src_port_e;

typedef enum _atr_dst_port {
	ATR_DST_PCI_TRX = 0,
	ATR_DST_PCI_CONFIG,
	ATR_DST_AXIM_0 = 4,
	ATR_DST_AXIM_1,
	ATR_DST_AXIM_2,
	ATR_DST_AXIM_3,
} atr_dst_port_e;

typedef struct mtk_atr_config {
	u64 src_addr;
	u64 trsl_addr;
	u64 size;
	u32 type;	//Port type
	u32 port;	//Port number
	u32 table;	//Table number(8 tables for each port)
	u32 trsl_id;
	u32 trsf_param;
	u32 transparent;
} mtk_atr_config_t;

/* Dummy reg enum */
typedef enum _pcie_dummy_num {
	PCIE_DUMMY_BROM_0 = 0,
	PCIE_DUMMY_BROM_1,
	PCIE_DUMMY_BROM_2,
	PCIE_DUMMY_BROM_3,
	PCIE_DUMMY_EXCEPTION_0,
	PCIE_DUMMY_EXCEPTION_1,
	PCIE_DUMMY_EXCEPTION_2,
	PCIE_DUMMY_SYNC,
} _pcie_dummy_num;
extern void mtk_disable_atr_table(
	PPCIE_MAC_IREG_REGS pbase, atr_src_port_e port, u32 table);
extern void mtk_disable_all_atr_table(
	PPCIE_MAC_IREG_REGS pbase, atr_src_port_e port);
extern int mtk_setup_atr(PPCIE_MAC_IREG_REGS pbase, mtk_atr_config_t *cfg);
inline void mtk_pcie_intr_enable(PPCIE_MAC_IREG_REGS pbase, bool enable);
extern int mtk_pcie_mmio_mem(struct pci_dev *dev, int len, int offset);
extern int mtk_pcie_atr_init(struct pci_dev *dev);
extern void mtk_md_pcie_map_set(
	unsigned short device_id, u64 infra_ao_base,
	u32 map, u32 pcie_msb, u32 pcie_lsb);
extern void mtk_pcie_clear_sw_irq(
	PPCIE_MAC_IREG_REGS pbase, u32 soft_irq, u32 event);
void mtk_pci_mac_msix_desc_mask_irq(
	struct pci_dev *dev, u32 entry_nr, u32 flag);

extern void mtk_pcie_set_int_mask(
	struct mtk_pci_dev *mtk_dev, _pcie_int_e intr_type, bool mask);
bool mtk_pcie_int_judge(PPCIE_MAC_IREG_REGS pbase, u32 *ret_status);
extern int mtk_pcie_control_atr_event(
	struct mtk_pci_dev *mtk_dev, _pcie_int_e atr_type, u32 operation);
extern void mtk_pcie_set_host_int_en_mask(
	PPCIE_MAC_IREG_REGS pbase, u32 mask);
//extern void mtk_pcie_msi_capability_query(struct pci_dev *dev);
extern void mtk_pcie_set_dummy_reg(
	PPCIE_MAC_IREG_REGS pbase, u32 num, u32 val);
extern u32 mtk_pcie_get_dummy_reg(PPCIE_MAC_IREG_REGS pbase, u32 num);
void mtk_pcie_swint_clear(struct mtk_pci_dev *mtk_dev,unsigned int swint_num);
inline unsigned int mtk_pcie_msix_status_get(PPCIE_MAC_IREG_REGS pbase);
void mtk_pcie_msix_ctrl_cfg(PPCIE_MAC_IREG_REGS pbase, int msix_count);


#endif /*__MTK_PCIE_MAC_H__*/
