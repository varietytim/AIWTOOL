// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/init.h>
#include <linux/irq.h>
#include <linux/log2.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/fs.h>           /* everything... */
#include <linux/errno.h>        /* error codes */
#include <linux/types.h>        /* size_t */
#include <linux/pci.h>
#include <linux/random.h>
#include <linux/msi.h>
#include "mtk-pci.h"
#include "mtk-pcie-dbg.h"
#include "mtk-pcie-mac.h"
#include "mtk-pcie.h"

#include "PCIE_EXT_REG.h"
#include "mtk-atr.h"

void mtk_disable_atr_table(PPCIE_MAC_IREG_REGS pbase,
	atr_src_port_e port, u32 table)
{
	u8 *reg;
	u32 val;
	int offset;

	MTK_DEBUG_LOG(TAG, "Diable ATR port %d table %d:\n", port, table);

	/* Calculate table offset */
	offset = (ATR_PORT_OFFSET * port) + (ATR_TABLE_OFFSET * table);

	/* Disable table by SRC_ADDR_L*/
	reg = (u8 *)(MTK_REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB
	(pbase)) + offset;
	val = 0x0;
	REG_IO_WRITE32(reg, val);

	mb();
}

void mtk_disable_all_atr_table(PPCIE_MAC_IREG_REGS pbase, atr_src_port_e port)
{
	int i;

	for (i = 0; i < ATR_TABLE_NUM_PER_ATR; i++)
		mtk_disable_atr_table(pbase, port, i);
}

int mtk_setup_atr(PPCIE_MAC_IREG_REGS pbase, mtk_atr_config_t *cfg)
{
	u8 *reg;
	u32 val, size_h, size_l;
	int atr_size;
	int pos = 0, offset;

	if (cfg->transparent) {
		/* No address conversion is performed*/
		atr_size = 0x3F;
	} else {
		size_l = cfg->size & 0xFFFFFFFF;
		size_h = cfg->size >> 32;
		pos = ffs(size_l);
		if (pos) {
			atr_size = pos - 1 - 1;
		} else {
			pos = ffs(size_h);
			atr_size = pos + 32 - 1 - 1;
		}

		if (cfg->src_addr & (cfg->size-1)) {
			MTK_ERR_LOG(TAG,
				"[%s]Src addr is not aligned to size\n",
				__FILE__);
			return -1;
		}

		if (cfg->trsl_addr & (cfg->size-1)) {
			MTK_ERR_LOG(TAG,
				"[%s]Trsl addr is not aligned to size, %llx, %llx\n",
				__FILE__, cfg->trsl_addr, cfg->size-1);
			return -1;
		}
	}

	MTK_DEBUG_LOG(TAG, "Set up ATR:\n");
	MTK_DEBUG_LOG(TAG, "src addr 0x%0lx, trsl addr 0x%0lx\n",
		(unsigned long)cfg->src_addr,
			(unsigned long)cfg->trsl_addr);
	MTK_DEBUG_LOG(TAG, "size 0x%0lx, port type %d, port num %d\n",
		(unsigned long)cfg->size, cfg->type, cfg->port);
	MTK_DEBUG_LOG(TAG,
		"table %d, trsl id %d, trsf param 0x%x, transparent 0x%x\n",
		cfg->table, cfg->trsl_id, cfg->trsf_param, cfg->transparent);
	MTK_DEBUG_LOG(TAG, "pos %d, atr_size %d\n",
		pos, atr_size);
	/* Calculate table offset */
	offset = (ATR_PORT_OFFSET * cfg->port) +
		(ATR_TABLE_OFFSET * cfg->table);
	//xprintk(PCIE_DEBUG, "offset 0x%08x\n", offset);

	/* SRC_ADDR_H */
	reg = (u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB(pbase) + offset;
	val = (u32)(cfg->src_addr >> 32);
	//xprintk(PCIE_DEBUG, "reg 0x%08x, val 0x%08x\n", reg, val);
	REG_IO_WRITE32(reg, val);

	/* TRSL_ADDR_L */
	reg = (u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB(pbase) + offset;
	val = (u32)(cfg->trsl_addr & 0xFFFFF000);
	//xprintk(PCIE_DEBUG, "reg 0x%08x, val 0x%08x\n", reg, val);
	REG_IO_WRITE32(reg, val);

	/* TRSL_ADDR_H */
	reg = (u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB(pbase) + offset;
	val = (u32)(cfg->trsl_addr >> 32);
	//xprintk(PCIE_DEBUG, "reg 0x%08x, val 0x%08x\n", reg, val);
	REG_IO_WRITE32(reg, val);

	/* TRSL_PARAM */
	reg = (u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_PARAM(pbase) + offset;
	val = (cfg->trsf_param << 16) | cfg->trsl_id;
	//xprintk(PCIE_DEBUG, "reg 0x%08x, val 0x%08x\n", reg, val);
	REG_IO_WRITE32(reg, val);

	/* SRC_ADDR_L */
	reg = (u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB
		(pbase) + offset;
	val = (u32)(cfg->src_addr & 0xFFFFF000) | (atr_size << 1) | 0x1;
	//xprintk(PCIE_DEBUG, "reg 0x%08x, val 0x%08x\n", reg, val);
	REG_IO_WRITE32(reg, val);

	/* Readback to ensure ATR is set */
	val = REG_IO_READ32(reg);

	mb();

	return 0;
}




int mtk_pcie_mmio_mem(struct pci_dev *dev, int len, int offset)
{
//	struct pci_dev *dev;
	struct mtk_pci_dev *mtk_dev;
	int i, val, fail = 0;
	long base, limit;
	int *data;
	mtk_atr_config_t cfg;

	mtk_dev = pci_get_drvdata(dev);

	limit = (long)mtk_dev->mem[MEMIO_BAR]+mtk_dev->resource_len[MEMIO_BAR];
	base = (long)mtk_dev->mem[MEMIO_BAR]+offset;
	MTK_DEBUG_LOG(TAG, "MMIO base 0x%08lx, len 0x%08x, limit 0x%08lx\n",
		 base, len, limit);

	if (base > limit || base+len > limit) {
		MTK_ERR_LOG(TAG,
			"The access range of mmio is out of the resource range\n");
		return -1;
	}

	//Set up ATR
	cfg.src_addr = mtk_dev->resource_start[MEMIO_BAR];
	cfg.size = mtk_dev->resource_len[MEMIO_BAR];
	cfg.trsl_addr = MEMIO_TRSL_ADDR(mtk_dev->base_addr.pcie_mac_ireg_base);
	cfg.type = ATR_PCI2AXI;
	cfg.port = MEMIO_SRC_PORT;
	cfg.table = MEMIO_TABLE_NUM;
	cfg.trsl_id = MEMIO_DST_PORT;
	cfg.trsf_param = 0x0;
	cfg.transparent = 0;
	mtk_disable_all_atr_table(
		mtk_dev->base_addr.pcie_mac_ireg_base, cfg.port);
	mtk_setup_atr(mtk_dev->base_addr.pcie_mac_ireg_base, &cfg);

	//Enable correctable error report
	mtk_setup_error_report(dev, TRUE);

	data = kmalloc(len, GFP_KERNEL);
	if (!data) {
		MTK_ERR_LOG(TAG,
			"Allocate data buffer size 0x%08x failed", len);
		goto err;
	}

	//Generate data pattern
	for (i = 0; i*sizeof(int) < len; i++)
		get_random_bytes(data+i, 4);

	//write mmio memory
	for (i = 0; i*sizeof(int) < len; i++) {
		MTK_DEBUG_LOG(TAG, "Write data 0x%08x to memory 0x%08lx\n",
			*(data+i), (base+i*4));
		OUTREG32((base+i*4), *(data+i));
	}
	mb();



	//read mmio memory
	for (i = 0; i*sizeof(int) < len; i++) {
		val = INREG32((base+i*4));
		if (*(data+i) != val) {
			fail = 1;
			MTK_DEBUG_LOG(TAG,
				"Read data from 0x%08lx is 0x%08x not equal to data 0x%08x\n",
				(base+i*4), val, *(data+i));
		}
	}

	if (fail)
		goto err;

	kfree(data);

	// Disable tables
	mtk_disable_all_atr_table(
	mtk_dev->base_addr.pcie_mac_ireg_base, cfg.port);

	//Disable correctable error report
	mtk_setup_error_report(dev, FALSE);

	return 0;

err:

	kfree(data);

	// Disable tables
	mtk_disable_all_atr_table(
		mtk_dev->base_addr.pcie_mac_ireg_base, cfg.port);

	//Disable correctable error report
	mtk_setup_error_report(dev, FALSE);
	//xprintk(PCIE_DEBUG, "ERROR count: %d\n", g_err_count);

	return -1;

}

void mtk_pcie_set_dev_reg_trsl_addr(struct mtk_pci_dev *mtk_dev, u64 addr)
{
	mtk_dev->base_addr.pcie_dev_reg_trsl_addr = addr;

	//g_PCIE_DEV_REG_TRSL_ADDR = addr;
}

int mtk_pcie_atr_init(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;
	mtk_atr_config_t cfg;
	u32 i;

	MTK_DEBUG_LOG(TAG, "Init ATR tables\n");

	mtk_dev = pci_get_drvdata(dev);

	/* Disable all ATR table for all ports*/
	for (i = ATR_SRC_PCI_WIN0; i <= ATR_SRC_AXIS_3 ; i++)
		mtk_disable_all_atr_table(
			mtk_dev->base_addr.pcie_mac_ireg_base, i);


	/* Config ATR for RC to access EP's memory */
	/* Share memory is not used now so no setting here */

	/* Config ATR for RC to access device's register */
	MTK_DEBUG_LOG(TAG, "Setup BAR %d reg ATR\n", PCIE_REG_BAR);
	cfg.src_addr = mtk_dev->resource_start[PCIE_REG_BAR];
	cfg.size = PCIE_REG_SIZE;
	cfg.trsl_addr = PCIE_REG_TRSL_ADDR;
	cfg.type = ATR_PCI2AXI;
	cfg.port = PCIE_REG_PORT;
	cfg.table = PCIE_REG_TABLE_NUM;
	cfg.trsl_id = PCIE_REG_TRSL_PORT;
	cfg.trsf_param = 0x0;
	cfg.transparent = 0x0;
	mtk_disable_all_atr_table(
		mtk_dev->base_addr.pcie_mac_ireg_base, cfg.port);
	mtk_setup_atr(mtk_dev->base_addr.pcie_mac_ireg_base, &cfg);

	/* Update translation base */
	mtk_pcie_set_dev_reg_trsl_addr(mtk_dev, PCIE_REG_TRSL_ADDR);

	/* Config ATR for EP to access RC's memory */
	for (i = PCIE_DEV_DMA_PORT_START; i <= PCIE_DEV_DMA_PORT_END; i++) {
		MTK_DEBUG_LOG(TAG, "Setup port %d dev dma ATR\n", i);
		cfg.src_addr = PCIE_DEV_DMA_SRC_ADDR;
		cfg.size = PCIE_DEV_DMA_SIZE;
		cfg.trsl_addr = PCIE_DEV_DMA_TRSL_ADDR;
		cfg.type = ATR_AXI2PCI;
		cfg.port = i;
		cfg.table = PCIE_DEV_DMA_TABLE_NUM;
		cfg.trsl_id = ATR_DST_PCI_TRX;
		cfg.trsf_param = 0x0;
		/*Enable transparent translation*/
		cfg.transparent = PCIE_DEV_DMA_TRANSPARENT;
		mtk_disable_all_atr_table(
			mtk_dev->base_addr.pcie_mac_ireg_base, cfg.port);
		mtk_setup_atr(mtk_dev->base_addr.pcie_mac_ireg_base, &cfg);
	}

	return 0;
}

void mtk_md_pcie_map_set(unsigned short device_id,
	u64 infra_ao_base, u32 map, u32 pcie_msb, u32 pcie_lsb)
{
	u32 msb, lsb;

	if (map >= PCIE_MD_REMAP_SET) {
		MTK_ERR_LOG(TAG, "Wrong MD2PCIE map number!\r\n");
		return;
	}

	msb = pcie_msb >> 22;
	lsb = (pcie_msb & ((1 << 22)-1)) << 10 | (pcie_lsb >> 22);
	MTK_DEBUG_LOG(TAG,
		"%x Setup md2pcie map %d, map addr: MSB %x, LSB %x, setting: MSB %x, LSB %x,infra_ao_base %llx\r\n",
		device_id, map, pcie_msb,
		pcie_lsb, msb, lsb, infra_ao_base);

	if (map < 4) {
		REG_IO_WRITE32(
			REG_3A_MD2PCIE_MAPn_MSB(map, infra_ao_base), msb);
		REG_IO_WRITE32(
			REG_3A_MD2PCIE_MAPn_LSB(map, infra_ao_base), lsb);
	} else {
		REG_IO_WRITE32(
			REG_3B_MD2PCIE_MAPn_MSB(map%4, infra_ao_base), msb);
		REG_IO_WRITE32(
			REG_3B_MD2PCIE_MAPn_LSB(map%4, infra_ao_base), lsb);
	}


	MTK_DEBUG_LOG(TAG, "%x Setup md2pcie map %d done\n", device_id, map);
}

inline void mtk_pcie_intr_enable(PPCIE_MAC_IREG_REGS pbase, bool enable)
{
	if (enable == TRUE) {
		ISTATUS_HOST_CTRL_SET_ISTATUS_HOST_DIS(
			MTK_ISTATUS_HOST_CTRL(pbase), 0x0);
	} else {
		ISTATUS_HOST_CTRL_SET_ISTATUS_HOST_DIS(
			MTK_ISTATUS_HOST_CTRL(pbase), 0x1);
	}
}

void mtk_pcie_clear_sw_irq(PPCIE_MAC_IREG_REGS pbase, u32 soft_irq, u32 event)
{
	REG_ISTATUS_HOST status;

	status = (REG_ISTATUS_HOST)MTK_ISTATUS_HOST(pbase);

	MTK_DEBUG_LOG(TAG, "Got software irq%d (0x%x)\n", event, status.Raw);

	/* Clear software irq */
	soft_irq &= ~(1 << event);
	REG_SET(MTK_PCIE_SW_TRIG_INT(pbase), soft_irq);

	/* clear interrupt flag */
	REG_SET(MTK_ISTATUS_HOST(pbase), 1 << event);
}

bool mtk_pcie_int_judge(PPCIE_MAC_IREG_REGS pbase, u32 *ret_status)
{
	REG_ISTATUS_HOST status;
	REG_INT_ENABLE_HOST int_en;

	status = (REG_ISTATUS_HOST)MTK_ISTATUS_HOST(pbase);
	int_en = (REG_INT_ENABLE_HOST)MTK_INT_ENABLE_HOST(pbase);

	if (unlikely(!status.Raw))
		/* Shared interrupt with other device */
		return FALSE;
	/* for sw intr debug*/
	MTK_DEBUG_LOG(TAG, "ISTATUS_HOST status raw= 0x%x,\n", status.Raw);
	*ret_status = 0;

	/* SAP RGU interrupt */
	if (unlikely(status.Bits.SAP_RGU_INT & int_en.Bits.SAP_RGU_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "SAP RGU interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.SAP_RGU_INT, int_en.Bits.SAP_RGU_INT_EN);
		*ret_status |= 1 << _SAP_RGU_INT;
		}

	/* SW interrupt */
	if (unlikely(status.Bits.MHCCIF_INT & int_en.Bits.MHCCIF_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "MHCCIF interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.MHCCIF_INT, int_en.Bits.MHCCIF_INT_EN);
		*ret_status |= 1 << _MHCCIF_INT;
		}

	/* CLDMA2 interrupt */
	if (unlikely(status.Bits.CLDMA2_INT & int_en.Bits.CLDMA2_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "CLDMA2 interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.CLDMA2_INT, int_en.Bits.CLDMA2_INT_EN);
		*ret_status |= 1 << _CLDMA2_INT;
		}

	/* CLDMA1 interrupt */
	if (unlikely(status.Bits.CLDMA1_INT & int_en.Bits.CLDMA1_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "CLDMA1 interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.CLDMA1_INT, int_en.Bits.CLDMA1_INT_EN);
		*ret_status |= 1 << _CLDMA1_INT;
		}

	/* CLDMA0 interrupt */
	if (unlikely(status.Bits.CLDMA0_INT & int_en.Bits.CLDMA0_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "CLDMA0 interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.CLDMA0_INT, int_en.Bits.CLDMA0_INT_EN);
		*ret_status |= 1 << _CLDMA0_INT;
		}

	/* DPMAIF interrupt */
	if (likely(status.Bits.DPMAIF_INT & int_en.Bits.DPMAIF_INT_EN)) {
		MTK_DEBUG_LOG(TAG, "DPMAIF interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.DPMAIF_INT, int_en.Bits.DPMAIF_INT_EN);
		*ret_status |= 1 << _DPMAIF_INT;
	}

	/* A_ATR_EVT interrupt */
	if (unlikely(status.Bits.A_ATR_EVT & int_en.Bits.A_ATR_EVT_EN)) {
		MTK_DEBUG_LOG(
			TAG, "PCIE A_ATR_EVT interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.A_ATR_EVT, int_en.Bits.A_ATR_EVT_EN);
		*ret_status |= 1<<_A_ATR_INT;   //PCI2AXI==A_ATR?
		}
	/* P_ATR_EVT interrupt */
	if (unlikely(status.Bits.P_ATR_EVT & int_en.Bits.P_ATR_EVT_EN)) {
		MTK_DEBUG_LOG(
			TAG, "PCIE P_ATR_EVT interrupt triggered(0x%x, 0x%x)\n",
			status.Bits.P_ATR_EVT, int_en.Bits.P_ATR_EVT_EN);
		*ret_status |= 1<<_P_ATR_INT;
		}
	return TRUE;
}


void mtk_pci_mac_msix_desc_mask_irq(struct pci_dev *dev,
	u32 entry_nr, u32 flag)
{
	struct msi_desc *desc;
	u32 mask_bits;
	unsigned int offset = entry_nr * PCI_MSIX_ENTRY_SIZE +
						PCI_MSIX_ENTRY_VECTOR_CTRL;

	//xprintk(PCIE_DEBUG, "MSIX mask offset 0x%x\n", offset);

	desc = first_pci_msi_entry(dev);
	mask_bits = readl(desc->mask_base + offset);

	mask_bits &= ~PCI_MSIX_ENTRY_CTRL_MASKBIT;
	if (flag)
		mask_bits |= PCI_MSIX_ENTRY_CTRL_MASKBIT;
	writel(mask_bits, desc->mask_base + offset);

}

void mtk_pcie_set_int_mask_msix(struct mtk_pci_dev *mtk_dev,_pcie_int_e intr_type, bool mask)
{
	if (unlikely(intr_type > _END_INT)) {
		MTK_ERR_LOG(TAG,
			"Wrong intr_type (%d) not existed while setting int mask (%d)!\r\n",
			intr_type, mask);
		return;
	}
	if (mask) {
		if (likely(intr_type <= _END_EXT_INT)) {
			REG_SET(MTK_IMASK_HOST_MSIX_CLR_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr_type)));
		} else if (intr_type == _A_ATR_INT) {
			REG_SET(MTK_IMASK_HOST_MSIX_CLR_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_A_ATR_EVT));
		} else if (intr_type == _P_ATR_INT) {
			REG_SET(MTK_IMASK_HOST_MSIX_CLR_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_P_ATR_EVT));
		}
	}
	// FALSE == MASK
	else {
		if (likely(intr_type <= _END_EXT_INT)) {
			REG_SET(MTK_IMASK_HOST_MSIX_SET_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr_type)));
		} else if (intr_type == _P_ATR_INT) {
			REG_SET(MTK_IMASK_HOST_MSIX_SET_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_A_ATR_EVT));
		} else if (intr_type == _P_ATR_INT) {
			REG_SET(MTK_IMASK_HOST_MSIX_SET_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_P_ATR_EVT));
		}
	}

}

int mtk_pcie_control_atr_event_msix(struct mtk_pci_dev *mtk_dev,_pcie_int_e atr_type, u32 operation)
{
	//atr_type param check
	if (atr_type < _A_ATR_INT || atr_type > _P_ATR_INT) {
		MTK_ERR_LOG(TAG,
			"Wrong atr_type (%d) not existed !\r\n", atr_type);
		return 0;
	}

	if (operation == OPERATION_GET) {
		if (atr_type == _A_ATR_INT) {
			return REG_FLD_GET(ISTATUS_HOST_FLD_A_ATR_EVT,
				MTK_MSIX_ISTATUS_HOST_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base));
		} else if (atr_type == _P_ATR_INT) {
			return  REG_FLD_GET(ISTATUS_HOST_FLD_P_ATR_EVT,
				MTK_MSIX_ISTATUS_HOST_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base));
		}
		//no else condition due to param check
	} else if (operation == OPERATION_CLEAR) {
		if (atr_type == _A_ATR_INT) {
			REG_SET(MTK_MSIX_ISTATUS_HOST_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_A_ATR_EVT));
		} else if (atr_type == _P_ATR_INT) {
			REG_SET(MTK_MSIX_ISTATUS_HOST_GRP0_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_P_ATR_EVT));
		}

	} else {
		MTK_ERR_LOG(TAG, "Wrong operation (%d) not existed !\r\n",
			operation);
	}
	return 0;
}


void mtk_pcie_set_int_mask(struct mtk_pci_dev *mtk_dev,
	_pcie_int_e intr_type, bool mask)
{
	if (unlikely(intr_type > _END_INT)) {
		MTK_ERR_LOG(TAG,
			"Wrong intr_type (%d) not existed while setting int mask (%d)!\r\n",
			intr_type, mask);
		return;
	}

	if (mtk_dev->pdev->msix_enabled)
		return mtk_pcie_set_int_mask_msix(mtk_dev,intr_type,  mask);


	if (mask) {
		if (likely(intr_type <= _END_EXT_INT)) {
			INT_ENABLE_HOST_CLR_SET_HOST_INT_Enable_Clr(
				MTK_INT_ENABLE_HOST_CLR(mtk_dev->base_addr.pcie_mac_ireg_base),
				(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr_type)));
			}
		else if (intr_type == _A_ATR_INT) {
			INT_ENABLE_HOST_CLR_SET_HOST_INT_Enable_Clr(
				MTK_INT_ENABLE_HOST_CLR(mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_A_ATR_EVT));
			}
		else if (intr_type == _P_ATR_INT) {
			INT_ENABLE_HOST_CLR_SET_HOST_INT_Enable_Clr(
				MTK_INT_ENABLE_HOST_CLR(mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(ISTATUS_HOST_FLD_P_ATR_EVT));
			}
		}
	// FALSE == MASK
	else {
		if (likely(intr_type <= _END_EXT_INT)) {
			INT_ENABLE_HOST_SET_SET_HOST_INT_Enable_Set(
				MTK_INT_ENABLE_HOST_SET(mtk_dev->base_addr.pcie_mac_ireg_base),
				(1 << (PCIE_EXT_INTERRUPT_OFFSET+intr_type)));
			}
		else if (intr_type == _A_ATR_INT) {
			INT_ENABLE_HOST_SET_SET_HOST_INT_Enable_Set(
				MTK_INT_ENABLE_HOST_SET(mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(INT_ENABLE_HOST_FLD_A_ATR_EVT_EN));
			}
		else if (intr_type == _P_ATR_INT) {
			INT_ENABLE_HOST_SET_SET_HOST_INT_Enable_Set(
				MTK_INT_ENABLE_HOST_SET(mtk_dev->base_addr.pcie_mac_ireg_base),
				REG_FLD_MASK(INT_ENABLE_HOST_FLD_P_ATR_EVT_EN));
			}
		}

}


int mtk_pcie_control_atr_event(
	struct mtk_pci_dev *mtk_dev, _pcie_int_e atr_type, u32 operation)
{

	//atr_type param check
	if (atr_type < _A_ATR_INT || atr_type >  _P_ATR_INT) {
		MTK_ERR_LOG(TAG,
			"Wrong atr_type (%d) not existed !\r\n", atr_type);
		return 0;
	}

	if (mtk_dev->pdev->msix_enabled)
		return mtk_pcie_control_atr_event_msix(mtk_dev,atr_type,  operation);


	if (operation == OPERATION_GET) {
		if (atr_type == _A_ATR_INT) {
			return ISTATUS_HOST_GET_A_ATR_EVT(
				MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base));
			}
		else if (atr_type == _P_ATR_INT) {
			return  ISTATUS_HOST_GET_P_ATR_EVT(
				MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base));
			}
		//no else condition due to param check
		}
	else if (operation == OPERATION_CLEAR) {
		if (atr_type == _A_ATR_INT) {
			ISTATUS_HOST_SET_A_ATR_EVT(MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base),
				0xF);
			}
		else if (atr_type == _P_ATR_INT) {
			ISTATUS_HOST_SET_P_ATR_EVT(MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base),
				0xF);
			}
		} else {
			MTK_ERR_LOG(TAG,
				"Wrong operation (%d) not existed !\r\n",
				operation);
		}
	return 0;
}

/*now just let mask to set from 0 to 1 to mask or unmask all intr en.
 *keep input flexibility for masking single intr en.
 */
void mtk_pcie_set_host_int_en_mask(PPCIE_MAC_IREG_REGS pbase, u32 mask)
{
	if (!mask) {
		INT_ENABLE_HOST_SET_HOST_INT_Enable(MTK_INT_ENABLE_HOST(pbase),
			0xFF77FFFF);
		}
	else {
		INT_ENABLE_HOST_SET_HOST_INT_Enable(MTK_INT_ENABLE_HOST(pbase),
			(u32)0x0);
		}
}

void mtk_pcie_set_dummy_reg(PPCIE_MAC_IREG_REGS pbase, u32 num, u32 val)
{

	volatile unsigned int *dummy = &MTK_PCIE_DBG_DUMMY_0(pbase);

	*(dummy+num) = val;
}

u32 mtk_pcie_get_dummy_reg(PPCIE_MAC_IREG_REGS pbase, u32 num)
{
	volatile unsigned int *dummy = &MTK_PCIE_DBG_DUMMY_0(pbase);

	return *(dummy+num);
}
void mtk_pcie_swint_clear(struct mtk_pci_dev *mtk_dev,unsigned int swint_num)
{
	MTK_DEBUG_LOG(TAG, "got sw int %d\n", swint_num);

	if (mtk_dev->pdev->msix_enabled) {
		REG_SET(MTK_MSIX_ISTATUS_HOST_GRP0_0(
			mtk_dev->base_addr.pcie_mac_ireg_base),
			1 << (swint_num + MTK_PCIE_SWINT_OFFSET));
	} else {
		REG_SET(MTK_SW_TRIG_INTR_CLR(
			mtk_dev->base_addr.pcie_mac_ireg_base),
			1 << (swint_num + MTK_PCIE_SWINT_OFFSET));
		REG_SET(MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base),
			1 << (swint_num + MTK_PCIE_SWINT_OFFSET));
	}

}

inline unsigned int mtk_pcie_msix_status_get(PPCIE_MAC_IREG_REGS pbase)
{
	MTK_DEBUG_LOG(TAG,
		"MSIX_ISTATUS_HOST_GRP0_0 0x%x, IMASK_HOST_MSIX_GRP0_0 0x%x\n",
		MTK_MSIX_ISTATUS_HOST_GRP0_0(pbase),
		MTK_IMASK_HOST_MSIX_GRP0_0(pbase));
	return (MTK_MSIX_ISTATUS_HOST_GRP0_0(pbase) &
		MTK_IMASK_HOST_MSIX_GRP0_0(pbase));

}

void mtk_pcie_msix_ctrl_cfg(PPCIE_MAC_IREG_REGS pbase, int msix_count)
{
	if (msix_count == 0) {
		PCIE_CFG_MSIX_SET_cfg_msix_ctrl(MTK_PCIE_CFG_MSIX(pbase), 0);
	} else {
		MTK_DEBUG_LOG(TAG, "mtk_msix_merge_set 0x%x\n",
			ffs(msix_count)*2 - 1);
		PCIE_CFG_MSIX_SET_cfg_msix_ctrl(
			MTK_PCIE_CFG_MSIX(pbase), ffs(msix_count)*2 - 1);
	}
}
