/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_PCIE_DBG_H__
#define __MTK_PCIE_DBG_H__

#include <linux/kernel.h>       /* printk() */
#include "mtk_util_log.h"

#define TAG				("PCIE")

#define MTK_PCI_PM_FUNC_ENTER() \
	MTK_INFO_LOG("PM", "%s Enter\n", __func__)
#define MTK_PCI_ERS_FUNC_ENTER() \
	MTK_INFO_LOG("ERS", "%s Enter\n", __func__)

#endif /*__MTK_DBG_H__*/
