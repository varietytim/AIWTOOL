/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef _MTK_ISR_H_
#define _MTK_ISR_H_

#include <linux/interrupt.h>

#define PCIE_EXT_INT_OFFSET		24
#define PCIE_SW_INT_MAX		32

typedef enum _pcie_a_atr_int {
	ATR_AXI_POST_ERR_INT = 0,
	ATR_AXI_FETCH_ERR_INT,
	ATR_AXI_DISCARD_ERR_INT,
	ATR_AXI_DOORBELL_INT,
} pcie_a_atr_int_e;

typedef enum _pcie_p_atr_int {
	ATR_PCI_POST_ERR_INT = 0,
	ATR_PCI_FETCH_ERR_INT,
	ATR_PCI_DISCARD_ERR_INT,
	ATR_PCI_DOORBELL_INT,
} pcie_p_atr_int_e;


typedef struct mtk_pci_isr_res {
	struct mtk_pci_dev *mtk_dev;
	int isr_vector;
	int irq;
	irqreturn_t	(*isr)(int irq, void *__res);
	char	irq_descr[64];
} mtk_pci_isr_res_s;





/*
 * Exported function
 */

mtk_pci_isr_res_s *mtk_pci_request_isr_table(int msi_count);
extern irqreturn_t mtk_pcie_irq(int irq, void *__res);
extern irqreturn_t mtk_pcie_at_irq(int irq, void *__res);
extern void mtk_pcie_isr_service_task(struct work_struct *work);
extern void mtk_pcie_isr_service_event_schedule(struct mtk_pci_dev *mtk_dev);

#endif /*_MTK_ISR_H_*/
