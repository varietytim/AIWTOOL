// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */



#include <linux/irq.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/errno.h>        /* error codes */
#include <linux/types.h>        /* size_t */
#include <linux/string.h>
#include <linux/random.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/kthread.h>  // for threads
#include <linux/sched.h>  // for task_struct

#include "mtk-pcie-dbg.h"
#include "mtk-pci.h"
#include "mtk-pcie.h"
#include "chip_def.h"
#include "mtk-pcie-mac.h"
#include "mtk-pci-ext.h"
#include "mtk_pcie_ext.h"
#include "mtk-isr.h"
#include "mhccif.h"
#include "PCIE_MAC_IREG_c_header.h"

#define INT_MASK(mask, shift)	((mask)<<(shift))
#define EP2RC_SW_INT_SHIFT	24
#define EP2RC_SW_INT_MASK	INT_MASK(0xFF, EP2RC_SW_INT_SHIFT)

static u64 ds_lock_recvd;

static void mtk_pcie_isr_service_event_complete(
	struct mtk_pci_dev *mtk_dev);







u32 mtk_pci_msix_map[MTK_PCIE_IRQ_COUNT/2][5] = {
	{0xFFFFFFFF, 0x55555555, 0x11111111, 0x01010101, 0x00010001},
	{0x00000000, 0xAAAAAAAA, 0x22222222, 0x02020202, 0x00020002},
	{0x00000000, 0x00000000, 0x44444444, 0x04040404, 0x00040004},
	{0x00000000, 0x00000000, 0x88888888, 0x08080808, 0x00080008},
	{0x00000000, 0x00000000, 0x00000000, 0x10101010, 0x00100010},
	{0x00000000, 0x00000000, 0x00000000, 0x20202020, 0x00200020},
	{0x00000000, 0x00000000, 0x00000000, 0x40404040, 0x00400040},
	{0x00000000, 0x00000000, 0x00000000, 0x80808080, 0x00800080},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x01000100},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x02000200},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x04000400},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x08000800},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x10001000},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x20002000},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x40004000},
	{0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x80008000},
};



void mtk_pcie_swintx_isr(int irq, void *__res)
{
	struct mtk_pci_dev *mtk_dev = __res;
	unsigned int status;
	unsigned long flags = 0;
	int i;

	status = mtk_pcie_get_swint_status(
		mtk_dev->base_addr.pcie_mac_ireg_base);
	for (i = 0; i < MTK_PCIE_SWINT_COUNT; i++) {
		if (status & (1 << (i + MTK_PCIE_SWINT_OFFSET))) {
			mtk_pcie_swint_clear(mtk_dev,i);
			spin_lock_irqsave(&mtk_dev->lock, flags);
			mtk_dev->swint_flag |= 1 << (i + MTK_PCIE_SWINT_OFFSET);
			spin_unlock_irqrestore(&mtk_dev->lock, flags);

		}
	}
}



irqreturn_t mtk_pcie_msix_irq(int irq, void *__res)
{
	mtk_pci_isr_res_s *mtk_isr_res = __res;
	struct mtk_pci_dev *mtk_dev;
	int i, mod_irq, ext_int;
	unsigned int msix_status;
	bool swq_en = FALSE;
	irqreturn_t ret = IRQ_NONE;
	unsigned long flags = 0;
	/* Read status */
	mtk_dev = mtk_isr_res->mtk_dev;

	msix_status = mtk_pcie_msix_status_get(
		mtk_dev->base_addr.pcie_mac_ireg_base);

	/* Check if it is PCIE interrupt */
	if (!mtk_dev->msix_merged) {
		if (!(msix_status & (1 << mtk_isr_res->isr_vector))) {
			/* Shared interrupt with other device */
			goto _exit;
		}
	} else {
		MTK_DEBUG_LOG(TAG,
			"MSIX Merge Map 0x%x\n",
			mtk_pci_msix_map[mtk_isr_res->isr_vector][ffs(mtk_dev->irq_count)-1]);
		if (!(msix_status &
			mtk_pci_msix_map[mtk_isr_res->isr_vector][ffs(mtk_dev->irq_count)-1])) {
			/* Shared interrupt with other device */
			goto _exit;
		}
	}

	/* Find which interrupt is triggered */
	if (!mtk_dev->irq_count) {
		MTK_ERR_LOG(TAG, "MSIX Ext interrupt irq count is 0\n");
		goto _exit;
	}

	/* Disable interrupt through per-bit mask */
	mtk_pci_mac_msix_desc_mask_irq(
		mtk_dev->pdev, mtk_isr_res->isr_vector, 1);

	mod_irq = mtk_isr_res->isr_vector % mtk_dev->irq_count;
	MTK_DEBUG_LOG(TAG,
		"mod_irq %d, mtk_isr_res->isr_vector %d, mtk_dev->irq_count %d\n",
		mod_irq, mtk_isr_res->isr_vector, mtk_dev->irq_count);

	for (i = mod_irq; i < MTK_PCIE_IRQ_COUNT; i += mtk_dev->irq_count) {

		if (msix_status & (1 << i)) {

			if (i >= PCIE_EXT_INT_OFFSET) {

				/* Setup mask (disable int)  */
				mtk_pcie_set_msix_mask(
					mtk_dev->base_addr.pcie_mac_ireg_base,
					i);
				mb();
				ext_int =  i - PCIE_EXT_INT_OFFSET;

				MTK_DEBUG_LOG(TAG,
					"MSIX Ext interrupt %d, mod_irq %d\n",
					ext_int, mod_irq);

				if (likely(mtk_dev->intr_callback[ext_int]
					!= NULL))
					mtk_dev->intr_callback[ext_int](
						mtk_dev->callback_param[ext_int]);

			} else if ((i >= MTK_PCIE_SWINT_OFFSET) &&
				(i < MTK_PCIE_SWINT_END)) {
				/* SW interrupt */
				mtk_pcie_swint_clear(mtk_dev,i);
				spin_lock_irqsave(&mtk_dev->lock, flags);
				mtk_dev->swint_flag |=
					1 << (i + MTK_PCIE_SWINT_OFFSET);
				spin_unlock_irqrestore(&mtk_dev->lock, flags);

			} else if ((i >= MTK_PCIE_A_ATR_OFFSET) &&
				(i < MTK_PCIE_A_ATR_END)) {

				/* Setup mask (disable int)  */
				mtk_pcie_set_msix_mask(
					mtk_dev->base_addr.pcie_mac_ireg_base,
					i);
				set_bit(__PCIE_A_ATR_INT, mtk_dev->state);
				swq_en = TRUE;
			} else if ((i >= MTK_PCIE_P_ATR_OFFSET) &&
				(i < MTK_PCIE_P_ATR_END)) {

				/* Setup mask (disable int)  */
				mtk_pcie_set_msix_mask(
					mtk_dev->base_addr.pcie_mac_ireg_base,
					i);
				set_bit(__PCIE_P_ATR_INT, mtk_dev->state);
				swq_en = TRUE;
			} else {
				//ATR error
				MTK_DEBUG_LOG(TAG,
				"MSIX not matched interrupt %d, mod_irq %d\n",
				mtk_isr_res->isr_vector, mod_irq);
			}

		}

	}

	/* Setup mask (disable int) and trigger work queue */
	if (unlikely(swq_en == TRUE))
		mtk_pcie_isr_service_event_schedule(mtk_dev);


	/* Enable interrupt through per-bit mask */
	mtk_pci_mac_msix_desc_mask_irq(
		mtk_dev->pdev, mtk_isr_res->isr_vector, 0);

	ret = IRQ_HANDLED;

_exit:
	return ret;
}

mtk_pci_isr_res_s *mtk_pci_request_isr_table(int msi_count)
{
	mtk_pci_isr_res_s *tmp_res;
	int i;

	tmp_res = kcalloc(msi_count, sizeof(mtk_pci_isr_res_s), GFP_KERNEL);
	if (tmp_res == NULL)
		return tmp_res;

	for (i = 0; i < msi_count; i++) {
		tmp_res[i].isr_vector = i;
		tmp_res[i].isr = mtk_pcie_msix_irq;
	}
	return tmp_res;
	//return mtk_pci_msix_isr_table;
}

/*
 * Function definition
 */

irqreturn_t mtk_pcie_irq(int irq, void *__res)
{
	irqreturn_t ret = IRQ_NONE;
	struct mtk_pci_dev *mtk_dev = __res;
	u32 soft_irq;
	u32 ret_judge = 0, loop = 0;
	u32 ret_status = 0;

	/* Disable interrupt, replaced with mtk_pcie_intr_enable*/
	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, FALSE);

	ret_judge = mtk_pcie_int_judge(
		mtk_dev->base_addr.pcie_mac_ireg_base, &ret_status);

	if (unlikely(!ret_judge)) {
		/* Shared interrupt with other device */
		goto _exit;
	}

	MTK_DEBUG_LOG(TAG, "PCIE interrupt handler\n");

	/* Check software irq */
	soft_irq = mtk_pcie_get_sw_trig_int(
		mtk_dev->base_addr.pcie_mac_ireg_base);
	if (unlikely(soft_irq)) {
		mtk_pcie_swintx_isr(irq, __res);
	} else {
		/*by sequence judge _pcie_int_e's ext int part*/
		for (loop = _DPMAIF_INT; loop <= _SAP_RGU_INT; loop++) {
			if (ret_status&(1 << loop)) {
				/* Setup mask (disable int)  */
				mtk_pcie_set_int_mask(	mtk_dev,	loop, TRUE);
				mb();
				if (likely(mtk_dev->intr_callback[loop]
					!= NULL)) {
					mtk_dev->intr_callback[loop](
						mtk_dev->callback_param[loop]);
					} else {
						MTK_ERR_LOG(TAG, "Fatal Error: ext drv %d did not register callback while interrupt coming!\n", loop);
						mtk_pcie_set_int_mask(	mtk_dev,	loop, FALSE);
					}
				}
			}

		/* A_ATR_EVT interrupt */
		if (unlikely(ret_status&(1 << _A_ATR_INT))) {
			/* Setup mask (disable int)  */
			mtk_pcie_set_int_mask(mtk_dev,	_A_ATR_INT, TRUE);
			set_bit(__PCIE_A_ATR_INT, mtk_dev->state);
			}

		/* P_ATR_EVT interrupt */
		if (unlikely(ret_status&(1 << _P_ATR_INT))) {
			mtk_pcie_set_int_mask(	mtk_dev,	_P_ATR_INT, TRUE);
			set_bit(__PCIE_P_ATR_INT, mtk_dev->state);
			}

		/* Setup mask (disable int) and trigger work queue */
		if (unlikely((ret_status&(1 << _A_ATR_INT)) ||
			(ret_status&(1 << _P_ATR_INT)))) {
			mtk_pcie_isr_service_event_schedule(mtk_dev);
			}
	}

	ret = IRQ_HANDLED;

_exit:
	mb();
	/* Enable interrupt, , replaced with mtk_pcie_intr_enable*/
	mtk_pcie_intr_enable(
		mtk_dev->base_addr.pcie_mac_ireg_base, TRUE);

	return ret;
}

void mtk_pcie_isr_service_event_schedule(struct mtk_pci_dev *mtk_dev)
{
	if (!test_and_set_bit(__PCIE_SERVICE_SCHED, mtk_dev->state)) {
		MTK_DEBUG_LOG(TAG, "Schedule interrupt service task\n");
		queue_work(mtk_dev->pcie_isr_wq, &mtk_dev->service_task);
	}
}

static void mtk_pcie_isr_service_event_complete(struct mtk_pci_dev *mtk_dev)
{
	/* flush memory to make sure state is correct */
	smp_mb();
	clear_bit(__PCIE_SERVICE_SCHED, mtk_dev->state);
}

static void mtk_pcie_handle_sw_int(struct mtk_pci_dev *mtk_dev)
{
	u32 reg, i;
	int ds_lock_ack = 0;
	int pm_suspend_ack = 0;
	int pm_resume_ack = 0;
	int pm_suspend_ap_ack = 0;
	int pm_resume_ap_ack = 0;

	if (!test_bit(__PCIE_EP2RC_SW_INT, mtk_dev->state)) {
		return;
	}

	MTK_DEBUG_LOG(TAG, "Handle SW interrupt\n");

        /* We must use the 1*4 bits to not conflict with low power */
		PCIE_CFG_SET_L_STATES_DIS(
			mtk_dev->base_addr.pcie_mac_ireg_base,
			1<<PCIE_L1_1_DISABLE_BIT(1)|
			1<<PCIE_L1_2_DISABLE_BIT(1));

	if (!mhccif_ep2rc_reg_read(mtk_dev,&reg)) {
		MTK_ERR_LOG(TAG,
			"mhccif cannot read register.\n");
		goto done_mhccif;
	}

	MTK_INFO_LOG(TAG, "SW int status 0x%x\n", reg);

		if (reg & (1<<MHCCIF_D2H_INT_PCIE_DS_LOCK_ACK)) {
			MTK_INFO_LOG("PM",
				"Get DS Lock SW int status 0x%x, ds_lock_recvd=%llu\n",
				reg, ++ds_lock_recvd);
			ds_lock_ack = 1;
		}

		if (reg & (1<<MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK)) {
			MTK_INFO_LOG("PM",
				"Get MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK\n");
			pm_suspend_ack = 1;
		}

		if (reg & (1<<MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK)) {
			MTK_INFO_LOG("PM",
				"Get MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK\n");
			pm_resume_ack = 1;
		}

		if (reg & (1<<MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK_AP)) {
			MTK_INFO_LOG("PM",
				"Get MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK_AP\n");
			pm_suspend_ap_ack = 1;
		}

		if (reg & (1<<MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK_AP)) {
			MTK_INFO_LOG("PM",
				"Get MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK_AP\n");
			pm_resume_ap_ack = 1;
		}

	for (i = _DPMAIF_INT; i <= _END_EXT_INT; i++) {
		if (reg&(mtk_dev->mhccif_bitmask[i])) {
			MTK_DEBUG_LOG(TAG,
				"hit ext id %d, start to enter callback.\n", i);
			if (mtk_dev->mhccif_callback[i] != NULL) {
				mtk_dev->mhccif_callback[i](
					mtk_dev->mhccif_callback_param[i]);
			} else {
				MTK_ERR_LOG(TAG,
					"Error : ext id(%d) not register valid callback but register valid bitmask, skip callback.\n",
					i);
			}
		}
	}
	/* Clear 2&1 level interrupt */
	mtk_pcie_clear_mhccif_int(mtk_dev, reg);

		if (ds_lock_ack)
			complete_all(&mtk_dev->l_res_acquire);
		if (pm_suspend_ack)
			complete(&mtk_dev->pm_suspend_ack);
		if (pm_resume_ack)
			complete(&mtk_dev->pm_resume_ack);
		if (pm_suspend_ap_ack)
			complete(&mtk_dev->pm_suspend_ack_sap);
		if (pm_resume_ap_ack)
			complete(&mtk_dev->pm_resume_ack_sap);
        /* We must use the 1 bits to not conflict with low power */
		PCIE_CFG_CLR_L_STATES_DIS(
			mtk_dev->base_addr.pcie_mac_ireg_base,
			1<<PCIE_L1_DISABLE_BIT(1));

		if(!mhccif_ep2rc_reg_read(mtk_dev,&reg)){
			MTK_ERR_LOG(TAG,
			"mhccif cannot read register.\n");
			goto done_mhccif;
		}

		if (!reg) {
			PCIE_CFG_CLR_L_STATES_DIS(
				mtk_dev->base_addr.pcie_mac_ireg_base,
				1<<PCIE_L1_1_DISABLE_BIT(1)|
				1<<PCIE_L1_2_DISABLE_BIT(1));
		}

done_mhccif:
	/* Renable related interrupt*/
	clear_bit(__PCIE_EP2RC_SW_INT, mtk_dev->state);

	/* Enable corresponding interrupt */
	mtk_pcie_set_ext_int_mask(mtk_dev,MHCCIF_INT, false);

	MTK_PCIE_FLUSH();

}

static void mtk_pcie_handle_a_atr_int(struct mtk_pci_dev *mtk_dev)
{
	u32 val;

	if (!test_bit(__PCIE_A_ATR_INT, mtk_dev->state)) {
		return;
	}

	MTK_DEBUG_LOG(TAG, "Handle A_ATR_EVT interrupt\n");

	/* Get interrupt status */
	val = mtk_pcie_control_atr_event(	mtk_dev,_A_ATR_INT, OPERATION_GET);

	/* Clear interrupt */
	val = mtk_pcie_control_atr_event(	mtk_dev,_A_ATR_INT, OPERATION_CLEAR);
	/* Renable related interrupt*/
	clear_bit(__PCIE_A_ATR_INT, mtk_dev->state);

	//TODO:disable doorbell?
	/* Enable corresponding interrupt */
	mtk_pcie_set_int_mask(mtk_dev,_A_ATR_INT, FALSE);
	mb();
	MTK_PCIE_FLUSH();

}

static void mtk_pcie_handle_p_atr_int(struct mtk_pci_dev *mtk_dev)
{
	u32 val;

	if (!test_bit(__PCIE_P_ATR_INT, mtk_dev->state)) {
		return;
	}

	MTK_DEBUG_LOG(TAG, "Handle P_ATR_EVT interrupt\n");

	/* Get interrupt status */
	val = mtk_pcie_control_atr_event(	mtk_dev,_P_ATR_INT, OPERATION_GET);

	/* Clear interrupt */
	val = mtk_pcie_control_atr_event(	mtk_dev,_P_ATR_INT, OPERATION_CLEAR);

	/* Renable related interrupt*/
	clear_bit(__PCIE_P_ATR_INT, mtk_dev->state);

	/* Enable corresponding interrupt */
	mtk_pcie_set_int_mask(mtk_dev, _P_ATR_INT, FALSE);
	mb();
	MTK_PCIE_FLUSH();
}


void mtk_pcie_isr_service_task(struct work_struct *work)
{
	struct mtk_pci_dev *mtk_dev = container_of(work,
					  struct mtk_pci_dev,
					  service_task);

	MTK_DEBUG_LOG(TAG, "Running Interrupt service task\n");

	mtk_pcie_handle_sw_int(mtk_dev);
	mtk_pcie_handle_a_atr_int(mtk_dev);
	mtk_pcie_handle_p_atr_int(mtk_dev);

	mtk_pcie_isr_service_event_complete(mtk_dev);

	/* If there is more work to be done, reschedule the service
	 *  task now.
	 */
	if (test_bit(__PCIE_EP2RC_SW_INT, mtk_dev->state))
		mtk_pcie_isr_service_event_schedule(mtk_dev);
}
