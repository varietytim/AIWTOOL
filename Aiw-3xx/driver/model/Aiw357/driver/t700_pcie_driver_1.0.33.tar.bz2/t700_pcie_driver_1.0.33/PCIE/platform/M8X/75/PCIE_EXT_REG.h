/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PCIE_EXT_REG_H__
#define __PCIE_EXT_REG_H__


#define REG_MD2PCIE_MAP0_MSB(INFRACFG_AO_BASE)	\
	(INFRACFG_AO_BASE + 0x34)
#define REG_MD2PCIE_MAP0_LSB(INFRACFG_AO_BASE)	\
	(INFRACFG_AO_BASE + 0x30)



#endif /*__PCIE_EXT_REG_H__*/
