/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CHIP_DEF__
#define __CHIP_DEF__

/* PCIE ID */
#define PCI_CLASS_MTK_DEVICE_CHIP             0x0D4000
#define PCI_VENDOR_ID_TEST_CHIP                 0x14C3
#define PCI_DEVICE_ID_TEST_CHIP                  0x4D70

/* Reg base */
#define INFRACFG_AO_DEV_CHIP             0x10001000

/* ATR setting */
#define PCIE_REG_TRSL_ADDR_CHIP	   0x10000000
#define PCIE_REG_SIZE_CHIP			   0x00400000 //4MB

/* AT ATR setting */
#define AT_REG_TRSL_ADDR_CHIP           0x10020000 //only cover MHCCIF range

/* IP base */
#define MHCCIF_RC_DEV_BASE_CHIP      0x10027000
#define MHCCIF_EP_DEV_BASE_CHIP      0x10028000

#define EXP_PCIE_IF_CONF         0x11460181
#define EXP_PCIE_BASIC_CONF   0x03110303
#define EXP_AXI_MST0_CONF      0x11444246
#define EXP_AXI_SLV0_CONF      0x55804343
#define EXP_AXI_SLV1_CONF      0x55804353
#define EXP_AXI_SLV2_CONF      0x55484363
#define EXP_BAR0	0xC
#define EXP_BAR2	0x4
#define EXP_BAR4	0xC
#define EXP_BAR0_SIZE	0x4000
#define EXP_BAR2_SIZE	0x400000
#define EXP_BAR4_SIZE	0x800000

#define PCIE_MD_REMAP_SET 8
#define PCIE_MD_REMAP_START 0
#define PCIE_MD_REMAP_END     PCIE_MD_REMAP_SET
#define PCIE_MD_REMAP_SIZE_PER_SET  0x400000

typedef enum _pcie_int {
	_DPMAIF_INT = 0,
	_CLDMA0_INT,
	_CLDMA1_INT,
	_CLDMA2_INT,
	_MHCCIF_INT,
	_SAP_RGU_INT,
	_RSV1_INT,
	_RSV2_INT,
	_END_EXT_INT = _RSV2_INT,
	_A_ATR_INT,
	_P_ATR_INT,
	_END_INT = _P_ATR_INT,
} _pcie_int_e;

typedef enum _pcie_ext_int {
	DPMAIF_INT = 0,
	CLDMA0_INT,
	CLDMA1_INT,
	CLDMA2_INT,
	MHCCIF_INT,
	SAP_RGU_INT,
	RSV1_INT,
	RSV2_INT,
	END_INT = RSV2_INT,
} pcie_ext_int_e;


#endif /*__CHIP_DEF__*/
