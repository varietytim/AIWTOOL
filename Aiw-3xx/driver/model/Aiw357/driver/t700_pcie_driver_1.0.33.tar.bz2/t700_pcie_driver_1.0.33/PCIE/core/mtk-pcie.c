// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/init.h>
#include <linux/irq.h>
#include <linux/log2.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/kernel.h>       /* printk() */
#include <linux/fs.h>           /* everything... */
#include <linux/errno.h>        /* error codes */
#include <linux/types.h>        /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>        /* O_ACCMODE */
#include <linux/seq_file.h>
#include <linux/cdev.h>
#include <linux/pci.h>
#include <linux/pci_regs.h>
#include <linux/msi.h>
#include <linux/string.h>
#include <linux/random.h>
#include <linux/scatterlist.h>
#include <asm/unaligned.h>
#include <linux/kthread.h>
#include <linux/reboot.h>
#include <linux/delay.h>
#include <linux/version.h>
#include <linux/suspend.h>
#include <linux/rtc.h>

#include "mtk-pcie-dbg.h"
#include "mtk-pci.h"
#include "mtk-pcie.h"
//#include "mtk-dma.h"
#include "PCIE_MAC_IREG_c_header.h"
//#include "PCIE_EXT_REG.h"
//#include "mtk-test.h"
//#include "mtk-atr.h"
#include "mtk_pcie_ext.h"
#include "mtk-isr.h"

struct pci_dev *mtk_get_pcie_resource(int class_code)
{
	//Todo: use simple global variable?
	struct pci_dev *dev = NULL;
	unsigned int l;
	unsigned short vid, did;

	while (1) {
		dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, dev);
		if (!dev) {
			MTK_CRIT_LOG(TAG, "no matched device.\n");
			return 0;
		}

		pci_bus_read_config_dword(
			dev->bus, dev->devfn, PCI_CLASS_REVISION, &l);
		l >>= 8;
		dev->class = l;

		pci_bus_read_config_word(dev->bus,
			dev->devfn, PCI_VENDOR_ID, &vid);
		pci_bus_read_config_word(dev->bus,
			dev->devfn, PCI_DEVICE_ID, &did);
		MTK_DEBUG_LOG(TAG, "[%s:%d], l=0x%x, vid=0x%x, did=0x%x\n", __func__, __LINE__, l, vid, did);

		if (dev->class == class_code && vid == PCI_VENDOR_ID_TEST
			&& did == PCI_DEVICE_ID_TEST) {
			MTK_DEBUG_LOG(TAG, "pcie dev : 0x%p\n", dev);
			return dev;
		}
	}

	MTK_CRIT_LOG(TAG, "no matched device.\n");
	return 0;
}

int mtk_pci_check_bar0(struct pci_dev *dev)
{
	struct pci_bus *bus;
	unsigned int devfn, l;

	bus = dev->bus;
	devfn = dev->devfn;
	pci_bus_read_config_dword(bus, devfn, PCI_BASE_ADDRESS_0, &l);
	MTK_DEBUG_LOG(TAG, "pcie dev bar 0 addr : 0x%x\n", l);
	if (l & 0xFFFFFFF0)
		return -1;

	return 0;
}

int mtk_pci_retrain(struct pci_dev *dev)
{
	u16 ctrl, ctrl1, reg16;
	struct pci_dev *parent;
	int pos, ppos;
	unsigned long start_jiffies;

	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	pos = dev->pcie_cap;

	pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA, &reg16);
	if (reg16 & PCI_EXP_LNKSTA_LT)
		MTK_DEBUG_LOG(TAG, "link status = 0x%x\n", reg16);

	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL, &ctrl);
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL, &ctrl1);

	/* Retrain link */
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL, &reg16);
	reg16 |= PCI_EXP_LNKCTL_RL;
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL, reg16);
	/* Wait for link training end. Break out after waiting for timeout */
	start_jiffies = jiffies;
	usleep_range(10000, 11000);

	/*disable aspm before read link training bit.
	 *avoid rc doesn't clear link training bit at L1
	 */
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL, ctrl & ~0x03);
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, ctrl1 & ~0x03);

	for (;;) {
		pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA, &reg16);

		if (!(reg16 & PCI_EXP_LNKSTA_LT)) {
			pci_write_config_word(parent,
				ppos + PCI_EXP_LNKCTL, ctrl);
			pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, ctrl1);
			return 0;
		}
		if (time_after(jiffies, start_jiffies + LINK_RETRAIN_TIMEOUT)) {
			MTK_ERR_LOG(TAG, "PCI_EXP_LNKSTA=0x%x\n", reg16);
			pci_write_config_word(
				parent, ppos + PCI_EXP_LNKCTL, ctrl);
			pci_write_config_word(
				dev, pos + PCI_EXP_LNKCTL, ctrl1);
			return -1;
		}
		usleep_range(1000, 2000);
	}

	return 0;
}

int mtk_pci_get_retrain_status(struct pci_dev *dev)
{
	u16 reg16;
	struct pci_dev *parent;
	int ppos;
	unsigned long start_jiffies = jiffies;

	parent = dev->bus->self;
	ppos = parent->pcie_cap;

	for (;;) {
		pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA, &reg16);
		if (!(reg16 & PCI_EXP_LNKSTA_LT))
			return 0;
		if (time_after(jiffies, start_jiffies + LINK_RETRAIN_TIMEOUT))
			return -1;
		usleep_range(1000, 2000);
	}

	return 0;
}

int mtk_pci_link_disabled(struct pci_dev *dev)
{
	u16 reg16;
	struct pci_dev *parent;
	int ppos;

	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	/* disable link */
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL, &reg16);
	reg16 |= PCI_EXP_LNKCTL_LD;
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL, reg16);

	return 0;
}

int mtk_pci_link_enabled(struct pci_dev *dev)
{
	u16 reg16;
	struct pci_dev *parent;
	int ppos;

	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	/* enable link */
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL, &reg16);
	reg16 &= ~PCI_EXP_LNKCTL_LD;
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL, reg16);

	return 0;
}

static void mtk_pcie_config_aspm_dev(struct pci_dev *dev, int val)
{
	u16 reg16;
	int pos = dev->pcie_cap;


	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL, &reg16);
	reg16 &= ~0x3;
	reg16 |= val;
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, reg16);
}

int mtk_set_mps_mrrs(struct pci_dev *dev, int mps, int mrrs)
{
	int pos;
	u32 cap;
	u16 control;

	mps = ffs(mps) - 8;
	mrrs = ffs(mrrs) - 8;

	pos = dev->pcie_cap;
	pci_read_config_dword(dev, pos + PCI_EXP_DEVCAP, &cap);
	cap &= PCI_EXP_DEVCAP_PAYLOAD;
	if (mps > cap) {
		MTK_ERR_LOG(TAG, "not support this payload size\n");
		return -1;
	}

	pci_read_config_word(dev, pos + PCI_EXP_DEVCTL, &control);
	control &= ~PCI_EXP_DEVCTL_PAYLOAD;
	control |= mps << 5;
	control &= ~PCI_EXP_DEVCTL_READRQ;
	control |= mrrs << 12;
	pci_write_config_word(dev, pos + PCI_EXP_DEVCTL, control);

	return 0;
}

int mtk_pcie_aspm(struct mtk_pci_dev *mtk_dev,struct mkt_aspm_state aspm)
{
	struct pci_dev *child, *parent;

	child = mtk_dev->pdev;
	if (!child) {
		MTK_ERR_LOG(TAG, "can't find target device\n");
		return -1;
	}

	parent = child->bus->self;

	mtk_pcie_config_aspm_dev(child, aspm.aspm_us);
	mtk_pcie_config_aspm_dev(parent, aspm.aspm_ds);

	return 0;
}

#ifdef MTK_PCIE_ASPM_DISABLE

void mtk_pcie_aspm_disable_set_disable_control(
	struct mtk_pci_dev *mtk_dev,int set, int count, int test_state)
{
	unsigned int low_power_ctrl;

	if (set) {
		if (count < 8) {
			REG_SET(MTK_DIS_ASPM_LOWPWR_SET_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				test_state << (count * 4));
		} else if (count >= 8 && count < 16) {
			REG_SET(MTK_DIS_ASPM_LOWPWR_SET_1(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				test_state << (count % 8 * 4));
		} else {
			low_power_ctrl =
				PCIE_LOW_POWER_CTRL_GET_force_dis_lowpwr(
				MTK_PCIE_LOW_POWER_CTRL(
				mtk_dev->base_addr.pcie_mac_ireg_base));
			PCIE_LOW_POWER_CTRL_SET_force_dis_lowpwr(
				MTK_PCIE_LOW_POWER_CTRL(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				low_power_ctrl | test_state);
		}
	} else {
		if (count < 8) {
			REG_SET(MTK_DIS_ASPM_LOWPWR_CLR_0(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				test_state << (count * 4));
		} else if (count >= 8 && count < 16) {
			REG_SET(MTK_DIS_ASPM_LOWPWR_CLR_1(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				test_state << (count % 8 * 4));
		} else {
			low_power_ctrl =
				PCIE_LOW_POWER_CTRL_GET_force_dis_lowpwr(
				MTK_PCIE_LOW_POWER_CTRL(
				mtk_dev->base_addr.pcie_mac_ireg_base));
			PCIE_LOW_POWER_CTRL_SET_force_dis_lowpwr(
				MTK_PCIE_LOW_POWER_CTRL(
				mtk_dev->base_addr.pcie_mac_ireg_base),
				low_power_ctrl & ~test_state);
		}
	}

	MTK_PCIE_FLUSH();
}

int mtk_pcie_aspm_disable_state_flag_check(
	int set, int test_state, int dn_state, int up_state,
	volatile unsigned int *ltssm, int aspm[], int l1ss_enable)
{
	if (set) {
		if (*ltssm & aspm[test_state]) {
			MTK_ERR_LOG(TAG,
				"ASPM flag shouldn't raise. test_state = %d\n, ltssm 0x%x",
				test_state, *ltssm);
			return -1;
		}
	} else {
		if (test_state == MTK_PCIE_DISABLE_LOW_POWER_SET_L0s) {
			if (dn_state == LP_ASPM_L0S ||
				dn_state == LP_ASPM_BOTH) {
				if (!(*ltssm & aspm[test_state])) {
					MTK_ERR_LOG(TAG,
						"ASPM flag didn't raise. test_state = %d\n, ltssm 0x%x",
						test_state, *ltssm);
					goto _err; //return -1;
				}
			} else {
				if ((*ltssm & aspm[test_state])) {
					MTK_ERR_LOG(TAG,
						"ASPM flag shouldn't raise. test_state = %d\n, ltssm 0x%x",
						test_state, *ltssm);
					goto _err; //return -1;
				}
			}
		} else {
			if (dn_state > LP_ASPM_L0S && up_state > LP_ASPM_L0S) {
				if (l1ss_enable ==
					(PCI_L1PM_CAP_ASPM_L11 |
					PCI_L1PM_CAP_ASPM_L12)
					&& test_state ==
					MTK_PCIE_DISABLE_LOW_POWER_SET_L11) {
					if ((*ltssm & aspm[test_state])) {
						MTK_ERR_LOG(TAG,
							"ASPM flag shouldn't raise. test_state = %d\n, ltssm 0x%x",
							test_state, *ltssm);
						goto _err; //return -1;
					}
				} else {
					if (!(*ltssm & aspm[test_state])) {
						MTK_ERR_LOG(TAG,
							"ASPM flag didn't raise. test_state = %d\n, ltssm 0x%x",
							test_state, *ltssm);
						goto _err; //return -1;
					}
				}
			} else {
				if ((*ltssm & aspm[test_state])) {
					MTK_ERR_LOG(TAG,
						"ASPM flag shouldn't raise. test_state = %d\n, ltssm 0x%x",
						test_state, *ltssm);
					goto _err; //return -1;
				}
			}
		}
	}
	return 0;

_err:
	if (test_state == MTK_PCIE_DISABLE_LOW_POWER_SET_L12) {
		u64 start_j, end_j;

		start_j = jiffies;
		while ((*ltssm & aspm[test_state]) == 0) {
			usleep_range(10000, 11000);
		};
		end_j = jiffies;

		MTK_ERR_LOG(TAG,
			"start_j = %lld, end_j = %lld, diff = %lld, %lld ms, ltssm 0x%x\n",
			start_j, end_j, (end_j - start_j),
			((end_j - start_j)*1000/HZ), *ltssm);
	}

	return -1;
}

int mtk_pcie_aspm_disable_l1ss_enable(
	int l1ss_enable, int test_state,
	int test_state_2, int test_state_3, int test_state_4)
{
	if (test_state == MTK_PCIE_DISABLE_LOW_POWER_SET_L11)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L11;
	else if (test_state == MTK_PCIE_DISABLE_LOW_POWER_SET_L12)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L12;
	if (test_state_2 == MTK_PCIE_DISABLE_LOW_POWER_SET_L11)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L11;
	else if (test_state_2 == MTK_PCIE_DISABLE_LOW_POWER_SET_L12)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L12;
	if (test_state_3 == MTK_PCIE_DISABLE_LOW_POWER_SET_L11)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L11;
	else if (test_state_3 == MTK_PCIE_DISABLE_LOW_POWER_SET_L12)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L12;
	if (test_state_4 == MTK_PCIE_DISABLE_LOW_POWER_SET_L11)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L11;
	else if (test_state_4 == MTK_PCIE_DISABLE_LOW_POWER_SET_L12)
		l1ss_enable |= PCI_L1PM_CAP_ASPM_L12;
	return l1ss_enable;
}

int mtk_pcie_aspm_disable(struct mtk_pci_dev *mtk_dev)
{
	struct pci_dev *child, *parent;
	// count for control group 1~16, test_state for ASPM state
	int test_state, test_state_2, test_state_3, test_state_4, count;
	int ret, up_state, dn_state;
	int set = 1, clr = 0; // set and clear the disable control bit
	unsigned int l1ss_enable = 0;
	int aspm[] = { // For ASPM flag
		1 << 5,		// L0s flag:	0x150[5]
		1 << 6,		// L1 flag:	0x150[6]
		1 << 12,	// L1.1 flag:	0x150[12]
		1 << 13,	// L1.2 flag:	0x150[13]
	};
	volatile unsigned int *ltssm; // LTSSM Status 0x150

	child = mtk_dev->pdev;
	parent = child->bus->self;

	ltssm = &MTK_PCIe_Ltssm_Status(mtk_dev->base_addr.pcie_mac_ireg_base);
	/* ASPM disable control per bit test */
	for (test_state = MTK_PCIE_DISABLE_LOW_POWER_SET_L0s;
		test_state <= MTK_PCIE_DISABLE_LOW_POWER_SET_L12;
		test_state++) {
		for (count = 0; count < 17; count++) {
			// Set l1ss // L1.1
			if (test_state == MTK_PCIE_DISABLE_LOW_POWER_SET_L11) {
				ret = mtk_setup_l1ss(mtk_dev->pdev,PCI_L1PM_CAP_ASPM_L11,
					PCI_L1PM_CAP_ASPM_L11);
				if (ret)
					return ret;

			}	// L1.2
			else if (test_state ==
					MTK_PCIE_DISABLE_LOW_POWER_SET_L12) {
				ret = mtk_setup_l1ss(mtk_dev->pdev,PCI_L1PM_CAP_ASPM_L12,
				PCI_L1PM_CAP_ASPM_L12);
			if (ret)
				return ret;

			}
			/* Test for all combination aspm state */
			for (up_state = LP_NORMAL;
				up_state <= LP_ASPM_BOTH;
				up_state++) {
				for (dn_state = LP_NORMAL;
					dn_state <= LP_ASPM_BOTH;
					dn_state++) {
					// Set the disable control bit
					mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,set, count, 1 << test_state);

					// Clr the LTSSM rg
					*(&MTK_PCIe_Ltssm_Status(
						mtk_dev->base_addr.pcie_mac_ireg_base))
						= 0xFFFFFFFF;
					// Make the link go in ASPM state
					mtk_pcie_config_aspm_dev(
					child, dn_state);
					mtk_pcie_config_aspm_dev(
						parent, up_state);
					usleep_range(10000, 11000);

					// Check if the flag raise (shouldn't raise)
					ret = mtk_pcie_aspm_disable_state_flag_check(
						set, test_state, dn_state, up_state,
						ltssm, aspm, l1ss_enable);
					if (ret) {
						MTK_ERR_LOG(TAG,
							"count = %d, dn_state = %d, up_state = %d.\n",
							count, dn_state, up_state);
						mtk_pcie_config_aspm_dev(
							child, LP_NORMAL);
						mtk_pcie_config_aspm_dev(
							parent, LP_NORMAL);
						mtk_pcie_aspm_disable_set_disable_control(
							mtk_dev,clr, count, 1 << test_state);
						continue; //return -1;
					}
					// Clr the disable control bit and back to L0
					mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,clr, count, 1 << test_state);
					// Make the link go in ASPM state
					usleep_range(10000, 11000);
					// Check if the flag raise (should raise)
					ret = mtk_pcie_aspm_disable_state_flag_check(
					clr, test_state, dn_state, up_state,
						ltssm, aspm, l1ss_enable);
					if (ret) {
						MTK_ERR_LOG(TAG,
							"count = %d, dn_state = %d, up_state = %d.\n",
							count, dn_state, up_state);
						mtk_pcie_config_aspm_dev(
							child, LP_NORMAL);
						mtk_pcie_config_aspm_dev(
							parent, LP_NORMAL);
						continue; //return -1;
					}

					// Re-set the disable control bit
					mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,set, count, 1 << test_state);
					// Clr the LTSSM rg
					*(&MTK_PCIe_Ltssm_Status(
						mtk_dev->base_addr.pcie_mac_ireg_base))
						= 0xFFFFFFFF;
					usleep_range(10000, 11000);

					// Check if the flag raise (shouldn't raise)
					ret = mtk_pcie_aspm_disable_state_flag_check(
						set, test_state, dn_state,
						up_state, ltssm, aspm, l1ss_enable);
					if (ret) {
						MTK_ERR_LOG(TAG,
							"count = %d, dn_state = %d, up_state = %d.\n",
							count, dn_state, up_state);
						mtk_pcie_config_aspm_dev(child, LP_NORMAL);
						mtk_pcie_config_aspm_dev(parent, LP_NORMAL);
						mtk_pcie_aspm_disable_set_disable_control(
							mtk_dev,clr, count, 1 << test_state);
						continue; //return -1;
					}
					// Clr the disable control bit and back to L0
					mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,clr, count, 1 << test_state);
					usleep_range(10000, 11000);
					// Check if the flag raise (should raise)
					ret = mtk_pcie_aspm_disable_state_flag_check(
						clr, test_state,
						dn_state, up_state,
						ltssm, aspm, l1ss_enable);
					if (ret) {
						MTK_ERR_LOG(TAG,
							"count = %d, dn_state = %d, up_state = %d.\n",
							count, dn_state,
							up_state);
						mtk_pcie_config_aspm_dev(
							child, LP_NORMAL);
						mtk_pcie_config_aspm_dev(
							parent, LP_NORMAL);
						continue; //return -1;
					}

					mtk_pcie_config_aspm_dev(
						child, LP_NORMAL);
					mtk_pcie_config_aspm_dev(
						parent, LP_NORMAL);
				}
			}
		}
	}

	/* ASPM disable control combination test,
	 *force disable two aspm state
	 */
	for (count = 0; count < 17; count++) {

		/* Combinations of two disable control bit */
		MTK_DEBUG_LOG(TAG,
			"Combinations of two disable control bit\n");
		for (test_state = MTK_PCIE_DISABLE_LOW_POWER_SET_L0s;
			test_state <=
				MTK_PCIE_DISABLE_LOW_POWER_SET_L12;
				test_state++) {
			for (test_state_2 = test_state+1; test_state_2
				<= MTK_PCIE_DISABLE_LOW_POWER_SET_L12;
				test_state_2++) {
				// Set l1ss enable
				l1ss_enable = 0;
				l1ss_enable = mtk_pcie_aspm_disable_l1ss_enable(
					l1ss_enable, test_state,
					test_state_2, 0, 0);
				ret = mtk_setup_l1ss(mtk_dev->pdev,l1ss_enable, l1ss_enable);

				// Test with 16 aspm state combinations
				for (up_state = LP_NORMAL;
					up_state <= LP_ASPM_BOTH;
					up_state++) {
					for (dn_state = LP_NORMAL;
						dn_state <= LP_ASPM_BOTH;
						dn_state++) {

						MTK_DEBUG_LOG(TAG,
							"Test count = %d, dn_state = %d, up_state = %d, test_state %d, test_state_2 %d\n",
							count, dn_state, up_state, test_state, test_state_2);

						// Set the disable control bit
						mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,set, count, (1<<test_state) + (1<<test_state_2));
						// Clr the LTSSM rg
						*(&MTK_PCIe_Ltssm_Status(
						mtk_dev->base_addr.pcie_mac_ireg_base))
						= 0xFFFFFFFF;
						// aspm both both
						mtk_pcie_config_aspm_dev(
							child, dn_state);
						mtk_pcie_config_aspm_dev(
							parent, up_state);
						usleep_range(10000, 11000);

						// Check if the flag raise (shouldn't raise)
						ret = mtk_pcie_aspm_disable_state_flag_check(
						set, test_state, dn_state, up_state,
						ltssm, aspm, l1ss_enable);
						ret += mtk_pcie_aspm_disable_state_flag_check(
							set, test_state_2, dn_state,
							up_state, ltssm, aspm, l1ss_enable);
						if (ret) {
							MTK_ERR_LOG(TAG,
								"count = %d, dn_state = %d, up_state = %d.\n",
								count, dn_state, up_state);
							mtk_pcie_config_aspm_dev(child, LP_NORMAL);
							mtk_pcie_config_aspm_dev(parent, LP_NORMAL);
							mtk_pcie_aspm_disable_set_disable_control(
								mtk_dev,clr, count, (1<<test_state)
								+ (1<<test_state_2));
							continue; //return -1;
						}
						// Clear the disable control bit
						mtk_pcie_aspm_disable_set_disable_control(
							mtk_dev,clr, count, (1<<test_state)
							+ (1<<test_state_2));
						mtk_pcie_config_aspm_dev(child, LP_NORMAL);
						mtk_pcie_config_aspm_dev(parent, LP_NORMAL);
						// Clr the LTSSM rg
						*(&MTK_PCIe_Ltssm_Status(
							mtk_dev->base_addr.pcie_mac_ireg_base))
							= 0xFFFFFFFF;
						mtk_pcie_config_aspm_dev(child, dn_state);
						mtk_pcie_config_aspm_dev(parent, up_state);
						usleep_range(10000, 11000);
						// Check if the flag raise
						ret = mtk_pcie_aspm_disable_state_flag_check(
						clr, test_state, dn_state, up_state,
						ltssm, aspm, l1ss_enable);
						ret += mtk_pcie_aspm_disable_state_flag_check(
							clr, test_state_2, dn_state,
							up_state, ltssm, aspm, l1ss_enable);
						if (ret) {
							MTK_ERR_LOG(TAG,
								"count = %d, dn_state = %d, up_state = %d.\n",
								count, dn_state, up_state);
							mtk_pcie_config_aspm_dev(
								child, LP_NORMAL);
							mtk_pcie_config_aspm_dev(
								parent, LP_NORMAL);
							continue; //return -1;
						}
						mtk_pcie_config_aspm_dev(child,
							LP_NORMAL);
						mtk_pcie_config_aspm_dev(parent,
							LP_NORMAL);
					}
				}
			}
		}

		/* Combinations of three disable control bit */
		MTK_DEBUG_LOG(TAG, "Combinations of three disable control bit\n");
		for (test_state = MTK_PCIE_DISABLE_LOW_POWER_SET_L0s; test_state <=
			MTK_PCIE_DISABLE_LOW_POWER_SET_L12; test_state++) {
			for (test_state_2 = test_state+1; test_state_2 <=
				MTK_PCIE_DISABLE_LOW_POWER_SET_L12; test_state_2++) {
				for (test_state_3 = test_state_2+1; test_state_3 <=
					MTK_PCIE_DISABLE_LOW_POWER_SET_L12; test_state_3++) {
					// Set l1ss enable
					l1ss_enable = 0;
					l1ss_enable = mtk_pcie_aspm_disable_l1ss_enable(l1ss_enable, test_state, test_state_2, test_state_3, 0);
					ret = mtk_setup_l1ss(mtk_dev->pdev,l1ss_enable, l1ss_enable);

					// Test with 16 aspm state combinations
					for (up_state = LP_NORMAL; up_state <= LP_ASPM_BOTH; up_state++) {
						for (dn_state = LP_NORMAL; dn_state <= LP_ASPM_BOTH; dn_state++) {

							MTK_DEBUG_LOG(TAG, "=================\n");

							MTK_DEBUG_LOG(TAG,
								"Test count = %d, dn_state = %d, up_state = %d, test_state %d, test_state_2 %d, test_state_3 %d\n",
								count, dn_state, up_state, test_state, test_state_2, test_state_3);

							// Set the disable control bit
							mtk_pcie_aspm_disable_set_disable_control(
							mtk_dev,set, count, (1<<test_state) +
							(1<<test_state_2) + (1<<test_state_3));
							// Clr the LTSSM rg
							*(&MTK_PCIe_Ltssm_Status(
							mtk_dev->base_addr.pcie_mac_ireg_base))
							= 0xFFFFFFFF;
							// aspm both both
							mtk_pcie_config_aspm_dev(child, dn_state);
							mtk_pcie_config_aspm_dev(parent, up_state);
							usleep_range(10000, 11000);

							// Check if the flag raise (shouldn't raise)
							ret = mtk_pcie_aspm_disable_state_flag_check(
							set, test_state, dn_state, up_state,
							ltssm, aspm, l1ss_enable);
							ret += mtk_pcie_aspm_disable_state_flag_check(
								set, test_state_2, dn_state,
								up_state, ltssm, aspm, l1ss_enable);
							ret += mtk_pcie_aspm_disable_state_flag_check(
								set, test_state_3, dn_state,
								up_state, ltssm, aspm, l1ss_enable);
							if (ret) {
								MTK_ERR_LOG(TAG,
									"count = %d, dn_state = %d, up_state = %d.\n",
									count, dn_state, up_state);
								mtk_pcie_config_aspm_dev(child, LP_NORMAL);
								mtk_pcie_config_aspm_dev(parent, LP_NORMAL);
								mtk_pcie_aspm_disable_set_disable_control(
									mtk_dev,clr, count, (1<<test_state) +
									(1<<test_state_2) + (1<<test_state_3));
								continue; //return -1;
							}
							// Clear the disable control bit
							mtk_pcie_aspm_disable_set_disable_control(
								mtk_dev,clr, count, (1<<test_state) +
								(1<<test_state_2) + (1<<test_state_3));
							usleep_range(10000, 11000);

							// Check if the flag raise
							ret = mtk_pcie_aspm_disable_state_flag_check(
							clr, test_state, dn_state, up_state,
							ltssm, aspm, l1ss_enable);
							ret += mtk_pcie_aspm_disable_state_flag_check(
								clr, test_state_2, dn_state,
								up_state, ltssm, aspm, l1ss_enable);
							ret += mtk_pcie_aspm_disable_state_flag_check(
								clr, test_state_3, dn_state, up_state,
								ltssm, aspm, l1ss_enable);
							if (ret) {
								MTK_ERR_LOG(TAG,
									"count = %d, dn_state = %d, up_state = %d.\n",
									count, dn_state, up_state);
								mtk_pcie_config_aspm_dev(
									child, LP_NORMAL);
								mtk_pcie_config_aspm_dev(
									parent, LP_NORMAL);
								//return -1;
								continue;
							}
							mtk_pcie_config_aspm_dev(
								child, LP_NORMAL);
							mtk_pcie_config_aspm_dev(
								parent, LP_NORMAL);
						}
					}
				}
			}
		}

		/* Combinations of four disable control bit */
		test_state = 0;
		test_state_2 = 1;
		test_state_3 = 2;
		test_state_4 = 3;
		l1ss_enable = 0;
		l1ss_enable = mtk_pcie_aspm_disable_l1ss_enable(
			l1ss_enable, test_state,
			test_state_2, test_state_3, test_state_4);
		ret = mtk_setup_l1ss(mtk_dev->pdev,l1ss_enable, l1ss_enable);

		MTK_DEBUG_LOG(TAG,
			"Combinations of four disable control bit\n");

		// Test with 16 aspm state combinations
		for (up_state = LP_NORMAL;
			up_state <= LP_ASPM_BOTH; up_state++) {
			for (dn_state = LP_NORMAL;
				dn_state <= LP_ASPM_BOTH; dn_state++) {

				up_state = dn_state = LP_ASPM_BOTH;

				MTK_DEBUG_LOG(TAG, "============\n");

				// Set the disable control bit
				mtk_pcie_aspm_disable_set_disable_control(
					mtk_dev,set, count, (1<<test_state)
					+ (1<<test_state_2) +
					(1<<test_state_3) + (1<<test_state_4));
				// Clr the LTSSM rg
				*(&MTK_PCIe_Ltssm_Status(
					mtk_dev->base_addr.pcie_mac_ireg_base))
					= 0xFFFFFFFF;
				// aspm both both
				mtk_pcie_config_aspm_dev(child, dn_state);
				mtk_pcie_config_aspm_dev(parent, up_state);
				usleep_range(10000, 11000);

				// Check if the flag raise (shouldn't raise)
				ret = mtk_pcie_aspm_disable_state_flag_check(
				set, test_state, dn_state,
				up_state, ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					set, test_state_2, dn_state, up_state,
					ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					set, test_state_3, dn_state,
					up_state, ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					set, test_state_4, dn_state,
					up_state, ltssm, aspm, l1ss_enable);
				if (ret) {
					MTK_ERR_LOG(TAG,
						"count = %d, dn_state = %d, up_state = %d.\n",
						count, dn_state, up_state);
					mtk_pcie_config_aspm_dev(
						child, LP_NORMAL);
					mtk_pcie_config_aspm_dev(
						parent, LP_NORMAL);
					mtk_pcie_aspm_disable_set_disable_control(
						mtk_dev,clr, count, (1<<test_state) +
						(1<<test_state_2) +
						(1<<test_state_3) +
						(1<<test_state_4));
					continue; //return -1;
				}
				// Clear the disable control bit
				mtk_pcie_aspm_disable_set_disable_control(
					mtk_dev,clr, count, (1<<test_state) +
					(1<<test_state_2) + (1<<test_state_3) +
					(1<<test_state_4));
				usleep_range(10000, 11000);

				// Check if the flag raise
				ret = mtk_pcie_aspm_disable_state_flag_check(
					clr, test_state, dn_state, up_state,
					ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					clr, test_state_2, dn_state,
					up_state, ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					clr, test_state_3, dn_state,
					up_state, ltssm, aspm, l1ss_enable);
				ret += mtk_pcie_aspm_disable_state_flag_check(
					clr, test_state_4, dn_state, up_state,
					ltssm, aspm, l1ss_enable);

				if (ret) {
					MTK_ERR_LOG(TAG,
						"count = %d, dn_state = %d, up_state = %d.\n",
						count, dn_state, up_state);
					mtk_pcie_config_aspm_dev(
						child, LP_NORMAL);
					mtk_pcie_config_aspm_dev(
						parent, LP_NORMAL);
					continue; //return -1;
				}
				mtk_pcie_config_aspm_dev(child, LP_NORMAL);
				mtk_pcie_config_aspm_dev(parent, LP_NORMAL);
			}
		}

	}

	return 0;
}
#endif

int mtk_pcie_retrain(struct pci_dev *dev)
{
	int ret;

	ret = mtk_pci_retrain(dev);
	if (ret) {
		MTK_ERR_LOG(TAG, "retrain fail\n");
		return ret;
	}

	if (mtk_pci_check_bar0(dev) == 0) {
		MTK_ERR_LOG(TAG, "restore fail ??\n");
		return -1;
	}
	return ret;
}

static int mtk_pcie_check_speed(struct pci_dev *dev)
{
	int ret = 0;
	int pos, ppos;
	u16 plinksta, plinkctl2;
	struct pci_dev *parent;

	pos = dev->pcie_cap;
	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA, &plinksta);
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL2, &plinkctl2);
	if ((plinksta & PCI_EXP_LNKSTA_CLS) != (plinkctl2 & PCI_SPEED_MASK))
		ret = 1;
	else
		ret = 0;

	return ret;
}

static struct pci_dev *mtk_get_pcie_dev(int bus_number, int slot, int function)
{
	struct pci_dev *dev = NULL;

	while (1) {
		dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, dev);
		if (!dev) {
			//xprintk(PCIE_CRIT,"no matched device.\n");
			return NULL;
		}

		if (dev->bus->number == bus_number &&
			PCI_SLOT(dev->devfn) == slot &&
			PCI_FUNC(dev->devfn) == function) {
			return dev;
		}
	}

	MTK_CRIT_LOG(TAG, "no matched device.\n");
	return NULL;
}

static void mtk_pcie_save_state(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	int i;

	if (!dev->multifunction) {
		pci_save_state(dev);
		return;
	}

	// find multi-function device
	for (i = 0; i < 8; i++) {
		mfdev = mtk_get_pcie_dev(
			dev->bus->number, PCI_SLOT(dev->devfn), i);
		if (mfdev)
			pci_save_state(mfdev);

	}


}

static void mtk_pcie_restore_state(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	int i;

	if (!dev->multifunction) {
		pci_restore_state(dev);
		return;
	}

	// find multi-function device
	for (i = 0; i < 8; i++) {
		mfdev = mtk_get_pcie_dev(
			dev->bus->number, PCI_SLOT(dev->devfn), i);
		if (mfdev)
			pci_restore_state(mfdev);

	}


}

int mtk_pcie_disabled(struct pci_dev *dev)
{
	int ret;

	mtk_pcie_save_state(dev);
	ret = mtk_pci_link_disabled(dev);
	usleep_range(10000, 11000);
	ret = mtk_pci_link_enabled(dev);
	msleep(100);
	ret = mtk_pci_check_bar0(dev); //check if device has been reset
	if (ret) {
		MTK_ERR_LOG(TAG, "disable reset failed!\n");
		return ret;
	}
	mtk_pcie_restore_state(dev);
	//check if the speed needs to train to 5G or not
	if (mtk_pcie_check_speed(dev)) {
		ret = mtk_pci_retrain(dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "retrain failed!\n");
			return ret;
		}
	}
	if (mtk_pci_check_bar0(dev) == 0) {
		MTK_ERR_LOG(TAG, "restore fail ??\n");
		return -1;
	}
	return ret;
}

static int mtk_pcie_flr(struct pci_dev *dev)
{
	int i;
	int pos;
	u32 cap;
	u16 status, control;

	pos = dev->pcie_cap;
	pci_read_config_dword(dev, pos + PCI_EXP_DEVCAP, &cap);
	if (!(cap & PCI_EXP_DEVCAP_FLR)) {
		MTK_ERR_LOG(TAG,
			"the function don't support Function Level Reset mechanism\n");
		return -1;
	}
	/* Wait for Transaction Pending bit clean */
	for (i = 0; i < 4; i++) {
		if (i)
			msleep((1 << (i - 1)) * 100);

		pci_read_config_word(dev, pos + PCI_EXP_DEVSTA, &status);
		if (!(status & PCI_EXP_DEVSTA_TRPND))
			goto clear;
	}

clear:
	pci_read_config_word(dev, pos + PCI_EXP_DEVCTL, &control);
	control |= PCI_EXP_DEVCTL_BCR_FLR;
	pci_write_config_word(dev, pos + PCI_EXP_DEVCTL, control);

	msleep(100);

	return 0;
}

int mtk_function_level_reset(struct pci_dev *dev)
{
	int ret = 0;
	mtk_pcie_save_state(dev);
	ret = mtk_pcie_flr(dev);
	ret = mtk_pci_check_bar0(dev); //check if device has been reset
	if (ret) {
		MTK_ERR_LOG(TAG, "function level reset failed!\n");
		return ret;
	}
	mtk_pcie_restore_state(dev);

	return ret;

}

static void mtk_pci_parent_bus_reset(struct pci_dev *dev)
{
	u16 ctrl;
	struct pci_dev *parent;
	int pos, ppos;

	MTK_DEBUG_LOG(TAG, "%s\n", __func__);

	pos = dev->pcie_cap;
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL2, &ctrl);
	ctrl &= ~0x10;//disable Enter Compliance bit
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL2, ctrl);
	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL2, &ctrl);
	ctrl &= ~0x10;//disable Enter Compliance bit
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL2, ctrl);
	pci_read_config_word(parent, PCI_BRIDGE_CONTROL, &ctrl);
	ctrl |= PCI_BRIDGE_CTL_BUS_RESET;
	pci_write_config_word(parent, PCI_BRIDGE_CONTROL, ctrl);
	usleep_range(10000, 11000);
	ctrl &= ~PCI_BRIDGE_CTL_BUS_RESET;
	pci_write_config_word(parent, PCI_BRIDGE_CONTROL, ctrl);
	msleep(100);
}

int mtk_pcie_hot_reset(struct pci_dev *dev)
{
	int ret;
	MTK_DEBUG_LOG(TAG, "%s\n", __func__);
	mtk_pcie_save_state(dev);
	mtk_pci_parent_bus_reset(dev);
	ret = mtk_pci_check_bar0(dev); //check if device has been reset
	if (ret) {
		MTK_ERR_LOG(TAG, "hot reset failed!\n");
		return ret;
	}
	mtk_pcie_restore_state(dev);
	//check if the speed needs to train to 5G or not
	if (mtk_pcie_check_speed(dev)) {
		ret = mtk_pci_retrain(dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "retrain failed!\n");
			return ret;
		}
	}
	if (mtk_pci_check_bar0(dev) == 0) {
		MTK_ERR_LOG(TAG, "restore fail ??\n");
		return -1;
	}
	return ret;

}

static int mtk_pcie_speed(struct pci_dev *dev, int speed)
{
	int ret = 0;
	int pos, ppos;
	u16 linksta, plinksta, plinkctl2;
	struct pci_dev *parent;

	pos = dev->pcie_cap;
	pci_read_config_word(dev, pos + PCI_EXP_LNKSTA, &linksta);
	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA, &plinksta);
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL2, &plinkctl2);
	if ((plinkctl2 & PCI_SPEED_MASK) != speed) {
		plinkctl2 &= ~PCI_SPEED_MASK;
		plinkctl2 |= speed;
		pci_write_config_word(parent,
			ppos + PCI_EXP_LNKCTL2, plinkctl2);
	}
	if (((linksta & PCI_EXP_LNKSTA_CLS) == speed) &&
		((plinksta & PCI_EXP_LNKSTA_CLS) == speed))
		return 0;
	ret = mtk_pcie_retrain(dev);
	if (ret) {
		MTK_ERR_LOG(TAG, "retrain fails\n");
		return ret;
	}
	pci_read_config_word(dev, pos + PCI_EXP_LNKSTA, &linksta);
	if ((linksta & PCI_EXP_LNKSTA_CLS) != speed) {
		MTK_ERR_LOG(TAG,
			"can't train to target speed!! Link Status(Dev) : 0x%x\n",
			linksta);
		ret = -1;
	}
	parent = dev->bus->self;
	pos = parent->pcie_cap;
	pci_read_config_word(parent, pos + PCI_EXP_LNKSTA, &linksta);

	if ((linksta & PCI_EXP_LNKSTA_CLS) != speed) {
		MTK_ERR_LOG(TAG,
			"can't train to target speed!! Link Status(parent) : 0x%x\n",
			linksta);
		ret = -1;
	}

	if (mtk_pci_check_bar0(dev) == 0) {
		MTK_ERR_LOG(TAG, "restore fail ??\n");
		return -1;
	}

	return ret;
}

int mtk_pcie_change_speed(struct mtk_pci_dev *mtk_dev,int speed)
{
	int ret;

	ret = mtk_pcie_speed(mtk_dev->pdev, speed);//train speed

	return ret;
}

int mtk_pcie_configuration(struct pci_dev *dev)
{
	unsigned int l, devfn;
	struct pci_bus *bus;
	unsigned int bar0_ori, bar0_temp;
	unsigned int mask, value;

	bus = dev->bus;
	devfn = dev->devfn;
	pci_bus_read_config_dword(bus, devfn, PCI_VENDOR_ID, &l);
	if ((l & 0xffff) != dev->vendor) {
		MTK_ERR_LOG(TAG, "read vendor id error!![0x%x != 0x%x]\n",
			(l & 0xffff), dev->vendor);
		return -1;
	}
	if (((l >> 16) & 0xffff) != dev->device) {
		MTK_ERR_LOG(TAG, "read device id error!![0x%x != 0x%x]\n",
			((l >> 16) & 0xffff), dev->device);
		return -1;
	}
	dev->vendor = l & 0xffff;
	dev->device = (l >> 16) & 0xffff;
	pci_bus_read_config_dword(bus, devfn, PCI_CLASS_REVISION, &l);
	if ((l & 0xff) != dev->revision) {
		MTK_ERR_LOG(TAG, "read revision id error!![0x%x != 0x%x]\n",
			(l & 0xffff), dev->revision);
		return -1;
	}
	if ((l >> 8) != dev->class) {
		MTK_ERR_LOG(TAG, "read class id error!![0x%x != 0x%x]\n",
			((l >> 8) & 0xffff), dev->class);
		return -1;
	}

	pci_read_config_dword(dev, PCI_BASE_ADDRESS_0, &bar0_ori);
	pci_write_config_dword(dev, PCI_BASE_ADDRESS_0, 0xFFFFFFFF);
	pci_read_config_dword(dev, PCI_BASE_ADDRESS_0, &mask);
	get_random_bytes(&value, 4);
	value = value & mask & (~0xF);
	pci_write_config_dword(dev, PCI_BASE_ADDRESS_0, value);
	pci_read_config_dword(dev, PCI_BASE_ADDRESS_0, &bar0_temp);
	pci_write_config_dword(dev, PCI_BASE_ADDRESS_0, bar0_ori);

	if ((bar0_temp & ~0xF) != value)
		return -1;


	return 0;
}

int mtk_pcie_reset_config(struct pci_dev *dev)
{
	unsigned int pos, l, devfn;
	int ret;
	u16 reg16;
	struct pci_bus	*bus;

	mtk_pcie_save_state(dev);
	mtk_pci_parent_bus_reset(dev);
	ret = mtk_pci_check_bar0(dev); //check if device has been reset
	if (ret) {
		MTK_ERR_LOG(TAG, "hot reset failed!\n");
		return ret;
	}
	mtk_pcie_restore_state(dev);

	//check if the speed needs to train to 5G or not
	if (mtk_pcie_check_speed(dev)) {
		ret = mtk_pci_retrain(dev);
		if (ret) {
			MTK_ERR_LOG(TAG, "retrain failed!\n");
			return ret;
		}
	}
	if (mtk_pci_check_bar0(dev) == 0) {
		MTK_ERR_LOG(TAG, "restore fail ??\n");
		return -1;
	}

	pos = dev->pcie_cap;
	bus = dev->bus;
	devfn = dev->devfn;
	pci_bus_read_config_dword(bus, devfn, PCI_VENDOR_ID, &l);
	if ((l & 0xffff) != dev->vendor) {
		MTK_ERR_LOG(TAG, "read vendor id error!![0x%x != 0x%x]\n",
			(l & 0xffff), dev->vendor);
		return -1;
	}
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL, &reg16);
	reg16 &= ~0x3;
	reg16 |= LINK_STATE_L1;
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, reg16);
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL, &reg16);
	if (!(reg16 & LINK_STATE_L1)) {
		MTK_ERR_LOG(TAG, "configuration write error\n");
		return -1;
	}
	reg16 &= ~0x3;
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, reg16);

	return 0;
}

int wait_dma_done(struct pci_dev *dev)
{
	unsigned long start_jiffies;

	struct mtk_pci_dev	*mtk_dev;
	int *done;

	mtk_dev = pci_get_drvdata(dev);
	done = (int *) &mtk_dev->dma_done;
	start_jiffies = jiffies;
	for (;;) {
		if (*done) {
			*done = 0;
			return 0;
		} else if (time_after(jiffies,
			start_jiffies + PCIE_DMA_TIMEOUT)) {
			return -1;
		}
		usleep_range(1000, 2000);
	}

	return 0;
}

int mtk_pcie_go_l1(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	int error;
	int i;

	if (!dev->multifunction) {
		error = pci_set_power_state(dev, PCI_D0);
		if (error)
			return -1;
		pci_prepare_to_sleep(dev);
		return 0;
	}

	// find multi-function device
	for (i = 0; i < 8; i++) {
		mfdev = mtk_get_pcie_dev(
			dev->bus->number, PCI_SLOT(dev->devfn), i);
		if (mfdev) {
			error = pci_set_power_state(mfdev, PCI_D0);
			if (error)
				return -1;
			pci_prepare_to_sleep(mfdev);
		}
	}

	return 0;
}

int mtk_pcie_go_l2(struct pci_dev *dev)
{
	int	status, error;
	struct rtc_wkalrm	alm;
	struct rtc_device	*rtc = NULL;


	error = pci_set_power_state(dev, PCI_D0);
	if (error)
		return -1;
	status = pm_suspend(PM_SUSPEND_MEM);
	/* Clear rtc alarm settings */
	rtc = rtc_class_open("rtc0");
	status = rtc_read_time(rtc, &alm.time);
	if (status < 0)
		return -1;

	alm.enabled = false;
	rtc_set_alarm(rtc, &alm);

	return 0;
}

int mtk_pcie_wakeup(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	int i;
	if (!dev->multifunction) {
		pci_back_from_sleep(dev);
		return 0;
	}

	// find multi-function device
	for (i = 0; i < 8; i++) {
		mfdev = mtk_get_pcie_dev(
			dev->bus->number, PCI_SLOT(dev->devfn), i);
		if (mfdev)
			pci_back_from_sleep(mfdev);

	}

	return 0;
}

int mtk_pcie_exit_l2(int delay)
{
	struct rtc_wkalrm	alm;
	struct rtc_device	*rtc = NULL;
	int	status;
	unsigned long now;

	rtc = rtc_class_open("rtc0");
	if (!rtc)
		return -1;

	status = rtc_read_time(rtc, &alm.time);
	if (status < 0)
		return -1;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
	now = rtc_tm_to_time64(&alm.time);
#else
	rtc_tm_to_time(&alm.time, &now);
#endif
	memset(&alm, 0, sizeof(alm));
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
	rtc_time64_to_tm(now + delay, &alm.time);
#else	
	rtc_time_to_tm(now + delay, &alm.time);
#endif	
	alm.enabled = true;
	status = rtc_set_alarm(rtc, &alm);
	if (status < 0) {
		alm.enabled = false;
		rtc_set_alarm(rtc, &alm);
		return -1;
	}

	return now;
}

int mtk_pcie_read_rtc(void)
{
	struct rtc_wkalrm	alm;
	struct rtc_device	*rtc = NULL;
	int	status;
	unsigned long now;

	rtc = rtc_class_open("rtc0");
	if (!rtc)
		return -1;

	status = rtc_read_time(rtc, &alm.time);
	if (status < 0)
		return -1;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
	now = rtc_tm_to_time64(&alm.time);
#else
	rtc_tm_to_time(&alm.time, &now);
#endif
	return now;
}

void mtk_enable_pme(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	u32 regValue;
	u16 pmcsr;
	int i;
	struct mtk_pci_dev *mtk_dev;

	mtk_dev = pci_get_drvdata(dev);

	regValue = ISTATUS_LOCAL_GET_PM_EVT(
		MTK_ISTATUS_LOCAL(mtk_dev->base_addr.pcie_mac_ireg_base));
	REG_SET(MTK_ISTATUS_LOCAL(
		mtk_dev->base_addr.pcie_mac_ireg_base), MTK_PM_EVENT_STATUS);
	regValue = ISTATUS_LOCAL_GET_PM_EVT(
		MTK_ISTATUS_LOCAL(mtk_dev->base_addr.pcie_mac_ireg_base));

	if (!dev->multifunction) {
		pci_read_config_word(dev, dev->pm_cap + PCI_PM_CTRL, &pmcsr);
		/* Clear PME_Status by writing 1 to it and enable PME# */
		pmcsr |= PCI_PM_CTRL_PME_STATUS | PCI_PM_CTRL_PME_ENABLE;
		pci_write_config_word(dev, dev->pm_cap + PCI_PM_CTRL, pmcsr);
		return;
	}

	for (i = 0; i < 8; i++) {
		mfdev = mtk_get_pcie_dev(dev->bus->number,
			PCI_SLOT(dev->devfn), i);
		if (mfdev) {
			pci_read_config_word(mfdev, mfdev->pm_cap
				+ PCI_PM_CTRL, &pmcsr);
		/* Clear PME_Status by writing 1 to it and enable PME# */
			pmcsr |= PCI_PM_CTRL_PME_STATUS |
				PCI_PM_CTRL_PME_ENABLE;
			pci_write_config_word(mfdev,
				mfdev->pm_cap + PCI_PM_CTRL, pmcsr);
		}
	}
}

int mtk_wait_wakeup(struct pci_dev *dev)
{
	struct pci_dev *mfdev;
	unsigned long start_jiffies;
	struct mtk_pci_dev	*mtk_dev;
	u32 *pme_event;
	int status;
	u16 pmcsr;
	u32 regValue;
	int i;

	status = 0;

	mtk_dev = pci_get_drvdata(dev);
	pme_event = (u32 *)&mtk_dev->pme_event;
	start_jiffies = jiffies;
	for (;;) {
		if (*pme_event) {
			*pme_event = 0;
			status = 0;
			break;
		} else if (time_after(jiffies, start_jiffies +
				L1_REMOTE_WAKEUP_TIMEOUT)) {
			status = -1;
			break;
		}
		usleep_range(1000, 2000);
	}

	if (!dev->multifunction) {
		pci_read_config_word(dev, dev->pm_cap + PCI_PM_CTRL, &pmcsr);
		pmcsr &= ~PCI_PM_CTRL_PME_ENABLE;
		if (pmcsr & PCI_PM_CTRL_PME_STATUS)
			pmcsr |= PCI_PM_CTRL_PME_STATUS;

		pci_write_config_word(dev, dev->pm_cap + PCI_PM_CTRL, pmcsr);
		pci_read_config_word(dev, dev->pm_cap + PCI_PM_CTRL, &pmcsr);
	} else {
		for (i = 0; i < 8; i++) {
			mfdev = mtk_get_pcie_dev(dev->bus->number,
				PCI_SLOT(dev->devfn), i);
			if (mfdev) {
				pci_read_config_word(mfdev,
					mfdev->pm_cap + PCI_PM_CTRL, &pmcsr);
				pmcsr &= ~PCI_PM_CTRL_PME_ENABLE;
				if (pmcsr & PCI_PM_CTRL_PME_STATUS)
					pmcsr |= PCI_PM_CTRL_PME_STATUS;

				pci_write_config_word(mfdev,
					mfdev->pm_cap + PCI_PM_CTRL, pmcsr);
				pci_read_config_word(mfdev,
					mfdev->pm_cap + PCI_PM_CTRL, &pmcsr);
			}
		}
	}
	mtk_pcie_wakeup(dev);

	regValue = ISTATUS_LOCAL_GET_PM_EVT(
		MTK_ISTATUS_LOCAL(mtk_dev->base_addr.pcie_mac_ireg_base));
	REG_SET(MTK_ISTATUS_LOCAL(
		mtk_dev->base_addr.pcie_mac_ireg_base), MTK_PM_EVENT_STATUS);
	regValue = ISTATUS_LOCAL_GET_PM_EVT(
		MTK_ISTATUS_LOCAL(mtk_dev->base_addr.pcie_mac_ireg_base));

	return status;
}

void mtk_pme_interrupt_enable(struct pci_dev *dev, bool enable)
{
	int rtctl_pos;
	u16 rtctl;

	rtctl_pos = dev->pcie_cap + PCI_EXP_RTCTL;

	pci_read_config_word(dev, rtctl_pos, &rtctl);
	if (enable)
		rtctl |= PCI_EXP_RTCTL_PMEIE;
	else
		rtctl &= ~PCI_EXP_RTCTL_PMEIE;
	pci_write_config_word(dev, rtctl_pos, rtctl);
}

u32 mtk_get_root_pme_status(struct pci_dev *dev)
{
	int rtsta_pos;
	u32 rtsta;

	rtsta_pos = dev->pcie_cap + PCI_EXP_RTSTA;

	pci_read_config_dword(dev, rtsta_pos, &rtsta);
	rtsta &= PCI_EXP_RTSTA_PME;

	return rtsta;
}

void mtk_clear_root_pme_status(struct pci_dev *dev)
{
	int rtsta_pos;
	u32 rtsta;

	rtsta_pos = dev->pcie_cap + PCI_EXP_RTSTA;

	pci_read_config_dword(dev, rtsta_pos, &rtsta);
	rtsta |= PCI_EXP_RTSTA_PME;
	pci_write_config_dword(dev, rtsta_pos, rtsta);
}


int mtk_l1ss_mode_en(struct pci_dev *dev, int enable)
{
	int pos;
	u32 reg32;

	pos = pci_find_ext_capability(dev, PCI_EXT_CAP_ID_L1PMSS);
	if (!pos) {
		MTK_ERR_LOG(TAG, "L1 PM Substate capability is not found!\n");
		return -1;
	}
	pci_read_config_dword(dev, pos + PCI_L1PMSS_CAP, &reg32);
	if (!(reg32 &
		PCI_L1PM_CAP_L1PM_SS)) {
		MTK_ERR_LOG(TAG, "not support L1 PM Substates!\n");
		return -1;
	}
	if ((enable & PCI_L1PM_CAP_PCIPM_L12) &&
		(!(reg32 & PCI_L1PM_CAP_PCIPM_L12))) {
		MTK_ERR_LOG(TAG, "not support PCI-PM L1.2!\n");
		return -1;
	}
	if ((enable & PCI_L1PM_CAP_PCIPM_L11) &&
		(!(reg32 & PCI_L1PM_CAP_PCIPM_L11))) {
		MTK_ERR_LOG(TAG, "not support PCI-PM L1.1!\n");
		return -1;
	}
	if ((enable & PCI_L1PM_CAP_ASPM_L12) &&
		(!(reg32 & PCI_L1PM_CAP_ASPM_L12))) {
		MTK_ERR_LOG(TAG, "not support ASPM L1.2!\n");
		return -1;
	}
	if ((enable & PCI_L1PM_CAP_ASPM_L11) &&
		(!(reg32 & PCI_L1PM_CAP_ASPM_L11))) {
		MTK_ERR_LOG(TAG, "not support ASPM L1.1!\n");
		return -1;
	}
	pci_read_config_dword(dev, pos + PCI_L1PMSS_CTR1, &reg32);
	reg32 &= ~PCI_L1PMSS_ENABLE_MASK;
	reg32 |= enable;
	pci_write_config_dword(dev, pos + PCI_L1PMSS_CTR1, reg32);

	return 0;
}

int mtk_setup_clkpm(struct pci_dev *dev, int enable)
{
	int pos;
	u16 reg16;
	u32 reg32;

	pci_find_capability(dev, PCI_CAP_ID_EXP);
	pos = dev->pcie_cap;
	pci_read_config_dword(dev, pos + PCI_EXP_LNKCAP, &reg32);
	if (!(reg32 & PCI_EXP_LNKCAP_CLKPM)) {
		MTK_ERR_LOG(TAG, "not support clock PM!\n");
		return -1;
	}
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL, &reg16);
	reg16 &= ~PCI_EXP_LNKCTL_CLKREQ_EN;
	if (enable)
		reg16 |= PCI_EXP_LNKCTL_CLKREQ_EN;
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL, reg16);

	return 0;
}

int mtk_l1ss_enable(struct pci_dev *dev, int enable)
{
	int ret;

	ret = mtk_l1ss_mode_en(dev, enable);
	if (ret) {
		MTK_ERR_LOG(TAG, "Can't enable L1 PM Substates!\n");
		return -1;
	}

	return 0;
}

int mtk_setup_l1pm(struct pci_dev *dev,int enable)
{
	int ret;
	ret = mtk_setup_clkpm(dev, enable);
	if (ret)
		return -1;

	return 0;
}

int mtk_setup_l1ss(struct pci_dev *dev,int ds_mode, int us_mode)
{
	struct pci_dev *pdev;
	int ret;

	pdev = dev->bus->self;
	ret = mtk_l1ss_enable(pdev, ds_mode);
	if (ret)
		return -1;

	ret = mtk_l1ss_enable(dev, us_mode);
	if (ret)
		return -1;

	return 0;
}

int mtk_pcie_compliance(struct pci_dev *dev,int mode, int skip, int deemph, int speed)
{
	int pos, ppos;
	u16 ctrl;
	struct pci_dev  *pdev;

	pdev = dev->bus->self;
	pos = dev->pcie_cap;
	ppos = pdev->pcie_cap;

	/* Set EP port */
	pci_read_config_word(dev, pos + PCI_EXP_LNKCTL2, &ctrl);
	ctrl &= ~(PCI_EXP_LNKCTL2_TARGET_SPEED_MASK |
		PCI_EXP_LNKCTL2_COMPLIANCE |
		PCI_EXP_LNKCTL2_MODIFIED_COMPLIANCE |
		PCI_EXP_LNKCTL2_COMPLIANCE_SOS |
		PCI_EXP_LNKCTL2_COMPLIANCE_PRESET);
	ctrl |= speed;
	ctrl |= deemph << 12;
	if (mode == 1)
		ctrl |= PCI_EXP_LNKCTL2_COMPLIANCE; //Enter Compliance bit
	else if (mode == 2) //Enter Modified Compliance bit
		ctrl |= (PCI_EXP_LNKCTL2_COMPLIANCE |
			PCI_EXP_LNKCTL2_MODIFIED_COMPLIANCE);
	if (skip)
		ctrl |= PCI_EXP_LNKCTL2_COMPLIANCE_SOS; //compliance sos
	pci_write_config_word(dev, pos + PCI_EXP_LNKCTL2, ctrl);

	/* Set RC port */
	pci_read_config_word(pdev, ppos + PCI_EXP_LNKCTL2, &ctrl);
	ctrl &= ~(PCI_EXP_LNKCTL2_TARGET_SPEED_MASK |
		PCI_EXP_LNKCTL2_COMPLIANCE |
		PCI_EXP_LNKCTL2_MODIFIED_COMPLIANCE |
		PCI_EXP_LNKCTL2_COMPLIANCE_SOS |
		PCI_EXP_LNKCTL2_COMPLIANCE_PRESET);
	ctrl |= speed;
	ctrl |= deemph << 12;
	if (mode == 1)
		ctrl |= PCI_EXP_LNKCTL2_COMPLIANCE; //Enter Compliance bit
	else if (mode == 2) //Enter Modified Compliance bit
		ctrl |= (PCI_EXP_LNKCTL2_COMPLIANCE |
			PCI_EXP_LNKCTL2_MODIFIED_COMPLIANCE);
	if (skip)
		ctrl |= PCI_EXP_LNKCTL2_COMPLIANCE_SOS; //compliance sos
	pci_write_config_word(pdev, ppos + PCI_EXP_LNKCTL2, ctrl);

	/* Initiating a hot reset */
	if ((mode == 1) || (mode == 2)) {
		pci_read_config_word(pdev, PCI_BRIDGE_CONTROL, &ctrl);
		ctrl |= PCI_BRIDGE_CTL_BUS_RESET;
		pci_write_config_word(pdev, PCI_BRIDGE_CONTROL, ctrl);
		usleep_range(1000, 2000);
		ctrl &= ~PCI_BRIDGE_CTL_BUS_RESET;
		pci_write_config_word(pdev, PCI_BRIDGE_CONTROL, ctrl);
		msleep(100);
	}

	return 0;
}

int mtk_pcie_equalization(struct pci_dev *dev)
{
	struct pci_dev *parent;
	int pcie_secpci;
	int pos, ppos;
	u16 plinkctl2, plinkctl3;
	u16 linksta2, plinksta2;
	int ret = 0;

	parent = dev->bus->self;
	ppos = parent->pcie_cap;
	pos = dev->pcie_cap;

	/* eq only perform when Target Link Speed field is set to 8.0 GT/s */
	pci_read_config_word(parent, ppos + PCI_EXP_LNKCTL2, &plinkctl2);
	plinkctl2 &= ~PCI_SPEED_MASK;
	plinkctl2 |= MTK_SPEED_8_0GT;
	pci_write_config_word(parent, ppos + PCI_EXP_LNKCTL2, plinkctl2);

	/* Set link control 3, perform eq bit = 1 */
	pcie_secpci = pci_find_ext_capability(parent, PCI_EXT_CAP_ID_SECPCI);
	pci_read_config_word(parent, pcie_secpci + PCI_EXP_LNKCTL3, &plinkctl3);
	plinkctl3 |= PCI_EXP_LNKCTL3_EQ;
	pci_write_config_word(parent, pcie_secpci + PCI_EXP_LNKCTL3, plinkctl3);

	/* Retrain link to perform eq. */
	if (mtk_pci_retrain(dev)) {
		MTK_ERR_LOG(TAG, "retrain failed!\n");
		return -1;
	}

	/* Check result */
	pci_read_config_word(parent, pcie_secpci + PCI_EXP_LNKCTL3, &plinkctl3);
	if (plinkctl3 & PCI_EXP_LNKCTL3_EQ) {
		MTK_ERR_LOG(TAG, "Link control 3, bit[0] should be 0 (0x%x)\n",
			plinkctl3);
		ret = -1;
	}

	pci_read_config_word(parent, ppos + PCI_EXP_LNKSTA2, &plinksta2);
	if ((plinksta2 & PCI_EXP_LNKSTA2_EQMASK) != PCI_EXP_LNKSTA2_EQMASK) {
		MTK_ERR_LOG(TAG,
			"link status 2, check rc complete fail (0x%x)\n",
			plinksta2);
		ret = -1;
	}

	pci_read_config_word(dev, pos + PCI_EXP_LNKSTA2, &linksta2);
	if ((linksta2 & PCI_EXP_LNKSTA2_EQMASK) != PCI_EXP_LNKSTA2_EQMASK) {
		MTK_ERR_LOG(TAG,
			"link status 2, check eq complete fail (0x%x)\n",
			linksta2);
		ret = -1;
	}
	return ret;
}


static int mtk_wait_sw_int(struct mtk_pci_dev *mtk_dev,
	unsigned int irq_enable_bits)
{
	unsigned long start_jiffies;

	start_jiffies = jiffies;
	for (;;) {
		if (mtk_dev->swint_flag == irq_enable_bits)
			break;
		else if (time_after(jiffies, start_jiffies + 1 * HZ)) {
			MTK_INFO_LOG(TAG, "0x%08x, 0x%08x\n",
				irq_enable_bits, mtk_dev->swint_flag);
			return -1;
		}

		mdelay(1);
	}

	return 0;
}

int mtk_sw_int(struct pci_dev *dev,int irq_number)
{
	struct mtk_pci_dev *mtk_dev;
	unsigned int irq_enable_bits;

	mtk_dev = pci_get_drvdata(dev);

	if (irq_number < 0)
		get_random_bytes(&irq_enable_bits, 1);
	else
		irq_enable_bits = irq_number;

	irq_enable_bits &= 0xFF;
	if (!irq_enable_bits)
		irq_enable_bits = 0xFF;

	irq_enable_bits = irq_enable_bits << MTK_PCIE_SWINT_OFFSET;

	mtk_dev->swint_flag = 0;

	if (dev->msix_enabled)
		REG_SET(MTK_MSIX_SW_TRIG_SET_GRP0_0(
		mtk_dev->base_addr.pcie_mac_ireg_base), irq_enable_bits);
	else
		REG_SET(MTK_SW_TRIG_INTR_SET(
			mtk_dev->base_addr.pcie_mac_ireg_base),
			irq_enable_bits);

	return mtk_wait_sw_int(mtk_dev, irq_enable_bits);
}


static int mtk_msi_int_mask(struct pci_dev *dev,int mask_bits)
{
	struct mtk_pci_dev *mtk_dev;
	int pos, i;
	u16 msi_ctrl;
	u32 msi_mask;
	u32 msi_pend;
	int sw_mask = 0;
	
	mtk_dev = pci_get_drvdata(dev);

	/* Set msi mask = mask_bits */
	pos = pci_find_capability(dev, PCI_CAP_ID_MSI);
	if (!pos) {
		MTK_ERR_LOG(TAG, " can't find MSI cap?\n");
		return -EINVAL;
	}

	for (i = 0; i < 8; i += mtk_dev->irq_count)
		sw_mask |= mask_bits << i;

	pci_read_config_word(dev, pos + PCI_MSI_FLAGS, &msi_ctrl);
	if (msi_ctrl & PCI_MSI_FLAGS_64BIT) {
		pci_read_config_dword(dev, pos + PCI_MSI_MASK_64, &msi_mask);
		pci_write_config_dword(dev, pos + PCI_MSI_MASK_64, msi_mask |
			(mask_bits <<
			(MTK_PCIE_SWINT_OFFSET % mtk_dev->irq_count)));
	} else {
		pci_read_config_dword(dev, pos + PCI_MSI_MASK_32, &msi_mask);
		pci_write_config_dword(dev, pos + PCI_MSI_MASK_32, msi_mask |
			(mask_bits <<
			(MTK_PCIE_SWINT_OFFSET % mtk_dev->irq_count)));
	}

	mtk_sw_int(dev,0xFF);

	/* Check swint_flag value */
	if (mtk_dev->swint_flag != (~sw_mask & 0xFF) << MTK_PCIE_SWINT_OFFSET) {
		MTK_ERR_LOG(TAG, "test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, (~sw_mask & 0xFF));
		return -1;
	}

	/* Check pending bits */
	if (msi_ctrl & PCI_MSI_FLAGS_64BIT)
		pci_read_config_dword(dev, pos + PCI_MSI_PENDING_64, &msi_pend);
	else
		pci_read_config_dword(dev, pos + PCI_MSI_PENDING_32, &msi_pend);
	msi_pend = (msi_pend >> (MTK_PCIE_SWINT_OFFSET % mtk_dev->irq_count))
		& 0xFF;
	if (msi_pend != (mask_bits & 0xFF)) {
		MTK_ERR_LOG(TAG,
			"test failed. 0x%08x, 0x%08x\n", msi_pend, mask_bits);
		return -1;
	}

	mtk_dev->swint_flag = 0;

	/* Set msi mask = 0 */
	if (msi_ctrl & PCI_MSI_FLAGS_64BIT)
		pci_write_config_dword(dev, pos + PCI_MSI_MASK_64, 0);
	else
		pci_write_config_dword(dev, pos + PCI_MSI_MASK_32, 0);

	return mtk_wait_sw_int(mtk_dev, sw_mask << (MTK_PCIE_SWINT_OFFSET));

}

static u32 mtk_get_msix_pending_bits(struct pci_dev *dev)
{
	resource_size_t phys_addr;
	u32 table_offset;
	u8 bir;
	u32 *base;
	u32 pending_bits;

	pci_read_config_dword(dev, dev->msix_cap + PCI_MSIX_PBA,
			      &table_offset);
	bir = (u8)(table_offset & PCI_MSIX_PBA_BIR);
	table_offset &= PCI_MSIX_PBA_OFFSET;
	phys_addr = pci_resource_start(dev, bir) + table_offset;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
	base = (unsigned int *) ioremap(phys_addr, 16);
#else
	base = (unsigned int *) ioremap_nocache(phys_addr, 16);
#endif	
	pending_bits = *base;
	iounmap(base);

	return pending_bits;
}

static u32 mtk_pci_msix_desc_mask_irq(struct msi_desc *desc, u32 flag)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,15,0)
	u32 mask_bits = desc->msi_mask;
#else
	u32 mask_bits = desc->masked;
#endif
	unsigned int offset = desc->msi_attrib.entry_nr * PCI_MSIX_ENTRY_SIZE +
						PCI_MSIX_ENTRY_VECTOR_CTRL;

	mask_bits &= ~PCI_MSIX_ENTRY_CTRL_MASKBIT;
	if (flag)
		mask_bits |= PCI_MSIX_ENTRY_CTRL_MASKBIT;
	writel(mask_bits, desc->mask_base + offset);

	return mask_bits;
}

static inline void mtk_pci_msix_clear_and_set_ctrl(
	struct pci_dev *dev, u16 clear, u16 set)
{
	u16 ctrl;

	pci_read_config_word(dev, dev->msix_cap + PCI_MSIX_FLAGS, &ctrl);
	ctrl &= ~clear;
	ctrl |= set;
	pci_write_config_word(dev, dev->msix_cap + PCI_MSIX_FLAGS, ctrl);
}

/* Native per bit mask function */
static int msix_native_per_bit_mask(struct mtk_pci_dev *mtk_dev,
	struct pci_dev *dev, int mask_bits, int sw_mask)
{
	int i;
	struct msi_desc *entry;
	u32 pending_bits;

	/* Set msix mask bit */
	for_each_pci_msi_entry(entry, dev) {
		for (i = 0; i < mtk_dev->irq_count; i++) {
			if ((mtk_dev->msix_res[i +
				(MTK_PCIE_SWINT_OFFSET %
				mtk_dev->irq_count)].irq ==
				entry->irq) && (sw_mask & (1 << i))) {
				mtk_pci_msix_desc_mask_irq(entry, 1);
			}
		}
	}

	mtk_sw_int(dev,0xFF);

	/* Check swint_flag value */
	if (mtk_dev->swint_flag != (~sw_mask & 0xFF) << MTK_PCIE_SWINT_OFFSET) {
		MTK_ERR_LOG(TAG, "sw inf test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, (~sw_mask & 0xFF));
		return -1;
	}

	/* Check pending bits */
	pending_bits = mtk_get_msix_pending_bits(dev);
	pending_bits = (pending_bits >>
		(MTK_PCIE_SWINT_OFFSET % mtk_dev->irq_count)) & 0xFF;
	if (pending_bits != mask_bits) {
		MTK_ERR_LOG(TAG, "pending bit check failed. 0x%08x, 0x%08x\n",
			pending_bits, mask_bits);
		return -1;
	}

	mtk_dev->swint_flag = 0;

	/* Set msi mask = 0 */
	for_each_pci_msi_entry(entry, dev) {
		for (i = 0; i < mtk_dev->irq_count; i++) {
			if ((mtk_dev->msix_res[i +
				(MTK_PCIE_SWINT_OFFSET %
				mtk_dev->irq_count)].irq
				== entry->irq) && (sw_mask & (1 << i))) {
				mtk_pci_msix_desc_mask_irq(entry, 0);
			}
		}
	}

	/* Check swint_flag value */
	if (mtk_wait_sw_int(mtk_dev, sw_mask << MTK_PCIE_SWINT_OFFSET) < 0) {
		MTK_ERR_LOG(TAG, "test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, sw_mask);
		return -1;
	}
	return 0;
}

/* Proprietary mask function */
static int msix_proprietary_mask(struct mtk_pci_dev *mtk_dev,
	struct pci_dev *dev, int sw_mask)
{
	u32 pending_bits;

	/* Set the Proprietary_mask bit */
	IMASK_HOST_MSIX_GRP0_0_SET_imask_host_msix_clr(
		MTK_IMASK_HOST_MSIX_CLR_GRP0_0(
		mtk_dev->base_addr.pcie_mac_ireg_base),
		sw_mask << MTK_PCIE_SWINT_OFFSET);
	mtk_sw_int(dev,0xFF);

	/* Check swint_flag value */
	if (mtk_dev->swint_flag != (~sw_mask & 0xFF) << MTK_PCIE_SWINT_OFFSET) {
		MTK_ERR_LOG(TAG, "sw int test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, (~sw_mask & 0xFF));
		IMASK_HOST_MSIX_SET_GRP0_0_SET_imask_host_msix_set(
			MTK_IMASK_HOST_MSIX_SET_GRP0_0(
			mtk_dev->base_addr.pcie_mac_ireg_base),
			sw_mask << MTK_PCIE_SWINT_OFFSET);
		return -1;
	}

	/* Check pending bits should not be set */
	pending_bits = mtk_get_msix_pending_bits(dev);
	if (pending_bits) {
		MTK_ERR_LOG(TAG,
			"pending bit check failed. pending_bits = 0x%08x\n",
			pending_bits);
		IMASK_HOST_MSIX_SET_GRP0_0_SET_imask_host_msix_set(
			MTK_IMASK_HOST_MSIX_SET_GRP0_0(
			mtk_dev->base_addr.pcie_mac_ireg_base),
			sw_mask << MTK_PCIE_SWINT_OFFSET);
		return -1;
	}
	mtk_dev->swint_flag = 0;

	/* Clear the Proprietary_mask bit */
	IMASK_HOST_MSIX_SET_GRP0_0_SET_imask_host_msix_set(
		MTK_IMASK_HOST_MSIX_SET_GRP0_0(
		mtk_dev->base_addr.pcie_mac_ireg_base),
		sw_mask << MTK_PCIE_SWINT_OFFSET);
	/* Check swint_flag value */
	if (mtk_wait_sw_int(mtk_dev, sw_mask << MTK_PCIE_SWINT_OFFSET) < 0) {
		MTK_ERR_LOG(TAG, "test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, sw_mask);
		return -1;
	}
	return 0;
}

static int mtk_msix_int_mask(struct pci_dev *dev,int mask_bits)
{
	struct mtk_pci_dev *mtk_dev;
	int i, ret, sw_mask = 0;
	u32 pending_bits;

	mtk_dev = pci_get_drvdata(dev);

	/* Transform the mask bits to 8 bits*/
	for (i = 0; i < 8; i += mtk_dev->irq_count)
		sw_mask |= mask_bits << i;


	mtk_dev->swint_flag = 0;
	/* Native per bit mask (0x400c, 0x401c, 0x402c,...)*/
	ret = msix_native_per_bit_mask(mtk_dev, dev, mask_bits, sw_mask);
	if (ret) {
		MTK_ERR_LOG(TAG, "Vector Control mask test fail.\n");
		return ret;
	}

	mtk_dev->swint_flag = 0;
	/*
	 * Proprietary mask
	 * 0x3000 ~ 0x300c: Write one to set MSIX Proprietary Mask Bit
	 * 0x3080 ~ 0x308c: Write one to clear MSIX Proprietary Mask Bit
	 * 0x3100 ~ 0x310c: MSIX Proprietary Mask Bit
	 */
	ret = msix_proprietary_mask(mtk_dev, dev, sw_mask);
	if (ret) {
		MTK_ERR_LOG(TAG, "Proprietary mask test fail.\n");
		return ret;
	}

	mtk_dev->swint_flag = 0;
	/* Function mask bit test */
	mtk_pci_msix_clear_and_set_ctrl(dev, 0, PCI_MSIX_FLAGS_MASKALL);
	mtk_sw_int(dev,sw_mask);

	/* Check swint_flag value */
	if (mtk_dev->swint_flag) {
		MTK_ERR_LOG(TAG, "sw inf test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, sw_mask);
		return -1;
	}

	/* Check pending bits */
	pending_bits = mtk_get_msix_pending_bits(dev);
	if (pending_bits) {
		MTK_ERR_LOG(TAG, "pending bit check failed. 0x%08x, 0x%08x\n",
			pending_bits, sw_mask);
		return -1;
	}

	mtk_pci_msix_clear_and_set_ctrl(dev, PCI_MSIX_FLAGS_MASKALL, 0);

	/* Check swint_flag value */
	if (mtk_wait_sw_int(mtk_dev, sw_mask << MTK_PCIE_SWINT_OFFSET) < 0) {
		MTK_ERR_LOG(TAG, "test failed. 0x%08x, 0x%08x\n",
			mtk_dev->swint_flag, sw_mask);
		return -1;
	}

	return 0;
}

int mtk_int_mask(struct pci_dev *dev,int type)
{
	int mask_bits;
	int ret = 0;
	struct mtk_pci_dev *mtk_dev;

	mtk_dev = pci_get_drvdata(dev);

	/* Get the corresponding random bit according to msi number */
	get_random_bytes(&mask_bits, 1);
	mask_bits &= GENMASK(mtk_dev->irq_count-1, 0) & 0xFF;
	if (!(mask_bits))
		mask_bits = 0x55 & GENMASK(mtk_dev->irq_count-1, 0);

	if (type == TYPE_MSI)
		ret = mtk_msi_int_mask(dev,mask_bits);
	else
		ret = mtk_msix_int_mask(dev,mask_bits);

	return ret;
}



int mtk_pcie_read_sku(struct pci_dev *dev,unsigned int *SKU1, unsigned int *SKU2)
{
	unsigned int devfn;
	struct pci_bus *bus;

	bus = dev->bus;
	devfn = dev->devfn;
	pci_bus_read_config_dword(bus, devfn, 0x34, SKU1);
	pci_bus_read_config_dword(bus, devfn, 0x38, SKU2);

	MTK_ERR_LOG(TAG, "Read SKU1 0x%x, SKU2 0x%x\n", *SKU1, *SKU2);

	return 0;
}


void mtk_setup_error_report(struct pci_dev *dev, bool enable)
{
	struct pci_bus	*bus;
	unsigned int devfn, pos;
	u16 val;

	devfn = dev->devfn;
	bus = dev->bus;

	//write test
	pos = pci_pcie_cap(dev);
	//Set the error enable bits in PCI_EXP_DEVCTL
	pci_bus_read_config_word(bus, devfn, pos+PCI_EXP_DEVCTL, &val);
	if (enable == TRUE)
		val = val | PCI_EXP_DEVCTL_CERE;
	else
		val = val & (~PCI_EXP_DEVCTL_CERE);

	pci_bus_write_config_word(bus, devfn, pos+PCI_EXP_DEVCTL, val);
	pci_bus_read_config_word(bus, devfn, pos+PCI_EXP_DEVCTL, &val);
	MTK_DEBUG_LOG(TAG, "THe PCI_EXP_DEVCTL is updated to 0x%08x\n", val);


}

