/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef ___COMMON_H__
#define ___COMMON_H__

#include <asm/io.h>
#include "x_typedef.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PACKING
typedef unsigned int FIELD;

// ---------------------------------------------------------------------------
//  Type Casting
// ---------------------------------------------------------------------------

#define AS_INT32(x)     (*(INT32 *)(x))
#define AS_INT16(x)     (*(INT16 *)(x))
#define AS_INT8(x)      (*(INT8  *)(x))

#define AS_UINT32(x)    (*(UINT32 *)(x))
#define AS_UINT16(x)    (*(UINT16 *)(x))
#define AS_UINT8(x)     (*(UINT8  *)(x))


// ---------------------------------------------------------------------------
//  Register Manipulations
// ---------------------------------------------------------------------------

#define READ_REGISTER_UINT32(reg) \
	(*(volatile UINT32 * const)(reg))

#define WRITE_REGISTER_UINT32(reg, val) \
	((*(volatile UINT32 * const)(reg)) = (val))

#define READ_REGISTER_UINT16(reg) \
	(*(volatile UINT16 * const)(reg))

#define WRITE_REGISTER_UINT16(reg, val) \
	((*(volatile UINT16 * const)(reg)) = (val))

#define READ_REGISTER_UINT8(reg) \
	(*(volatile UINT8 * const)(reg))

#define WRITE_REGISTER_UINT8(reg, val) \
	((*(volatile UINT8 * const)(reg)) = (val))

#define INREG32(x)          READ_REGISTER_UINT32((UINT32 *)(x))
#define OUTREG32(x, y)      WRITE_REGISTER_UINT32((UINT32 *)(x), (UINT32)(y))

// ---------------------------------------------------------------------------
//  Register Field Access
// ---------------------------------------------------------------------------

#define REG_FLD(width, shift) \
	((UINT32)((((width) & 0xFF) << 16) | ((shift) & 0xFF)))

#define REG_FLD_WIDTH(field) \
	((UINT32)(((field) >> 16) & 0xFF))

#define REG_FLD_SHIFT(field) \
	((UINT32)((field) & 0xFF))

#define REG_FLD_MASK(field) \
	(((UINT32)((u64) 1 << REG_FLD_WIDTH(field)) - 1) \
	<< REG_FLD_SHIFT(field))

#define REG_FLD_GET(field, reg32) \
	(((reg32) & REG_FLD_MASK(field)) >> REG_FLD_SHIFT(field))

#define REG_FLD_VAL(field, val) \
	(((val) << REG_FLD_SHIFT(field)) & REG_FLD_MASK(field))

#define REG_FLD_SET(field, reg32, val)                  \
		((reg32) = (((reg32) & ~REG_FLD_MASK(field)) |   \
				   REG_FLD_VAL((field), (val))))        \


#define REG_SET(reg32, val)                  \
					((reg32) = (val))	\



#define REG_IO_READ32(reg)    readl((volatile void *)(reg))
#define REG_IO_WRITE32(reg, val)   writel((val), (volatile void*)(reg))

#ifdef __cplusplus
}
#endif


#endif // ___COMMON_H__
