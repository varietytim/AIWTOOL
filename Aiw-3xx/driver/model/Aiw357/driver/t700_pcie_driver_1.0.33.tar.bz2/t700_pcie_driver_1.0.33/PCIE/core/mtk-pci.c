// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/pci.h>
#include <linux/rwsem.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/spinlock_types.h>
#include <linux/spinlock.h>
#include <linux/types.h>
#include <linux/dma-mapping.h>
#include <linux/random.h>
#include <linux/slab.h>
#include <linux/pm_runtime.h>
#include <linux/device.h>
#include <linux/module.h>
//#include <linux/pcieport_if.h>
#include <linux/version.h>
#include <linux/acpi.h>

#include "mtk-pcie-dbg.h"
#include "mtk-pci.h"
#include "mtk-pci-ext.h"
#include "mtk-pcie.h"
#include "mtk-pcie-mac.h"
#include "PCIE_MAC_IREG_c_header.h"
#include "PCIE_EXT_REG.h"
#include "mtk-isr.h"
#include "mhccif.h"
#include "mtk-pci-drv.h"
#include "mtk-pci-rescan.h"
#include "modem_sys_1.h"
#include "modem_sys.h"

static int mtk_pci_probe(struct pci_dev *dev, const struct pci_device_id *id);
static void mtk_pci_remove(struct pci_dev *dev);
static void mtk_pci_shutdown(struct pci_dev *pdev);

static int mtk_pci_request_irq(struct pci_dev *dev, int irq_count);

static void mtk_free_irq(struct pci_dev *dev);


static int mtk_setup_msix(struct pci_dev *dev, int irq_count);


static void mtk_ext_driver_init(struct pci_dev *dev);
static void mtk_ext_driver_deinit(struct pci_dev *dev);
static void mtk_ext_driver_init_int_callback(struct pci_dev *dev);
static int mtk_pcie_reinit_pcie_only(struct mtk_pci_dev *mtk_dev);



static u64 ds_lock_sent;

static const struct mtk_pci_driver mtk_bus_driver = {
	.description =      MTK_PCI_DRIVER_NAME,
	.irq_descr =        MTK_PCI_IRQ_DESCR,
	.isr =          mtk_pcie_irq,
};

/* PCI driver selection metadata; PCI hotplugging uses this */
static const struct pci_device_id pci_ids[] = { {
	PCI_DEVICE(PCI_VENDOR_ID_TEST, PCI_DEVICE_ID_TEST),
	PCI_CLASS_MTK_DEVICE, ~0,
	.driver_data =  (unsigned long) &mtk_bus_driver,
	},
	{ /* end: all zeroes */ }
};
MODULE_DEVICE_TABLE(pci, pci_ids);

static void __mtk_pci_read_pcistate_regs(struct pci_dev *pdev)
{
	char tag[64];
	int aer_pos;
	u32 reg32;
	u16 reg16;

	snprintf(tag, 64, "dev=0x%04x bdf:%d-%d-%d",
		pdev->device, pdev->bus->number,
		pdev->devfn >> 12, pdev->devfn & 0xfff);

	pci_read_config_word(pdev, PCI_STATUS, &reg16);
	MTK_ERR_LOG(tag, "PCI_STATUS = 0x%04x\n", reg16);

	aer_pos = pdev->aer_cap;

	if (!aer_pos) {
		MTK_ERR_LOG(tag, "pci_dev has no aer_cap\n");
		return;
	}

	pci_read_config_dword(pdev, aer_pos + PCI_ERR_UNCOR_STATUS, &reg32);
	MTK_ERR_LOG(tag, "PCI_ERR_UNCOR_STATUS = 0x%08x\n", reg32);
	pci_read_config_dword(pdev, aer_pos + PCI_ERR_UNCOR_MASK, &reg32);
	MTK_ERR_LOG(tag, "PCI_ERR_UNCOR_MASK   = 0x%08x\n", reg32);
	pci_read_config_dword(pdev, aer_pos + PCI_ERR_UNCOR_SEVER, &reg32);
	MTK_ERR_LOG(tag, "PCI_ERR_UNCOR_SEVER  = 0x%08x\n", reg32);
	pci_read_config_dword(pdev, aer_pos + PCI_ERR_COR_STATUS, &reg32);
	MTK_ERR_LOG(tag, "PCI_ERR_COR_STATUS   = 0x%08x\n", reg32);
	pci_read_config_dword(pdev, aer_pos + PCI_ERR_COR_MASK, &reg32);
	MTK_ERR_LOG(tag, "PCI_ERR_COR_MASK     = 0x%08x\n", reg32);

	if (pdev->hdr_type == PCI_HEADER_TYPE_BRIDGE) {
		pci_read_config_dword(pdev,
			aer_pos + PCI_ERR_HEADER_LOG, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_HEADER_LOG[0]  = 0x%08x\n", reg32);
		pci_read_config_dword(pdev,
			aer_pos + PCI_ERR_HEADER_LOG + 4, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_HEADER_LOG[4]  = 0x%08x\n", reg32);
		pci_read_config_dword(pdev,
			aer_pos + PCI_ERR_HEADER_LOG + 8, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_HEADER_LOG[8]  = 0x%08x\n", reg32);
		pci_read_config_dword(pdev,
			aer_pos + PCI_ERR_HEADER_LOG + 12, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_HEADER_LOG[12] = 0x%08x\n", reg32);

		pci_read_config_dword(pdev, aer_pos + PCI_ERR_ROOT_COMMAND, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_ROOT_COMMAND = 0x%08x\n", reg32);
		pci_read_config_dword(pdev, aer_pos + PCI_ERR_ROOT_STATUS, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_ROOT_STATUS  = 0x%08x\n", reg32);
		pci_read_config_dword(pdev, aer_pos + PCI_ERR_ROOT_ERR_SRC, &reg32);
		MTK_ERR_LOG(tag, "PCI_ERR_ROOT_ERR_SRC = 0x%08x\n", reg32);
	}
}

void mtk_pci_read_pcistate_regs(struct mtk_pci_dev *mtk_dev)
{
	struct pci_dev *bridge;
	unsigned short vend_id;
	volatile unsigned int ltssm_state;	
	unsigned char* p_mac_ireg_base;
	u32 istatus_local, int_enable_host, istatus_host, istatus_pending_adt, local_interrupt, register_value;

	__mtk_pci_read_pcistate_regs(mtk_dev->pdev);

	bridge = pci_upstream_bridge(mtk_dev->pdev);
	if (!bridge) {
		MTK_ERR_LOG(TAG, "Bridge is not found \n");
	} else {
		__mtk_pci_read_pcistate_regs(bridge);
	}

	/* Dump more information for debugging */

	/*Dump PCIE vendor ID.*/
	pci_read_config_word(mtk_dev->pdev, PCI_VENDOR_ID, &vend_id);
	MTK_ERR_LOG(TAG, "[PM] dump vend id: 0x%x \n", vend_id);

	/*Dump LTSSM state:0x150*/
	ltssm_state = MTK_PCIe_Ltssm_Status(mtk_dev->base_addr.pcie_mac_ireg_base) ;
	MTK_ERR_LOG(TAG, "[PM] dump LTSSM state: 0x%x \n", ltssm_state);

	/*Dump ISTATUS LOCAL:0x184*/
	istatus_local = MTK_ISTATUS_LOCAL(mtk_dev->base_addr.pcie_mac_ireg_base) ;
	MTK_ERR_LOG(TAG, "[PM] dump ISTATUS LOCAL: 0x%x \n", istatus_local); 
	/*Dump INT ENABLE HOST:0x188*/
	int_enable_host = MTK_INT_ENABLE_HOST(mtk_dev->base_addr.pcie_mac_ireg_base) ;
	MTK_ERR_LOG(TAG, "[PM] dump INT ENABLE HOST: 0x%x \n", int_enable_host);

	/*Dump ISTATUS HOST:0x18C*/
	istatus_host = MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base) ;
	MTK_ERR_LOG(TAG, "[PM] dump STATUS HOST: 0x%x \n", istatus_host);

	p_mac_ireg_base = (unsigned char*)(mtk_dev->base_addr.pcie_mac_ireg_base);
	MTK_ERR_LOG(TAG, "mac reg base: 0x%llx, 0x%llx\n", (u64)p_mac_ireg_base, (u64)(mtk_dev->base_addr.pcie_mac_ireg_base));

	/*Dump ISTATUS PENDING ADT:0x1D4*/
	istatus_pending_adt = INREG32(p_mac_ireg_base + 0x1D4);
	MTK_ERR_LOG(TAG, "[PM] dump ISTATUS PENDING ADT: 0x%x \n", istatus_pending_adt); 

	/*Dump Local Interrupt enable register:0x180*/
	local_interrupt = INREG32(p_mac_ireg_base + 0x180);
	MTK_ERR_LOG(TAG, "[PM] dump Interrupt enable register: 0x%x \n", local_interrupt);

	/*Dump mhccif registers.*/
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_ep_base + 0x8));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif 0x8 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_ep_base + 0x10));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif 0x10 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_ep_base + 0x20));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif 0x20 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_ep_base + 0x24));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif 0x24 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_ep_base + 0x28));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif 0x28 register: 0x%x \n", register_value);

	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_rc_base + 0x8));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif RC 0x8 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_rc_base + 0x10));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif RC 0x10 register: 0x%x \n", register_value);
	register_value = REG_IO_READ32((mtk_dev->base_addr.mhccif_rc_base + 0x20));
	MTK_ERR_LOG(TAG, "[PM] dump mhccif RC 0x20 register: 0x%x \n", register_value); 
}

static int mtk_pci_wait_lss_lock_done(struct mtk_pci_dev *mtk_dev)
{
	u32 polling_time = 0;
	u32 res_state = 0;

	while (polling_time < l_res_polling_max) {

		udelay(l_res_polling_period);

		res_state = PCIE_READ_RESOURCE_STATUS(mtk_dev->base_addr.pcie_mac_ireg_base);
		if ((res_state & 0X1F) == 0X1F) {
			MTK_DEBUG_LOG(TAG, "Polling Done time %d\n", polling_time);
			return 0;
		}

		polling_time += l_res_polling_period;
	}
	MTK_ERR_LOG(TAG, "achieving max polling time %d res_state = 0x%X\n",
		l_res_polling_max, res_state);

	return -ETIMEDOUT;
}

mtk_resume_reg_state_t mtk_dev_pci_check_resume_reg_state(struct mtk_pci_dev *mtk_dev)
{
    volatile mtk_resume_reg_state_t ret = PM_RESUME_REG_STATE_L1;

    MTK_PCI_PM_FUNC_ENTER();

    /* TODO: Check register */
    ret = (mtk_resume_reg_state_t) MTK_REG_BASE_PCIE_DEBUG_DUMMY_3(mtk_dev->base_addr.pcie_mac_ireg_base);

    return ret;
}

static void __mtk_dev_pci_resource_lock(struct mtk_pci_dev *mtk_dev)
{

    PCIE_CFG_SET_PEXTP_MAC_SLEEP(MTK_PCIE_MISC_CTRL(mtk_dev->base_addr.pcie_mac_ireg_base), 1);

    return;
}

static void __mtk_dev_send_pci_resource_lock_req(struct mtk_pci_dev *mtk_dev)
{

    __mhccif_rc2ep_swint_trigger(mtk_dev, MHCCIF_H2D_INT_PCIE_DS_LOCK);

    return;
}

static void __mtk_dev_pci_resource_unlock(struct mtk_pci_dev *mtk_dev)
{

    PCIE_CFG_SET_PEXTP_MAC_SLEEP(MTK_PCIE_MISC_CTRL(mtk_dev->base_addr.pcie_mac_ireg_base), 0);

    return;
}
#ifdef CONFIG_PM
static void mtk_pm_resume_check_work(struct work_struct *work)
{
    struct delayed_work *dwork = to_delayed_work(work);

    struct mtk_pci_dev *mtk_dev = (struct mtk_pci_dev *) container_of(dwork, struct mtk_pci_dev, pm_resume_check);

    mtk_resume_reg_state_t resume_reg_state;

    resume_reg_state = mtk_dev_pci_check_resume_reg_state (mtk_dev);

    MTK_INFO_LOG(TAG, "[PM] mtk_pci_pm_resume: Resume from 0x%x\n", resume_reg_state);
#if 1
    mtk_queue_rescan_work(mtk_dev->pdev);

#else
    if (resume_reg_state == PM_RESUME_REG_STATE_L3) {
        mtk_queue_rescan_work(mtk_dev->pdev);
    } else {
        mtk_dev->pm_resume_check_count++;

        if(mtk_dev->pm_resume_check_count == 4) {
             mtk_dev->pm_resume_check_count = 0;
             mtk_queue_rescan_work(mtk_dev->pdev);
        } else {
             schedule_delayed_work(&mtk_dev->pm_resume_check, 10*HZ);
        }
    }
 #endif
}
#endif
static void mtk_l_res_unlock_work(struct work_struct *work)
{
    unsigned long flags = 0;
    struct delayed_work *dwork = to_delayed_work(work);

    struct mtk_pci_dev *mtk_dev = (struct mtk_pci_dev *) container_of(dwork, struct mtk_pci_dev, l_res_unlock_work);

    spin_lock_irqsave(&mtk_dev->md_pm_lock, flags);

    if (!atomic_read(&mtk_dev->l_res_lock_count))
        __mtk_dev_pci_resource_unlock(mtk_dev);

    spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);
}

static int mtk_pci_pm_init(struct mtk_pci_dev *mtk_dev)
{
	struct pci_dev *pdev = mtk_dev->pdev;

	MTK_PCI_PM_FUNC_ENTER();
	ds_lock_sent = 0;
	INIT_LIST_HEAD(&mtk_dev->md_pm_entities);

	spin_lock_init(&mtk_dev->md_pm_lock);

	mutex_init(&mtk_dev->md_pm_entity_mtx);

	init_completion(&mtk_dev->l_res_acquire);

	init_completion(&mtk_dev->pm_suspend_ack);
	init_completion(&mtk_dev->pm_resume_ack);

	init_completion(&mtk_dev->pm_suspend_ack_sap);
	init_completion(&mtk_dev->pm_resume_ack_sap);
#ifdef CONFIG_PM
	INIT_DELAYED_WORK(&mtk_dev->pm_resume_check, mtk_pm_resume_check_work);
#endif
	INIT_DELAYED_WORK(&mtk_dev->l_res_unlock_work, mtk_l_res_unlock_work);
	mtk_dev->pm_resume_check_count = 0;
	atomic_set(&mtk_dev->l_res_lock_count, 0);

	device_init_wakeup(&pdev->dev, true);
#ifdef CONFIG_PM
	if(!suspend_direct_complete)
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,8,0)
		dev_pm_set_driver_flags(&pdev->dev, pdev->dev.power.driver_flags|DPM_FLAG_NO_DIRECT_COMPLETE);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0)
		dev_pm_set_driver_flags(&pdev->dev, pdev->dev.power.driver_flags|DPM_FLAG_NEVER_SKIP);
#else
		// under 4.14
		pdev->dev_flags |= PCI_DEV_FLAGS_NEEDS_RESUME;
#endif		
	MTK_DEBUG_LOG("PM", "After PM Init usage_count=%d", atomic_read(&(mtk_dev->pdev->dev.power.usage_count)));
#endif
	atomic_set(&mtk_dev->md_pm_init_done, 0);
	atomic_set(&mtk_dev->md_pm_resumed, 1);

	atomic_set(&mtk_dev->pm_counter, 0);

	PCIE_CFG_SET_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base,
		1<<PCIE_L1_DISABLE_BIT(0));
	mtk_pci_wait_lss_lock_done(mtk_dev);

	return 0;
}

int mtk_pci_pm_init_late(struct mtk_pci_dev *mtk_dev)
{
	MTK_PCI_PM_FUNC_ENTER();
	/* PCIE Resource Lock: We could only enable Lock after MD deep sleep finish */
	if(likely(l_res_lock_enable)) {
		mhccif_mask_clr(mtk_dev,   (1<<MHCCIF_D2H_INT_PCIE_DS_LOCK_ACK)|
					(1<<MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK)|
					(1<<MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK)|
					(1<<MHCCIF_D2H_INT_PCIE_PM_SUSPEND_ACK_AP)|
					(1<<MHCCIF_D2H_INT_PCIE_PM_RESUME_ACK_AP));
		PCIE_CFG_CLR_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base, 1<<PCIE_L1_DISABLE_BIT(0));
		atomic_inc(&mtk_dev->md_pm_init_done);
	}
#ifdef CONFIG_PM
	/* Runtime PM enable: We could only enable runtime PM after CCCI HS done */
	if(likely(runtime_detect_enable)) {
		struct pci_dev *pdev = mtk_dev->pdev;
		unsigned short vend_id;
		pm_runtime_put_noidle(&pdev->dev);
		pci_read_config_word(mtk_dev->pdev, PCI_VENDOR_ID, &vend_id);
		MTK_DEBUG_LOG("PM", "After PM Late Init usage_count=%d, vend_id=0x%x", atomic_read(&(mtk_dev->pdev->dev.power.usage_count)), vend_id);
	}
#endif
	return 0;
}

int mtk_pci_pm_deinit(struct mtk_pci_dev *mtk_dev)
{
	MTK_PCI_PM_FUNC_ENTER();
#ifdef CONFIG_PM
	cancel_delayed_work_sync(&mtk_dev->pm_resume_check);
#endif
	cancel_delayed_work_sync(&mtk_dev->l_res_unlock_work);
	return 0;
}

static int mtk_pci_pm_reinit(struct mtk_pci_dev *mtk_dev)
{
	/* The MTK_DEV is kept in FSM reinit flow, so just roll back PM setting to the init setting */
	atomic_set(&mtk_dev->md_pm_init_done, 0);
	atomic_set(&mtk_dev->md_pm_resumed, 1);
#ifdef CONFIG_PM
	if(likely(runtime_detect_enable))
		pm_runtime_get_noresume(&mtk_dev->pdev->dev);
#endif
	PCIE_CFG_SET_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base,
		1<<PCIE_L1_DISABLE_BIT(0));
	mtk_pci_wait_lss_lock_done(mtk_dev);

	return 0;
}

void mtk_pci_pm_exp_detected(struct mtk_pci_dev *mtk_dev)
{
	PCIE_CFG_SET_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base,
		1<<PCIE_L1_DISABLE_BIT(0));
	mtk_pci_wait_lss_lock_done(mtk_dev);
	atomic_dec(&mtk_dev->md_pm_init_done);
}

int mtk_pci_pm_entity_register(struct mtk_pci_dev *mtk_dev,
	struct md_pm_entity *pm_entity)
{
	struct md_pm_entity *entity;

	MTK_DEBUG_LOG(TAG, "Registering PM entity %d\n", pm_entity->key);
	mutex_lock(&mtk_dev->md_pm_entity_mtx);
	list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
		if (entity->key == pm_entity->key) {
			MTK_ERR_LOG(TAG, "Registering an exist PM entity %d\n",
								pm_entity->key);
			mutex_unlock(&mtk_dev->md_pm_entity_mtx);
			return -EALREADY;
		}
	}
	list_add_tail(&pm_entity->entity, &mtk_dev->md_pm_entities);
	mutex_unlock(&mtk_dev->md_pm_entity_mtx);
	return 0;
}

int mtk_pci_pm_entity_unregister(struct mtk_pci_dev *mtk_dev,
	struct md_pm_entity *pm_entity)
{
	struct md_pm_entity *entity, *tmp_entity;

	MTK_INFO_LOG(TAG, "[PM] UnRegistering  PM entity %d\n", pm_entity->key);

	mutex_lock(&mtk_dev->md_pm_entity_mtx);

	list_for_each_entry_safe(entity, tmp_entity, &mtk_dev->md_pm_entities, entity) {
		if (entity->key == pm_entity->key) {
			list_del(&pm_entity->entity);
			mutex_unlock(&mtk_dev->md_pm_entity_mtx);
			return 0;
		}
	}
	mutex_unlock(&mtk_dev->md_pm_entity_mtx);

	MTK_INFO_LOG(TAG,
		"[PM] Unregistering an non-exist PM entity %d\n",
		pm_entity->key);
	return -EALREADY;
}

void mtk_pci_l_resource_wait_complete(struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user)
{
    MTK_DEBUG_LOG(TAG, "[PM] user %d, caller: %ps\n",\
        lock_user, __builtin_return_address(0));

	/* Note: Since Kernel Ver 4.11,
	 *we don't have to worry about the completion number
	 * consumed to 0, because the wait will
	 *never be cleared for complete_all
	 * But we should be careful when porting it to other platform,
	 *please find out similar primitives are supported or not
	 */
    if(likely(mtk_dev->pm_enabled))
	    wait_for_completion(&mtk_dev->l_res_acquire);


}

bool mtk_pci_l_resource_try_wait_complete(struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user)
{
    bool ret = true;    /* if PM is not enabled, maybe we just let it continue */

    MTK_DEBUG_LOG(TAG, "[PM] try wait user %d, caller: %ps\n",\
        lock_user, __builtin_return_address(0));

	/* Note: Since Kernel Ver 4.11,
	 *we don't have to worry about the completion number
	 * consumed to 0, because the wait will
	 *never be cleared for complete_all
	 * But we should be careful when porting it to other platform,
	 *please find out similar primitives are supported or not
	 */
    if(likely(mtk_dev->pm_enabled))
	    ret = try_wait_for_completion(&mtk_dev->l_res_acquire);

    return ret;
}

int mtk_pci_l_resource_lock(struct mtk_pci_dev *mtk_dev,
	mtk_l_res_t lock_user)
{
	int ret = 0;
    unsigned long flags = 0;

    if(unlikely(!mtk_dev->pm_enabled))
        return 0;

    MTK_INFO_LOG(TAG, "user %d, caller: %ps\n",\
        lock_user, __builtin_return_address(0));

    if(unlikely((atomic_read(&mtk_dev->md_pm_init_done) < 1) || (!atomic_read(&mtk_dev->md_pm_resumed)) ) ) {
        atomic_inc(&mtk_dev->l_res_lock_count);
        complete_all(&mtk_dev->l_res_acquire);
        return ret;
    }
    /* __mtk_dev_pci_resource_lock_req */
    spin_lock_irqsave(&mtk_dev->md_pm_lock, flags);
    if (atomic_inc_return(&mtk_dev->l_res_lock_count) == 1) {
        ret = 1;
        reinit_completion(&mtk_dev->l_res_acquire);
        __mtk_dev_pci_resource_lock(mtk_dev);
        if((PCIE_READ_RESOURCE_STATUS(mtk_dev->base_addr.pcie_mac_ireg_base) & 0X1F) == 0X1F) {
               spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);
               complete_all(&mtk_dev->l_res_acquire);
               return ret;
        }
        __mtk_dev_send_pci_resource_lock_req(mtk_dev);
        spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);
        MTK_INFO_LOG(TAG, "ds_lock_sent=%llu\n", ++ds_lock_sent);
        return ret;
    }
    spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);

	return ret;
}

int mtk_pci_l_resource_unlock(
	struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user)
{
	int ret = 0;
	unsigned long flags = 0;

	if(unlikely(!mtk_dev->pm_enabled)){
        	return 0;
	}

	MTK_INFO_LOG(TAG, "user %d, caller: %ps\n",
		lock_user, __builtin_return_address(0));
	/* mtk_dev_pci_resource_unlock_req */
	if (unlikely((atomic_read(&mtk_dev->md_pm_init_done) < 1 )
		|| (!atomic_read(&mtk_dev->md_pm_resumed)))) {
		atomic_dec(&mtk_dev->l_res_lock_count);
		return ret;
	}

    if (atomic_dec_and_test(&mtk_dev->l_res_lock_count)) {

        if(l_res_delayed_unlock) {
            cancel_delayed_work(&mtk_dev->l_res_unlock_work);
            schedule_delayed_work(&mtk_dev->l_res_unlock_work, msecs_to_jiffies(l_res_delayed_unlock_timeout));
        } else {
            spin_lock_irqsave(&mtk_dev->md_pm_lock, flags);
            __mtk_dev_pci_resource_unlock(mtk_dev);
            spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);
        }
    }


	return ret;
}

#ifdef CONFIG_PM

static void __mtk_dev_send_pci_d3_enter_req(struct mtk_pci_dev *mtk_dev)
{
	__mhccif_rc2ep_swint_trigger(mtk_dev, MHCCIF_H2D_INT_PCIE_PM_SUSPEND_REQ);
}

static void __mtk_dev_send_pci_d3_exit_req(struct mtk_pci_dev *mtk_dev)
{
	__mhccif_rc2ep_swint_trigger(mtk_dev, MHCCIF_H2D_INT_PCIE_PM_RESUME_REQ);
}

static void __mtk_dev_send_pci_d3_enter_req_sap(struct mtk_pci_dev *mtk_dev)
{
	__mhccif_rc2ep_swint_trigger(mtk_dev, MHCCIF_H2D_INT_PCIE_PM_SUSPEND_REQ_AP);
}

static void __mtk_dev_send_pci_d3_exit_req_sap(struct mtk_pci_dev *mtk_dev)
{
	__mhccif_rc2ep_swint_trigger(mtk_dev, MHCCIF_H2D_INT_PCIE_PM_RESUME_REQ_AP);
}

static int __mtk_dev_pci_check_last_link_state (struct mtk_pci_dev *mtk_dev)
{
	volatile unsigned int ltssm_state;

	ltssm_state = MTK_PCIe_Ltssm_Status(mtk_dev->base_addr.pcie_mac_ireg_base) ;

	MTK_INFO_LOG(TAG, "[PM]LTSSM_L0=%d\n", !!(ltssm_state&(1<<4)));
	MTK_INFO_LOG(TAG, "[PM]LTSSM_L0S=%d\n", !!(ltssm_state&(1<<5)));
	MTK_INFO_LOG(TAG, "[PM]LTSSM_L1=%d\n", !!(ltssm_state&(1<<6)));
	MTK_INFO_LOG(TAG, "[PM]LTSSM_L2=%d\n", !!(ltssm_state&(1<<7)));
	MTK_INFO_LOG(TAG, "[PM]L1PM_L11=%d\n", !!(ltssm_state&(1<<12)));
	MTK_INFO_LOG(TAG, "[PM]L1PM_L12=%d\n", !!(ltssm_state&(1<<13)));
	return 0;
}

int mtk_pm_runtime_get(struct mtk_pci_dev *mtk_dev)
{
	if(unlikely(!mtk_dev->pm_enabled))
		return 0;
	return pm_runtime_get(&mtk_dev->pdev->dev);
}

int mtk_pm_runtime_get_sync(struct mtk_pci_dev *mtk_dev)
{
	if(unlikely(!mtk_dev->pm_enabled))
		return 0;
	return pm_runtime_get_sync(&mtk_dev->pdev->dev);
}

int mtk_pm_runtime_put(struct mtk_pci_dev *mtk_dev)
{
	if(unlikely(!mtk_dev->pm_enabled))
		return 0;
	return pm_runtime_put(&mtk_dev->pdev->dev);
}

int mtk_pm_runtime_put_sync(struct mtk_pci_dev *mtk_dev)
{
	if(unlikely(!mtk_dev->pm_enabled))
		return 0;
	return pm_runtime_put_sync(&mtk_dev->pdev->dev);
}

static int __mtk_pci_wait_suspend_ack(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "[PM] caller: %ps\n",  __builtin_return_address(0));

	return wait_for_completion_timeout(
		&mtk_dev->pm_suspend_ack,
		msecs_to_jiffies(suspend_wait_timeout));
}

static int __mtk_pci_wait_resume_ack(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "[PM] caller: %ps\n",  __builtin_return_address(0));

	return wait_for_completion_timeout(
		&mtk_dev->pm_resume_ack, msecs_to_jiffies(resume_wait_timeout));
}

static int __mtk_pci_wait_suspend_ack_sap(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "[PM] caller: %ps\n",  __builtin_return_address(0));

	return wait_for_completion_timeout(
		&mtk_dev->pm_suspend_ack_sap,
		msecs_to_jiffies(suspend_wait_timeout_sap));
}

static int __mtk_pci_wait_resume_ack_sap(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "[PM] caller: %ps\n",  __builtin_return_address(0));

	return wait_for_completion_timeout(
		&mtk_dev->pm_resume_ack_sap,
		msecs_to_jiffies(resume_wait_timeout_sap));
}

static int __mtk_pci_enable_wake(u8 dev_state, u8 system_state, bool enable)
{
	union acpi_object in_arg[3];
	struct acpi_object_list arg_list = { 3, in_arg };
	acpi_status acpi_ret;

	MTK_INFO_LOG(TAG, "[PM] system_state %d, enable %d\n", system_state, enable);

	in_arg[0].type = ACPI_TYPE_INTEGER;
	in_arg[0].integer.value = enable;
	in_arg[1].type = ACPI_TYPE_INTEGER;
	in_arg[1].integer.value = system_state;
	in_arg[2].type = ACPI_TYPE_INTEGER;
	in_arg[2].integer.value = dev_state;
	acpi_ret = acpi_evaluate_object(NULL, "\\_SB.PCI0.RP02._DSW", &arg_list, NULL);
	if (ACPI_FAILURE(acpi_ret))
		MTK_INFO_LOG(TAG, "_DSW method fail for parent: %s\n",\
								acpi_format_exception(acpi_ret));
	return acpi_ret;
}

/*
 * 1) description :  To make it easier to synchronize logs for device's debugging.
 * 2) solution    :  Add a counter to distinguish each suspending and remusing.
*/
static void __mtk_pci_pm_counter(struct mtk_pci_dev *mtk_dev, u32 header)
{
	u32 pm_cnt, cnt_reg;

	pm_cnt = atomic_inc_return(&mtk_dev->pm_counter) & 0xFFFF;
	cnt_reg = header | pm_cnt;
	REG_IO_WRITE32(MHCCIF_H2D_REG_PCIE_PM_COUNTER(
		mtk_dev->base_addr.mhccif_rc_base), cnt_reg);
	MTK_INFO_LOG(TAG, "pm_cnt = %u, cnt_reg = 0x%X\n", pm_cnt, cnt_reg);
}

static int __mtk_pci_pm_suspend(struct mtk_pci_dev *mtk_dev, bool is_runtime)
{
	struct md_pm_entity *entity;
	int ret = 0;
	unsigned long wait_ret = 0;
	unsigned int key = 255;

	MTK_INFO_LOG(TAG, "[PM] Suspend Enter\n");

	if(unlikely(!mtk_dev->pm_enabled))
		return 0;

	if(unlikely(atomic_read(&mtk_dev->md_pm_init_done) < 1 ))
	{
		MTK_INFO_LOG(TAG, "[PM] Suspend Exit Because CCCI not Handshaked or in EE\n");
		return -EFAULT;
	}

	PCIE_CFG_SET_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base, 1<<PCIE_L1_DISABLE_BIT(0));
	mtk_pci_wait_lss_lock_done(mtk_dev);

	atomic_dec(&mtk_dev->md_pm_resumed);

	mtk_pcie_set_int_mask(mtk_dev, SAP_RGU_INT, true);
	atomic_set(&mtk_dev->rgu_pci_irq_en, 0);

	/* Now we can use the list freely */
	list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
		if (entity->suspend) {
			ret = entity->suspend(mtk_dev, entity->entity_param);
			if (ret) {
				key = entity->key;
				break;
			}
		}
	}

	if (ret) {
		MTK_ERR_LOG(TAG,
			"[PM] Suspend Entry Key %d  Failure ret %d, Resume what we have suspended\n",
			key, ret);

		list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
			if ( key == entity->key)
				break;
			if (entity->resume)
				entity->resume(mtk_dev, entity->entity_param);
		}
		goto __suspend_complete;
	}

	reinit_completion(&mtk_dev->pm_suspend_ack);
	reinit_completion(&mtk_dev->pm_suspend_ack_sap);
	/*  Start to let device enter D3/L2 */
	__mtk_pci_pm_counter(mtk_dev, PM_SUSPEND_HEADER);
	__mtk_dev_send_pci_d3_enter_req(mtk_dev);
	__mtk_dev_send_pci_d3_enter_req_sap(mtk_dev);

	/* TODO: Do we need to do something since the suspend timeout? */
	wait_ret = __mtk_pci_wait_suspend_ack(mtk_dev);
	if(!wait_ret) {
		MTK_ERR_LOG(TAG, "[PM] Wait for device suspend ACK timeout\n");
	}


	wait_ret = __mtk_pci_wait_suspend_ack_sap(mtk_dev);
	if(!wait_ret) {
		MTK_ERR_LOG(TAG, "[PM] Wait for device suspend ACK timeout-SAP\n");
	}

	/* Each HW's final work */
	list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
		if(entity->suspend_late) {
			ret = entity->suspend_late(mtk_dev, entity->entity_param);
			if (ret) {
				key = entity->key;
				break;
			}
		}
	}

	if (l_res_delayed_unlock) {
		unsigned long flags = 0;
		MTK_INFO_LOG(TAG, "[PM] cancel the delayed unlock workqueue.\n");
		cancel_delayed_work_sync(&mtk_dev->l_res_unlock_work);
		if (!atomic_read(&mtk_dev->l_res_lock_count)) {
			spin_lock_irqsave(&mtk_dev->md_pm_lock, flags);
			__mtk_dev_pci_resource_unlock(mtk_dev);
			spin_unlock_irqrestore(&mtk_dev->md_pm_lock, flags);
		} else {
			MTK_ERR_LOG(TAG, "[PM] resource lock count is not zero.\n");
		}
	}

	/* S0ix/D3/L2 Enter, force to enable wake: i.e. call _DSW for the RP directly */
	if (!ret && is_runtime && d3l2_force_dsw)
		__mtk_pci_enable_wake(3, 0, true);

	if (ret)
		MTK_ERR_LOG(TAG,
			"[PM] Suspend Late Entry Key %d  Failure ret %d\n", key, ret);

__suspend_complete:
	if(ret || !l1ss_state_logging)
		PCIE_CFG_CLR_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base, 1<<PCIE_L1_DISABLE_BIT(0));

	if(ret) {
		atomic_inc(&mtk_dev->md_pm_resumed);
		mtk_pcie_set_int_mask(mtk_dev, SAP_RGU_INT, false);
	}

	MTK_INFO_LOG(TAG, "[PM] Suspend Done Ret %d, pme_poll = %d, pm_cap=%x\n", ret, mtk_dev->pdev->pme_poll, mtk_dev->pdev->pm_cap);
	return ret;
}

static int __mtk_pci_pm_resume(struct mtk_pci_dev *mtk_dev, bool no_state_check, bool is_runtime, bool from_s4)
{
	struct md_pm_entity *entity;
	int ret = 0;
	unsigned long wait_ret = 0;
	unsigned int key = 255;
	mtk_resume_reg_state_t resume_reg_state;
	unsigned int last_link_state;
	unsigned short vend_id;

	if (is_runtime && d3l2_force_dsw)
		__mtk_pci_enable_wake(0, 0, false);

	pci_set_master(mtk_dev->pdev);

	if(unlikely(!mtk_dev->pm_enabled))
		return 0;

	if(unlikely(atomic_read(&mtk_dev->md_pm_init_done) < 1))
		goto __resume_complete;

	/* Check where  resume from*/
	resume_reg_state = mtk_dev_pci_check_resume_reg_state (mtk_dev);
	last_link_state = __mtk_dev_pci_check_last_link_state( mtk_dev);

	pci_read_config_word(mtk_dev->pdev, PCI_VENDOR_ID, &vend_id);

	MTK_INFO_LOG(TAG, "[PM] Resume Enter:no_state_check: %d, is_runtime: %d\n", no_state_check, is_runtime);

	MTK_INFO_LOG(TAG, "[PM] mtk_pci_pm_resume: Resume from 0x%x, last link state is %d, vend_id is 0x%x\n", resume_reg_state, last_link_state, vend_id);

	if(!no_state_check) {
		u32 atr_reg_val;

		/* For D3/L3 resume, there are condition that device bootup so quick so that the dummy register could be set by MD to new value
		 * other than initial value. We cannot identify it's a new boot or not. So we use atr_reg_val to help identify.
		 * If it is not set by Host Driver,the value is 0x7F  */
		atr_reg_val = REG_IO_READ32((u8 *)MTK_REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(mtk_dev->base_addr.pcie_mac_ireg_base));

		MTK_DEBUG_LOG(TAG, "[PM] atr_reg_val: 0x%x\n", atr_reg_val);

		if ((resume_reg_state == PM_RESUME_REG_STATE_L3) || (resume_reg_state == PM_RESUME_REG_STATE_INIT &&  atr_reg_val == 0x0000007f ) ) {
			MTK_INFO_LOG(TAG, "Before pcie reinit\n");
			if(mtk_dev->event_callback != NULL)
				mtk_dev->event_callback(__PCIE_EVENT_L3ENTER,mtk_dev->event_callback_param);
			else
				MTK_ERR_LOG(TAG, "ERROR: resume from L3 but fsm_callback not registered!\n");

			ret = mtk_pcie_reinit(mtk_dev);
			if (ret < 0) {
				MTK_ERR_LOG(TAG, "PCI reinit fail\n");
				return ret;
			}
			MTK_INFO_LOG(TAG, "pcie reinit done (%d)\n", ret);

			mtk_clear_rgu_irq(mtk_dev);
			if(mtk_dev->event_callback != NULL)
				mtk_dev->event_callback(__PCIE_EVENT_L3EXIT,mtk_dev->event_callback_param);
			else
				MTK_ERR_LOG(TAG, "ERROR: resume from L3 but fsm_callback not registered!\n");
			return ret;
		} else if (resume_reg_state == PM_RESUME_REG_STATE_EXP ||
			resume_reg_state == PM_RESUME_REG_STATE_L2_EXP) {
			if (resume_reg_state == PM_RESUME_REG_STATE_L2_EXP) {
				MTK_INFO_LOG(TAG, "pcie reinit resume from L2 EXP.\n");
				ret = mtk_pcie_reinit_pcie_only(mtk_dev);
				if (ret < 0) {
					MTK_ERR_LOG(TAG, "PCI reinit fail\n");
					return ret;
				}
				MTK_INFO_LOG(TAG, "pcie reinit done (%d)\n", ret);
			}
			atomic_dec(&mtk_dev->md_pm_init_done);
			atomic_set(&mtk_dev->rgu_pci_irq_en, 1);
			mtk_pcie_set_int_mask(mtk_dev, SAP_RGU_INT, false);

			mhccif_mask_clr(mtk_dev,
				(1<<MHCCIF_D2H_INT_except_init)|
				(1<<MHCCIF_D2H_INT_except_init_done)|
				(1<<MHCCIF_D2H_INT_except_clearQ_done)|
				(1<<MHCCIF_D2H_INT_except_allQ_reset)|
				(1<<MHCCIF_BOOT_FLOW_SYNC));
			return ret;
		} else if (resume_reg_state == PM_RESUME_REG_STATE_L2) {
			MTK_INFO_LOG(TAG, "pcie reinit resume from L2.\n");
			ret = mtk_pcie_reinit_pcie_only(mtk_dev);
			if (ret < 0) {
				MTK_ERR_LOG(TAG, "PCI reinit fail\n");
				return ret;
			}
		} else if (resume_reg_state != PM_RESUME_REG_STATE_L1 && resume_reg_state != PM_RESUME_REG_STATE_INIT) {
			MTK_INFO_LOG(TAG, "Resumed with crash, or L3?Start check\n");
			if(mtk_dev->event_callback!=NULL)
				mtk_dev->event_callback(__PCIE_EVENT_L3ENTER,mtk_dev->event_callback_param);
			else
				MTK_ERR_LOG(TAG, "Resume FSM Callback not registered!\n");
			mtk_clear_rgu_irq(mtk_dev);
			atomic_dec(&mtk_dev->md_pm_init_done);
			cancel_delayed_work_sync(&mtk_dev->pm_resume_check);
			schedule_delayed_work(&mtk_dev->pm_resume_check, HZ);
			return ret;
		}
	}

	if(likely(!l1ss_state_logging)) {
		PCIE_CFG_SET_L_STATES_DIS(mtk_dev->base_addr.pcie_mac_ireg_base, 1<<PCIE_L1_DISABLE_BIT(0));
		mtk_pci_wait_lss_lock_done(mtk_dev);
	}

	/* Now we can use the list freely */
	list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
		if (entity->resume_early) {
			ret = entity->resume_early(mtk_dev, entity->entity_param);
			if (ret) {
				key = entity->key;
				MTK_ERR_LOG(TAG,
					"[PM] Resume Early Entry Key %d  Failure ret %d\n",
					key, ret);
			}
		}
	}

	reinit_completion(&mtk_dev->pm_resume_ack);
	reinit_completion(&mtk_dev->pm_resume_ack_sap);

	__mtk_pci_pm_counter(mtk_dev, PM_RESUME_HEADER);
	__mtk_dev_send_pci_d3_exit_req(mtk_dev);
	__mtk_dev_send_pci_d3_exit_req_sap(mtk_dev);

	wait_ret = __mtk_pci_wait_resume_ack(mtk_dev);
	if(!wait_ret) {
		MTK_ERR_LOG(TAG, "[PM] Wait for device resume ACK timeout\n");
	}

	wait_ret = __mtk_pci_wait_resume_ack_sap(mtk_dev);
	if(!wait_ret) {
		MTK_ERR_LOG(TAG, "[PM] Wait for device resume ACK timeout-SAP\n");
	}

	/* Each HW final restore works */
	list_for_each_entry(entity, &mtk_dev->md_pm_entities, entity) {
		if(entity->resume) {
			ret = entity->resume(mtk_dev, entity->entity_param);
			if (ret) {
				key = entity->key;
				MTK_ERR_LOG(TAG, "[PM] Resume Entry Key %d  Failure ret %d\n", key, ret);
			}
		}
	}

	atomic_set(&mtk_dev->rgu_pci_irq_en, 1);
	mtk_pcie_set_int_mask(mtk_dev, SAP_RGU_INT, false);

	if (is_runtime)
		pm_runtime_mark_last_busy(&mtk_dev->pdev->dev);

__resume_complete:
	PCIE_CFG_CLR_L_STATES_DIS(
		mtk_dev->base_addr.pcie_mac_ireg_base,
		1<<PCIE_L1_DISABLE_BIT(0));
	atomic_inc(&mtk_dev->md_pm_resumed);
	MTK_INFO_LOG(TAG, "[PM] Resume Done\n");
	return ret;
}

#else /* !CONFIG_PM */
int mtk_pm_runtime_get(struct mtk_pci_dev *mtk_dev)
{
	return 0;
}

int mtk_pm_runtime_get_sync(struct mtk_pci_dev *mtk_dev)
{
	return 0;
}

int mtk_pm_runtime_put(struct mtk_pci_dev *mtk_dev)
{
	return 0;
}

int mtk_pm_runtime_put_sync(struct mtk_pci_dev *mtk_dev)
{
	return 0;
}
#endif /* !CONFIG_PM */

int mtk_pcie_bar_init(struct mtk_pci_dev *mtk_dev)
{
	/* BAR initialization */
	/* BAR0/1 */
	mtk_dev->resource_start[BAR_0_1] = pci_resource_start(mtk_dev->pdev, 0);
	mtk_dev->resource_len[BAR_0_1] = pci_resource_len(mtk_dev->pdev, 0);
	/* BAR2/3 */
	mtk_dev->resource_start[BAR_2_3] = pci_resource_start(mtk_dev->pdev, 2);
	mtk_dev->resource_len[BAR_2_3] = pci_resource_len(mtk_dev->pdev, 2);
	/* BAR4/5 */
	mtk_dev->resource_start[BAR_4_5] = pci_resource_start(mtk_dev->pdev, 4);
	mtk_dev->resource_len[BAR_4_5] = pci_resource_len(mtk_dev->pdev, 4);

	MTK_INFO_LOG(TAG, "BAR0/1 start : 0x%llx, len:  0x%llx, BAR2/3 start : 0x%llx, len:  0x%llx, BAR4/5 start : 0x%llx, len: 0x%llx\n",
		mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1],
		mtk_dev->resource_start[BAR_2_3],
		mtk_dev->resource_len[BAR_2_3],
		mtk_dev->resource_start[BAR_4_5],
		mtk_dev->resource_len[BAR_4_5]);

	/* Allocate BAR0/1 memory */
	if (!request_mem_region(mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1],
			mtk_dev->driver->description)) {
		MTK_ERR_LOG(TAG, "controller already in use\n");
		goto err_bar;
	}

	mtk_dev->base_addr.pcie_mac_ireg_base = mtk_dev->regs =
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,6,0)
		mtk_dev->mem[BAR_0_1] = ioremap(
#else	
		mtk_dev->mem[BAR_0_1] = ioremap_nocache(
#endif		
		mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1]);
	if (mtk_dev->regs == NULL) {
		MTK_ERR_LOG(TAG, "error mapping memory for BAR0/1\n");
		goto err_3;
	}

	/* Allocate BAR2/3 memory */
	if (!request_mem_region(mtk_dev->resource_start[BAR_2_3],
			mtk_dev->resource_len[BAR_2_3],
			mtk_dev->driver->description)) {
		MTK_ERR_LOG(TAG, "BAR2/3 controller already in use\n");
		goto err_4;
	}

	mtk_dev->mem[BAR_2_3] = ioremap(mtk_dev->resource_start[BAR_2_3],
		mtk_dev->resource_len[BAR_2_3]);
	mtk_dev->base_addr.pcie_ext_reg_base = (u64)mtk_dev->mem[BAR_2_3];
	if (mtk_dev->mem[BAR_2_3] == NULL) {
		MTK_ERR_LOG(TAG, "error mapping memory for BAR2/3\n");
		goto err_5;
	}
#if 0
	/* Allocate BAR4/5 memory */
	if (!request_mem_region(mtk_dev->resource_start[BAR_4_5],
			mtk_dev->resource_len[BAR_4_5],
			mtk_dev->driver->description)) {
		MTK_ERR_LOG(TAG, "BAR4/5 controller already in use\n");
		goto err_6;
	}
	mtk_dev->mem[BAR_4_5] = ioremap(mtk_dev->resource_start[BAR_4_5],
		mtk_dev->resource_len[BAR_4_5]);
	mtk_dev->base_addr.pcie_ext_mem_base = (u64)mtk_dev->mem[BAR_4_5];
	if (mtk_dev->mem[BAR_4_5] == NULL) {
		MTK_ERR_LOG(TAG, "error mapping memory for BAR4/5\n");
		goto err_7;
	}
#endif
	MTK_INFO_LOG(TAG, "start to print base address debug info of B(%d)D(%d)F(%d), pcie_mac_ireg_base : 0x%llx\npcie_ext_reg_base : 0x%llx\n",
		mtk_dev->pdev->bus->number, (mtk_dev->pdev->devfn)>>12,
		(mtk_dev->pdev->devfn)&0xfff,
		(u64)mtk_dev->base_addr.pcie_mac_ireg_base,
		(u64)mtk_dev->base_addr.pcie_ext_reg_base);
	return 0;
#if 0
err_7:
	release_mem_region(mtk_dev->resource_start[BAR_4_5],
		mtk_dev->resource_len[BAR_4_5]);
err_6:
	iounmap(mtk_dev->mem[BAR_2_3]);
#endif
err_5:
	release_mem_region(mtk_dev->resource_start[BAR_2_3],
		mtk_dev->resource_len[BAR_2_3]);
err_4:
	iounmap(mtk_dev->regs);
err_3:
	release_mem_region(mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1]);
err_bar:
	return -1;

}

void mtk_pcie_bar_deinit(struct mtk_pci_dev *mtk_dev)
{
	/* Release BAR0/1 memory */
	iounmap(mtk_dev->regs);
	release_mem_region(mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1]);
	/* Release BAR2/3 memory */
	iounmap(mtk_dev->mem[BAR_2_3]);
	release_mem_region(mtk_dev->resource_start[BAR_2_3],
		mtk_dev->resource_len[BAR_2_3]);
#if 0
	/* Release BAR4/5 memory */
	iounmap(mtk_dev->mem[BAR_4_5]);
	release_mem_region(mtk_dev->resource_start[BAR_4_5],
		mtk_dev->resource_len[BAR_4_5]);
#endif

}

void mtk_pcie_interrupt_reinit(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "MSIX interrupt interrupt number %d.\n",mtk_dev->irq_count);
	/*In case that MTK_PCIE_IRQ_COUNT varies from chips, note here to remind owner*/
	if(mtk_dev->irq_count >1){
		if(mtk_dev->irq_count <MTK_PCIE_IRQ_COUNT){
			MTK_INFO_LOG(TAG, "MSIX interrupt need reconfig MAC.\n");
			mtk_pcie_msix_ctrl_cfg( mtk_dev->base_addr.pcie_mac_ireg_base, mtk_dev->irq_count);
		}

		/*disable interrupt first and let the IPs enable them*/
		mtk_pcie_set_msix_mask_all(mtk_dev->base_addr.pcie_mac_ireg_base);

		/*L2 resume device will disable PCIe interrupt, and this function can re-enable PCIe interrupt
		* for L3, just do this with no effect.
		*/
		mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, TRUE);

		mtk_pcie_set_int_mask(mtk_dev, _MHCCIF_INT, FALSE);
	}
	else if(mtk_dev->irq_count ==1){/*Legacy interrupt*/
		/* Unmask interrupt except ATR doorbell */
		mtk_pcie_set_host_int_en_mask(mtk_dev->base_addr.pcie_mac_ireg_base,FALSE);

		/* Enable MHCCIF interrupt, next move is to receive MHCCIF interrupt */
		ISTATUS_HOST_SET_MHCCIF_INT(MTK_ISTATUS_HOST(mtk_dev->base_addr.pcie_mac_ireg_base), 0x1);
	}
}


static int mtk_pcie_reinit_pcie_only(struct mtk_pci_dev *mtk_dev)
{
	MTK_INFO_LOG(TAG, "start PCIe only reinit\n");

	if (pci_enable_device(mtk_dev->pdev) < 0) {
		MTK_ERR_LOG(TAG, "pci_enable_device return fail.\n");
		goto err_dev;
	}

	/* ATR table setting, MUST before ext driver init */
	mtk_pcie_atr_init(mtk_dev->pdev);

	/*interrupt re-init, in case this is MSIX interrupt with merged entries.*/
	mtk_pcie_interrupt_reinit(mtk_dev);

	/* Enable PCIE bus master */
	pci_set_master(mtk_dev->pdev);

	MTK_INFO_LOG(TAG, "end of PCIe only reinit\n");

	return 0;
err_dev:
	pci_disable_device(mtk_dev->pdev);
	return -1;

}

int mtk_pcie_reinit(struct mtk_pci_dev *mtk_dev)
{
	//int ret;
	MTK_INFO_LOG(TAG, "start PCIe reinit\n");

	if (pci_enable_device(mtk_dev->pdev) < 0) {
		MTK_ERR_LOG(TAG, "pci_enable_device return fail.\n");
		goto err_dev;
	}
#if 0
	mtk_pcie_bar_deinit(mtk_dev);

	ret = mtk_pcie_bar_init(mtk_dev);
	if(ret == -1)
		goto err_dev;
#endif

	/* ATR table setting, MUST before ext driver init */
	mtk_pcie_atr_init(mtk_dev->pdev);
	/* Initial infra ao base addr*/
	//mtk_pci_infracfg_ao_calc(mtk_dev);

	/*interrupt re-init, in case this is MSIX interrupt with merged entries.*/
	mtk_pcie_interrupt_reinit(mtk_dev);

	mhccif_init(mtk_dev);

	/* Enable PCIE bus master */
	pci_set_master(mtk_dev->pdev);

	mtk_pci_pm_reinit(mtk_dev);

	MTK_INFO_LOG(TAG, "end of PCIe reinit\n");
	return 0;
err_dev:
	pci_disable_device(mtk_dev->pdev);
	return -1;
}

#ifdef CONFIG_SUSPEND
static int mtk_pci_pm_suspend(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);
	return __mtk_pci_pm_suspend(mtk_dev, false);
}

static int __mtk_pci_pm_resume_noirq(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);
	if (mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "pci device error.\n ");
		return -1;
	}

	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, FALSE);

	return 0;
}

static int mtk_pci_pm_restore_noirq(struct device *dev)
{
	MTK_PCI_PM_FUNC_ENTER();
	__mtk_pci_pm_resume_noirq(dev);
	return 0;
}

static int mtk_pci_pm_suspend_noirq(struct device *dev)
{
	MTK_PCI_PM_FUNC_ENTER();
	return 0;
}

static int mtk_pci_pm_resume(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();

	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);
	if (mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "pci device error.\n ");
		return -1;
	}
	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, TRUE);

	return __mtk_pci_pm_resume(mtk_dev, false, false, false);
}

static int mtk_pci_pm_resume_noirq(struct device *dev)
{
	MTK_PCI_PM_FUNC_ENTER();
	__mtk_pci_pm_resume_noirq(dev);
	return 0;
}
#else /*!CONFIG_SUSPEND*/
#define mtk_pci_pm_suspend	NULL
#define mtk_pci_pm_suspend_noirq	NULL
#define mtk_pci_pm_resume	NULL
#define mtk_pci_pm_resume_noirq	NULL
#endif /*!CONFIG_SUSPEND*/

#ifdef CONFIG_HIBERNATE_CALLBACKS
static int mtk_pci_pm_freeze(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	return __mtk_pci_pm_suspend(mtk_dev, false);
}

static int mtk_pci_pm_poweroff(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	return __mtk_pci_pm_suspend(mtk_dev, false);
}

static int mtk_pci_pm_restore(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();

	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);
	if (mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "pci device error.\n ");
		return -1;
	}
	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, TRUE);

	return __mtk_pci_pm_resume(mtk_dev, false, false, true);
}

static int mtk_pci_pm_thaw(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	if (mtk_dev == NULL) {
		MTK_ERR_LOG(TAG, "pci device error.\n ");
		return -1;
	}
	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base, TRUE);

	return __mtk_pci_pm_resume(mtk_dev, true, false, false);
}
#else /*!#ifdef CONFIG_HIBERNATE_CALLBACKS*/
#define mtk_pci_pm_freeze	NULL
#define mtk_pci_pm_poweroff	NULL
#define mtk_pci_pm_restore	NULL
#define mtk_pci_pm_thaw	NULL
#endif/*!#ifdef CONFIG_HIBERNATE_CALLBACKS*/

#ifdef CONFIG_PM
static int mtk_pci_pm_runtime_suspend(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	return __mtk_pci_pm_suspend(mtk_dev, true);
}

static int mtk_pci_pm_runtime_resume(struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct pci_dev *pdev = to_pci_dev(dev);

	MTK_PCI_PM_FUNC_ENTER();

	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	//Change for the D3/L2 exception case in RVP 
	if(rpm_resume_set_powerstate) {
		pdev->current_state = PCI_D3cold;
		pci_set_power_state(pdev, 0);
		MTK_INFO_LOG(TAG,"Set power state to D0 in rpm resume flow\n");
	}

	return __mtk_pci_pm_resume(mtk_dev, false, true, false);
}

static int mtk_pci_pm_runtime_idle(struct device *dev)
{

	MTK_INFO_LOG(TAG,
		"Schedule Runtime Suspend after %d seconds\n",
		runtime_idle_delay);
	pm_schedule_suspend(dev, runtime_idle_delay * MSEC_PER_SEC);

	return -EBUSY;
}

static const struct dev_pm_ops mtk_pci_pm_ops = {
	.suspend = mtk_pci_pm_suspend,
	.suspend_noirq = mtk_pci_pm_suspend_noirq,
	.resume = mtk_pci_pm_resume,
	.resume_noirq = mtk_pci_pm_resume_noirq,
	.freeze = mtk_pci_pm_freeze,
	.freeze_noirq = mtk_pci_pm_suspend_noirq,
	.thaw = mtk_pci_pm_thaw,
	.poweroff = mtk_pci_pm_poweroff,
	.restore = mtk_pci_pm_restore,
	.restore_noirq = mtk_pci_pm_restore_noirq,
	.runtime_suspend = mtk_pci_pm_runtime_suspend,
	.runtime_resume = mtk_pci_pm_runtime_resume,
	.runtime_idle = mtk_pci_pm_runtime_idle,
};

#define MTK_PCI_PM_OPS_PTR	(&mtk_pci_pm_ops)
#else /* !CONFIG_PM */
#define mtk_pci_pm_runtime_suspend	NULL
#define mtk_pci_pm_runtime_resume	NULL
#define mtk_pci_pm_runtime_idle	NULL
#define MTK_PCI_PM_OPS_PTR	NULL
#endif /* !CONFIG_PM */

static pci_ers_result_t mtk_pci_error_detected(
	struct pci_dev *pdev, pci_channel_state_t state)
{
	MTK_PCI_PM_FUNC_ENTER();

	return PCI_ERS_RESULT_NEED_RESET;
}



static void mtk_pci_reset_prepare(struct pci_dev *pdev)
{
	MTK_PCI_ERS_FUNC_ENTER();

}

static void mtk_pci_reset_done(struct pci_dev *pdev)
{
	MTK_PCI_ERS_FUNC_ENTER();

}


static pci_ers_result_t mtk_pci_slot_reset(struct pci_dev *pdev)
{
	MTK_PCI_ERS_FUNC_ENTER();

	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t mtk_pcie_mmio_enabled(struct pci_dev *pdev)
{
	MTK_PCI_ERS_FUNC_ENTER();

	return PCI_ERS_RESULT_NEED_RESET;
}

static void mtk_pci_resume(struct pci_dev *pdev)
{
	MTK_PCI_ERS_FUNC_ENTER();

}

static const struct pci_error_handlers mtk_pci_err_handler = {
	.error_detected = mtk_pci_error_detected,
	.slot_reset = mtk_pci_slot_reset,

	.reset_prepare = mtk_pci_reset_prepare,
	.reset_done = mtk_pci_reset_done,

	.mmio_enabled = mtk_pcie_mmio_enabled,
	.resume = mtk_pci_resume,
};


/* pci driver glue; this is a "new style" PCI driver module */
static struct pci_driver mtk_pci_driver = {
	.name =     (char *) MTK_PCI_DRIVER_NAME,
	.id_table = pci_ids,

	.probe =    mtk_pci_probe,

	.driver.pm = MTK_PCI_PM_OPS_PTR,
	.err_handler = &mtk_pci_err_handler,

	.remove =   mtk_pci_remove,
	.shutdown =     mtk_pci_shutdown,
};

struct mtk_pci_dev *mtk_create_dev(struct mtk_pci_driver *driver,
		struct device *dev)
{
	struct mtk_pci_dev *mtk_dev;

	mtk_dev = kzalloc(sizeof(*mtk_dev), GFP_KERNEL);
	if (!mtk_dev)
		return NULL;

	mtk_dev->driver = driver;
	mtk_dev->mtk_pcie_probe_done = FALSE;   /*init this value*/
	mtk_dev->mhccif_init_done = FALSE;
	dev_set_drvdata(dev, mtk_dev);

	return mtk_dev;
}

static inline void mtk_pci_infracfg_ao_calc(struct mtk_pci_dev *mtk_dev)
{
    mtk_dev->base_addr.infracfg_ao_dev = (u64)INFRACFG_AO_DEV_CHIP;
    mtk_dev->base_addr.infracfg_ao_base =
        mtk_dev->base_addr.pcie_ext_reg_base +mtk_dev->base_addr.infracfg_ao_dev - mtk_dev->base_addr.pcie_dev_reg_trsl_addr;
    MTK_INFO_LOG(TAG, "pcie_ext_reg_base 0x%llx, infracfg_ao_dev 0x%llx, pcie_dev_reg_trsl_addr 0x%llx\n", mtk_dev->base_addr.pcie_ext_reg_base, mtk_dev->base_addr.infracfg_ao_dev,mtk_dev->base_addr.pcie_dev_reg_trsl_addr );

}

static void mtk_pci_bridge_configure(struct mtk_pci_dev *mtk_dev, struct pci_dev *dev)
{
	struct pci_dev *bridge;
	int dpc_cap;
	u32 slot_cap;
	u16 ctl, cap;

	//check hotplug capability
	bridge = pci_upstream_bridge(dev);
	if(!bridge) {
		MTK_ERR_LOG(TAG, "Bridge is not found \n");
		return;
	}

	pcie_capability_read_dword(bridge, PCI_EXP_SLTCAP, &slot_cap);
	if(slot_cap & PCI_EXP_SLTCAP_HPC) {
		mtk_dev->hp_enable = TRUE;
		MTK_INFO_LOG(TAG, "Slot has hotplug capability\n");
	}
	MTK_INFO_LOG(TAG, "Slot capability %x \n", slot_cap);
	MTK_INFO_LOG(TAG, "Self [Bus:%x Devfn:%x Vendor:%x Device:%x] \n", dev->bus->number,dev->devfn, dev->vendor, dev->device);
	MTK_INFO_LOG(TAG, "Parent [Bus:%x Devfn:%x Vendor:%x Device:%x] \n", bridge->bus->number, bridge->devfn, bridge->vendor, bridge->device);

	//disable dpc capability
	dpc_cap = pci_find_ext_capability(bridge, PCI_EXT_CAP_ID_DPC);
	if (dpc_cap != 0) {
		pci_read_config_word(bridge, dpc_cap + PCI_EXP_DPC_CAP, &cap);
		pci_read_config_word(bridge, dpc_cap + PCI_EXP_DPC_CTL, &ctl);
		MTK_INFO_LOG(TAG, "Bridge dpc pos %x cap %x ctl %x \n", dpc_cap, cap, ctl);
		ctl &= ~(PCI_EXP_DPC_CTL_INT_EN|0x3);
		pci_write_config_word(bridge, dpc_cap + PCI_EXP_DPC_CTL, ctl);
	} else {
		ctl = ~0;
		cap = ~0;
	}
	MTK_INFO_LOG(TAG, "Bridge dpc after set pos %x cap %x ctl %x \n", dpc_cap, cap, ctl);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,18,0)	
	//re-configure bridge ltr to satisfy remove-rescan case
#ifdef CONFIG_PCIEASPM
	if (bridge->ltr_path == 1) {
		pcie_capability_read_word(bridge, PCI_EXP_DEVCTL2, &cap);
		if(!(cap&PCI_EXP_DEVCTL2_LTR_EN))
			pcie_capability_set_word(bridge, PCI_EXP_DEVCTL2, PCI_EXP_DEVCTL2_LTR_EN);
	}
	MTK_INFO_LOG(TAG, "Bridge LTR_Path %x/%x cap %x flag %x\n", bridge->ltr_path, dev->ltr_path, cap, cap&PCI_EXP_DEVCTL2_LTR_EN);
#endif
#endif
}

static void mtk_pci_configure_ltr(struct pci_dev *dev)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,18,0)		
	//re-configure device ltr to satisfy remove-rescan case
#ifdef CONFIG_PCIEASPM
	if (dev->ltr_path == 1) {
		pcie_capability_clear_word(dev, PCI_EXP_DEVCTL2, PCI_EXP_DEVCTL2_LTR_EN);
		pcie_capability_set_word(dev, PCI_EXP_DEVCTL2, PCI_EXP_DEVCTL2_LTR_EN);
	}
#endif
#endif
}

int mtk_pci_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
	struct mtk_pci_driver   *driver;
	struct mtk_pci_dev      *mtk_dev;
	char strwqbdf[128] = "";
	char strwq[] = MTK_PCI_WQ_DESCR;
	int retval,i;
	u16 old_cmd;

	driver = (struct mtk_pci_driver *)id->driver_data;
	if (!driver)
		goto err_drv;

	mtk_dev = mtk_create_dev(driver, &dev->dev);
	if (!mtk_dev) {
		MTK_ERR_LOG(TAG, "mtk_create_dev return\n");
		goto err_context;
	}

	//check bridge configure
	mtk_pci_bridge_configure(mtk_dev, dev);

	if (pci_enable_device(dev) < 0) {
		MTK_ERR_LOG(TAG, "pci_enable_device return fail.\n");
		goto err_dev;
	}
	retval = pci_set_dma_mask(dev, DMA_BIT_MASK(64));
	if (retval) {
		MTK_ERR_LOG(TAG,"Set DMA Mask Error %d\n", retval);
		goto err_dev;
	}

	retval = pci_set_consistent_dma_mask(dev, DMA_BIT_MASK(64));
	if (retval) {
		MTK_ERR_LOG(TAG,"Set Coherent DMA Mask Error %d\n", retval);
		goto err_dev;
	}

	dev->dma_mask = DMA_BIT_MASK(64);

	MTK_INFO_LOG(TAG, "mtk PCI Probe, Device ID= %x,msix_cap = %x\n",
		id->device, dev->msix_cap);
#ifdef CONFIG_PM
	MTK_INFO_LOG("PM", "Before Probe usage_count=%d",
		atomic_read(&(dev->dev.power.usage_count)));
#endif
	dev->current_state = PCI_D0;

	if (!dev->irq) {
		MTK_ERR_LOG(TAG, "dev->irq return\n");
		goto err_dev;
	}

	mtk_dev->irq = dev->irq;
	mtk_dev->pdev = dev;
	MTK_INFO_LOG(TAG, "irq : %d\n", mtk_dev->irq);

        if(id->device == MTK_PCI_DEVICE_ID_M7X || id->device == MTK_PCI_DEVICE_ID_M8X75)
            mtk_dev->pm_enabled = 1;
        else
            mtk_dev->pm_enabled = 0;

        if(!pm_suspend_enable)
            mtk_dev->pm_enabled = 0;

	retval = mtk_pcie_bar_init(mtk_dev);
	if(retval == -1)
		goto err_dev;
	mtk_pci_pm_init(mtk_dev);

	/* Initial lock */
	spin_lock_init(&mtk_dev->lock);

	sprintf(strwqbdf, "%s(bdf:%d-%x-%x)", strwq, mtk_dev->pdev->bus->number,
		(mtk_dev->pdev->devfn)>>12, (mtk_dev->pdev->devfn)&0xfff);
	MTK_INFO_LOG(TAG, "devfn is %x, strwqbdf is %s.\n",
		(mtk_dev->pdev->devfn), strwqbdf);
	/* Create irq service queue */
	mtk_dev->pcie_isr_wq = create_singlethread_workqueue(strwqbdf);
	if (!mtk_dev->pcie_isr_wq) {
		MTK_ERR_LOG(TAG, "Failed to create workqueue: %s\n", strwqbdf);
		retval = -1;
		goto fail_wq_create;
	}


	/*disable interrupt first to avoid unexpected MSIX interrupt*/
	mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base,FALSE);

	if (dev->msix_cap) {
		retval = mtk_setup_msix_merge(mtk_dev,MTK_PCIE_IRQ_COUNT);
		if (retval) {/*when msi-x requesting fail, use INTX.*/
			retval = mtk_pci_request_irq(dev, 1);
			if (retval)
				goto fail_wq_create;

		}

		/*disable interrupt first and let the IPs enable them when they are ready*/
		for(i=PCIE_EXT_INT_OFFSET;i<PCIE_EXT_INT_OFFSET+_END_EXT_INT;i++){
			mtk_pcie_set_msix_mask(mtk_dev->base_addr.pcie_mac_ireg_base,i);
		}
	} else { /*directly INTX*/
		retval = mtk_pci_request_irq(dev, 1);
		if (retval)
			goto fail_wq_create;

	}

	/* ATR table setting */
	/* MUST before ext driver init*/
	mtk_pcie_atr_init(dev);
	/* Initial infra ao base addr*/
	mtk_pci_infracfg_ao_calc(mtk_dev);

	/* Call ext driver init callback to init ext driver*/
	mtk_ext_driver_init(dev);
	/* Initializa work queue */
	INIT_WORK(&mtk_dev->service_task, mtk_pcie_isr_service_task);

	retval = mtk_pcie_attr_init(dev);
	if(retval)
	    goto err_irq;

    retval = ccci_modem_init(mtk_dev);
    if (retval){
        MTK_ERR_LOG(TAG, "register ccci device fail\n");
        goto err_irq;
    }
    mtk_rescan_done();

	if(mtk_dev->irq_count>1)  /*MSIX should enable mhccif*/
		mtk_pcie_set_ext_int_mask(mtk_dev,_MHCCIF_INT, FALSE);
	else/* Unmask interrupt except ATR doorbell */
		mtk_pcie_set_host_int_en_mask(mtk_dev->base_addr.pcie_mac_ireg_base,FALSE);

    /* Enable interrupt */
    mtk_pcie_intr_enable(mtk_dev->base_addr.pcie_mac_ireg_base,TRUE);

	mb();


	pci_read_config_word(dev, PCI_COMMAND, &old_cmd);
	MTK_INFO_LOG(TAG, "PCI_COMMAND %x\n",old_cmd);
	/* Enable PCIE bus master */
	pci_set_master(dev);
	if(!mtk_dev->hp_enable) {
		pci_ignore_hotplug(dev);
		MTK_INFO_LOG(TAG, "Ignore Hp event\n");
	}

	mtk_pci_configure_ltr(dev);

	mtk_dev->mtk_pcie_probe_done = TRUE;

	MTK_INFO_LOG(TAG, "MTK PCIE probe done.\n");
	return 0;
err_irq:
	mtk_free_irq(dev);
fail_wq_create:
	destroy_workqueue(mtk_dev->pcie_isr_wq);
	mtk_pcie_bar_deinit(mtk_dev);
err_dev:
	pci_disable_device(dev);
err_context:
	kfree(mtk_dev);
err_drv:
	return -1;
}

void mtk_pci_remove(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;
	struct device *pdev;

	MTK_INFO_LOG(TAG, "MTK PCI remove device 0x%x.\n", dev->device);

	pdev = &dev->dev;
	mtk_dev = pci_get_drvdata(dev);
	if (!mtk_dev)
		return;
	remove_driver_f(mtk_dev);
	remove_driver_r(mtk_dev);
	ccci_modem_exit(mtk_dev);
	mtk_pci_pm_deinit(mtk_dev);
	mtk_pcie_attr_remove(dev);

	/* Deinit ext drivers */
	mtk_ext_driver_deinit(dev);
	MTK_INFO_LOG(TAG, "[Remove Step] Pre free-irq\n");
	mtk_free_irq(dev);
	MTK_INFO_LOG(TAG, "[Remove Step] Pre iounmap 0_1\n");

	/* Release BAR0/1 memory */
	iounmap(mtk_dev->regs);
	MTK_INFO_LOG(TAG, "[Remove Step] Pre release mem_region 0_1\n");
	release_mem_region(mtk_dev->resource_start[BAR_0_1],
		mtk_dev->resource_len[BAR_0_1]);
	/* Release BAR0/1 memory */

	MTK_INFO_LOG(TAG, "[Remove Step] Pre iounmap 2_3\n");
	iounmap(mtk_dev->mem[BAR_2_3]);
	MTK_INFO_LOG(TAG, "[Remove Step] Pre release mem_region 2_3\n");
	release_mem_region(mtk_dev->resource_start[BAR_2_3],
		mtk_dev->resource_len[BAR_2_3]);
#if 0
	/* Release BAR0/1 memory */
	iounmap(mtk_dev->mem[BAR_4_5]);
	release_mem_region(mtk_dev->resource_start[BAR_4_5],
		mtk_dev->resource_len[BAR_4_5]);
#endif
	MTK_INFO_LOG(TAG, "[Remove Step] Pre cancel work\n");
	cancel_work_sync(&mtk_dev->service_task);
	MTK_INFO_LOG(TAG, "[Remove Step] Pre destroy workqueue\n");
	destroy_workqueue(mtk_dev->pcie_isr_wq);
	mtk_dev->pcie_isr_wq = NULL;
	//mtk_dev->mtk_ext_info.dev = NULL;
	//kfree(mtk_dev->strirqbdf);
	//mtk_dev->strirqbdf = NULL;
	MTK_INFO_LOG(TAG, "[Remove Step] Pre kfree\n");
	kfree(mtk_dev);
	mtk_dev =  NULL;
	MTK_INFO_LOG(TAG, "[Remove Step] Pre disable device\n");
	pci_disable_device(dev);
	/*no need to set probe done flag because mtk_dev is freed.*/
	MTK_INFO_LOG(TAG, "MTK PCI remove done.\n");
}

#ifdef CONFIG_PM
void mtk_pci_shutdown(struct pci_dev *pdev)
{
	struct mtk_pci_dev *mtk_dev;

	MTK_PCI_PM_FUNC_ENTER();
	mtk_dev = (struct mtk_pci_dev *) pci_get_drvdata(pdev);

	__mtk_pci_pm_suspend(mtk_dev, false);
}
#else /*!CONFIG_PM*/
void mtk_pci_shutdown(struct pci_dev *pdev)
{
	MTK_PCI_PM_FUNC_ENTER();
}

#endif/*!CONFIG_PM*/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,3,0)
static int mtk_always_match(struct device *dev, const void *data)
#else
static int mtk_always_match(struct device *dev, void *data)
#endif
{
	MTK_INFO_LOG(TAG, "MTK match function, always match.\n");
	return 1;
}
int mtk_register_pci(void)
{
	return pci_register_driver(&mtk_pci_driver);
}

void mtk_unregister_pci(void)
{
	struct device *dev;
	int remove_flag=0;
	dev = driver_find_device(&mtk_pci_driver.driver,NULL,NULL,mtk_always_match);
	if(dev != NULL)  /*dev pointer maybe modified by bus, so judge it first*/
	{
		MTK_INFO_LOG(TAG, "unregister MTK PCIe driver while device is still exist.\n");
		put_device(dev);
		remove_flag=1;
	}
	else
		MTK_INFO_LOG(TAG, "unregister MTK PCIe driver with no device exist.\n");

	pci_lock_rescan_remove();
	pci_unregister_driver(&mtk_pci_driver);
	pci_unlock_rescan_remove();

	if (remove_flag) {
		MTK_INFO_LOG(TAG,"start remove MTK PCI device\n");
		pci_stop_and_remove_bus_device_locked(to_pci_dev(dev));
	}
}

struct pci_driver *mtk_pci_get_drv(void)
{
	return &mtk_pci_driver;
}
#if 0 //no use warning
static int mtk_pci_dev_always_match(struct device *dev,void *data)
{
    return 1;
}
#endif

static int mtk_pci_request_irq(struct pci_dev *dev, int irq_count)
{
	int ret;
	struct mtk_pci_dev *mtk_dev;
	int i;

	mtk_dev = pci_get_drvdata(dev);

	if (irq_count == 1) {
		/*please do not modify this string content without reviewing.*/
		sprintf(mtk_dev->strirqbdf, "%s(bdf:%d-%x-%x)",
			mtk_dev->driver->irq_descr,
			mtk_dev->pdev->bus->number,
			(mtk_dev->pdev->devfn)>>12,
			(mtk_dev->pdev->devfn)&0xfff);
		/* Inilitialize ISR */
		ret = devm_request_irq(&dev->dev, dev->irq,
			mtk_dev->driver->isr, IRQF_SHARED,
					mtk_dev->strirqbdf, mtk_dev);
		if (ret != 0) {
			MTK_ERR_LOG(TAG,
				"failed to request_irq %d: %d\n",
				dev->irq, ret);
			return ret;
		}
	} else {
		mtk_dev->msix_res = mtk_pci_request_isr_table(irq_count);
		if (mtk_dev->msix_res == NULL) {
			MTK_ERR_LOG(TAG,
				"failed to alloc memory of irq_count: %d\n",
				irq_count);
			return 1;
		}

		for (i = 0; i < irq_count; i++) {
			mtk_dev->msix_res[i].mtk_dev = mtk_dev;

			mtk_dev->msix_res[i].irq = pci_irq_vector(dev, i);
			sprintf(mtk_dev->msix_res[i].irq_descr,
				"%s(intr_num:%d,bdf:%d-%x-%x)",
				MTK_PCI_MSIX_IRQ_DESCR,
				i, mtk_dev->pdev->bus->number,
				(mtk_dev->pdev->devfn)>>12,
				(mtk_dev->pdev->devfn)&0xfff);
			ret = devm_request_irq(
				&dev->dev, pci_irq_vector(dev, i),
				mtk_dev->msix_res[i].isr,
				IRQF_SHARED, mtk_dev->msix_res[i].irq_descr,
				&mtk_dev->msix_res[i]);

			if (ret) {
				MTK_ERR_LOG(TAG,
					"failed to request_irq %d: %d\n",
					pci_irq_vector(dev, i), ret);
				for (i--; i >= 0; i--) {
					if (mtk_dev->msix_res[i].isr) {
						devm_free_irq(&dev->dev,
							pci_irq_vector(dev, i),
							&mtk_dev->msix_res[i]);
					}
				}

				return ret;
			}
		}
	}

	mtk_dev->irq = dev->irq;
	mtk_dev->irq_count = irq_count;

	return 0;
}

/*
 * Free IRQs
 * free all IRQs request
 */
static void mtk_free_irq(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;
	int i;

	mtk_dev = pci_get_drvdata(dev);

	if (mtk_dev->irq_count == 1)
		devm_free_irq(&dev->dev, dev->irq, mtk_dev);
	else {
		for (i = 0; i < mtk_dev->irq_count; i++) {
			if (mtk_dev->msix_res[i].isr) {
				mtk_dev->msix_res[i].irq = 0;
				devm_free_irq(&dev->dev,
					pci_irq_vector(dev, i),
					&mtk_dev->msix_res[i]);
			}
		}
		kfree(mtk_dev->msix_res);
	}

	mtk_dev->irq = 0;
	mtk_dev->irq_count = 0;
	MTK_INFO_LOG(TAG, "[Remove Step] Pre disable msix\n");

	if (dev->msi_enabled)
		pci_disable_msi(dev);

	if (dev->msix_enabled)
		pci_disable_msix(dev);


}

/*
 * Set up MSI-X
 */
static int mtk_setup_msix(struct pci_dev *dev, int irq_count)
{
	int ret;

	ret = pci_alloc_irq_vectors(dev, MTK_PCIE_IRQ_MSIX_MIN_COUNT, irq_count, PCI_IRQ_MSIX);
	if (ret <= 0) {
		MTK_ERR_LOG(TAG, "failed to allocate MSI-X entry, errno %d\n",ret);
		return ret;
	}
	else if (irq_count > ret) {
		MTK_ERR_LOG(TAG, "MSI-X entry not enough, need %d, get %d.\n",
			irq_count, ret);
		pci_free_irq_vectors(dev);
		return ret;
	}

	ret = mtk_pci_request_irq(dev, irq_count);
	if (ret) {
		pci_disable_msix(dev);
		return ret;
	}

	return irq_count;
}


static int mtk_calc_2power_msix_count(int given_value)
{
	int new_value = 0;

	new_value = 1<<(fls(given_value)-1);
	MTK_INFO_LOG(TAG,
		"MTK device MSIX entry given_value %d, new_value %d .\n",
		given_value, new_value);
	return new_value;
}
/*
 * MSI-X merge set
 */
int mtk_setup_msix_merge(struct mtk_pci_dev *mtk_dev,int msix_count)
{
	int ret;
	int msix_retry = 0;
	int temp_msix_count;

	if (msix_count == 0) {

		MTK_INFO_LOG(TAG, "Disable MSIX\n");

		if (mtk_dev->msix_merged) {
			//Disable MSIX merge
			mtk_pcie_msix_ctrl_cfg(
				mtk_dev->base_addr.pcie_mac_ireg_base, 0);
		mtk_dev->msix_merged = 0;
		}

	} else {
		temp_msix_count = msix_count;
		do {
			if (temp_msix_count > MTK_PCIE_IRQ_COUNT ||
				temp_msix_count == 1) {
				MTK_ERR_LOG(TAG,
					"Max supported MSIX is between 2 to %d\n",
					MTK_PCIE_IRQ_COUNT);
				return 1;
			}

			if ((temp_msix_count & (temp_msix_count - 1)) != 0) {
				MTK_ERR_LOG(TAG,
					"MSIX merge only allow power of 2 setting (%d is unsupported)\n",
					msix_count);
				return 1;
			}

			ret = mtk_setup_msix(mtk_dev->pdev, temp_msix_count);
			if ((ret <= 1)) {
				MTK_ERR_LOG(TAG,"MSIX allocate failed.\n");
				mtk_free_irq(mtk_dev->pdev);
				return 1;
			} else if ((ret > 1) && (ret < temp_msix_count)) {
				MTK_ERR_LOG(TAG,
					"msix original want %d,actual want %d, but get %d, need retry.\n",
					msix_count, temp_msix_count, ret);
				msix_retry = 1;
				temp_msix_count =
					mtk_calc_2power_msix_count(ret);
				MTK_ERR_LOG(TAG,
					"retry with %d .\n", temp_msix_count);
			} else if(ret > temp_msix_count){
				MTK_ERR_LOG(TAG,
					"Fatal error: Actual MSIX entry %d  is more than we requested %d.\n",
					ret,temp_msix_count);
				mtk_free_irq(mtk_dev->pdev);
				return 1;
			}
			else{
				MTK_INFO_LOG(TAG,
					"msix original want %d,actual want %d,  success apply.\n",
					msix_count, temp_msix_count);
				msix_retry = 0;
			}
		} while (msix_retry);

		if (temp_msix_count != MTK_PCIE_IRQ_COUNT) {
			// Set MSIX merge config. (0x3ec)
			mtk_pcie_msix_ctrl_cfg(
				mtk_dev->base_addr.pcie_mac_ireg_base,
				temp_msix_count);
			mtk_dev->msix_merged = 1;
		}
	}

	return 0;
}



static void mtk_ext_driver_init(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;
	int ret;

	mtk_dev = pci_get_drvdata(dev);

	/* Inilitialize EXT int callback */
	mtk_ext_driver_init_int_callback(dev);

	MTK_INFO_LOG(TAG, "Call ext init functions\n");
#if 0
	mtk_dev->mtk_ext_info.dev = &dev->dev;
	mtk_dev->mtk_ext_info.reg_base = mtk_dev->base_addr.pcie_ext_reg_base;
	mtk_dev->mtk_ext_info.mem_base = mtk_dev->base_addr.pcie_ext_mem_base;
	mtk_dev->mtk_ext_info.reg_dev_trsl_addr =
		mtk_dev->base_addr.pcie_dev_reg_trsl_addr;
#endif
	/*do mhccif init*/
	ret = mhccif_init((void *)mtk_dev);
	if (ret)
		MTK_ERR_LOG(TAG, "mhccif init funtion fail\n");


}

static void mtk_ext_driver_deinit(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;
	int ret;

	mtk_dev = pci_get_drvdata(dev);

	MTK_INFO_LOG(TAG, "Call ext deinit functions\n");

	ret = mhccif_deinit(mtk_dev);
	if (ret)
		MTK_ERR_LOG(TAG, "mhccif deinit funtion fail\n");

}

static void mtk_ext_driver_init_int_callback(struct pci_dev *dev)
{
	struct mtk_pci_dev *mtk_dev;

	int i;

	mtk_dev = pci_get_drvdata(dev);

	MTK_DEBUG_LOG(TAG, "Init interrupt callback functions\n");

	for (i = 0; i < PCI_EXT_INTR_NUM; i++) {
		mtk_dev->intr_callback[i] = NULL;
		mtk_dev->mhccif_callback[i] = NULL;
		mtk_dev->mhccif_bitmask[i] = 0;
	}
}
