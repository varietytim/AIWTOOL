/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __CHIP_DEF__
#define __CHIP_DEF__

/*================================ 4d75 ======================================*/


/* PCIE ID */
#define PCI_CLASS_MTK_DEVICE_CHIP             0x0D4000	//TODO: update
#define PCI_VENDOR_ID_TEST_CHIP                 0x14C3
#define PCI_DEVICE_ID_TEST_CHIP                  0x4D75

/* Reg base */
#define INFRACFG_AO_DEV_CHIP             0x10001000

/* ATR setting */
#define PCIE_REG_TRSL_ADDR_CHIP	   0x10000000
#define PCIE_REG_SIZE_CHIP			   0x00400000 //4MB

/* AT ATR setting */
#define AT_REG_TRSL_ADDR_CHIP           0x10020000 //only cover MHCCIF range

/* IP base */
#define MHCCIF_RC_DEV_BASE_CHIP      0x10024000
#define MHCCIF_EP_DEV_BASE_CHIP      0x10025000


#define EXP_PCIE_IF_CONF         0x11460181
#ifdef FPGA
#define EXP_PCIE_BASIC_CONF   0x03110303
#else
#define EXP_PCIE_BASIC_CONF   0x03110703
#endif
#define EXP_AXI_MST0_CONF      0x11454246
#define EXP_AXI_SLV0_CONF      0x55254243
#define EXP_AXI_SLV1_CONF      0x55254253
#define EXP_AXI_SLV2_CONF      0x55234263
#define EXP_BAR0	0xC
#define EXP_BAR2	0x4
#define EXP_BAR4	0xC
#define EXP_BAR0_SIZE	0x8000
#define EXP_BAR2_SIZE	0x800000
#define EXP_BAR4_SIZE	0x800000

#define PCIE_MD_REMAP_SET 1
#define PCIE_MD_REMAP_START 0
#define PCIE_MD_REMAP_END   PCIE_MD_REMAP_SET
#define PCIE_MD_REMAP_SIZE_PER_SET  0x400000

typedef enum _pcie_int {
	_DPMAIF_INT = 0,
	_CLDMA0_INT,
	_CLDMA1_INT,
	_CLDMA2_INT,
	_MHCCIF_INT,
	_DPMAIF2_INT,
	_SAP_RGU_INT,
	_CLDMA3_INT,
	_END_EXT_INT = _CLDMA3_INT,
	_A_ATR_INT,
	_P_ATR_INT,
	_END_INT = _P_ATR_INT,
} _pcie_int_e;

typedef enum _pcie_ext_int {
	DPMAIF_INT = 0,
	CLDMA0_INT,
	CLDMA1_INT,
	CLDMA2_INT,
	MHCCIF_INT,
	DPMAIF2_INT,
	SAP_RGU_INT,
	CLDMA3_INT,
	END_INT = CLDMA3_INT,
} pcie_ext_int_e;


#endif /*__CHIP_DEF__*/
