// SPDX-License-Identifier: BSD-3-Clause-Clear
/*
 * Copyright (c) 2020, MediaTek Inc.
 */


#include <linux/pci.h>
#include <linux/rwsem.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/spinlock_types.h>
#include <linux/spinlock.h>
#include <linux/types.h>

#include "mtk-pcie-dbg.h"
#include "mtk-pci.h"
#include "mtk-pci-ext.h"
#include "mtk-pcie.h"
#include "mtk-pcie-mac.h"
#include "PCIE_MAC_IREG_c_header.h"

/*
 * Macro Definition
 */

/*
 * Data Definition
 */

/*
 * Function Definition
 */
void mtk_pci_msix_dump(struct mtk_pci_dev *mtk_dev)
{
	u8 *base;
	u32 offset;
	base = (char *)mtk_dev->base_addr.pcie_mac_ireg_base;
	
	REG_IO_WRITE32(base+0x164,0x0000CFCE);
	REG_IO_WRITE32(base+0x168,0x99990100);
	
	offset = 0x20;
	MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	
	for(offset=0x2C; offset<=0x30; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}	
	for(offset=0x1A0; offset<=0x1B0; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}		
	for(offset=0xF00; offset<=0x1010; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}				
	for(offset=0x10D0; offset<=0x10E0; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}		
	for(offset=0x3100; offset<=0x3110; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}		
	for(offset=0x4000; offset<=0x4200; offset+=4)
	{
		MTK_INFO_LOG(TAG, "Offset 0x%04x, Data:0x%08x\n", offset, REG_IO_READ32((base+offset)));
	}	
}


int mtk_pcie_register_ext_int_callback(struct mtk_pci_dev *mtk_dev,pcie_ext_int_e ext_int,
	mtk_pci_intr_callback intr_callback, void *param)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d input NULL pointer mtk_dev\n", ext_int);
		return -1;
	}

	if (ext_int > END_INT) {
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d does not exist\n", ext_int);
		return -1;
	}
	if (intr_callback == NULL) {
		MTK_ERR_LOG(TAG,
			"Error : Ext interrupt ID %d register a callback with NULl pointer\n",
			ext_int);
		return -1;
	}
	MTK_DEBUG_LOG(TAG, "Register ext interrupt ID %d callback 0x%p\n",
		ext_int, intr_callback);

	mtk_dev->intr_callback[ext_int] = intr_callback;
	mtk_dev->callback_param[ext_int] = param;

	return 0;
}



/*
 * Function Definition
 */
int mtk_pcie_register_mhccif_ext_int_callback(struct mtk_pci_dev *mtk_dev,
	pcie_ext_int_e ext_int, UINT32 bitmask,
	mtk_pci_sw_intr_callback intr_callback, void *param)
{
	int i;
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d input NULL pointer mtk_dev\n", ext_int);
		return -1;
	}

	/*mhccif can't register to itself*/
	if (ext_int == MHCCIF_INT) {
		MTK_ERR_LOG(TAG,
			"Error : input ilegal, cannot input MHCCIF_INT\n");
		return -1;
	}

	if (ext_int > END_INT) {
		MTK_ERR_LOG(TAG, "Error : Ext interrupt ID %d does not exist\n",
			ext_int);
		return -1;
	}
	if (bitmask == 0) {
		MTK_ERR_LOG(TAG,
			"Error : Ext interrupt ID %d register a bitmask 0\n",
			ext_int);
		return -1;
	}
	if (intr_callback == NULL) {
		MTK_ERR_LOG(TAG,
			"Error : Ext interrupt ID %d register a callback with NULl pointer\n",
			ext_int);
		return -1;
	}
	for (i = 0; i <= END_INT; i++) {
		if ((mtk_dev->mhccif_bitmask[i])&bitmask) {
			MTK_ERR_LOG(TAG,
				"Error !Register mhccif callback fail, register ext num %d bitmask(%d) overlap with exists ext num %d(%d)\n",
				ext_int, bitmask, i,
				mtk_dev->mhccif_bitmask[i]);
			return -1;
			}
	}
	MTK_DEBUG_LOG(TAG, "ID %d, bitmask %d\n", ext_int, bitmask);
	mtk_dev->mhccif_callback[ext_int] = intr_callback;
	mtk_dev->mhccif_bitmask[ext_int] = bitmask;
	mtk_dev->mhccif_callback_param[ext_int] = param;
	return 0;
}


int mtk_pcie_register_event_callback(struct mtk_pci_dev *mtk_dev,
	mtk_pci_event_callback event_callback,void *param)

{
	if(event_callback == NULL){
		MTK_ERR_LOG(TAG, "invalid input\n");
		return -1;
	}
	mtk_dev->event_callback = event_callback;
	mtk_dev->event_callback_param = param;
	return 0;
}

int mtk_pcie_set_ext_int_mask(struct mtk_pci_dev *mtk_dev, pcie_ext_int_e ext_int, bool mask)
{

	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d input NULL pointer mtk_dev\n", ext_int);
		return -1;
	}

	if (unlikely(ext_int > END_INT)) {
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d does not exist\n", ext_int);
		return -1;
	}

	mtk_pcie_set_int_mask(mtk_dev, (_pcie_int_e)ext_int, mask);

	mb();

	return 0;
}



int mtk_pcie_clr_ext_int_sts(struct mtk_pci_dev *mtk_dev, pcie_ext_int_e ext_int)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d input NULL pointer mtk_dev\n", ext_int);
		return -1;
	}

	if (unlikely(ext_int > END_INT)) {
		MTK_ERR_LOG(TAG,
			"Ext interrupt ID %d does not exist\n", ext_int);
		return -1;
	}

	if (mtk_dev->pdev->msix_enabled) {
		mtk_pcie_ext_int_status_clear_msix(
			mtk_dev->base_addr.pcie_mac_ireg_base, ext_int);
	} else {
		mtk_pcie_ext_int_status_clear(
			mtk_dev->base_addr.pcie_mac_ireg_base, ext_int);
	}
	mb();
	return 0;
}




u32 mtk_pcie_ext_set_dummy_reg(struct mtk_pci_dev *mtk_dev,u32 num, u32 val)
{
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Error: input NULL pointer mtk_dev\n");
		return -1;
	}

	mtk_pcie_set_dummy_reg(mtk_dev->base_addr.pcie_mac_ireg_base, num, val);
	return 0;
}


u32 mtk_pcie_ext_get_dummy_reg(struct mtk_pci_dev *mtk_dev,u32 num)
{
	u32 ret;
	if(mtk_dev == NULL){
		MTK_ERR_LOG(TAG,
			"Error: input NULL pointer mtk_dev\n");
		return -1;
	}

	ret = mtk_pcie_get_dummy_reg(
		mtk_dev->base_addr.pcie_mac_ireg_base, num);
	return ret;
}


