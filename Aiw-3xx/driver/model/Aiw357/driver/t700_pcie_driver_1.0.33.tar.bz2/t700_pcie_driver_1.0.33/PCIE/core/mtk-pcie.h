/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_PCIE_H__
#define __MTK_PCIE_H__

#define PCI_SPEED_MASK  0x03
#define L2_SUSPEND_SECONDS	6
#define L2_REMOTE_WAKEUP_TIMEOUT 60
/* Capability ID */
#define PCI_EXT_CAP_ID_L1PMSS				0x1E
/* L1 PM Substates Capabilities Register */
#define PCI_L1PMSS_CAP						4
/* PCI-PM L1.2 is supported */
#define PCI_L1PM_CAP_PCIPM_L12				0x00000001
/* PCI-PM L1.1 is supported */
#define PCI_L1PM_CAP_PCIPM_L11				0x00000002
/* ASPM L1.2 is supported */
#define PCI_L1PM_CAP_ASPM_L12				0x00000004
/* ASPM L1.1 is supported */
#define PCI_L1PM_CAP_ASPM_L11				0x00000008
/* support L1 PM Substates */
#define PCI_L1PM_CAP_L1PM_SS				0x00000010
/* port common mode restore time */
#define PCI_L1PM_CAP_PORT_CMR_TIME_MASK		0x0000FF00
/* Port T_POWER_ON Scale */
#define PCI_L1PM_CAP_PWR_ON_SCALE_MASK		0x00030000
/* Port T_POWER_ON Value */
#define PCI_L1PM_CAP_PWR_ON_VALUE_MASK		0x00F80000
/* L1 PM Substates Control 1 Register */
#define PCI_L1PMSS_CTR1						8
/* PCI-PM L1.2 Enable */
#define PCI_L1PM_CTR1_PCIPM_L12_EN			0x00000001
/* PCI-PM L1.1 Enable */
#define PCI_L1PM_CTR1_PCIPM_L11_EN			0x00000002
/* ASPM L1.2 Enable */
#define PCI_L1PM_CTR1_ASPM_L12_EN			0x00000004
/* ASPM L1.1 Enable */
#define PCI_L1PM_CTR1_ASPM_L11_EN			0x00000008
/* port common mode restore time */
#define PCI_L1PM_CTR1_CMR_TIME_MASK			0x0000FF00
/* LTR L1.2 threshold value */
#define PCI_L1PM_CTR1_LTR_L12_TH_MASK		0x03FF0000
/* LTR L1.2 threshold scale */
#define PCI_L1PM_CTR1_LTR_L12_SCALE_MASK	0xE0000000
/* L1 PM Substates Control 2 Register */
#define PCI_L1PMSS_CTR2						8
/* Power on value scale */
#define PCI_L1PM_CTR2_PWR_ON_SCALE_MASK		0x00000003
/* Power on value value */
#define PCI_L1PM_CTR2_PWR_ON_VALUE_MASK   0x000000F8
#define PCI_L1PMSS_ENABLE_MASK	            (PCI_L1PM_CTR1_PCIPM_L12_EN |   \
	PCI_L1PM_CTR1_PCIPM_L11_EN |   \
	PCI_L1PM_CTR1_ASPM_L12_EN |    \
	PCI_L1PM_CTR1_ASPM_L11_EN)

#define PCI_EXP_LNKCTL2_TARGET_SPEED_MASK	0x000F
#define PCI_EXP_LNKCTL2_COMPLIANCE			0x0010
#define PCI_EXP_LNKCTL2_MODIFIED_COMPLIANCE	0x0400
#define PCI_EXP_LNKCTL2_COMPLIANCE_SOS		0x0800
#define PCI_EXP_LNKCTL2_COMPLIANCE_PRESET	0xF000

#define PCI_EXP_LNKSTA2_EQMASK	0x1E	/* Equalization Complete Mask */
/* Link Control 3 Register */
#define PCI_EXP_LNKCTL3			0x4
#define PCI_EXP_LNKCTL3_EQ		0x01	/* Perform Equalization */

#define MTK_PM_EVENT_STATUS				(0x40000000)

#define MTK_PCIE_SWINT_COUNT	8
#define MTK_PCIE_SWINT_OFFSET  0
#define MTK_PCIE_SWINT_END   (MTK_PCIE_SWINT_OFFSET+MTK_PCIE_SWINT_COUNT)

#define MTK_PCIE_A_ATR_OFFSET	16
#define MTK_PCIE_A_ATR_END     20
#define MTK_PCIE_P_ATR_OFFSET	20
#define MTK_PCIE_P_ATR_END    24

enum mtk_pci_bus_speed {
	MTK_SPEED_2_5GT = 1,
	MTK_SPEED_5_0GT,
	MTK_SPEED_8_0GT,
	MTK_SPEED_UNKNOWN
};

enum mtk_pcie_reset {

	MTK_WARM_RESET,
	MTK_COLD_RESET,
	MTK_HOT_RESET,
	MTK_DISABLED,
	MTK_FLR
};

enum mtk_pcie_link_state {

	LINK_STATE_L0S = 1,
	LINK_STATE_L1,
	LINK_STATE_L2
};

enum mtk_pcie_aspm_disable_bit {
	MTK_PCIE_DISABLE_LOW_POWER_SET_L0s = 0,
	MTK_PCIE_DISABLE_LOW_POWER_SET_L1,
	MTK_PCIE_DISABLE_LOW_POWER_SET_L11,
	MTK_PCIE_DISABLE_LOW_POWER_SET_L12
};

enum mtk_pcie_pm_exit {

	EXIT_EP,
	EXIT_RC
};
enum mtk_pci_irq {
	TYPE_MSI,
	TYPE_MSIX,
	TYPE_INTx
};

enum mtk_pcie_mem {
	MTK_MEM_READ,
	MTK_MEM_WRITE
};

enum mtk_pcie_loopback {
	LP_NORMAL = 0,
	LP_ASPM_L0S,
	LP_ASPM_L1,
	LP_ASPM_BOTH,
	LP_PCIPM_L1,
	LP_PCIPM_L2
};

struct mkt_aspm_state {
	int	 aspm_us;
	int	 aspm_ds;
};
enum mtk_dma_mode {

	RANDOM_LOOPBACK,
	SCAN_LOOPBACK
};
enum mtk_l1pm_ss {
	L1SS_PCIPM_L12 = PCI_L1PM_CTR1_PCIPM_L12_EN,
	L1SS_PCIPM_L11 = PCI_L1PM_CTR1_PCIPM_L11_EN,
	L1SS_ASPM_L12 = PCI_L1PM_CAP_ASPM_L12,
	L1SS_ASPM_L11 = PCI_L1PM_CAP_ASPM_L11
};

typedef enum _mtk_bar_num {
	BAR_0_1 = 0,
	BAR_2_3,
	BAR_4_5,
	BAR_END,
} mtk_bar_num_e;

extern int mtk_set_mps_mrrs(struct pci_dev *dev, int mps, int mrrs);
extern int mtk_pcie_aspm(struct mtk_pci_dev *mtk_dev,struct mkt_aspm_state aspm);
#ifdef MTK_PCIE_ASPM_DISABLE
int mtk_pcie_aspm_disable(struct mtk_pci_dev *mtk_dev);
#endif
extern int mtk_pcie_retrain(struct pci_dev *dev);
extern int mtk_pcie_disabled(struct pci_dev *dev);
extern int mtk_pcie_hot_reset(struct pci_dev *dev);
extern int mtk_function_level_reset(struct pci_dev *dev);
extern int mtk_pcie_change_speed(struct mtk_pci_dev *mtk_dev,int speed);
extern int mtk_pcie_configuration(struct pci_dev *dev);
extern int mtk_pcie_reset_config(struct pci_dev *dev);
extern int wait_dma_done(struct pci_dev *dev);
extern int mtk_pcie_go_l1(struct pci_dev *dev);
extern int mtk_pcie_go_l2(struct pci_dev *dev);
extern int mtk_pcie_wakeup(struct pci_dev *dev);
extern int mtk_pcie_exit_l2(int delay);
extern int mtk_pcie_read_rtc(void);
extern void mtk_pme_interrupt_enable(struct pci_dev *dev, bool enable);
extern void mtk_clear_root_pme_status(struct pci_dev *dev);
//extern irqreturn_t mtk_pme_irq (int irq, void *__res);
extern void mtk_enable_pme(struct pci_dev *dev);
extern int mtk_wait_wakeup(struct pci_dev *dev);
extern int mtk_setup_l1pm(struct pci_dev *dev,int enable);
extern int mtk_setup_l1ss(struct pci_dev *dev,int ds_mode, int us_mode);
extern int mtk_pcie_compliance(struct pci_dev *dev,int mode, int skip, int deemph, int speed);
extern int mtk_pcie_equalization(struct pci_dev *dev);
extern int mtk_sw_int(struct pci_dev *dev,int irq_number);
extern int mtk_int_mask(struct pci_dev *dev,int type);

int mtk_pcie_read_sku(struct pci_dev *dev,unsigned int *SKU1, unsigned int *SKU2);
extern void mtk_setup_error_report(struct pci_dev *dev, bool enable);
extern struct pci_dev *mtk_get_pcie_resource(int class_code);

#endif /*__MTK_PCIE_H__*/
