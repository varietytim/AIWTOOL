/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __PCIE_MAC_IREG_REGS_H__
#define __PCIE_MAC_IREG_REGS_H__

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef REG_BASE_C_MODULE
// ----------------- PCIE_MAC_IREG Bit Field Definitions -------------------

#define PACKING
typedef unsigned int FIELD;

typedef PACKING union
{
	PACKING struct
	{
		FIELD SOFTWARE_TRIG_INTERRUPT_HOST : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_SW_TRIG_INT, *PREG_PCIE_SW_TRIG_INT;

typedef PACKING union
{
	PACKING struct
	{
		FIELD LTSSM_DETECT              : 1;
		FIELD LTSSM_POLLING             : 1;
		FIELD LTSSM_CONFIGURATION       : 1;
		FIELD LTSSM_RECOVERY            : 1;
		FIELD LTSSM_L0                  : 1;
		FIELD LTSSM_L0S                 : 1;
		FIELD LTSSM_L1                  : 1;
		FIELD LTSSM_L2                  : 1;
		FIELD LTSSM_DISABLE             : 1;
		FIELD LTSSM_LOOPBACK            : 1;
		FIELD LTSSM_HOTRESET            : 1;
		FIELD LinkUnstable              : 1;
		FIELD L1PM_L11                  : 1;
		FIELD L1PM_L12                  : 1;
		FIELD LTSSM_RECOV_LOCK          : 1;
		FIELD LTSSM_RECOV_EQUAL         : 1;
		FIELD LTSSM_RECOV_SPEED         : 1;
		FIELD LTSSM_RECOV_CFG           : 1;
		FIELD RSVD1                     : 6;
		FIELD LTSSM_state               : 5;
		FIELD rsv_29                    : 3;
	} Bits;
	UINT32 Raw;
} REG_PCIe_Ltssm_Status, *PREG_PCIe_Ltssm_Status;

typedef PACKING union
{
	PACKING struct
	{
		FIELD DMA_END                   : 8;
		FIELD DMA_ERROR                 : 8;
		FIELD A_ATR_EVT                 : 4;
		FIELD P_ATR_EVT                 : 4;
		FIELD INT_EVT                   : 4;
		FIELD MSG_EVT                   : 1;
		FIELD AER_L2_EVT                : 1;
		FIELD PM_EVT                    : 1;
		FIELD ERROR_RST_EVT             : 1;
	} Bits;
	UINT32 Raw;
} REG_ISTATUS_LOCAL, *PREG_ISTATUS_LOCAL;

typedef PACKING union
{
	PACKING struct
	{
		FIELD DMA_END_EN			: 8;
		FIELD DMA_ERROR_EN			: 8;
		FIELD A_ATR_EVT_EN			: 4;
		FIELD P_ATR_EVT_EN			: 4;
		FIELD DPMAIF_INT_EN			: 1;
		FIELD CLDMA0_INT_EN			: 1;
		FIELD CLDMA1_INT_EN			: 1;
		FIELD CLDMA2_INT_EN			: 1;
		FIELD MHCCIF_INT_EN			: 1;
		FIELD DPMAIF2_INT_EN            : 1;
		FIELD SAP_RGU_INT_EN		: 1;
		FIELD CLDMA3_INT_EN			: 1;
	} Bits;
	UINT32 Raw;
} REG_INT_ENABLE_HOST, *PREG_INT_ENABLE_HOST;

typedef PACKING union
{
	PACKING struct
	{
		FIELD DMA_END				: 8;
		FIELD DMA_ERROR			: 8;
		FIELD A_ATR_EVT				: 4;
		FIELD P_ATR_EVT				: 4;
		FIELD DPMAIF_INT			: 1;
		FIELD CLDMA0_INT			: 1;
		FIELD CLDMA1_INT			: 1;
		FIELD CLDMA2_INT			: 1;
		FIELD MHCCIF_INT			: 1;
		FIELD DPMAIF2_INT			: 1;
		FIELD SAP_RGU_INT			: 1;
		FIELD CLDMA3_INT			: 1;
	} Bits;
	UINT32 Raw;
} REG_ISTATUS_HOST, *PREG_ISTATUS_HOST;

typedef PACKING union
{
	PACKING struct
	{
		FIELD ISTATUS_HOST_DIS          : 1;
		FIELD rsv_1                     : 29;
		FIELD RSVD                      : 2;
	} Bits;
	UINT32 Raw;
} REG_ISTATUS_HOST_CTRL, *PREG_ISTATUS_HOST_CTRL;

typedef PACKING union
{
	PACKING struct
	{
		FIELD HOST_INT_Enable_Set       : 32;
	} Bits;
	UINT32 Raw;
} REG_INT_ENABLE_HOST_SET, *PREG_INT_ENABLE_HOST_SET;

typedef PACKING union
{
	PACKING struct
	{
		FIELD HOST_INT_Enable_Clr       : 32;
	} Bits;
	UINT32 Raw;
} REG_INT_ENABLE_HOST_CLR, *PREG_INT_ENABLE_HOST_CLR;

typedef PACKING union
{
	PACKING struct
	{
		FIELD PCIE_DUMMY                : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DMA_DUMMY_0, *PREG_PCIE_DMA_DUMMY_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD PCIE_DUMMY_0              : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DUMMY_0, *PREG_PCIE_DUMMY_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD pl_cken                   : 1;
		FIELD RSVD1                     : 1;
		FIELD br_cken                   : 1;
		FIELD tl_cken                   : 1;
		FIELD axi_cken                  : 1;
		FIELD pcie_ck_dis               : 1;
		FIELD pextp_mac_active_dis      : 1;
		FIELD pextp_mac_sleep_dis       : 1;
		FIELD rsv_8                     : 8;
		FIELD pcie_linkdown_enable      : 1;
		FIELD rsv_17                    : 7;
		FIELD WAKE_N                    : 1;
		FIELD rsv_25                    : 6;
		FIELD DISABLE_HW_STRAP          : 1;
	} Bits;
	UINT32 Raw;
} REG_PCIE_MISC_CTRL, *PREG_PCIE_MISC_CTRL;

typedef PACKING union
{
	PACKING struct
	{
		FIELD ATR_IMPL                  : 1;
		FIELD ATR_SIZE                  : 6;
		FIELD rsv_7                     : 5;
		FIELD SRC_ADDR_LSB              : 20;
	} Bits;
	UINT32 Raw;
} REG_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB,
	*PREG_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB;

typedef PACKING union
{
	PACKING struct
	{
		FIELD SRC_ADDR_MSB              : 32;
	} Bits;
	UINT32 Raw;
} REG_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB, *PREG_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB;

typedef PACKING union
{
	PACKING struct
	{
		FIELD SRC_BAR                   : 4;
		FIELD SRC_FUNC                  : 5;
		FIELD rsv_9                     : 3;
		FIELD TRSL_ADDR_LSB             : 20;
	} Bits;
	UINT32 Raw;
} REG_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB, *PREG_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB;

typedef PACKING union
{
	PACKING struct
	{
		FIELD TRSL_ADDR_MSB             : 32;
	} Bits;
	UINT32 Raw;
} REG_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB, *PREG_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB;

typedef PACKING union
{
	PACKING struct
	{
		FIELD TRSL_ID                   : 4;
		FIELD rsv_4                     : 12;
		FIELD TRSF_PARAM                : 12;
		FIELD rsv_28                    : 4;
	} Bits;
	UINT32 Raw;
} REG_ATR_PCIE_WIN0_T0_TRSL_PARAM, *PREG_ATR_PCIE_WIN0_T0_TRSL_PARAM;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_0             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_0, *PREG_PCIE_DEBUG_DUMMY_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_1             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_1, *PREG_PCIE_DEBUG_DUMMY_1;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_2             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_2, *PREG_PCIE_DEBUG_DUMMY_2;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_3             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_3, *PREG_PCIE_DEBUG_DUMMY_3;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_4             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_4, *PREG_PCIE_DEBUG_DUMMY_4;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_5             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_5, *PREG_PCIE_DEBUG_DUMMY_5;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_6             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_6, *PREG_PCIE_DEBUG_DUMMY_6;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_7             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_DEBUG_DUMMY_7, *PREG_PCIE_DEBUG_DUMMY_7;

typedef PACKING union
{
	PACKING struct
	{
		FIELD debug_dummy_7             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_RESOURCE_STATUS, *PREG_PCIE_RESOURCE_STATUS;

typedef PACKING union
{
	PACKING struct
	{
		FIELD SW_TRIG_INTR_SET          : 32;
	} Bits;
	UINT32 Raw;
} REG_SW_TRIG_INTR_SET, *PREG_SW_TRIG_INTR_SET;

typedef PACKING union
{
	PACKING struct
	{
		FIELD SW_TRIG_INTR_CLR          : 32;
	} Bits;
	UINT32 Raw;
} REG_SW_TRIG_INTR_CLR, *PREG_SW_TRIG_INTR_CLR;

typedef PACKING union
{
	PACKING struct
	{
		FIELD cfg_msix_ctrl             : 32;
	} Bits;
	UINT32 Raw;
} REG_PCIE_CFG_MSIX, *PREG_PCIE_CFG_MSIX;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_set_0          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_SET_0, *PREG_DIS_ASPM_LOWPWR_SET_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_clr_0          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_CLR_0, *PREG_DIS_ASPM_LOWPWR_CLR_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_set_1          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_SET_1, *PREG_DIS_ASPM_LOWPWR_SET_1;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_clr_1          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_CLR_1, *PREG_DIS_ASPM_LOWPWR_CLR_1;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_sts_0          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_STS_0, *PREG_DIS_ASPM_LOWPWR_STS_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_aspm_lowpwr_sts_1          : 32;
	} Bits;
	UINT32 Raw;
} REG_DIS_ASPM_LOWPWR_STS_1, *PREG_DIS_ASPM_LOWPWR_STS_1;

typedef PACKING union
{
	PACKING struct
	{
		FIELD dis_lowpwr_mask           : 4;
		FIELD rsv_4                     : 4;
		FIELD force_dis_lowpwr          : 4;
		FIELD rsv_12                    : 20;
	} Bits;
	UINT32 Raw;
} REG_PCIE_LOW_POWER_CTRL, *PREG_PCIE_LOW_POWER_CTRL;

typedef PACKING union
{
	PACKING struct
	{
		FIELD msix_sw_trig_set          : 32;
	} Bits;
	UINT32 Raw;
} REG_MSIX_SW_TRIG_SET_GRP0_0, *PREG_MSIX_SW_TRIG_SET_GRP0_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD imask_host_msix_clr       : 32;
	} Bits;
	UINT32 Raw;
} REG_IMASK_HOST_MSIX_CLR_GRP0_0, *PREG_IMASK_HOST_MSIX_CLR_GRP0_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD imask_host_msix_set       : 32;
	} Bits;
	UINT32 Raw;
} REG_IMASK_HOST_MSIX_SET_GRP0_0, *PREG_IMASK_HOST_MSIX_SET_GRP0_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD imask_host_msix_clr       : 32;
	} Bits;
	UINT32 Raw;
} REG_IMASK_HOST_MSIX_GRP0_0, *PREG_IMASK_HOST_MSIX_GRP0_0;

typedef PACKING union
{
	PACKING struct
	{
		FIELD msix_istatus_host         : 32;
	} Bits;
	UINT32 Raw;
} REG_MSIX_ISTATUS_HOST_GRP0_0, *PREG_MSIX_ISTATUS_HOST_GRP0_0;

// ----------------- PCIE_MAC_IREG  Grouping Definitions -------------------
// ----------------- PCIE_MAC_IREG Register Definition -------------------

typedef volatile PACKING struct
{
	UINT32               rsv_0000[47];      //0000...00B8
	REG_PCIE_SW_TRIG_INT              PCIE_SW_TRIG_INT;   // 00BC
	UINT32                           rsv_00C0[36];    //00C0...014C
	REG_PCIe_Ltssm_Status         PCIe_Ltssm_Status;       // 0150
	UINT32                        rsv_0154[12];            //0154...0180
	REG_ISTATUS_LOCAL             ISTATUS_LOCAL;       // 0184
	REG_INT_ENABLE_HOST          INT_ENABLE_HOST;     // 0188
	REG_ISTATUS_HOST          ISTATUS_HOST;           // 018C
	UINT32                          rsv_0190;        // 0190
	REG_PCIE_LOW_POWER_CTRL     PCIE_LOW_POWER_CTRL;    // 0194
	UINT32         rsv_0198[5];        //0198...01A8
	REG_ISTATUS_HOST_CTRL       ISTATUS_HOST_CTRL;   // 01AC
	UINT32                                rsv_01B0[16];        //01B0..01EC
	REG_INT_ENABLE_HOST_SET           INT_ENABLE_HOST_SET;  // 01F0
	REG_INT_ENABLE_HOST_CLR  INT_ENABLE_HOST_CLR; // 01F4
	REG_PCIE_DMA_DUMMY_0         PCIE_DMA_DUMMY_0;        // 01F8
	UINT32                      rsv_01FC[83];// 01FC...0344
	REG_PCIE_MISC_CTRL           PCIE_MISC_CTRL;   // 0348
	UINT32                         rsv_034C[29]; // 034C...03BC
	REG_PCIE_DUMMY_0              PCIE_DUMMY_0;    // 03C0
	UINT32               rsv_03C4;            //03C4
	REG_SW_TRIG_INTR_SET         SW_TRIG_INTR_SET;    // 03C8
	REG_SW_TRIG_INTR_CLR          SW_TRIG_INTR_CLR; // 03CC
	UINT32                   rsv_03D0[7];       //03D0...03E8
	REG_PCIE_CFG_MSIX                   PCIE_CFG_MSIX;      // 03EC
	UINT32                    rsv_03F0[132];        //03F0...05FC

	REG_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB
		ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB; // 0600

	// 0604
	REG_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB     ATR_PCIE_WIN0_T0_SRC_ADDR_MSB;
	// 0608
	REG_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB   ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB;
	// 060C
	REG_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB    ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB;
	REG_ATR_PCIE_WIN0_T0_TRSL_PARAM    ATR_PCIE_WIN0_T0_TRSL_PARAM; // 0610
	UINT32                     rsv_0614[443];         // 0614...0CFC
	REG_PCIE_DEBUG_DUMMY_0          PCIE_DEBUG_DUMMY_0; // 0D00
	REG_PCIE_DEBUG_DUMMY_1          PCIE_DEBUG_DUMMY_1; // 0D04
	REG_PCIE_DEBUG_DUMMY_2          PCIE_DEBUG_DUMMY_2; // 0D08
	REG_PCIE_DEBUG_DUMMY_3          PCIE_DEBUG_DUMMY_3; // 0D0C
	REG_PCIE_DEBUG_DUMMY_4          PCIE_DEBUG_DUMMY_4; // 0D10
	REG_PCIE_DEBUG_DUMMY_5          PCIE_DEBUG_DUMMY_5; // 0D14
	REG_PCIE_DEBUG_DUMMY_6          PCIE_DEBUG_DUMMY_6; // 0D18
	REG_PCIE_DEBUG_DUMMY_7          PCIE_DEBUG_DUMMY_7; // 0D1C
	UINT32                           rsv_0D20[2];              //0D20...0D24
	REG_PCIE_RESOURCE_STATUS           PCIE_RESOURCE_STATUS; //0D28
	UINT32             rsv_0D2C[73];  //0D2C...0E4C
	REG_DIS_ASPM_LOWPWR_SET_0       DIS_ASPM_LOWPWR_SET_0;  // 0E50
	REG_DIS_ASPM_LOWPWR_CLR_0       DIS_ASPM_LOWPWR_CLR_0;  // 0E54
	REG_DIS_ASPM_LOWPWR_SET_1       DIS_ASPM_LOWPWR_SET_1;  // 0E58
	REG_DIS_ASPM_LOWPWR_CLR_1       DIS_ASPM_LOWPWR_CLR_1;  // 0E5C
	REG_DIS_ASPM_LOWPWR_STS_0       DIS_ASPM_LOWPWR_STS_0;  // 0E60
	REG_DIS_ASPM_LOWPWR_STS_1       DIS_ASPM_LOWPWR_STS_1;  // 0E64
	UINT32                            rsv_0E68[6];     // 0E68..0E7C
	REG_MSIX_SW_TRIG_SET_GRP0_0     MSIX_SW_TRIG_SET_GRP0_0; // 0E80
	UINT32                           rsv_0E84[31];   //0E84...0EFC
	REG_MSIX_ISTATUS_HOST_GRP0_0    MSIX_ISTATUS_HOST_GRP0_0; // 0F00
	UINT32                            rsv_0F04[2111];    //0F04...2FFC
	REG_IMASK_HOST_MSIX_SET_GRP0_0  IMASK_HOST_MSIX_SET_GRP0_0; // 3000
	UINT32                            rsv_3004[31];   //3004...307C
	REG_IMASK_HOST_MSIX_CLR_GRP0_0  IMASK_HOST_MSIX_CLR_GRP0_0; // 3080
	UINT32                            rsv_3084[31];    //3084...30FC
	REG_IMASK_HOST_MSIX_GRP0_0      IMASK_HOST_MSIX_GRP0_0; // 3100
} PCIE_MAC_IREG_REGS, *PPCIE_MAC_IREG_REGS;

// ---------- PCIE_MAC_IREG Enum Definitions      ----------
// ---------- PCIE_MAC_IREG C Macro Definitions   ----------

#define MTK_PCIE_SW_TRIG_INT(BASE)              \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_SW_TRIG_INT) // 00BC
#define MTK_PCIe_Ltssm_Status(BASE)                \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIe_Ltssm_Status) // 0150
#define MTK_ISTATUS_LOCAL(BASE)                    \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ISTATUS_LOCAL) // 0184
#define MTK_INT_ENABLE_HOST(BASE)               \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->INT_ENABLE_HOST) // 0188
#define MTK_ISTATUS_HOST(BASE)                     \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ISTATUS_HOST) // 018C
#define MTK_PCIE_LOW_POWER_CTRL(BASE)      \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_LOW_POWER_CTRL) // 0194
#define MTK_ISTATUS_HOST_CTRL(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ISTATUS_HOST_CTRL) // 01AC
#define MTK_INT_ENABLE_HOST_SET(BASE)          \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->INT_ENABLE_HOST_SET) // 01F0
#define MTK_INT_ENABLE_HOST_CLR(BASE)         \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->INT_ENABLE_HOST_CLR) // 01F4
#define MTK_PCIE_DMA_DUMMY_0(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DMA_DUMMY_0) // 01F8
#define MTK_PCIE_MISC_CTRL(BASE)                \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_MISC_CTRL) // 0348

#define MTK_PCIE_DUMMY_0(BASE)                  \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DUMMY_0) // 03C0
#define MTK_SW_TRIG_INTR_SET(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->SW_TRIG_INTR_SET) // 03C8
#define MTK_SW_TRIG_INTR_CLR(BASE)           \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->SW_TRIG_INTR_CLR) // 03CC
#define MTK_PCIE_CFG_MSIX(BASE)                  \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_CFG_MSIX) // 03EC
#define MTK_PCIE_ATR_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(BASE)     \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->\
	ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB) // 0600
// 0604
#define MTK_PCIE_ATR_WIN0_T0_SRC_ADDR_MSB(BASE)       \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_SRC_ADDR_MSB)
// 0608
#define MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_LSB(BASE)    \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB)
// 060C
#define MTK_PCIE_ATR_WIN0_T0_TRSL_ADDR_MSB(BASE)   \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB)
// 0610
#define MTK_PCIE_ATR_WIN0_T0_TRSL_PARAM(BASE)    \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_PARAM)
#define MTK_PCIE_DBG_DUMMY_0(BASE)                      \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_0) // 0D00
#define MTK_DIS_ASPM_LOWPWR_SET_0(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_SET_0) // 0E50
#define MTK_DIS_ASPM_LOWPWR_CLR_0(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_CLR_0) // 0E54
#define MTK_DIS_ASPM_LOWPWR_SET_1(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_SET_1) // 0E58
#define MTK_DIS_ASPM_LOWPWR_CLR_1(BASE)           \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_CLR_1) // 0E5C
#define MTK_DIS_ASPM_LOWPWR_STS_0(BASE)           \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_STS_0) // 0E58
#define MTK_DIS_ASPM_LOWPWR_STS_1(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->DIS_ASPM_LOWPWR_STS_1) // 0E5C

#define MTK_MSIX_SW_TRIG_SET_GRP0_0(BASE)                \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->MSIX_SW_TRIG_SET_GRP0_0) // 0E80
#define MTK_MSIX_ISTATUS_HOST_GRP0_0(BASE)               \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->MSIX_ISTATUS_HOST_GRP0_0) // 0F00
// 3000
#define MTK_IMASK_HOST_MSIX_SET_GRP0_0(BASE)            \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->IMASK_HOST_MSIX_SET_GRP0_0)
// 3080
#define MTK_IMASK_HOST_MSIX_CLR_GRP0_0(BASE)           \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->IMASK_HOST_MSIX_CLR_GRP0_0)
#define MTK_IMASK_HOST_MSIX_GRP0_0(BASE)                   \
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->IMASK_HOST_MSIX_GRP0_0) // 3100


#define MTK_REG_BASE_ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB(BASE) \
	(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_ATR_PARAM_SRC_ADDR_LSB)
#define MTK_REG_BASE_ATR_PCIE_WIN0_T0_SRC_ADDR_MSB(BASE)        \
	(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_SRC_ADDR_MSB)
#define MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB(BASE)       \
	(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_ADDR_LSB)
#define MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB(BASE)      \
	(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_ADDR_MSB)
#define MTK_REG_BASE_ATR_PCIE_WIN0_T0_TRSL_PARAM(BASE)        \
	(&((PPCIE_MAC_IREG_REGS)BASE)->ATR_PCIE_WIN0_T0_TRSL_PARAM)

#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_0(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_0)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_1(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_1)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_2(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_2)
//0D0C, used for PCIE Low power resume state querying
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_3(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_3)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_4(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_4)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_5(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_5)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_6(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_6)
#define MTK_REG_BASE_PCIE_DEBUG_DUMMY_7(BASE)		\
	(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_DEBUG_DUMMY_7)
#define MTK_REG_BASE_PCIE_RESOURCE_STATUS(BASE)		\
	INREG32(&((PPCIE_MAC_IREG_REGS)BASE)->PCIE_RESOURCE_STATUS)


#endif
#define ISTATUS_LOCAL_FLD_PM_EVT                               REG_FLD(1, 30)
#define ISTATUS_HOST_CTRL_FLD_ISTATUS_HOST_DIS                 REG_FLD(1, 0)
#define INT_ENABLE_HOST_CLR_FLD_HOST_INT_Enable_Clr            REG_FLD(32, 0)
#define ISTATUS_HOST_FLD_A_ATR_EVT                             REG_FLD(4, 16)
#define ISTATUS_HOST_FLD_P_ATR_EVT                             REG_FLD(4, 20)
#define INT_ENABLE_HOST_FLD_A_ATR_EVT_EN                       REG_FLD(4, 16)
#define INT_ENABLE_HOST_FLD_P_ATR_EVT_EN                       REG_FLD(4, 20)
#define INT_ENABLE_HOST_SET_FLD_HOST_INT_Enable_Set            REG_FLD(32, 0)
#define INT_ENABLE_HOST_FLD_HOST_INT_Enable                    REG_FLD(32, 0)
#define ISTATUS_HOST_FLD_ALL          REG_FLD(32, 0)
#define ISTATUS_HOST_FLD_MHCCIF_INT                  REG_FLD(1, 28)
#define PCIE_LOW_POWER_CTRL_FLD_force_dis_lowpwr               REG_FLD(4, 8)
#define IMASK_HOST_MSIX_GRP0_0_FLD_imask_host_msix_clr         REG_FLD(32, 0)
#define IMASK_HOST_MSIX_SET_GRP0_0_FLD_imask_host_msix_set  REG_FLD(32, 0)
#define PCIE_CFG_MSIX_FLD_cfg_msix_ctrl            REG_FLD(32, 0)

#define ISTATUS_LOCAL_GET_PM_EVT(reg32)               \
	REG_FLD_GET(ISTATUS_LOCAL_FLD_PM_EVT, (reg32))
#define ISTATUS_HOST_CTRL_SET_ISTATUS_HOST_DIS(reg32, val)  \
	REG_FLD_SET(ISTATUS_HOST_CTRL_FLD_ISTATUS_HOST_DIS, (reg32), (val))
#define INT_ENABLE_HOST_CLR_SET_HOST_INT_Enable_Clr(reg32, val) \
	REG_FLD_SET(INT_ENABLE_HOST_CLR_FLD_HOST_INT_Enable_Clr, (reg32), (val))
#define ISTATUS_HOST_GET_A_ATR_EVT(reg32)             \
	REG_FLD_GET(ISTATUS_HOST_FLD_A_ATR_EVT, (reg32))
#define ISTATUS_HOST_SET_A_ATR_EVT(reg32, val)      \
	REG_FLD_SET(ISTATUS_HOST_FLD_A_ATR_EVT, (reg32), (val))
#define ISTATUS_HOST_GET_P_ATR_EVT(reg32)          \
	REG_FLD_GET(ISTATUS_HOST_FLD_P_ATR_EVT, (reg32))
#define INT_ENABLE_HOST_SET_SET_HOST_INT_Enable_Set(reg32, val) \
	REG_FLD_SET(INT_ENABLE_HOST_SET_FLD_HOST_INT_Enable_Set, (reg32), (val))
#define ISTATUS_HOST_SET_P_ATR_EVT(reg32, val)             \
	REG_FLD_SET(ISTATUS_HOST_FLD_P_ATR_EVT, (reg32), (val))
#define INT_ENABLE_HOST_SET_HOST_INT_Enable(reg32, val)  \
	REG_FLD_SET(INT_ENABLE_HOST_FLD_HOST_INT_Enable, (reg32), (val))
#define ISTATUS_HOST_SET_INT_ALL(reg32, val)             \
	REG_FLD_SET(ISTATUS_HOST_FLD_ALL, (reg32), (val))
#define ISTATUS_HOST_SET_MHCCIF_INT(reg32, val)      \
	REG_FLD_SET(ISTATUS_HOST_FLD_MHCCIF_INT, (reg32), (val))
#define PCIE_LOW_POWER_CTRL_SET_force_dis_lowpwr(reg32, val) \
	REG_FLD_SET(PCIE_LOW_POWER_CTRL_FLD_force_dis_lowpwr, (reg32), (val))
#define PCIE_LOW_POWER_CTRL_GET_force_dis_lowpwr(reg32)     \
	REG_FLD_GET(PCIE_LOW_POWER_CTRL_FLD_force_dis_lowpwr, (reg32))
#define IMASK_HOST_MSIX_GRP0_0_SET_imask_host_msix_clr(reg32, val) \
	REG_FLD_SET(\
	IMASK_HOST_MSIX_GRP0_0_FLD_imask_host_msix_clr, (reg32), (val))
#define IMASK_HOST_MSIX_SET_GRP0_0_SET_imask_host_msix_set(reg32, val) \
	REG_FLD_SET(\
	IMASK_HOST_MSIX_SET_GRP0_0_FLD_imask_host_msix_set, (reg32), (val))
#define PCIE_CFG_MSIX_SET_cfg_msix_ctrl(reg32, val)     \
	REG_FLD_SET(PCIE_CFG_MSIX_FLD_cfg_msix_ctrl, (reg32), (val))
#define PCIE_CFG_SET_PEXTP_MAC_SLEEP(reg32, val)    \
	REG_FLD_SET(REG_FLD(1, 7), (reg32), (val))

#define PCIE_L0_DISABLE_BIT(i)                                      ((i)*4)
#define PCIE_L1_DISABLE_BIT(i)                                      ((i)*4+1)
#define PCIE_L1_1_DISABLE_BIT(i)                                  ((i)*4+2)
#define PCIE_L1_2_DISABLE_BIT(i)                                  ((i)*4+3)

#define PCIE_CFG_SET_L_STATES_DIS(BASE, val)   \
	REG_SET(MTK_DIS_ASPM_LOWPWR_SET_0(BASE), (val))
#define PCIE_CFG_CLR_L_STATES_DIS(BASE, val)    \
	REG_SET(MTK_DIS_ASPM_LOWPWR_CLR_0(BASE), (val))

#define PCIE_READ_RESOURCE_STATUS(BASE)     \
	MTK_REG_BASE_PCIE_RESOURCE_STATUS(BASE)

#ifdef __cplusplus
}
#endif

#endif // __PCIE_MAC_IREG_REGS_H__

