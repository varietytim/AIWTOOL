/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_PCIE_EXT_H__
#define __MTK_PCIE_EXT_H__

//TODO: need flush or not?
#define MTK_PCIE_FLUSH()




#endif //__MTK_PCIE_EXT_H__
