/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef _MTK_PCI_EXT_H_
#define _MTK_PCI_EXT_H_
#include "chip_def.h"

typedef int (*mtk_pci_sw_intr_callback)(void *param);
typedef int (*mtk_pci_intr_callback)(void *param);
typedef int (*mtk_pci_event_callback)(u32 pci_event, void *param);

typedef struct _pcie_ext_info {
	struct device *dev;
	u64 reg_base;
	u64 reg_dev_trsl_addr;
	u64 mem_base;
} pcie_ext_info_t;

void mtk_pci_msix_dump(struct mtk_pci_dev *mtk_dev);

int mtk_pcie_register_mhccif_ext_int_callback(struct mtk_pci_dev *mtk_dev,
	pcie_ext_int_e ext_int, u32 bitmask,
	mtk_pci_sw_intr_callback intr_callback, void *param);
int mtk_pcie_register_ext_int_callback(struct mtk_pci_dev *mtk_dev,
	pcie_ext_int_e ext_int, mtk_pci_intr_callback intr_callback,
	void *param);
int mtk_pcie_register_event_callback(struct mtk_pci_dev *mtk_dev,
	mtk_pci_event_callback event_callback,void *param);

int mtk_pcie_set_ext_int_mask(struct mtk_pci_dev *mtk_dev, pcie_ext_int_e ext_int, bool mask);
int mtk_pcie_clr_ext_int_sts(struct mtk_pci_dev *mtk_dev, pcie_ext_int_e ext_int);
u32 mtk_pcie_ext_set_dummy_reg(struct mtk_pci_dev *mtk_dev,u32 num, u32 val);
u32 mtk_pcie_ext_get_dummy_reg(struct mtk_pci_dev *mtk_dev,u32 num);

#endif /*_MTK_PCI_EXT_H_*/
