/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_ATR_H__
#define __MTK_ATR_H__

#include "chip_def.h"

#define PCIE_MEM_BAR            BAR_4_5
#define PCIE_MEM_PORT                ATR_SRC_PCI_WIN1
#define PCIE_MEM_TABLE_NUM    0
#define PCIE_MEM_SIZE            0x00800000 //8MB

#define PCIE_REG_BAR            BAR_2_3
#define PCIE_REG_PORT                 ATR_SRC_PCI_WIN0
#define PCIE_REG_TABLE_NUM        0
#define PCIE_REG_TRSL_ADDR        PCIE_REG_TRSL_ADDR_CHIP
#define PCIE_REG_TRSL_PORT        ATR_DST_AXIM_0
#define PCIE_REG_SIZE            PCIE_REG_SIZE_CHIP

#define PCIE_DEV_DMA_PORT_START     ATR_SRC_AXIS_0
#define PCIE_DEV_DMA_PORT_END       ATR_SRC_AXIS_2
#define PCIE_DEV_DMA_TABLE_NUM    0
#define PCIE_DEV_DMA_TRSL_ADDR    0x00000000

#ifdef PCIE_64BIT_ADDR_TEST
#define PCIE_DEV_DMA_SRC_ADDR        ((u64)PCIE_64BIT_ADDR_H << 32)
#define PCIE_DEV_DMA_TRANSPARENT 0
#define PCIE_DEV_DMA_SIZE            0x100000000   //4G
#else
#define PCIE_DEV_DMA_SRC_ADDR        0x00000000
#define PCIE_DEV_DMA_TRANSPARENT 1
#define PCIE_DEV_DMA_SIZE            0
#endif

#endif /*__MTK_ATR_H__*/
