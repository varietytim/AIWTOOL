/* SPDX-License-Identifier: BSD-3-Clause-Clear
 *
 * Copyright (c) 2020, MediaTek Inc.
 */



#ifndef __MTK_PCI_H__
#define __MTK_PCI_H__

#include <linux/irq.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/spinlock_types.h>
#include <linux/spinlock.h>
#include <linux/atomic.h>
#include <linux/mutex.h>
#include <linux/delay.h>


#include "chip_def.h"
struct mtk_pci_dev;
#include "mtk-pcie-mac.h"
#include "mtk-pci-ext.h"


#define MTK_PCI_DRIVER_NAME	"mtk_bus_driver"
#define MTK_PCI_IRQ_DESCR "mtk_pcie_irq"
#define MTK_PCI_WQ_DESCR "mtk_pcie_wq"
#define MTK_PCI_MSIX_IRQ_DESCR "mtk_pcie_msix_irq"
// offset 0x9, 3 bytes
#define PCI_CLASS_MTK_DEVICE    PCI_CLASS_MTK_DEVICE_CHIP
// offset 0x0, 2 bytes
#define PCI_VENDOR_ID_TEST        PCI_VENDOR_ID_TEST_CHIP
// offset 0x2, 2 byte
#define PCI_DEVICE_ID_TEST         PCI_DEVICE_ID_TEST_CHIP

#define MTK_PCI_DEVICE_ID_M7X           (0x4D70)
#define MTK_PCI_DEVICE_ID_M8X75    (0x4D75)

#define PCI_BAR_NUM 6
#define PCI_EXT_INTR_NUM 8

#define DMA_BUFFER_SIZE 0x100000
#define PCIE_DMA_TIMEOUT  (5*HZ)
#define LINK_RETRAIN_TIMEOUT HZ
#define L1_REMOTE_WAKEUP_TIMEOUT  (10*HZ)
#define MTK_PCIE_IRQ_COUNT		32
#define MTK_PCIE_IRQ_MSIX_MIN_COUNT	2

extern bool l_res_lock_enable;
extern bool runtime_detect_enable;
extern unsigned short runtime_idle_delay;
extern u32 suspend_wait_timeout;
extern u32 resume_wait_timeout;
extern u32 suspend_wait_timeout_sap;
extern u32 resume_wait_timeout_sap;
extern u32 l_res_polling_period;
extern u32 l_res_polling_max;
extern bool l_res_delayed_unlock;
extern u32 l_res_delayed_unlock_timeout;
extern bool pm_suspend_enable;
extern bool l1ss_state_logging;
extern bool suspend_direct_complete;
extern bool pci_cap_debug_enable;
extern bool d3l2_force_dsw;
extern bool rpm_resume_set_powerstate;


enum mtk_pcie_state_t {
	__PCIE_EP2RC_SW_INT,
	__PCIE_A_ATR_INT,
	__PCIE_P_ATR_INT,
	__PCIE_SERVICE_SCHED,
	__PCIE_AT_RECEIVE_RESULT_ERR,
};

enum mtk_pcie_event_t {
	__PCIE_EVENT_L3ENTER,
	__PCIE_EVENT_L3EXIT,
};


struct mtk_pci_driver {
	const char	*description;
	const char	*irq_descr;
	/* irq handler */
	irqreturn_t	(*isr)(int irq, void *__res);
};

typedef u32 mtk_l_res_t;
#define L_RES_USER_CTRL		((mtk_l_res_t) 0)
#define L_RES_USER_RESERVE	((mtk_l_res_t) 1)
#define L_RES_USER_DATA		((mtk_l_res_t) 2)
#define L_RES_USER_MHCCIF	((mtk_l_res_t) 3)
#define L_RES_USER_PM		((mtk_l_res_t) 4)
#define L_RES_USER_MAX		((mtk_l_res_t) 255)

typedef u32 mtk_resume_reg_state_t;
#define PM_RESUME_REG_STATE_L3		((mtk_resume_reg_state_t) 0)
#define PM_RESUME_REG_STATE_L1		((mtk_resume_reg_state_t) 1)
#define PM_RESUME_REG_STATE_INIT	((mtk_resume_reg_state_t) 2)
#define PM_RESUME_REG_STATE_EXP	((mtk_resume_reg_state_t) 3)
#define PM_RESUME_REG_STATE_L2		((mtk_resume_reg_state_t) 4)
#define PM_RESUME_REG_STATE_L2_EXP	((mtk_resume_reg_state_t) 5)


#define PM_ENTITY_KEY_CTRL		((unsigned int)1)	/* Control Path */
#define PM_ENTITY_KEY_CTRL2		((unsigned int)2)	/* Control Path */
#define PM_ENTITY_KEY_DATA		((unsigned int)3)	/* Data Path */
#define PM_ENTITY_KEY_RESERVE0	((unsigned int)4)	/* Reserved */
#define PM_ENTITY_KEY_RESERVE1	((unsigned int)5)	/* Reserved */
#define PM_ENTITY_KEY_RESERVE2	((unsigned int)6)	/* Reserved */

#define PM_RESUME_HEADER	0x52450000
#define PM_SUSPEND_HEADER	0x53550000

#define mtk_pcie_set_msix_mask_all(pbase)	\
		REG_SET(MTK_IMASK_HOST_MSIX_CLR_GRP0_0(pbase), 0xFF000000)

/*
 * struct md_pm_entity - MTK PCIE device Power Management Entity
 * Use self defined suspend callbacks
 *instead of dev_pm_ops for each PM entity
 * @entity:	List of PM Entities.
 * @entity_pm_ops:	For each of entity,
 *there should be one entity related to it.
 * @shutdown:	For each of entity, an shutdown callback is realted to it.
 *             TODO: Should reuse CCCI Shutndow?
 * @suspend: Called by MTK PCI Driver's PM FWK,
 *before send PM_D3_Enter_REQ to device
 * @suspend_late: Called by MTK PCI Driver's PM FWK,
 *after get PM_D3_Enter_ACK from device
 * @resume_early: Called by MTK PCI Driver's PM FWK,
 *before send PM_D3_Exit_REQ to device
 * @resume: Called by MTK PCI Driver's PM FWK,
 *after get PM_D3_Exit_ACK from device
 * @key: Unique number represents one PM Entity
 * @power_state: TODO: used for debug purpose
 */
struct md_pm_entity {
	struct list_head entity;
	int (*suspend)(struct mtk_pci_dev *mtk_dev, void *entity_param);
	int (*suspend_late)(struct mtk_pci_dev *mtk_dev, void *entity_param);
	int (*resume_early)(struct mtk_pci_dev *mtk_dev, void *entity_param);
	int (*resume)(struct mtk_pci_dev *mtk_dev, void *entity_param);
	unsigned int	key;
	void	*entity_param;
#ifdef CONFIG_PM_SLEEP_DEBUG
	pm_message_t		power_state;
#endif
};

struct mtk_pci_dev {
	int                         irq;		/* irq allocated */
	void __iomem          *regs;		/* device memory/io */
	void __iomem          *mem[3];		/* device memory/io */
	/* memory/io resource start */
	u64                        resource_start[3];
	/* memory/io resource length */
	u64                        resource_len[3];

	/* device state */
	unsigned long    state[1];

	/* lock */
	spinlock_t          lock;

	int					irq_count;

	volatile u32		swint_flag;
	struct msix_entry	msix_entries[MTK_PCIE_IRQ_COUNT];
	int msix_merged;
	struct mtk_pci_isr_res *msix_res;


	dma_addr_t ep_data_buffer;	/* (in) EP data buffer for loopback*/
	volatile u32 dma_done;			/* (return) dma status */
	volatile u32 pme_event;			/* (return) receive pme event */

	/* Varible for MD remap buffer*/
	void *md_remap_buffer[PCIE_MD_REMAP_SET];
	volatile dma_addr_t md_remap_buffer_dma[PCIE_MD_REMAP_SET];

	/* Interrupt callback function */
	mtk_pci_intr_callback intr_callback[PCI_EXT_INTR_NUM];
	void *callback_param[PCI_EXT_INTR_NUM];

	/*mhccif interrupt callback function*/
	mtk_pci_sw_intr_callback mhccif_callback[PCI_EXT_INTR_NUM];
	u32 mhccif_bitmask[PCI_EXT_INTR_NUM];
	void *mhccif_callback_param[PCI_EXT_INTR_NUM];

	mtk_pci_event_callback event_callback;
	void *event_callback_param;

	struct pci_dev *pdev;
	struct mtk_pci_driver	*driver;

	/* Service task */
	struct work_struct service_task;

	struct mtk_addr_base base_addr;
	struct kobject pcie_kobj;
	struct workqueue_struct *pcie_isr_wq;
	//pcie_ext_info_t mtk_ext_info;
	char strirqbdf[64];
	void *ccci_md;

	/* Low Power Items */
	struct list_head md_pm_entities; //Please remember to init
	spinlock_t md_pm_lock;
	struct mutex md_pm_entity_mtx;
	/* PCIE L1.2 acquire/release Resource */
	atomic_t l_res_lock_count;
	u32 l_res_state;
	struct completion l_res_acquire;
	struct work_struct l_res_release_work;
	/* PCIE Suspend/Resume ACK */
	struct completion pm_suspend_ack;
	struct completion pm_resume_ack;
	struct completion pm_suspend_ack_sap;
	struct completion pm_resume_ack_sap;
	atomic_t md_pm_init_done;
	atomic_t md_pm_resumed;
#ifdef CONFIG_PM
	struct delayed_work pm_resume_check;
#endif	
	u32 pm_resume_check_count;
	struct delayed_work l_res_unlock_work;
	atomic_t pm_counter;

#ifndef M7X
	struct ccmni_ctl_block *ccmni_ctlb;
#endif

	bool mtk_pcie_probe_done;
	bool mhccif_init_done;
	bool hp_enable;

	u32 pm_enabled:1;
	atomic_t rgu_pci_irq_en;
};


extern int mtk_register_pci(void);
extern void mtk_unregister_pci(void);
struct pci_driver *mtk_pci_get_drv(void);
extern int mtk_setup_int(int type, int irq_count);
extern int mtk_setup_msix_merge(struct mtk_pci_dev *mtk_dev,int msix_count);



int mtk_pci_pm_entity_register(
	struct mtk_pci_dev *mtk_dev, struct md_pm_entity *pm_entity);
int mtk_pci_pm_entity_unregister(
	struct mtk_pci_dev *mtk_dev, struct md_pm_entity *pm_entity);

int mtk_pci_l_resource_lock(
	struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user);
int mtk_pci_l_resource_unlock(
	struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user);
void mtk_pci_l_resource_wait_complete(
	struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user);
/*
** Add a new interface for interrupt context
** This interface won't be blocking and just check wait status
** return value:
** @true, wait is completed
** @false, wait is in progress
*/
bool mtk_pci_l_resource_try_wait_complete(
	struct mtk_pci_dev *mtk_dev, mtk_l_res_t lock_user);
mtk_resume_reg_state_t mtk_dev_pci_check_resume_reg_state(struct mtk_pci_dev *mtk_dev);
int mtk_pcie_reinit(struct mtk_pci_dev *mtk_dev);

int mtk_pm_runtime_get(struct mtk_pci_dev *mtk_dev);
int mtk_pm_runtime_get_sync(struct mtk_pci_dev *mtk_dev);
int mtk_pm_runtime_put(struct mtk_pci_dev *mtk_dev);
int mtk_pm_runtime_put_sync(struct mtk_pci_dev *mtk_dev);

int mtk_pci_pm_init_late(struct mtk_pci_dev *mtk_dev);

void mtk_pci_pm_exp_detected(struct mtk_pci_dev *mtk_dev);
void mtk_pci_read_pcistate_regs(struct mtk_pci_dev *mtk_dev);

#endif /* __MTK_PCI_H__ */
